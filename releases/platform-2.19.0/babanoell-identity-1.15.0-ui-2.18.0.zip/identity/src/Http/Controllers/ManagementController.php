<?php
declare(strict_types=1);
namespace Babanoell\Auth\Http\Controllers;
use Babanoell\Auth\Administration\AdminAuthorization; use Babanoell\Auth\Administration\UserDirectory; use Babanoell\Auth\Administration\AccessDirectory; use Babanoell\Auth\Http\JsonResponse; use Babanoell\Auth\Http\Request; use Babanoell\Auth\Http\ResponseMapper; use RuntimeException; use Throwable;
final class ManagementController {
 public function __construct(private readonly \Closure$authFactory,private readonly \Closure$directoryFactory,private readonly \Closure$accessFactory){}
 public function roles(Request$r):JsonResponse{$a=$this->auth($r,'identity.roles.read');if($a instanceof JsonResponse)return$a;return new JsonResponse(200,['data'=>['items'=>$this->dir()->roles()]]);}
 public function permissions(Request$r):JsonResponse{$a=$this->auth($r,'identity.roles.read');if($a instanceof JsonResponse)return$a;return new JsonResponse(200,['data'=>['items'=>$this->dir()->permissions()]]);}
 public function notificationContact(Request $request):JsonResponse {
  $id=$request->json()['user_id']??'';
  if(!is_string($id)||!preg_match('/^[a-f0-9]{26}$/D',$id))return ResponseMapper::error(422,'invalid_user','شناسه کاربر معتبر نیست.');
  $user=$this->dir()->get($id);
  if($user===null||$user['status']!=='active'||!empty($user['disabled_at']))return ResponseMapper::error(404,'contact_unavailable','اطلاعات تماس فعال موجود نیست.');
  return new JsonResponse(200,['data'=>['contact'=>['id'=>$id,'display_name'=>$user['display_name'],'mobile'=>$user['mobile']]]]);
 }
 public function planPolicy(Request $request):JsonResponse {
  $id=$request->json()['user_id']??'';
  if(!is_string($id)||!preg_match('/^[a-f0-9]{26}$/D',$id))return ResponseMapper::error(422,'invalid_user','شناسه کاربر معتبر نیست.');
  $user=$this->dir()->get($id);
  if($user===null||$user['status']!=='active'||!empty($user['disabled_at']))return ResponseMapper::error(404,'user_unavailable','حساب فعال موجود نیست.');
  $roles=$user['roles'];$restricted=in_array('acceptor',$roles,true)&&!array_intersect(['super_admin','admin','operations_expert','finance_expert'],$roles);
  return new JsonResponse(200,['data'=>['policy'=>['user_id'=>$id,'plan_exclusions_apply'=>$restricted]]]);
 }
 public function users(Request$r):JsonResponse{$a=$this->auth($r,'identity.users.read');if($a instanceof JsonResponse)return$a;$q=$r->queryParams();$result=$this->dir()->listUsers((int)($q['page']??1),(int)($q['per_page']??25),trim((string)($q['q']??'')));return new JsonResponse(200,['data'=>$result,'meta'=>['pagination'=>\Babanoell\Auth\Http\Pagination::fromResult($result)]]);}
 public function createUser(Request$r):JsonResponse{$a=$this->auth($r,'identity.users.manage');if($a instanceof JsonResponse)return$a;try{return new JsonResponse(201,['data'=>['user'=>$this->dir()->create($r->json(),(string)$a['user_id'])]]);}catch(RuntimeException$e){return ResponseMapper::error(422,'validation_failed',$e->getMessage());}}
 public function activatePartner(Request$r):JsonResponse{
  if(\Babanoell\Auth\Platform\RequestContext::callerService()!=='partners')return ResponseMapper::error(403,'service_access_denied','این مسیر فقط برای سرویس شرکا مجاز است.');
  $a=$this->auth($r,'partners.cooperation.manage');if($a instanceof JsonResponse)return$a;
  try{return new JsonResponse(200,['data'=>['activation'=>$this->dir()->activatePartner($r->json(),(string)$a['user_id'])]]);}
  catch(RuntimeException$e){if($e->getMessage()==='partner_account_inactive')return ResponseMapper::error(409,'partner_account_inactive','حساب متقاضی فعال یا قابل دریافت نیست.');return ResponseMapper::error($e->getMessage()==='partner_activation_conflict'?409:422,'partner_activation_failed',$e->getMessage());}
 }
 public function replaceRoles(Request$r,string$uid):JsonResponse{$a=$this->auth($r,'identity.users.manage');if($a instanceof JsonResponse)return$a;try{$b=$r->json();return new JsonResponse(200,['data'=>['user'=>$this->dir()->replaceRoles($uid,is_array($b['roles']??null)?$b['roles']:[],(string)$a['user_id'])]]);}catch(RuntimeException$e){return ResponseMapper::error(422,'validation_failed',$e->getMessage());}}
 public function status(Request$r,string$uid):JsonResponse{$a=$this->auth($r,'identity.users.manage');if($a instanceof JsonResponse)return$a;try{$b=$r->json();return new JsonResponse(200,['data'=>['user'=>$this->dir()->setStatus($uid,strtolower(trim((string)($b['status']??''))),(string)$a['user_id'])]]);}catch(RuntimeException$e){return ResponseMapper::error(422,'validation_failed',$e->getMessage());}}
 public function organizations(Request$r):JsonResponse{$a=$this->auth($r,'identity.memberships.read');if($a instanceof JsonResponse)return$a;return new JsonResponse(200,['data'=>$this->accessDir()->organizations()]);}
 public function createOrganization(Request$r):JsonResponse{$a=$this->auth($r,'identity.memberships.manage');if($a instanceof JsonResponse)return$a;try{return new JsonResponse(201,['data'=>['organization'=>$this->accessDir()->createOrganization($r->json(),(string)$a['user_id'])]]);}catch(RuntimeException$e){return ResponseMapper::error(422,'validation_failed',$e->getMessage());}}
 public function branches(Request$r,string$org=''):JsonResponse{$a=$this->auth($r,'identity.memberships.read');if($a instanceof JsonResponse)return$a;return new JsonResponse(200,['data'=>$this->accessDir()->branches($org)]);}
 public function createBranch(Request$r,string$org):JsonResponse{$a=$this->auth($r,'identity.memberships.manage');if($a instanceof JsonResponse)return$a;try{return new JsonResponse(201,['data'=>['branch'=>$this->accessDir()->createBranch($org,$r->json(),(string)$a['user_id'])]]);}catch(RuntimeException$e){return ResponseMapper::error(422,'validation_failed',$e->getMessage());}}
 public function access(Request$r,string$uid):JsonResponse{$a=$this->auth($r,'identity.memberships.read');if($a instanceof JsonResponse)return$a;return new JsonResponse(200,['data'=>$this->accessDir()->userAccess($uid)]);}
 public function memberships(Request$r,string$uid):JsonResponse{$a=$this->auth($r,'identity.memberships.manage');if($a instanceof JsonResponse)return$a;try{$b=$r->json();return new JsonResponse(200,['data'=>$this->accessDir()->replaceMemberships($uid,is_array($b['memberships']??null)?$b['memberships']:[],(string)$a['user_id'])]);}catch(RuntimeException$e){return ResponseMapper::error(422,'validation_failed',$e->getMessage());}}
 public function grants(Request$r,string$uid):JsonResponse{$a=$this->auth($r,'identity.memberships.manage');if($a instanceof JsonResponse)return$a;try{$b=$r->json();return new JsonResponse(200,['data'=>$this->accessDir()->replaceGrants($uid,is_array($b['grants']??null)?$b['grants']:[],(string)$a['user_id'])]);}catch(RuntimeException$e){return ResponseMapper::error(422,'validation_failed',$e->getMessage());}}
 private function dir():UserDirectory{$f=$this->directoryFactory;return$f();} private function accessDir():AccessDirectory{$f=$this->accessFactory;return$f();}
 private function auth(Request$r,string$p):array|JsonResponse{try{$f=$this->authFactory;$x=$f()->requirePermission($r,$p);}catch(Throwable){return ResponseMapper::error(503,'auth_unavailable','مدیریت دسترسی موقتاً در دسترس نیست.');}return$x['ok']?$x:ResponseMapper::error((int)$x['status'],(string)$x['code'],(string)$x['message']);}
}
