<?php
declare(strict_types=1);
return ['service'=>'loans','version'=>'1.6.0','ui'=>'1.6.0','phase'=>'3'];
