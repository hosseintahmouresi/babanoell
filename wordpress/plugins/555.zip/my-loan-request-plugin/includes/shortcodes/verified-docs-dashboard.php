<?php
if (!defined('ABSPATH')) {
    exit;
}

add_shortcode('mlr_verified_docs_dashboard', 'mlr_verified_docs_dashboard_shortcode');

function mlr_verified_docs_dashboard_shortcode() {
    // Check if user is logged in and has the 'bank' role
    if (!is_user_logged_in()) {
        return '<p>برای دسترسی به این بخش، لطفاً ابتدا وارد شوید.</p>';
    }

    $current_user = wp_get_current_user();
    if (!in_array('bank', (array) $current_user->roles)) {
        return '<p>شما دسترسی لازم برای مشاهده این صفحه را ندارید.</p>';
    }

    // Enqueue necessary scripts and styles
    wp_enqueue_style('dashicons');
    wp_enqueue_style('persian-datepicker-style', 'https://unpkg.com/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css');
    wp_enqueue_script('persian-date', 'https://unpkg.com/persian-date@1.1.0/dist/persian-date.min.js', [], '1.1.0', true);
    wp_enqueue_script('persian-datepicker-script', 'https://unpkg.com/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js', ['jquery', 'persian-date'], '1.2.0', true);
    
    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], '6.7.0');
    wp_enqueue_style('mlr-bank-expert-dashboard-css', MLR_PLUGIN_URL . 'assets/css/bank-expert-dashboard.css', [], '1.0.1');

    // Enqueue the new specific JS for this dashboard
    wp_enqueue_script('mlr-verified-docs-dashboard-js', MLR_PLUGIN_URL . 'assets/js/verified-docs-dashboard.js', ['jquery'], '1.0.2', true);
    wp_localize_script('mlr-verified-docs-dashboard-js', 'mlr_verified_ajax_obj', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
    ]);
    
    $unique_id = uniqid('mlr-verified-dashboard-');

    ob_start();
    ?>
    <div class="mlr-glass-dashboard mlr-user-requests" id="<?php echo esc_attr($unique_id); ?>">
        <div class="mlr-glass-blob blob-1"></div>
        <div class="mlr-glass-blob blob-2"></div>
        
        <div class="mlr-dashboard-wrapper">
            <h2 class="mlr-dashboard-title"><span class="dashicons dashicons-yes-alt"></span> داشبورد تأیید مدارک</h2>
        
            <div class="mlr-glass-card mlr-filter-section">
                <div class="mlr-filter-form">
                    <button type="button" class="mlr-btn mlr-btn-secondary" id="mlr-export-excel">خروجی اکسل</button>
                    <input type="text" id="mlr-search" class="mlr-glass-input" placeholder="کدملی، متقاضی، شماره موبایل، شناسه">
                    <input type="text" class="jalali-datepicker mlr-glass-input" id="mlr-date-from" placeholder="از تاریخ..." autocomplete="off">
                    <input type="text" class="jalali-datepicker mlr-glass-input" id="mlr-date-to" placeholder="تا تاریخ..." autocomplete="off">
                    <button type="button" id="mlr-filter-btn" class="mlr-btn mlr-btn-primary">فیلتر</button>
                </div>
            </div>

            <div class="mlr-glass-card mlr-table-section">
                <div class="mlr-table-responsive-wrapper">
                    <table class="mlr-requests-table" id="mlr-requests-table">
                        <thead>
                            <tr>
                                <th>شناسه</th>
                                <th>متقاضی</th>
                                <th>شماره موبایل</th>
                                <th>کد ملی</th>
                                <th>مبلغ (ریال)</th>
                                <th>طرح</th>
                                <th>وضعیت</th>
                                <th>تاریخ تأیید مدارک</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody id="mlr-requests-table-body" class="mlr-requests-table-body">
                            <tr><td colspan="9" style="text-align: center; padding: 20px;">در حال بارگذاری درخواست‌ها...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="mlr-modal-overlay" style="display:none;"></div>
        <div class="mlr-modal" style="display:none;">
            <button class="mlr-modal-close">&times;</button>
            <div class="mlr-modal-content"></div>
        </div>
    </div>
    
    <script>
    (function($){
        var $wrap = $('#<?php echo esc_js($unique_id); ?>');
        if (!$wrap.length) return;
        $wrap.on('click', '#mlr-export-excel', function(){
            var search = $wrap.find('#mlr-search').val() || '';
            var date_from = $wrap.find('#mlr-date-from').val() || '';
            var date_to = $wrap.find('#mlr-date-to').val() || '';
            var url = mlr_verified_ajax_obj.ajax_url + '?action=mlr_export_bank_expert_requests'
                + '&nonce=' + encodeURIComponent(mlr_verified_ajax_obj.nonce)
                + '&status=' + encodeURIComponent('تأیید مدارک')
                + '&search=' + encodeURIComponent(search)
                + '&date_from=' + encodeURIComponent(date_from)
                + '&date_to=' + encodeURIComponent(date_to);
            window.location.href = url;
        });
    })(jQuery);
    </script>
    <?php
    return ob_get_clean();
}