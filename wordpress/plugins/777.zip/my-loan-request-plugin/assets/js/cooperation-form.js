jQuery(document).ready(function($) {
    const form = $('#mlr-cooperation-form-main');
    if (form.length === 0) return;

    form.on('submit', function(e) {
        e.preventDefault();
        const submitBtn = form.find('.mlr-btn');
        const formData = new FormData(this);
        formData.append('action', 'mlr_submit_cooperation_request');
        formData.append('_wpnonce', mlr_coop_ajax.nonce);

        submitBtn.prop('disabled', true).text('در حال ارسال...');
        
        $.ajax({
            url: mlr_coop_ajax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
        }).done(function(response) {
            if (response.success) {
                showSubmissionModal('success', response.data.message);
                form[0].reset();
            } else {
                showSubmissionModal('error', response.data.message || 'خطای ناشناخته رخ داد.');
            }
        }).fail(function() {
            showSubmissionModal('error', 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کرده و مجدداً تلاش نمایید.');
        }).always(function() {
            submitBtn.prop('disabled', false).text('ارسال درخواست');
        });
    });

    function showSubmissionModal(type, message) {
        $('.mlr-submission-overlay').fadeIn(200);
        if (type === 'success') {
            $('#mlr-success-modal').find('p').html(message);
            $('#mlr-success-modal').fadeIn(200);
        } else {
            $('#mlr-error-modal').find('#mlr-error-modal-message').html(message);
            $('#mlr-error-modal').fadeIn(200);
        }
    }

    // Close modals
    $('.mlr-submission-overlay, #mlr-close-error-modal-btn, #mlr-close-success-modal-btn').on('click', function() {
        $('.mlr-submission-overlay, .mlr-submission-modal').fadeOut(200);
    });
});