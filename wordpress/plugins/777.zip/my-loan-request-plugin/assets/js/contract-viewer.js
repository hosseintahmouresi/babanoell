jQuery(document).ready(function($) {
    const signatureSection = $('.mlr-contract-signature-section');
    if (signatureSection.length === 0) return; // Only run if signature section exists

    const requestToken = signatureSection.data('token');
    const initialView = $('#mlr-sign-initial-view');
    const otpView = $('#mlr-sign-otp-view');
    const initiateBtn = $('#mlr-initiate-sign-btn');
    const otpInput = $('#mlr-otp-code');
    const verifyBtn = $('#mlr-verify-otp-btn');
    const timerDisplay = $('#mlr-otp-timer');
    const countdownSpan = $('#mlr-timer-countdown');
    const resendBtn = $('#mlr-resend-otp-btn');
    const messageDiv = $('#mlr-sign-message');
    let timerInterval = null;
    let cooldownSeconds = mlr_contract_ajax.resend_cooldown || 60;

    // 1. Initiate Signature Process (Send OTP)
    initiateBtn.on('click', function() {
        sendOtp();
    });

    // 2. Resend OTP
    resendBtn.on('click', function() {
        if ($(this).is(':disabled')) return;
        sendOtp();
    });

    // 3. Verify OTP
    verifyBtn.on('click', function() {
        verifyOtp();
    });

    // Allow Enter key to trigger verification
    otpInput.on('keyup', function(e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            verifyOtp();
        }
        // Basic input filtering for digits only
        this.value = this.value.replace(/[^0-9]/g, '');
    });


    // --- Helper Functions ---

    function sendOtp() {
        setLoadingState(true, 'در حال ارسال کد...');
        $.ajax({
            url: mlr_contract_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_send_cooperation_otp',
                nonce: mlr_contract_ajax.send_otp_nonce,
                request_token: requestToken
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showMessage('success', response.message || 'کد تایید ارسال شد.');
                    initialView.hide();
                    otpView.show();
                    startTimer(response.data.cooldown || cooldownSeconds);
                } else {
                    showMessage('error', response.data.message || 'خطا در ارسال کد.');
                    setLoadingState(false); // Only reset if staying on initial view or resend fails
                }
            },
            error: function() {
                showMessage('error', 'خطای ارتباط با سرور هنگام ارسال کد.');
                setLoadingState(false);
            }
            // No 'always' here, keep loading state until success/error message shown
        });
    }

    function verifyOtp() {
        const otpCode = otpInput.val();
        if (otpCode.length !== 5) {
            showMessage('error', 'کد تایید باید ۵ رقم باشد.');
            return;
        }

        setLoadingState(true, 'در حال بررسی کد...');
        stopTimer(); // Stop timer during verification

        $.ajax({
            url: mlr_contract_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_verify_cooperation_otp',
                nonce: mlr_contract_ajax.verify_otp_nonce,
                request_token: requestToken,
                otp_code: otpCode
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showMessage('success', response.message || 'قرارداد با موفقیت امضا شد.');
                    // Hide OTP view, maybe show a success message permanently, or reload
                    otpView.hide();
                    // Optional: Reload after a delay to show the "Signed" view
                     setTimeout(function() { window.location.reload(); }, 2000);
                } else {
                    showMessage('error', response.data.message || 'خطا در تایید کد.');
                    setLoadingState(false); // Reset button etc.
                    // Optionally restart timer or enable resend immediately on failure
                    resendBtn.prop('disabled', false); // Allow resend after failed attempt
                    timerDisplay.hide();
                }
            },
            error: function() {
                showMessage('error', 'خطای ارتباط با سرور هنگام تایید کد.');
                setLoadingState(false);
                resendBtn.prop('disabled', false);
                timerDisplay.hide();
            }
             // No 'always' here to avoid conflicts with success reload
        });
    }

    function startTimer(seconds) {
        stopTimer(); // Clear any existing timer
        let remaining = seconds;
        countdownSpan.text(remaining);
        timerDisplay.show();
        resendBtn.prop('disabled', true);
        otpInput.prop('disabled', false);
        verifyBtn.prop('disabled', false);

        timerInterval = setInterval(function() {
            remaining--;
            countdownSpan.text(remaining);
            if (remaining <= 0) {
                stopTimer();
                timerDisplay.hide();
                resendBtn.prop('disabled', false);
                otpInput.prop('disabled', true).val(''); // Clear and disable input
                verifyBtn.prop('disabled', true);
                showMessage('info', 'زمان ورود کد به پایان رسید. برای دریافت مجدد، روی دکمه ارسال مجدد کلیک کنید.');
            }
        }, 1000);
    }

    function stopTimer() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
    }

    function setLoadingState(isLoading, message = '') {
        if (isLoading) {
            messageDiv.removeClass('error success info').addClass('loading').text(message || 'لطفا صبر کنید...').slideDown();
            initiateBtn.prop('disabled', true);
            verifyBtn.prop('disabled', true);
            resendBtn.prop('disabled', true);
            otpInput.prop('disabled', true);
        } else {
            // Only re-enable buttons that should be active based on state
             if(initialView.is(':visible')){
                 initiateBtn.prop('disabled', false).text('امضای دیجیتال قرارداد');
             }
             if(otpView.is(':visible') && !timerInterval){ // If timer expired or verification failed
                 resendBtn.prop('disabled', false);
                 verifyBtn.prop('disabled', true); // Keep verify disabled until new OTP requested
                 otpInput.prop('disabled', true);
             } else if (otpView.is(':visible') && timerInterval) { // If timer is running
                  verifyBtn.prop('disabled', false);
                  otpInput.prop('disabled', false);
                  resendBtn.prop('disabled', true); // Keep resend disabled while timer runs
             }
             // Let the showMessage function handle hiding the loading message
        }
    }

    function showMessage(type, text) {
        messageDiv.removeClass('loading error success info').addClass(type).html(text).slideDown();
        // Auto-hide info/error messages after a delay?
        if (type === 'error' || type === 'info') {
            setTimeout(function() {
                if (messageDiv.hasClass(type)) { // Check if it hasn't changed
                    messageDiv.slideUp();
                }
            }, 5000); // Hide after 5 seconds
        }
        if (type !== 'loading') {
             // If not loading, ensure buttons are in correct state (e.g., after error)
             setLoadingState(false);
        }
    }

});