jQuery(document).ready(function($) {

    // =========================================================
    // SELF-HEALING MODAL SETUP
    // =========================================================
    if ($('#mlr-global-modal-overlay').length === 0) {
        $('body').append(`
            <div id="mlr-global-modal-overlay" class="mlr-modal-overlay" style="display:none;"></div>
            <div id="mlr-global-modal" class="mlr-modal" style="display:none;">
                <button class="mlr-modal-close">&times;</button>
                <div class="mlr-modal-content"></div>
            </div>
        `);
        $(document).off('click.mlrModalClose').on('click.mlrModalClose', '#mlr-global-modal-overlay, .mlr-modal-close', function() {
            $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200, function(){ $('body').removeClass('mlr-modal-open'); });
        });
    }

    function mlrIsBodyTransformed() {
        try { var t = window.getComputedStyle(document.body).transform; return (t && t !== 'none'); } catch (e) { return false; }
    }

    function mlrPositionOpenModal($modal, $overlay) {
        var needsAbsolute = mlrIsBodyTransformed();
        var update = function() {
            var scrollTop = $(window).scrollTop();
            var winH = $(window).height();
            var docH = $(document).height();
            if (needsAbsolute) {
                $overlay.css({ position: 'absolute', top: scrollTop, left: 0, width: '100%', height: docH });
                $modal.css({ position: 'absolute', top: (scrollTop + (winH / 2)), left: '50%' });
            } else {
                $overlay.css({ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%' });
                $modal.css({ position: 'fixed', top: '50%', left: '50%' });
            }
        };
        // $modal.css('display', 'flex'); // Handled in showDetailsModal
        $(window).off('scroll.mlrModalPos resize.mlrModalPos').on('scroll.mlrModalPos resize.mlrModalPos', function() {
            if ($overlay.is(':visible') && $modal.is(':visible')) { update(); }
        });
        update();
    }

    // --- Initialize Jalali Datepicker ---
    try {
        if ($.fn.persianDatepicker && $('.jalali-datepicker').length > 0) {
            $('.jalali-datepicker').persianDatepicker({ format: 'YYYY/MM/DD', autoClose: true });
        }
    } catch (e) { console.log("Notice: Persian Datepicker init skipped."); }

    // =========================================================
    // UI HELPERS (Tabs, Accordions, Files)
    // =========================================================
    function mlrInitDocsCategoryTabs(context) {
        var $ctx = context ? $(context) : $(document);
        $ctx.find('.mlr-docs-card').each(function() {
            var $card = $(this);
            var $btns = $card.find('.mlr-doc-cat-btn');
            var $sections = $card.find('.mlr-doc-cat-section');
            if ($btns.length === 0 || $sections.length === 0) return;

            var defaultCat = $card.attr('data-default-cat') || $btns.first().data('cat');
            if (!defaultCat) defaultCat = $btns.first().data('cat');

            $btns.removeClass('is-active');
            $sections.hide();

            $btns.filter('[data-cat="' + defaultCat + '"]').addClass('is-active');
            $sections.filter('[data-cat="' + defaultCat + '"]').show();
        });
    }

    function mlrInitAccordions(context) {
        var $ctx = context ? $(context) : $(document);
        $ctx.find('.mlr-acc-content, .mlr-glass-acc-content').each(function(){
            if (!$(this).hasClass('is-open')) $(this).hide();
        });
    }

    // Event Delegation
    $(document).on('click', '.mlr-doc-cat-btn', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $card = $btn.closest('.mlr-docs-card');
        var cat = $btn.data('cat');
        $card.find('.mlr-doc-cat-btn').removeClass('is-active');
        $btn.addClass('is-active');
        $card.find('.mlr-doc-cat-section').hide();
        $card.find('.mlr-doc-cat-section[data-cat="' + cat + '"]').show();
    });

    $(document).on('click', '.mlr-acc-btn, .mlr-glass-acc-btn', function(e){
        e.preventDefault();
        var $btn = $(this);
        var targetId = $btn.attr('data-target');
        if (!targetId) return;
        var $content = $('#' + targetId);
        if ($content.length === 0) return;
        if ($content.is(':visible')) {
            $content.slideUp(150);
            $btn.removeClass('is-open');
        } else {
            $content.slideDown(150);
            $btn.addClass('is-open');
        }
    });

    $(document).on('click', '.mlr-view-file-btn', function(e) {
        var href = $(this).attr('href');
        if (!href) return;
        e.preventDefault();
        window.open(href, '_blank', 'noopener');
    });

    // --- Generic Dashboard Logic ---
    $('.mlr-user-requests[id^="mlr-expert-dashboard-"]').each(function() {
        var $container = $(this);
        var config = $container.data('config') || {};
        var ajaxAction = config.ajax_action || 'mlr_get_bank_expert_requests';
        var exportAction = config.export_action || 'mlr_export_bank_expert_requests';
        var exportStatus = config.export_status || 'تأیید کارشناس';
        var nonce = config.nonce || '';
        var ajaxUrl = config.ajax_url || '';

        function loadRequests() {
            var search = $container.find('#mlr-search').val();
            var dateFrom = $container.find('#mlr-date-from').val();
            var dateTo = $container.find('#mlr-date-to').val();
            var tableBody = $container.find('#mlr-requests-table-body');

            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: ajaxAction,
                    nonce: nonce,
                    search: search,
                    date_from: dateFrom,
                    date_to: dateTo
                },
                beforeSend: function() {
                    tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px;">در حال بارگذاری...</td></tr>');
                },
                success: function(response) {
                    if (response.success) {
                        tableBody.html(response.data.html);
                    } else {
                        tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">' + (response.data.message || 'خطا در دریافت اطلاعات.') + '</td></tr>');
                    }
                },
                error: function() {
                    tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">خطا در ارتباط با سرور.</td></tr>');
                }
            });
        }

        function showDetailsModal(requestId) {
            const modalOverlay = $('#mlr-global-modal-overlay');
            const modal = $('#mlr-global-modal');
            const modalContent = modal.find('.mlr-modal-content');

            if (!requestId) return;

            $('body').addClass('mlr-modal-open');
            modalOverlay.fadeIn(200);
            modal.css('display', 'flex').hide().fadeIn(200); // Fixed: Hide first to allow fadeIn animation
            mlrPositionOpenModal(modal, modalOverlay);
            modalContent.html('<p style="text-align:center; padding: 40px;">در حال بارگذاری جزئیات...</p>');

            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    action: 'mlr_get_frontend_request_details',
                    nonce: nonce,
                    request_id: requestId
                },
                success: function(response) {
                    if (response.success) {
                        modalContent.html(response.data.html);
                        // Add specific class to form for targeting
                        modalContent.find('.mlr-bank-expert-action-form').addClass('mlr-origin-expert-dashboard').data('dashboard-id', $container.attr('id'));
                        
                        // Initialize UI components
                        mlrInitDocsCategoryTabs(modalContent);
                        mlrInitAccordions(modalContent);
                        
                        if ($.fn.persianDatepicker) {
                             modalContent.find('.jalali-datepicker').persianDatepicker({ format: 'YYYY/MM/DD', autoClose: true });
                        }
                    } else {
                        modalContent.html('<p style="color:red; text-align:center; padding: 40px;">' + (response.data.message || 'خطا در دریافت جزئیات.') + '</p>');
                    }
                },
                error: function() { modalContent.html('<p class="mlr-error">خطا در ارتباط با سرور.</p>'); }
            });
        }

        // Initial Load
        loadRequests();

        // Bind Events
        $container.on('click', '#mlr-filter-btn', loadRequests);
        $container.on('keyup', '#mlr-search', function(e) { if (e.key === 'Enter') loadRequests(); });
        
        $container.on('click', '#mlr-requests-table-body tr', function(e) {
            if (!$(e.target).closest('button, a, input, select, textarea').length) {
                showDetailsModal($(this).data('id'));
            }
        });

        $container.on('click', '#mlr-export-excel', function() {
            var search = $container.find('#mlr-search').val() || '';
            var dateFrom = $container.find('#mlr-date-from').val() || '';
            var dateTo = $container.find('#mlr-date-to').val() || '';
            var url = ajaxUrl + '?action=' + exportAction + '&nonce=' + encodeURIComponent(nonce) + '&status=' + encodeURIComponent(exportStatus) + '&search=' + encodeURIComponent(search) + '&date_from=' + encodeURIComponent(dateFrom) + '&date_to=' + encodeURIComponent(dateTo);
            window.location.href = url;
        });
    });

    // --- Shared Action Form Submission ---
    $(document).on('submit', '.mlr-bank-expert-action-form.mlr-origin-expert-dashboard', function(e) {
        e.preventDefault();
        var form = $(this);
        var dashboardId = form.data('dashboard-id');
        var $dashboard = $('#' + dashboardId);
        var config = $dashboard.length ? $dashboard.data('config') : { ajax_url: mlr_expert_ajax.ajax_url, nonce: mlr_expert_ajax.nonce }; // Fallback

        var button = form.find('button[type="submit"]');
        var messageDiv = form.find('.mlr-action-message');
        var formData = {
            action: 'mlr_submit_bank_expert_review',
            nonce: config.nonce,
            request_id: form.find('input[name="request_id"]').val(),
            new_status: form.find('select[name="new_status"]').val(),
            comment_text: form.find('textarea[name="comment_text"]').val()
        };

        $.ajax({
            url: config.ajax_url,
            type: 'POST',
            data: formData,
            beforeSend: function() {
                button.prop('disabled', true).text('در حال ثبت...');
                messageDiv.removeClass().addClass('mlr-action-message loading').text('لطفا صبر کنید...').slideDown();
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass().addClass('mlr-action-message success').text(response.data.message);
                    setTimeout(function() {
                        $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200, function(){ $('body').removeClass('mlr-modal-open'); });
                        if ($dashboard.length) $dashboard.find('#mlr-filter-btn').click(); // Reload list
                    }, 2000);
                } else {
                    messageDiv.removeClass().addClass('mlr-action-message error').text(response.data.message || 'خطای ناشناخته.');
                    button.prop('disabled', false).text('ثبت بررسی');
                }
            },
            error: function() {
                messageDiv.removeClass().addClass('mlr-action-message error').text('خطا در ارتباط با سرور.');
                button.prop('disabled', false).text('ثبت بررسی');
            }
        });
    });
});