<?php
if (!defined('ABSPATH')) {
    exit;
}

// AJAX action for sending OTP
add_action('wp_ajax_mlr_send_cooperation_otp', 'mlr_send_cooperation_otp_callback');
add_action('wp_ajax_nopriv_mlr_send_cooperation_otp', 'mlr_send_cooperation_otp_callback'); // Allow logged-out if needed, adjust nonce check below

function mlr_send_cooperation_otp_callback() {
    // Nonce check should match the JS nonce name
    check_ajax_referer('mlr_send_cooperation_otp_nonce', 'nonce');

    $token = isset($_POST['request_token']) ? sanitize_text_field($_POST['request_token']) : '';
    if (empty($token)) {
        wp_send_json_error(['message' => 'شناسه قرارداد نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cooperation_requests';
    $request = $wpdb->get_row($wpdb->prepare("SELECT id, data, otp_expires_at, contract_signed_status FROM $table_name WHERE contract_token = %s", $token));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست همکاری یافت نشد.']);
        return;
    }

    if ($request->contract_signed_status === 'signed') {
         wp_send_json_error(['message' => 'این قرارداد قبلا امضا شده است.']);
        return;
    }

    // Check cooldown period (e.g., 60 seconds)
    if ($request->otp_expires_at && strtotime($request->otp_expires_at) > time()) {
        $remaining_time = strtotime($request->otp_expires_at) - time();
        wp_send_json_error(['message' => "لطفا {$remaining_time} ثانیه دیگر برای ارسال مجدد کد صبر کنید."]);
        return;
    }

    // Get OTP SMS settings
    $sms_options = get_option('mlr_sms_settings', []);
    $otp_settings = $sms_options['otp_settings']['cooperation_sign'] ?? [];

    if (empty($otp_settings['enabled']) || empty($otp_settings['bodyId'])) {
        mlr_log("OTP Send Error: OTP SMS for cooperation signing is disabled or Body ID is missing. Request ID: {$request->id}");
        wp_send_json_error(['message' => 'امکان ارسال کد تایید در حال حاضر وجود ندارد.']);
        return;
    }

    // Generate 5-digit OTP
    $otp_code = rand(10000, 99999);
    $otp_expiry_time = time() + 60; // 60 seconds expiry

    // Store OTP (consider hashing for security) and expiry time
    // For simplicity, storing plain text here. Hashing is recommended for production.
    $updated = $wpdb->update(
        $table_name,
        [
            'otp_code'       => $otp_code, // Store plain OTP (or hash: wp_hash_password($otp_code))
            'otp_expires_at' => date('Y-m-d H:i:s', $otp_expiry_time)
        ],
        ['id' => $request->id],
        ['%s', '%s'], // Format for OTP code and datetime
        ['%d']
    );

    if ($updated === false) {
        mlr_log("OTP DB Error: Failed to save OTP code for request ID {$request->id}. Error: " . $wpdb->last_error);
        wp_send_json_error(['message' => 'خطا در ذخیره سازی کد تایید.']);
        return;
    }

    // Get recipient mobile number
    $request_data = json_decode($request->data, true);
    if (!is_array($request_data)) $request_data = [];
    $mobile_number = $request_data['mobile_number'] ?? null;

    if (!$mobile_number || !preg_match('/^09\d{9}$/', $mobile_number)) {
        mlr_log("OTP SMS Error: Invalid mobile number for request ID {$request->id}. Found: " . ($mobile_number ?? 'NULL'));
        wp_send_json_error(['message' => 'شماره موبایل معتبری برای ارسال کد یافت نشد.']);
        return;
    }

    // Prepare variables for SMS pattern (MeliPayamak often uses %param1%, etc.)
    // We replace our internal placeholder `[[otp_code]]` just before sending.
    // Assuming the MeliPayamak pattern expects the OTP code as the first parameter.
    $sms_variables = [$otp_code];

    // You might need to add applicant name if your template uses it, e.g., %param2%
    // $applicant_name = ($request->request_type === 'individual') ? ($request_data['store_owner_name'] ?? '') : ($request_data['contact_person'] ?? '');
    // $sms_variables[] = $applicant_name;


    // Send OTP via SMS
    $sms_provider = new MLR_MeliPayamak_Provider();
    $result = $sms_provider->send_otp_pattern($mobile_number, $otp_settings['bodyId'], $sms_variables);

    if (is_wp_error($result)) {
        mlr_log("OTP SMS Send Error for request ID {$request->id}: " . $result->get_error_message());
        wp_send_json_error(['message' => 'خطا در ارسال پیامک کد تایید: ' . $result->get_error_message()]);
    } else {
        mlr_log("OTP SMS Sent Successfully for request ID {$request->id}. Mobile: {$mobile_number}");
        wp_send_json_success(['message' => 'کد تایید به شماره موبایل شما ارسال شد.', 'cooldown' => 60]);
    }
}


// AJAX action for verifying OTP
add_action('wp_ajax_mlr_verify_cooperation_otp', 'mlr_verify_cooperation_otp_callback');
add_action('wp_ajax_nopriv_mlr_verify_cooperation_otp', 'mlr_verify_cooperation_otp_callback'); // Allow logged-out if needed

function mlr_verify_cooperation_otp_callback() {
    check_ajax_referer('mlr_verify_cooperation_otp_nonce', 'nonce');

    $token = isset($_POST['request_token']) ? sanitize_text_field($_POST['request_token']) : '';
    $otp_entered = isset($_POST['otp_code']) ? preg_replace('/[^0-9]/', '', $_POST['otp_code']) : ''; // Only digits

    if (empty($token) || strlen($otp_entered) !== 5) {
        wp_send_json_error(['message' => 'اطلاعات ارسال شده نامعتبر است (توکن یا فرمت کد).']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cooperation_requests';
    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT id, otp_code, otp_expires_at, contract_signed_status FROM $table_name WHERE contract_token = %s", $token
    ));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست همکاری یافت نشد.']);
        return;
    }

     if ($request->contract_signed_status === 'signed') {
         wp_send_json_error(['message' => 'این قرارداد قبلا امضا شده است.']);
        return;
    }

    // Check if OTP has expired
    if (!$request->otp_expires_at || strtotime($request->otp_expires_at) < time()) {
        // Clear expired OTP from DB for security
        $wpdb->update($table_name, ['otp_code' => null, 'otp_expires_at' => null], ['id' => $request->id]);
        wp_send_json_error(['message' => 'کد تایید منقضی شده است. لطفا کد جدید دریافت کنید.']);
        return;
    }

    // Compare entered OTP with stored OTP
    // If using hashing: if (!wp_check_password($otp_entered, $request->otp_code)) { ... }
    if ($otp_entered !== $request->otp_code) {
        wp_send_json_error(['message' => 'کد تایید وارد شده صحیح نمی‌باشد.']);
        return;
    }

    // OTP is correct and not expired, update contract status
    $signed_time = current_time('mysql');
    $expiry_time_timestamp = strtotime('+1 year', strtotime($signed_time));
    $expiry_time_mysql = date('Y-m-d H:i:s', $expiry_time_timestamp);

    $updated = $wpdb->update(
        $table_name,
        [
            'contract_signed_status' => 'signed',
            'contract_signed_at'     => $signed_time,
            'contract_expires_at'    => $expiry_time_mysql,
            'otp_code'               => null, // Clear OTP after successful verification
            'otp_expires_at'         => null
        ],
        ['id' => $request->id],
        ['%s', '%s', '%s', '%s', '%s'], // Data formats
        ['%d']                          // Where format
    );

    if ($updated === false) {
         mlr_log("OTP Verify DB Error: Failed to update contract status for request ID {$request->id}. Error: " . $wpdb->last_error);
        wp_send_json_error(['message' => 'خطا در ثبت امضای قرارداد.']);
    } else {
         mlr_log("Contract Signed Successfully for request ID {$request->id}.");
        wp_send_json_success(['message' => 'قرارداد با موفقیت امضا شد.']);
        // Optionally trigger another SMS confirming the signature
    }
}