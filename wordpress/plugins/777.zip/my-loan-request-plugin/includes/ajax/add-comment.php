<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_add_comment', 'mlr_add_comment_callback');

function mlr_add_comment_callback() {
    // 1. Security Checks
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
        return;
    }

    // 2. Input Validation & Sanitization
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $comment_text = isset($_POST['comment']) ? sanitize_textarea_field(stripslashes($_POST['comment'])) : '';

    if (!$request_id || empty($comment_text)) {
        wp_send_json_error(['message' => 'شناسه درخواست یا متن یادداشت نامعتبر است.']);
        return;
    }

    // 3. Database Interaction
    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';

    // Fetch existing comments
    $existing_comments_json = $wpdb->get_var($wpdb->prepare("SELECT comments FROM $table_name WHERE id = %d", $request_id));
    $comments = !empty($existing_comments_json) ? json_decode($existing_comments_json, true) : [];
    
    if (!is_array($comments)) {
        $comments = [];
    }

    // Prepare new comment
    $current_user = wp_get_current_user();
    $new_comment = [
        'user_id'      => $current_user->ID,
        'display_name' => $current_user->display_name,
        'text'         => $comment_text,
        'timestamp'    => current_time('mysql'),
    ];

    // Add new comment to the array
    $comments[] = $new_comment;

    // Update the database
    $updated = $wpdb->update(
        $table_name,
        ['comments' => json_encode($comments, JSON_UNESCAPED_UNICODE)],
        ['id' => $request_id]
    );

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطایی در هنگام ذخیره یادداشت رخ داد.']);
        return;
    }

    // 4. Send Success Response with the new comment HTML for live update
    ob_start();
    ?>
    <div class="mlr-comment-bubble">
        <div class="mlr-comment-header">
            <strong class="mlr-comment-author"><?php echo esc_html($new_comment['display_name']); ?></strong>
            <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($new_comment['timestamp'], 'Y/m/d H:i'); ?></span>
        </div>
        <div class="mlr-comment-body">
            <?php echo nl2br(esc_html($new_comment['text'])); ?>
        </div>
    </div>
    <?php
    $new_comment_html = ob_get_clean();

    $request_messages = function_exists('mlr_get_request_messages') ? mlr_get_request_messages($request_id, 1000) : [];
    $conversation_html = function_exists('mlr_render_request_conversation_html') ? mlr_render_request_conversation_html($comments, $request_messages) : '';
    wp_send_json_success([
        'message' => 'یادداشت با موفقیت اضافه شد.',
        'new_comment_html' => $new_comment_html,
        'conversation_html' => $conversation_html
    ]);
}