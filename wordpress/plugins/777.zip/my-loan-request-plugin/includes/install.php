<?php
// FILE: my-loan-request-plugin/includes/install.php
if (!defined('ABSPATH')) {
    exit;
}

function mlr_install() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // 1. جدول درخواست‌های وام (Loan Requests)
    $table_requests = $wpdb->prefix . 'loan_requests';
    $sql_requests = "CREATE TABLE $table_requests (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        full_name varchar(255) NOT NULL,
        national_code varchar(10) NOT NULL,
        mobile_number varchar(11) NOT NULL,
        phone_number varchar(20) DEFAULT '' NOT NULL,
        birth_date date DEFAULT NULL,
        occupation varchar(100) DEFAULT '' NOT NULL,
        residential_address text,
        postal_code varchar(10) DEFAULT '' NOT NULL,
        work_address text,
        product_name text,
        installment_plan_id mediumint(9) NOT NULL,
        loan_amount bigint NOT NULL,
        installment_interval int NOT NULL,
        installment_count int NOT NULL,
        prepayment bigint DEFAULT 0,
        installment_amount bigint DEFAULT 0,
        total_payment bigint DEFAULT 0,
        wallet_charge bigint DEFAULT 0,
        profit bigint DEFAULT 0,
        acceptor_payment_amount bigint DEFAULT 0,
        final_settlement_amount bigint DEFAULT 0,
        bank_validation_file varchar(255) DEFAULT NULL,
        required_documents longtext DEFAULT NULL,
        order_items longtext DEFAULT NULL,
        order_total bigint DEFAULT NULL,
        description text DEFAULT NULL,
        signature_image varchar(255) DEFAULT NULL,
        contract_file varchar(255) DEFAULT NULL,
        check_images text DEFAULT NULL,
        status varchar(50) NOT NULL DEFAULT 'در حال بررسی',
        settlement_status varchar(20) DEFAULT NULL,
        comments longtext DEFAULT NULL,
        created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        last_edited_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // 2. جدول طرح‌های اقساطی (Installment Plans)
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $sql_installment_plans = "CREATE TABLE $table_installment_plans (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        description text,
        type varchar(50) DEFAULT 'market' NOT NULL,
        settings longtext,
        is_active tinyint(1) DEFAULT 1,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        min_amount bigint NOT NULL,
        max_amount bigint NOT NULL,
        min_interval int NOT NULL,
        max_interval int NOT NULL,
        min_count int NOT NULL,
        max_count int NOT NULL,
        requires_bank_validation tinyint(1) DEFAULT 0,
        required_documents text,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // 3. جدول درخواست‌های همکاری (Cooperation Requests) - به روز رسانی شده
    $table_cooperation = $wpdb->prefix . 'cooperation_requests';
    $sql_cooperation = "CREATE TABLE $table_cooperation (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        full_name varchar(255) NOT NULL,
        applicant_id_number varchar(20) DEFAULT '' NOT NULL, 
        mobile_number varchar(11) NOT NULL,
        phone_number varchar(20) DEFAULT '',
        store_name varchar(255) DEFAULT '',
        activity_type varchar(255) DEFAULT '',
        city varchar(100) DEFAULT '',
        province varchar(100) DEFAULT '',
        address text,
        description text,
        status varchar(50) NOT NULL DEFAULT 'در حال بررسی',
        otp_code varchar(6) DEFAULT NULL,
        otp_expiry datetime DEFAULT NULL,
        is_verified tinyint(1) DEFAULT 0,
        contract_signed tinyint(1) DEFAULT 0,
        signature_image varchar(255) DEFAULT NULL,
        contract_date datetime DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_requests);
    dbDelta($sql_installment_plans);
    dbDelta($sql_cooperation);
}
?>