<?php
if (!defined('ABSPATH')) {
    exit;
}

function mlr_granted_requests_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $users_table = $wpdb->prefix . 'users';
    $success_message = '';
    $error_message = '';

    // پردازش فرم
    if (isset($_POST['mlr_assign_date']) && check_admin_referer('mlr_assign_date_action')) {
        $request_ids = isset($_POST['request_ids']) ? array_map('intval', $_POST['request_ids']) : [];
        $settlement_date_jalali = isset($_POST['settlement_date']) ? sanitize_text_field($_POST['settlement_date']) : '';

        if (empty($settlement_date_jalali)) {
            $error_message = 'خطا: انتخاب تاریخ تسویه الزامی است.';
        } elseif (!empty($request_ids)) {
            $settlement_date_gregorian = mlr_jalali_to_gregorian($settlement_date_jalali);
            
            if($settlement_date_gregorian) {
                $settlement_date_gregorian .= ' ' . date('H:i:s'); // افزودن ساعت جاری
                $ids_placeholder = implode(',', array_fill(0, count($request_ids), '%d'));

                $updated_count = $wpdb->query($wpdb->prepare(
                    "UPDATE $table_requests
                     SET settlement_status = 'در انتظار تسویه', settlement_date = %s
                     WHERE id IN ($ids_placeholder) AND status = 'اعطا شده' AND (settlement_status = 'منتظر تعیین تاریخ' OR settlement_status IS NULL OR settlement_status = '')",
                    array_merge([$settlement_date_gregorian], $request_ids)
                ));

                if ($updated_count !== false) {
                     $success_message = $updated_count . ' درخواست با موفقیت تعیین تکلیف شدند.';
                } else {
                     $error_message = 'خطا در دیتابیس.';
                     mlr_log("DB Error: " . $wpdb->last_error); 
                }
            } else {
                $error_message = 'فرمت تاریخ نامعتبر است.';
            }
        } else {
             $error_message = 'هیچ درخواستی انتخاب نشده است.';
        }
    }

    $waiting_requests = $wpdb->get_results("
        SELECT r.id, r.full_name, r.mobile_number, r.wallet_charge, r.final_settlement_amount, r.product_name, r.last_edited_at, r.settlement_status, u.display_name
        FROM $table_requests r
        LEFT JOIN $users_table u ON r.user_id = u.ID
        WHERE r.status = 'اعطا شده' AND (r.settlement_status = 'منتظر تعیین تاریخ' OR r.settlement_status IS NULL OR r.settlement_status = '')
        ORDER BY u.display_name, r.last_edited_at DESC
    ");

    ?>
    <div class="wrap mlr-admin-wrap mlr-settlement-page">
        <div class="mlr-page-header">
             <h1><span class="dashicons dashicons-calendar-alt"></span> تعیین تاریخ تسویه (درخواست‌های اعطا شده)</h1>
        </div>
        <p class="mlr-page-description">برای درخواست‌های انتخاب شده، تاریخ تسویه را مشخص کنید.</p>

        <?php if ($success_message) : ?><div id="message" class="notice notice-success is-dismissible mlr-notice"><p><?php echo wp_kses_post($success_message); ?></p></div><?php endif; ?>
        <?php if ($error_message) : ?><div id="message" class="notice notice-error is-dismissible mlr-notice"><p><?php echo wp_kses_post($error_message); ?></p></div><?php endif; ?>

        <?php if (empty($waiting_requests)): ?>
            <div class="mlr-card">
                <div class="mlr-card-content" style="text-align: center; padding: 30px;">
                    <span class="dashicons dashicons-info-outline" style="font-size: 30px; color: #777;"></span>
                    <p>هیچ درخواستی منتظر تعیین تاریخ نیست.</p>
                    <a href="<?php echo admin_url('admin.php?page=mlr-unsettled-requests'); ?>" class="button button-primary">مشاهده لیست انتظار تسویه</a>
                </div>
            </div>
        <?php else: ?>
            <form method="post" id="mlr-assign-date-form">
                <?php wp_nonce_field('mlr_assign_date_action'); ?>
                <div class="mlr-card mlr-bulk-action-card">
                    <div class="mlr-card-content">
                        <label for="settlement_date" class="mlr-label">تاریخ تسویه:</label>
                        <div class="mlr-bulk-action-controls" style="position: relative; display: flex; align-items: center;">
                            
                            <div class="mlr-date-input-wrapper" style="position: relative;">
                                <input type="text" name="settlement_date" id="settlement_date" class="jalali-datepicker mlr-input" placeholder="انتخاب تاریخ" required autocomplete="off" style="padding-left: 30px; width: 140px; cursor: pointer;">
                                <span class="dashicons dashicons-calendar-alt mlr-datepicker-trigger" style="position: absolute; left: 5px; top: 50%; transform: translateY(-50%); color: #666; cursor: pointer; z-index: 2;"></span>
                            </div>

                            <button type="submit" name="mlr_assign_date" class="button button-primary" style="margin-right: 10px;">ثبت و انتقال</button>
                        </div>
                    </div>
                </div>

                <div class="mlr-card mlr-table-card">
                     <div class="mlr-card-content no-padding">
                        <table class="wp-list-table widefat fixed striped mlr-compact-table">
                            <thead>
                                <tr>
                                    <td id="cb1" class="manage-column column-cb check-column"><input type="checkbox" id="mlr-select-all-waiting"></td>
                                    <th class="column-id">شناسه</th>
                                    <th>پذیرنده</th>
                                    <th>متقاضی</th>
                                    <th>موبایل</th>
                                    <th class="column-amount">مبلغ (ریال)</th>
                                    <th class="column-date">تاریخ اعطا</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($waiting_requests as $request): ?>
                                <tr class="mlr-request-row">
                                    <th scope="row" class="check-column"><input type="checkbox" name="request_ids[]" value="<?php echo esc_attr($request->id); ?>" class="mlr-request-checkbox-waiting"></th>
                                    <td class="column-id"><?php echo esc_html($request->id); ?></td>
                                    <td><?php echo esc_html($request->display_name ?: '-'); ?></td>
                                    <td><strong><?php echo esc_html($request->full_name); ?></strong></td>
                                    <td><?php echo esc_html($request->mobile_number); ?></td>
                                    <td class="column-amount"><?php echo number_format($request->final_settlement_amount); ?></td>
                                    <td class="column-date"><?php echo mlr_gregorian_to_jalali($request->last_edited_at, 'Y/m/d'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <style>
        .mlr-settlement-page .mlr-card { background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04); margin-bottom: 20px; }
        .mlr-settlement-page .mlr-card-content { padding: 15px; }
        .mlr-settlement-page .mlr-card-content.no-padding { padding: 0; }
        .mlr-settlement-page .mlr-bulk-action-card .mlr-card-content { background: #f6f7f7; display: flex; align-items: center; }
        .mlr-settlement-page .mlr-label { font-weight: 600; margin-left: 10px; }
        .mlr-settlement-page .mlr-input { height: 32px; line-height: normal; }
    </style>

    <script>
    jQuery(document).ready(function($) {
        $('#mlr-select-all-waiting').on('click', function() {
            $('.mlr-request-checkbox-waiting').prop('checked', $(this).is(':checked'));
        });
         $('#mlr-assign-date-form').on('submit', function(e) {
             if (!$('#settlement_date').val()) {
                 alert('لطفاً تاریخ تسویه را انتخاب کنید.');
                 e.preventDefault();
             } else if ($('.mlr-request-checkbox-waiting:checked').length === 0) {
                  alert('لطفاً حداقل یک درخواست را انتخاب کنید.');
                 e.preventDefault();
             }
         });
    });
    </script>
    <?php
}
?>