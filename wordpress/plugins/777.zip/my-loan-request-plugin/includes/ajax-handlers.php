<?php
/**
 * Consolidated AJAX Handlers
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once MLR_PLUGIN_DIR . 'includes/ajax/add-comment.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/add-request-message.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/admin-calculate-loan.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/bank-expert-actions.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/filter-user-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/frontend-calculate-loan.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-cooperation-request-details.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-cycle-details.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-front-actions.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-frontend-request-details.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-plan-documents.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-request-details.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-request-messages.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-sms-credit.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-user-actions.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/get-user-cycle-details.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/save-expert-notes.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/submit-completed-docs.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/submit-cooperation-request.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/submit-loan-request.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/update-cooperation-status.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/update-invoice.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/upload-additional-docs.php';
require_once MLR_PLUGIN_DIR . 'includes/ajax/cooperation-otp-actions.php';
