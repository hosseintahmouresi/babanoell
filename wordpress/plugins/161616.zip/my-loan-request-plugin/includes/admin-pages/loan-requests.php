<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Main callback function for all loan request admin pages.
 * It dynamically filters requests based on the 'status' GET parameter.
 */
function mlr_loan_requests_page() {
    // Determine the status filter from the URL, if present.
    $status_filter = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : ''; // Use wp_unslash

    // Define titles for specific status pages.
    $page_titles = [
        'در حال بررسی' => 'درخواست‌های در حال بررسی',
        'نقص مدارک' => 'درخواست‌های نقص مدارک',
        'رد شده' => 'درخواست‌های رد شده',
        'تأیید کارشناس' => 'درخواست‌های تأیید کارشناس',
        'تکمیل مدارک' => 'درخواست‌های تکمیل مدارک',
        'تأیید مدارک' => 'درخواست‌های تأیید مدارک',
        // Add other status titles if needed for specific views
    ];

    // Set the page title based on the filter, default to general title if no specific filter.
    $page_title = $page_titles[$status_filter] ?? 'مدیریت درخواست‌های تسهیلات';

    // Call the main display function with the determined filter and title.
    mlr_display_requests_page($status_filter, $page_title);
}


/**
 * Renders the main admin page for viewing loan requests, filtered by status.
 *
 * @param string $status_filter The status to filter by (e.g., 'در حال بررسی'). Empty string shows all.
 * @param string $page_title The title to display for the page.
 */
function mlr_display_requests_page($status_filter = '', $page_title = 'مدیریت درخواست‌ها') {
    // Check user capabilities.
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $users_table = $wpdb->prefix . 'users';
    $all_valid_statuses = mlr_get_all_valid_statuses(); // Get the list of all possible statuses.

    // --- START: Status Transition Rules ---
    // Define the allowed transitions from each status
    $status_transitions = [
        'در حال بررسی' => ['در حال بررسی', 'نقص مدارک', 'رد شده', 'تأیید کارشناس'],
        'نقص مدارک' => ['نقص مدارک', 'در حال بررسی'],
        'تأیید کارشناس' => ['تأیید کارشناس', 'نقص مدارک', 'رد شده', 'تکمیل مدارک'],
        'تکمیل مدارک' => ['تکمیل مدارک', 'تأیید مدارک'],
        'تأیید مدارک' => ['تأیید مدارک', 'اعطا شده', 'تکمیل مدارک'],
        'رد شده' => ['رد شده', 'در حال بررسی'], // Allow reopening a rejected case
        'اعطا شده' => ['اعطا شده'], // Cannot be changed from here (handled by settlement pages)
        // Default fallback: allow all valid statuses if current status is unknown
        'default' => $all_valid_statuses
    ];
    // --- END: Status Transition Rules ---

    // --- Handle Status Update Form Submission ---
    if (isset($_POST['mlr_update_status']) && check_admin_referer('mlr_update_status_action', '_wpnonce')) {
        $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
        $new_status = isset($_POST['status']) ? sanitize_text_field(wp_unslash($_POST['status'])) : '';
        $assigned_bank_user_id = isset($_POST['assigned_bank_user_id']) ? intval($_POST['assigned_bank_user_id']) : 0;

        // Validate request ID
        if ($request_id > 0) {
            $current_request = $wpdb->get_row($wpdb->prepare("SELECT status, assigned_bank_user_id FROM $table_name WHERE id = %d", $request_id));

            if ($current_request) {
                // Get the allowed transitions for the *current* status
                $current_status = $current_request->status;
                $allowed_next_statuses = $status_transitions[$current_status] ?? $status_transitions['default'];

                // *** Check if the new status is allowed ***
                if (!in_array($new_status, $allowed_next_statuses)) {
                     echo '<div id="message" class="error notice is-dismissible"><p>خطا: تغییر وضعیت از "' . esc_html($current_status) . '" به "' . esc_html($new_status) . '" مجاز نیست.</p></div>';
                }
                // Check if bank expert assignment is required
                elseif ($new_status === 'تأیید کارشناس' && empty($assigned_bank_user_id) && $assigned_bank_user_id !== $current_request->assigned_bank_user_id) {
                    echo '<div id="message" class="error notice is-dismissible"><p>خطا: برای وضعیت "تأیید کارشناس"، لطفاً یک کارشناس بانک برای ارجاع انتخاب کنید.</p></div>';
                } else {
                    // All checks passed, prepare data for update
                    $data_to_update = ['last_edited_at' => current_time('mysql')];
                    $is_status_change = $current_request->status !== $new_status;

                    $data_to_update['status'] = $new_status;
                    // Automatically set settlement status when moving to 'اعطا شده'
                    if ($new_status === 'اعطا شده' && $current_request->status !== 'اعطا شده') {
                        $data_to_update['settlement_status'] = 'منتظر تعیین تاریخ';
                    }
                    // Assign bank expert if selected
                    if ($assigned_bank_user_id > 0) {
                        $data_to_update['assigned_bank_user_id'] = $assigned_bank_user_id;
                    }

                    // Perform the update
                    $update_result = $wpdb->update($table_name, $data_to_update, ['id' => $request_id]);

                    if ($update_result !== false) {
                        echo '<div id="message" class="updated notice is-dismissible"><p>وضعیت درخواست با موفقیت به‌روزرسانی شد.</p></div>';
                        
                        // --- Added Logging for Status & Settlement Changes ---
                        if (function_exists('mlr_add_request_event')) {
                            if ($is_status_change) {
                                mlr_add_request_event($request_id, 'status_change', 'تغییر وضعیت به: ' . $new_status);
                            }
                            if (isset($data_to_update['settlement_status'])) {
                                mlr_add_request_event($request_id, 'settlement_status_change', 'تغییر وضعیت تسویه به: ' . $data_to_update['settlement_status']);
                            }
                        }
                        // ----------------------------------------------------

                        // Send SMS only if the status actually changed
                        if ($is_status_change) {
                            mlr_send_sms_on_loan_status_change($request_id, $new_status);
                            // Notify all admins of loan request status change
                            if (function_exists('mlr_create_notification')) {
                                mlr_create_notification('status_change', 'وضعیت درخواست #' . $request_id . ' به «' . $new_status . '» تغییر کرد.', admin_url('admin.php?page=mlr-loan-requests&s=' . $request_id));
                            }
                        }
                    } else {
                         mlr_log("Error updating loan status for ID {$request_id}: " . $wpdb->last_error);
                         echo '<div id="message" class="error notice is-dismissible"><p>خطا در به‌روزرسانی دیتابیس.</p></div>';
                    }
                }
            } else {
                 echo '<div id="message" class="error notice is-dismissible"><p>خطا: درخواست مورد نظر یافت نشد.</p></div>';
            }
        } else {
             echo '<div id="message" class="error notice is-dismissible"><p>خطا: اطلاعات ارسال شده برای به‌روزرسانی وضعیت نامعتبر است.</p></div>';
        }
    }
    // --- End Handle Status Update ---


    // --- Filter & Search Logic ---
    $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
    // Use the $status_filter passed to the function if set, otherwise check URL
    $status_from_url = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : $status_filter;
    $date_from_jalali = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
    $date_to_jalali = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';

    // Convert Jalali dates to Gregorian for DB query
    $date_from_gregorian = !empty($date_from_jalali) ? mlr_jalali_to_gregorian($date_from_jalali) : '';
    $date_to_gregorian = !empty($date_to_jalali) ? mlr_jalali_to_gregorian($date_to_jalali) : '';

    // Build WHERE clauses
    $where_clauses = ["1=1"]; // Start with true condition
    $prepare_params = []; // Array for prepare parameters

    if (!empty($search)) {
         $search_like = '%' . $wpdb->esc_like($search) . '%';
         $where_clauses[] = "(r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s)";
         $prepare_params[] = $search_like;
         $prepare_params[] = $search_like;
         $prepare_params[] = $search_like;
         // Consider searching by ID if numeric
         if(is_numeric($search)){
             $where_clauses[count($where_clauses)-1] = substr($where_clauses[count($where_clauses)-1], 0, -1); // Remove closing parenthesis
             $where_clauses[count($where_clauses)-1] .= " OR r.id = %d)";
             $prepare_params[] = intval($search);
         }
    }
    if (!empty($status_from_url)) {
        // Ensure the status from URL is a valid one before adding to query
        if (in_array($status_from_url, $all_valid_statuses)) {
             $where_clauses[] = "r.status = %s";
             $prepare_params[] = $status_from_url;
        } else {
            // Optional: Show a notice if an invalid status was passed in URL?
            $status_from_url = ''; // Reset if invalid to avoid SQL errors
        }
    }
    if (!empty($date_from_gregorian)) {
        $where_clauses[] = "r.created_at >= %s";
        $prepare_params[] = $date_from_gregorian . ' 00:00:00';
    }
    if (!empty($date_to_gregorian)) {
        $where_clauses[] = "r.created_at <= %s";
        $prepare_params[] = $date_to_gregorian . ' 23:59:59';
    }

    $sql_where = "WHERE " . implode(' AND ', $where_clauses);

    // --- Pagination Logic ---
    $items_per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $items_per_page;

    // Get total items count
    $total_items_query = "SELECT COUNT(r.id) FROM $table_name r $sql_where";
    $total_items = $wpdb->get_var($wpdb->prepare($total_items_query, $prepare_params));
    if ($total_items === null) { $total_items = 0; }
    $total_pages = ceil($total_items / $items_per_page);

    // Get requests for the current page
    $requests_query = "SELECT r.*, u.display_name
                       FROM $table_name r
                       LEFT JOIN $users_table u ON r.user_id = u.ID
                       $sql_where
                       ORDER BY r.created_at DESC
                       LIMIT %d
                       OFFSET %d";
    $prepare_params[] = $items_per_page;
    $prepare_params[] = $offset;
    $requests = $wpdb->get_results($wpdb->prepare($requests_query, $prepare_params));

    // Get list of users with 'bank' role for assignment dropdown
    $bank_users = get_users(['role' => 'bank', 'orderby' => 'display_name', 'order' => 'ASC']);
    // --- End Filter & Search & Pagination Logic ---

    // Determine if the actions row should be displayed (only on specific status pages)
    $show_actions_row = !empty($status_filter);

    ?>
    <div class="wrap mlr-admin-wrap">
        <div class="mlr-page-header">
            <h1><?php echo esc_html($page_title); ?></h1>
            <?php // Add New button or other header actions if applicable ?>
        </div>

        <?php // Filters Card ?>
        <div class="mlr-filters-card">
            <form method="get">
                <input type="hidden" name="page" value="<?php echo esc_attr($_REQUEST['page']); ?>">
                <div class="mlr-filters-grid">
                    <div class="mlr-filter-item" style="grid-column: 1 / -1;">
                        <label for="s">جستجو</label>
                        <input type="search" id="s" name="s" value="<?php echo esc_attr($search); ?>" placeholder="جستجو در نام متقاضی، کد ملی، شماره موبایل، شناسه...">
                    </div>
                    <div class="mlr-filter-item">
                        <label for="status">وضعیت</label>
                        <select id="status" name="status">
                            <option value="">همه وضعیت‌ها</option>
                            <?php foreach ($all_valid_statuses as $stat) : ?>
                                <option value="<?php echo esc_attr($stat); ?>" <?php selected($status_from_url, $stat); ?>><?php echo esc_html($stat); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mlr-filter-item">
                        <label for="date_from">از تاریخ</label>
                        <input type="text" id="date_from" name="date_from" class="jalali-datepicker" value="<?php echo esc_attr($date_from_jalali); ?>" placeholder="انتخاب کنید..." readonly>
                    </div>
                    <div class="mlr-filter-item">
                        <label for="date_to">تا تاریخ</label>
                        <input type="text" id="date_to" name="date_to" class="jalali-datepicker" value="<?php echo esc_attr($date_to_jalali); ?>" placeholder="انتخاب کنید..." readonly>
                    </div>
                    <div class="mlr-filter-buttons">
                        <button type="submit" class="button button-primary">فیلتر</button>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=' . esc_attr($_REQUEST['page']))); ?>" class="button">حذف فیلترها</a>
                        <button type="submit" name="export_excel" value="1" class="button button-secondary" style="margin-right:auto;"><span class="dashicons dashicons-media-spreadsheet" style="vertical-align:middle;"></span> خروجی اکسل</button>
                        <button type="submit" name="export_pdf_credit" value="1" class="button button-secondary" formtarget="_blank" style="margin-right:5px;"><span class="dashicons dashicons-media-document" style="vertical-align:middle;"></span> PDF اعتبارسنجی</button>
                        <button type="submit" name="export_pdf_dossier" value="1" class="button button-secondary" formtarget="_blank" style="margin-right:5px;"><span class="dashicons dashicons-portfolio" style="vertical-align:middle;"></span> PDF پرونده</button>
                    </div>
                </div>
            </form>
        </div>

        <?php // Results Table Wrapper ?>
        <div class="mlr-table-wrapper">
            <table class="wp-list-table widefat fixed striped mlr-modern-table loan-requests-table">
                <thead>
                    <tr>
                        <th class="manage-column column-id" scope="col">شناسه</th>
                        <th scope="col">پذیرنده</th>
                        <th scope="col">متقاضی</th>
                        <th scope="col" class="column-national-code">کد ملی</th>
                        <th scope="col" class="column-amount">مبلغ (ریال)</th>
                        <th scope="col">وضعیت</th>
                        <th scope="col" class="column-bank-expert">کارشناس بانک</th>
                        <th scope="col" class="column-date">تاریخ ثبت</th>
                        <th scope="col" class="column-date">تاریخ تسویه</th>
                        <th class="manage-column column-actions" scope="col">
                           <?php echo $show_actions_row ? 'عملیات' : 'جزئیات'; // Change header based on view ?>
                        </th>
                    </tr>
                </thead>
                <tbody id="the-list" data-wp-lists="list:loan_request">
                    <?php if (empty($requests)) : ?>
                        <tr class="no-items"><td class="colspanchange" colspan="10">هیچ درخواستی یافت نشد.</td></tr> <?php // Colspan adjusted ?>
                    <?php else: ?>
                        <?php foreach ($requests as $request) :
                            // Get assigned bank expert info if available
                            $assigned_user_info = null;
                            if (!empty($request->assigned_bank_user_id)) {
                                $assigned_user_info = get_userdata($request->assigned_bank_user_id);
                            }
                            $acceptor_display_name = $request->display_name ?: 'کاربر حذف شده'; // Handle deleted users
                            
                            // *** Get allowed next statuses for this row ***
                            $current_row_status = $request->status;
                            $allowed_transitions = $status_transitions[$current_row_status] ?? $status_transitions['default'];
                        ?>
                        <tr class="mlr-request-row" data-id="<?php echo esc_attr($request->id); ?>">
                            <td class="column-id"><?php echo esc_html($request->id); ?></td>
                            <td><?php echo esc_html($acceptor_display_name); ?></td>
                            <td><strong><?php echo esc_html($request->full_name); ?></strong></td>
                            <td class="column-national-code"><?php echo esc_html($request->national_code); ?></td>
                            <td class="column-amount"><?php echo number_format($request->loan_amount); ?></td>
                            <td><?php echo esc_html($request->status); ?></td>
                            <td class="column-bank-expert"><?php echo $assigned_user_info ? esc_html($assigned_user_info->display_name) : '---'; ?></td>
                            <td class="column-date"><?php echo mlr_gregorian_to_jalali($request->created_at, 'Y/m/d H:i'); // Show time as well ?></td>
                            <td class="column-date"><?php echo !empty($request->settlement_date) ? mlr_gregorian_to_jalali($request->settlement_date, 'Y/m/d') : '—'; ?></td>
                            <td class="mlr-actions-container column-actions">
                                <button class="mlr-actions-btn-icon" data-id="<?php echo esc_attr($request->id); ?>" title="مشاهده جزئیات کامل" aria-label="مشاهده جزئیات کامل درخواست <?php echo esc_attr($request->id); ?>">
                                    <span class="dashicons dashicons-visibility" aria-hidden="true"></span>
                                </button>
                                <?php // Display toggle only if actions row is enabled for this view ?>
                                <?php if ($show_actions_row): ?>
                                    <button class="mlr-actions-toggle-btn-icon" data-id="<?php echo esc_attr($request->id); ?>" title="تغییر وضعیت" aria-label="تغییر وضعیت درخواست <?php echo esc_attr($request->id); ?>">
                                        <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php // Conditionally display the actions row ?>
                        <?php if ($show_actions_row): ?>
                            <tr class="mlr-actions-row" id="actions-row-<?php echo esc_attr($request->id); ?>" style="display:none;">
                                <td colspan="10"> <?php // Ensure colspan matches the number of columns ?>
                                    <div class="action-buttons">
                                        <form method="post" action="<?php echo esc_url(remove_query_arg('settings-updated')); // Prevent resubmission message ?>">
                                            <?php wp_nonce_field('mlr_update_status_action', '_wpnonce'); ?>
                                            <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">

                                            <?php // *** MODIFIED: Status Dropdown with Transition Logic *** ?>
                                            <?php if ($current_row_status !== 'اعطا شده'): ?>
                                                <label for="status_<?php echo esc_attr($request->id); ?>" class="screen-reader-text">وضعیت جدید</label>
                                                <select name="status" id="status_<?php echo esc_attr($request->id); ?>" class="mlr-status-select-action">
                                                    <?php // Loop through the *allowed* transitions for this status ?>
                                                    <?php foreach ($allowed_transitions as $stat) : ?>
                                                        <option value="<?php echo esc_attr($stat); ?>" <?php selected($current_row_status, $stat); ?>>
                                                            <?php echo esc_html($stat); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            <?php else: ?>
                                                <span class="mlr-status-message">وضعیت اصلی این درخواست نهایی شده است.</span>
                                            <?php endif; ?>
                                            <?php // *** END MODIFICATION *** ?>


                                            <?php // Bank expert assignment dropdown - Show only for relevant statuses ?>
                                            <?php if (in_array($current_row_status, ['در حال بررسی', 'نقص مدارک', 'تأیید کارشناس'])) : ?>
                                                <label for="bank_user_<?php echo esc_attr($request->id); ?>" class="screen-reader-text">ارجاع به کارشناس بانک</label>
                                                <select name="assigned_bank_user_id" id="bank_user_<?php echo esc_attr($request->id); ?>" class="mlr-bank-user-select">
                                                    <option value="">-- ارجاع به کارشناس بانک --</option>
                                                    <?php if (!empty($bank_users)): ?>
                                                        <?php foreach ($bank_users as $user): ?>
                                                            <option value="<?php echo esc_attr($user->ID); ?>" <?php selected($request->assigned_bank_user_id, $user->ID); ?>><?php echo esc_html($user->display_name); ?></option>
                                                        <?php endforeach; ?>
                                                    <?php else: ?>
                                                        <option value="" disabled>کارشناس بانکی یافت نشد</option>
                                                    <?php endif; ?>
                                                </select>
                                            <?php endif; ?>

                                            <?php // Submit button - Hide if status is 'اعطا شده' ?>
                                            <?php if ($current_row_status !== 'اعطا شده'): ?>
                                                <button type="submit" name="mlr_update_status" class="button button-primary mlr-update-button">به‌روزرسانی</button>
                                            <?php endif; ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; // End conditional display of actions row ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div> <?php // End mlr-table-wrapper ?>

        <?php // Pagination Navigation ?>
        <?php if ($total_pages > 1): ?>
            <div class="mlr-pagination-nav">
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php echo number_format($total_items); ?> آیتم</span>
                    <span class="pagination-links">
                        <?php
                        echo paginate_links([
                            'base' => add_query_arg('paged', '%#%'),
                            'format' => '',
                            'prev_text' => '«',
                            'next_text' => '»',
                            'total' => $total_pages,
                            'current' => $current_page,
                        ]);
                        ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>


        <?php // Modal structure for displaying details ?>
        <div id="mlr-overlay" style="display:none;" aria-hidden="true"></div>
        <div id="mlr-details-content" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="mlr-modal-title">
            <button id="mlr-close-details" aria-label="بستن پنجره جزئیات">&times;</button>
            <div id="mlr-details-inner">
                <?php // Content loaded via AJAX ?>
            </div>
        </div>
    </div> <?php // End wrap ?>

    <?php // Embedded CSS styles ?>
    <style>
        /* === START: Modern Loan Requests Styles (Mimicking Cooperation Style V6/V7) === */

        /* === START: Ultra Modern & Chic Admin Styles (Unified V2) === */
        :root {
            --mlr-primary: #4f46e5; /* Indigo 600 */
            --mlr-primary-hover: #4338ca; /* Indigo 700 */
            --mlr-bg: #f8fafc; /* Slate 50 */
            --mlr-surface: #ffffff;
            --mlr-border: #e2e8f0; /* Slate 200 */
            --mlr-text-main: #1e293b; /* Slate 800 */
            --mlr-text-muted: #64748b; /* Slate 500 */
            --mlr-shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --mlr-shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --mlr-radius: 12px;
        }

        .mlr-admin-wrap { padding: 25px; background-color: var(--mlr-bg); font-family: 'Vazirmatn', system-ui, sans-serif; }
        .mlr-admin-wrap h1 { font-weight: 800; color: var(--mlr-text-main); margin-bottom: 30px; font-size: 26px; letter-spacing: -0.5px; }
        
        /* Filters Card */
        .mlr-filters-card { background: var(--mlr-surface); border-radius: var(--mlr-radius); padding: 24px; box-shadow: var(--mlr-shadow-sm); border: 1px solid var(--mlr-border); margin-bottom: 30px; }
        .mlr-filters-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; align-items: end; }
        .mlr-filter-item label { display: block; font-weight: 600; margin-bottom: 8px; font-size: 13px; color: var(--mlr-text-muted); }
        .mlr-filter-item input, .mlr-filter-item select { width: 100%; padding: 12px 14px; border: 1px solid var(--mlr-border); border-radius: 8px; font-size: 14px; color: var(--mlr-text-main); transition: all 0.2s; background-color: #f8fafc; }
        .mlr-filter-item input:focus, .mlr-filter-item select:focus { border-color: var(--mlr-primary); background-color: #fff; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); outline: none; }
        
        .mlr-filter-buttons { display: flex; gap: 10px; }
        .mlr-filter-buttons .button { padding: 10px 20px; height: auto; border-radius: 8px; font-weight: 600; transition: all 0.2s; border: none; }
        .mlr-filter-buttons .button-primary { background: var(--mlr-primary); box-shadow: 0 4px 6px -1px rgba(79, 70, 229, 0.3); }
        .mlr-filter-buttons .button-primary:hover { background: var(--mlr-primary-hover); transform: translateY(-1px); }

        /* Table */
        .mlr-modern-table { border-collapse: separate; border-spacing: 0 12px; width: 100%; margin-top: 10px; }
        .mlr-modern-table thead th { font-size: 13px; font-weight: 700; color: var(--mlr-text-muted); padding: 0 20px 10px; border: none; text-align: right; }
        .mlr-modern-table tbody tr { background: var(--mlr-surface); box-shadow: var(--mlr-shadow-sm); transition: all 0.2s ease; border-radius: var(--mlr-radius); }
        .mlr-modern-table tbody tr:hover { transform: translateY(-3px); box-shadow: var(--mlr-shadow-md); z-index: 1; position: relative; }
        .mlr-modern-table td { padding: 18px 20px; border: none; vertical-align: middle; color: var(--mlr-text-main); font-size: 14px; }
        .mlr-modern-table td:first-child { border-top-right-radius: var(--mlr-radius); border-bottom-right-radius: var(--mlr-radius); }
        .mlr-modern-table td:last-child { border-top-left-radius: var(--mlr-radius); border-bottom-left-radius: var(--mlr-radius); }
        
        /* Columns */
        .column-id { font-weight: 700; color: var(--mlr-primary); }
        .column-amount { font-family: 'Vazirmatn', sans-serif; font-weight: 600; }
        
        /* Actions */
        .mlr-actions-container { display: flex; gap: 8px; justify-content: flex-end; }
        .mlr-actions-btn-icon { width: 36px; height: 36px; border-radius: 10px; background: #f1f5f9; color: var(--mlr-text-muted); border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
        .mlr-actions-btn-icon:hover { background: var(--mlr-primary); color: #fff; }
        .mlr-actions-btn-icon .dashicons { font-size: 18px; }

        /* Pagination */
        .mlr-pagination-nav { margin-top: 30px; display: flex; justify-content: center; gap: 5px; }
        .mlr-pagination-nav .pagination-links a, .mlr-pagination-nav .pagination-links span { padding: 8px 14px; background: var(--mlr-surface); border: 1px solid var(--mlr-border); border-radius: 8px; color: var(--mlr-text-main); text-decoration: none; font-weight: 600; transition: all 0.2s; }
        .mlr-pagination-nav .pagination-links a:hover { border-color: var(--mlr-primary); color: var(--mlr-primary); }
        .mlr-pagination-nav .pagination-links .current { background: var(--mlr-primary); color: #fff; border-color: var(--mlr-primary); }

        /* Modal */
        #mlr-details-content { border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); border: none; overflow: hidden; }
        .mlr-modal-header { background: #fff; padding: 25px 30px; border-bottom: 1px solid var(--mlr-border); }
        .mlr-modal-title { font-size: 20px; font-weight: 800; color: var(--mlr-text-main); }
        #mlr-details-inner { padding: 30px; background: #f8fafc; }
        .mlr-modal-card { background: #fff; border-radius: 16px; padding: 25px; box-shadow: var(--mlr-shadow-sm); border: 1px solid var(--mlr-border); margin-bottom: 25px; }
        .mlr-modal-subtitle { font-size: 16px; font-weight: 700; color: var(--mlr-primary); margin-bottom: 20px; display: flex; align-items: center; gap: 8px; }
        .mlr-modal-subtitle .dashicons { font-size: 20px; width: 20px; height: 20px; }

        /* Details Table */
        .mlr-details-table td { padding: 12px 0; border-bottom: 1px dashed var(--mlr-border); }
        .mlr-details-table tr:last-child td { border-bottom: none; }
        .mlr-details-table td:first-child { color: var(--mlr-text-muted); width: 40%; }
        .mlr-details-table td:last-child { font-weight: 600; color: var(--mlr-text-main); }

        /* === END: Ultra Modern Styles === */

    </style>
    <?php
}
?>
