<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_cycle_details', 'mlr_get_cycle_details_callback');

function mlr_get_cycle_details_callback() {
    // Using the standard, secure way to check nonces in admin-ajax calls.
    // The action 'mlr_ajax_nonce_action' must match what's in wp_localize_script.
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
        return;
    }

    $cycle_id = isset($_POST['cycle_id']) ? intval($_POST['cycle_id']) : 0;
    if (!$cycle_id) {
        wp_send_json_error(['message' => 'شناسه سیکل نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';

    $requests = $wpdb->get_results($wpdb->prepare(
        "SELECT id, full_name, national_code, loan_amount, settlement_date 
         FROM {$table_requests} 
         WHERE settlement_cycle_id = %d 
         ORDER BY id ASC",
        $cycle_id
    ));

    if (empty($requests)) {
        wp_send_json_error(['message' => 'هیچ درخواستی در این سیکل یافت نشد.']);
        return;
    }

    ob_start();
    ?>
    <div class="mlr-uni-wrapper">
    <div class="mlr-uni-body" style="padding:15px;">
    <table class="mlr-uni-table">
        <thead>
            <tr>
                <th>شناسه درخواست</th>
                <th>نام متقاضی</th>
                <th>کد ملی</th>
                <th>مبلغ (ریال)</th>
                <th>تاریخ تسویه</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $request): ?>
                <tr class="mlr-request-row" data-id="<?php echo esc_attr($request->id); ?>" style="cursor:pointer;">
                    <td><?php echo esc_html($request->id); ?></td>
                    <td><strong><?php echo esc_html($request->full_name); ?></strong></td>
                    <td><?php echo esc_html($request->national_code); ?></td>
                    <td><?php echo number_format($request->loan_amount); ?></td>
                    <td><?php echo !empty($request->settlement_date) ? (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->settlement_date, 'Y/m/d') : $request->settlement_date) : '—'; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    </div>
    <?php
    $html_output = ob_get_clean();

    wp_send_json_success(['html' => $html_output]);
}