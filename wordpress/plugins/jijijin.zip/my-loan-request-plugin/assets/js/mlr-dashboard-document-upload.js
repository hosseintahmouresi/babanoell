/**
 * Reliable dashboard document uploader.
 * Uploads files one-by-one (chunked when needed), then finalizes the request
 * with signed staged-upload tokens. This avoids total multipart/post_max_size
 * failures and keeps acceptor/applicant behavior identical.
 */
(function($, window) {
    'use strict';

    window.MLRDashboardDocumentUploadActive = true;

    function getConfig(action) {
        if (String(action || '').indexOf('mlr_applicant_') === 0) {
            return window.mlr_applicant_ajax_obj || {};
        }
        return window.mlr_ajax_obj || {};
    }

    function getPortalContext(action) {
        return String(action || '').indexOf('mlr_applicant_') === 0 ? 'applicant' : 'acceptor';
    }

    function getMessageBox($form) {
        var $box = $form.find('.mlr-upload-status').first();
        if (!$box.length) {
            $box = $('<div class="mlr-upload-status" style="display:none; margin:10px 0; padding:10px; border-radius:8px;"></div>');
            $form.prepend($box);
        }
        return $box;
    }

    function showMessage($box, type, message) {
        var styles = {
            loading: {'background':'#e8f4fd', 'color':'#1d4ed8', 'border':'1px solid #93c5fd'},
            success: {'background':'#d4edda', 'color':'#155724', 'border':'1px solid #86efac'},
            error: {'background':'#fde8e8', 'color':'#b91c1c', 'border':'1px solid #fca5a5'}
        };
        $box.show().removeClass('loading success error').addClass(type).css(styles[type] || {}).text(message);
    }

    function normalizeState(state) {
        if (window.MLRFileUpload && typeof window.MLRFileUpload.normalizeDocumentFlowState === 'function') {
            return window.MLRFileUpload.normalizeDocumentFlowState(state);
        }
        var aliases = {
            'نقص مدارک': 'defect_documents',
            'تکمیل مدارک': 'completion_documents',
            'در انتظار مدارک': 'pending_documents',
            'در انتظار تکمیل': 'pending_documents',
            'در انتظار تکمیل مدارک': 'pending_documents'
        };
        state = String(state || '').trim();
        return aliases[state] || state;
    }

    function getState($form) {
        var $body = $form.closest('.mlr-modal-body[data-document-flow-stage]');
        return normalizeState($body.attr('data-document-flow-stage') || $form.attr('data-document-flow-stage') || '');
    }

    function fileArray(input) {
        if (!input || !input.files) return [];
        return Array.prototype.slice.call(input.files);
    }

    function validateFileExtension(file) {
        var name = String(file && file.name || '').toLowerCase();
        return /\.(jpe?g|png|webp|pdf)$/.test(name);
    }

    function uploadFilesSequentially(files, opts, $message, progress) {
        var results = [];
        var chain = Promise.resolve();
        var total = files.length;

        files.forEach(function(file, index) {
            chain = chain.then(function() {
                if (!validateFileExtension(file)) {
                    throw new Error('فرمت فایل «' + file.name + '» مجاز نیست. فقط JPG، PNG، WEBP و PDF مجاز است.');
                }

                showMessage($message, 'loading', 'در حال بارگذاری فایل ' + (progress.offset + index + 1) + ' از ' + progress.total + ': ' + file.name);
                return window.MLRFileUpload.processAndUploadFile(file, opts, function(percent) {
                    showMessage($message, 'loading', 'در حال بارگذاری فایل ' + (progress.offset + index + 1) + ' از ' + progress.total + ' — ' + percent + '٪');
                });
            }).then(function(result) {
                if (!result || !result.url || !result.token) {
                    throw new Error('تأیید امنیتی فایل «' + file.name + '» دریافت نشد. صفحه را تازه‌سازی کنید.');
                }
                results.push({url: result.url, token: result.token});
            });
        });

        return chain.then(function() { return results; });
    }

    function ajaxFinalize(config, data) {
        return new Promise(function(resolve, reject) {
            $.ajax({
                url: config.ajax_url,
                method: 'POST',
                data: data,
                dataType: 'json',
                timeout: 120000
            }).done(function(response) {
                if (response && response.success) {
                    resolve(response);
                    return;
                }
                reject(new Error(response && response.data && response.data.message ? response.data.message : 'ثبت نهایی مدارک انجام نشد.'));
            }).fail(function(xhr) {
                var message = 'ارتباط با سرور برقرار نشد.';
                if (xhr && xhr.status === 413) {
                    message = 'حجم مجموع درخواست از محدودیت سرور بیشتر است. صفحه را تازه‌سازی کرده و دوباره تلاش کنید.';
                } else if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    message = xhr.responseJSON.data.message;
                }
                reject(new Error(message));
            });
        });
    }

    function finishSuccess($form, $message, response) {
        showMessage($message, 'success', response.data && response.data.message ? response.data.message : 'مدارک با موفقیت ثبت شد.');
        $form.find('button, input, textarea, select').prop('disabled', true);
        setTimeout(function() {
            $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200);
            $(document).trigger('mlr:requests:reload');
        }, 1600);
    }

    function resetAfterError($form, $message, error, originalButtonText) {
        showMessage($message, 'error', error && error.message ? error.message : 'خطای نامشخص در بارگذاری مدارک.');
        $form.data('mlr-upload-busy', false);
        $form.find('input, textarea, select').prop('disabled', false);
        $form.find('button[type="submit"]').prop('disabled', false).text(originalButtonText);
    }

    $(document).on('submit', '.mlr-completed-docs-form', function(event) {
        event.preventDefault();
        event.stopImmediatePropagation();

        var $form = $(this);
        if ($form.data('mlr-upload-busy')) return;

        var action = $form.attr('data-upload-action') || $form.find('input[name="action"]').val() || 'mlr_submit_completed_docs';
        var config = getConfig(action);
        var requestId = String($form.find('input[name="request_id"]').val() || '').trim();
        var state = getState($form);
        var $message = getMessageBox($form);
        var $button = $form.find('button[type="submit"]').first();
        var originalButtonText = $button.text();

        if (!config.ajax_url || !config.details_nonce) {
            showMessage($message, 'error', 'تنظیمات ارتباط با سرور بارگذاری نشده است. صفحه را تازه‌سازی کنید.');
            return;
        }
        if (!requestId) {
            showMessage($message, 'error', 'شناسه پرونده یافت نشد.');
            return;
        }
        if (state !== 'completion_documents' && state !== 'pending_documents') {
            showMessage($message, 'error', 'این فرم فقط در مرحله تکمیل مدارک فعال است.');
            return;
        }
        if (!window.MLRFileUpload || typeof window.MLRFileUpload.processAndUploadFile !== 'function') {
            showMessage($message, 'error', 'سرویس بارگذاری امن فایل در دسترس نیست. صفحه را تازه‌سازی کنید.');
            return;
        }

        var checks = fileArray($form.find('input[name="completed_check_files[]"]')[0]);
        var contracts = fileArray($form.find('input[name="signed_contract"]')[0]);
        var invoices = fileArray($form.find('input[name="signed_invoice"]')[0]);
        var others = fileArray($form.find('input[name="other_completed_files[]"]')[0]);

        if (!checks.length) {
            showMessage($message, 'error', 'حداقل یک تصویر یا فایل چک انتخاب کنید.');
            return;
        }
        if (contracts.length !== 1) {
            showMessage($message, 'error', 'فایل قرارداد امضا‌شده را انتخاب کنید.');
            return;
        }
        if (invoices.length !== 1) {
            showMessage($message, 'error', 'فایل فاکتور امضا/مهر‌شده را انتخاب کنید.');
            return;
        }
        if (checks.length > 20 || others.length > 20) {
            showMessage($message, 'error', 'حداکثر ۲۰ فایل در هر بخش چندفایلی مجاز است.');
            return;
        }

        var totalFiles = checks.length + contracts.length + invoices.length + others.length;
        var offset = 0;
        var commonOpts = {
            ajax_url: config.ajax_url,
            nonce: config.details_nonce,
            context: 'loan_request',
            request_id: requestId,
            portal_context: getPortalContext(action),
            document_flow_state: state
        };
        var staged = {};

        $form.data('mlr-upload-busy', true);
        $form.find('input, textarea, select').prop('disabled', true);
        $button.prop('disabled', true).text('در حال ارسال مدارک...');

        uploadFilesSequentially(checks, $.extend({}, commonOpts, {field_key: 'completed_check_files'}), $message, {offset: offset, total: totalFiles})
            .then(function(result) {
                staged.completed_check_uploads = result;
                offset += checks.length;
                return uploadFilesSequentially(contracts, $.extend({}, commonOpts, {field_key: 'signed_contract'}), $message, {offset: offset, total: totalFiles});
            })
            .then(function(result) {
                staged.signed_contract_uploads = result;
                offset += contracts.length;
                return uploadFilesSequentially(invoices, $.extend({}, commonOpts, {field_key: 'signed_invoice'}), $message, {offset: offset, total: totalFiles});
            })
            .then(function(result) {
                staged.signed_invoice_uploads = result;
                offset += invoices.length;
                return uploadFilesSequentially(others, $.extend({}, commonOpts, {field_key: 'other_completed_files'}), $message, {offset: offset, total: totalFiles});
            })
            .then(function(result) {
                staged.other_completed_uploads = result;
                showMessage($message, 'loading', 'بارگذاری فایل‌ها کامل شد؛ در حال ثبت نهایی پرونده...');
                return ajaxFinalize(config, {
                    action: action,
                    nonce: config.details_nonce,
                    request_id: requestId,
                    document_flow_state: state,
                    completed_check_uploads: JSON.stringify(staged.completed_check_uploads || []),
                    signed_contract_uploads: JSON.stringify(staged.signed_contract_uploads || []),
                    signed_invoice_uploads: JSON.stringify(staged.signed_invoice_uploads || []),
                    other_completed_uploads: JSON.stringify(staged.other_completed_uploads || [])
                });
            })
            .then(function(response) {
                finishSuccess($form, $message, response);
            })
            .catch(function(error) {
                resetAfterError($form, $message, error, originalButtonText);
            });
    });

    $(document).on('submit', '.mlr-universal-upload-form', function(event) {
        event.preventDefault();
        event.stopImmediatePropagation();

        var $form = $(this);
        if ($form.data('mlr-upload-busy')) return;

        var action = $form.attr('data-upload-action') || 'mlr_upload_additional_docs';
        var config = getConfig(action);
        var requestId = String($form.find('input[name="request_id"]').val() || '').trim();
        var state = getState($form);
        var $message = getMessageBox($form);
        var $button = $form.find('button[type="submit"]').first();
        var originalButtonText = $button.text();
        var input = $form.find('input[type="file"]').first()[0];
        var files = fileArray(input);

        if (!config.ajax_url || !config.details_nonce) {
            showMessage($message, 'error', 'تنظیمات ارتباط با سرور بارگذاری نشده است. صفحه را تازه‌سازی کنید.');
            return;
        }
        if (!requestId) {
            showMessage($message, 'error', 'شناسه پرونده یافت نشد.');
            return;
        }
        if (state !== 'defect_documents') {
            showMessage($message, 'error', 'این فرم فقط در مرحله نقص مدارک فعال است.');
            return;
        }
        if (!files.length) {
            showMessage($message, 'error', 'لطفاً حداقل یک فایل انتخاب کنید.');
            return;
        }
        if (files.length > 20) {
            showMessage($message, 'error', 'حداکثر ۲۰ فایل قابل ارسال است.');
            return;
        }
        if (!window.MLRFileUpload || typeof window.MLRFileUpload.processAndUploadFile !== 'function') {
            showMessage($message, 'error', 'سرویس بارگذاری امن فایل در دسترس نیست. صفحه را تازه‌سازی کنید.');
            return;
        }

        $form.data('mlr-upload-busy', true);
        $form.find('input, textarea, select').prop('disabled', true);
        $button.prop('disabled', true).text('در حال ارسال مدارک...');

        uploadFilesSequentially(files, {
            ajax_url: config.ajax_url,
            nonce: config.details_nonce,
            context: 'loan_request',
            field_key: 'additional_documents',
            request_id: requestId,
            portal_context: getPortalContext(action),
            document_flow_state: state
        }, $message, {offset: 0, total: files.length})
            .then(function(result) {
                showMessage($message, 'loading', 'بارگذاری فایل‌ها کامل شد؛ در حال ثبت رفع نقص...');
                return ajaxFinalize(config, {
                    action: action,
                    nonce: config.details_nonce,
                    request_id: requestId,
                    document_flow_state: state,
                    user_note: $form.find('textarea[name="user_note"]').val() || '',
                    additional_uploads: JSON.stringify(result)
                });
            })
            .then(function(response) {
                finishSuccess($form, $message, response);
            })
            .catch(function(error) {
                resetAfterError($form, $message, error, originalButtonText);
            });
    });

})(jQuery, window);
