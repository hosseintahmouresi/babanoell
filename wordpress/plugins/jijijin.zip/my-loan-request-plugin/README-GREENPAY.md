# GreenPay Integration — Babanoell 8.4.6.27

این Integration به صورت افزایشی طراحی شده و گردش اصلی پرونده بابانوئل را کنترل نمی‌کند.

## انتخاب پرونده‌های مشمول
پیش‌فرض همه پرونده‌ها «غیرمشمول GreenPay» است. مدیر از صفحه «مدیریت GreenPay» می‌تواند هر پرونده را تکی یا گروهی مشمول/غیرمشمول کند. فقط پرونده‌ای که صراحتاً مشمول شده باشد اجازه ورود به صف مالی را دارد.

پرونده‌های دارای تراکنش `success`، `processing`، `awaiting_otp` یا `unknown` برای حفظ سابقه مالی قابل خروج از GreenPay نیستند.

## Trigger
وقتی یک پرونده **مشمول** واقعاً وارد `تأیید مدارک` شود، در صورت فعال بودن GreenPay، تراکنش مستقل در صف قرار می‌گیرد. مسیرهای مدیریت ادمین، کارشناس بانک، Secret Editor و بارگذاری مدارک نهایی پوشش داده شده‌اند. اگر پرونده قبل از شروع ارسال مالی به مراحل قبلی برگردد، job صف‌شده لغو می‌شود؛ حرکت به «اعطا شده» باعث حذف سابقه یا لغو تراکنش درحال‌انتظار نمی‌شود.

## مبلغ
مبلغ ارسال‌شده به GreenPay دقیقاً `facility_amount` (فیلد «مبلغ تسهیلات») و با واحد ریال است. فقط برای پرونده‌های قدیمی که `facility_amount` ندارند از `loan_amount` استفاده می‌شود. هیچ تبدیل x10 انجام نمی‌شود.

## ایزوله بودن
- خطای GreenPay وضعیت پرونده را Rollback یا تغییر نمی‌دهد.
- جدول اصلی `loan_requests` برای GreenPay تغییر نکرده است.
- وضعیت تراکنش‌ها در جدول مستقل `mlr_greenpay_transactions` نگهداری می‌شود.
- `request_id` و `ref_number` یکتا هستند تا دوبارکسر جلوگیری شود.

## Safe by default
بعد از آپدیت، GreenPay به صورت پیش‌فرض غیرفعال است. ابتدا از منوی «تنظیمات API» Credentialها را بررسی و «تست اتصال» را اجرا کنید، سپس قابلیت را فعال کنید.

هیچ پرونده‌ای صرفاً با فعال شدن GreenPay مشمول نمی‌شود. ابتدا پرونده‌ها را در صفحه «مدیریت GreenPay» انتخاب کنید. برای پرونده‌های مشمولی که هم‌اکنون در `تأیید مدارک` هستند، دکمه «صف‌بندی مشمول‌های آماده» وجود دارد.

## Sandbox
پیش‌فرض‌های سناریوی تست تحویلی:
- FromPocketNumber: `1262010000002551`
- ToPocketNumber: خالی
- OTP: `123456`
- Password: در صورت خالی بودن در Test برابر `1`
- ارسال OTP در Test به صورت پیش‌فرض Bypass است و قابل تغییر است.

## Production
در محیط عملیاتی HTTPS اجباری است و Pocket تستی مجاز نیست. بر اساس API نمونه‌ی تحویلی، OTP واقعی ارسال می‌شود و مدیر از صفحه تراکنش‌ها OTP را برای تکمیل کسری وارد می‌کند.

اگر GreenPay برای هر مشتری Pocket متفاوت دارد، نسخه فعلی به صورت پیش‌فرض از FromPocket تنظیمات استفاده می‌کند چون در مستند/پلاگین تحویلی API قابل اتکایی برای تبدیل کدملی/موبایل به Pocket وجود نداشت. برای اتصال چنین Mappingای بدون دست‌زدن به Core می‌توان از Filter زیر استفاده کرد:

```php
add_filter('mlr_greenpay_from_pocket_number', function ($default, $request, $settings) {
    // Return the verified 16-digit GreenPay pocket for this request.
    return $default;
}, 10, 3);
```

## Timeout / نتیجه نامشخص
اگر درخواست انتقال با Timeout، خطای Transport، 5xx یا پاسخ 2xx مبهم مواجه شود، تراکنش `unknown` می‌شود و خودکار Retry نمی‌شود تا دوبارکسر رخ ندهد. پلاگین مرجع تحویلی API استعلام تراکنش ارائه نکرده است؛ قبل از Retry چنین رکوردی باید از GreenPay استعلام شود.

## WP-Cron
پردازش خودکار صف به WP-Cron متکی است. اگر `DISABLE_WP_CRON` فعال است باید Cron واقعی سرور `wp-cron.php` را اجرا کند. در صفحه مدیریت GreenPay برای این وضعیت هشدار نمایش داده می‌شود.

## حفظ تنظیمات API
- ورودی خالی Password/API Key گرین‌پی مقدار ذخیره‌شده را پاک نمی‌کند.
- Client Secret و سایر Credentialهای شاهکار نیز با ارسال فیلد خالی پاک نمی‌شوند.
- Snapshot ثانویه‌ی غیر-autoload برای تنظیمات API نگهداری و در آپدیت‌های بعدی بازیابی می‌شود.
- قبل/بعد از WordPress Plugin Upgrade نیز Snapshot/Restore اجرا می‌شود.

## نکته 1023
عدد `1023` در پلاگین مرجع GreenPay به هیچ نام پارامتر یا Endpoint مشخصی متصل نبود، بنابراین عمداً Payload ناشناخته/حدسی به درخواست مالی اضافه نشده است. اگر GreenPay قرارداد رسمی این پارامتر را اعلام کند باید بر اساس همان Contract اضافه شود.

## Generic online payment callback (8.4.6.27)
A provider-independent callback endpoint is available at `/wp-json/mlr/v1/payment-callback`.
It is only a stable integration point and does not modify financial state until a concrete gateway handler with server-to-server verification is added.
