<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', 'mlr_greenpay_add_admin_menu', 30);
function mlr_greenpay_add_admin_menu() {
    add_submenu_page(
        'mlr-loan-requests',
        'مدیریت GreenPay',
        'مدیریت GreenPay',
        'manage_options',
        'mlr-greenpay-transactions',
        'mlr_greenpay_transactions_page'
    );
}

function mlr_greenpay_status_label($status) {
    $map = [
        'not_started'    => 'کسر نشده',
        'queued'         => 'کسر نشده / در صف',
        'processing'     => 'در حال کسر',
        'awaiting_otp'   => 'کسر نشده / در انتظار OTP',
        'success'        => 'کسر شده',
        'failed'         => 'کسر نشده / خطا',
        'unknown'        => 'نامشخص / نیازمند استعلام',
        'cancelled'      => 'کسر نشده / لغو شده',
        'not_applicable' => 'مشمول GreenPay نیست',
    ];
    return $map[$status] ?? ($status ?: 'کسر نشده');
}

function mlr_greenpay_status_badge_style($status, $eligible) {
    if (!$eligible) {
        return 'background:#f0f0f1;color:#50575e;border:1px solid #c3c4c7;';
    }
    $map = [
        'success'      => 'background:#edfaef;color:#116329;border:1px solid #8fd19e;',
        'processing'   => 'background:#eef6ff;color:#135e96;border:1px solid #9ec5e5;',
        'queued'       => 'background:#fff8e5;color:#8a5a00;border:1px solid #e7c66b;',
        'awaiting_otp' => 'background:#fff8e5;color:#8a5a00;border:1px solid #e7c66b;',
        'failed'       => 'background:#fcf0f1;color:#b32d2e;border:1px solid #e5a5a8;',
        'unknown'      => 'background:#fcf0f1;color:#8a2424;border:1px solid #dba0a0;',
    ];
    return $map[$status] ?? 'background:#f6f7f7;color:#3c434a;border:1px solid #c3c4c7;';
}

function mlr_greenpay_set_admin_notice($type, $message) {
    set_transient('mlr_greenpay_notice_' . get_current_user_id(), [
        'type' => $type,
        'message' => $message,
    ], MINUTE_IN_SECONDS);
}

function mlr_greenpay_get_admin_notice() {
    $key = 'mlr_greenpay_notice_' . get_current_user_id();
    $notice = get_transient($key);
    delete_transient($key);
    return is_array($notice) ? $notice : null;
}

function mlr_greenpay_admin_selected_ids() {
    $ids = [];
    if (!empty($_POST['request_ids']) && is_array($_POST['request_ids'])) {
        $ids = array_map('absint', wp_unslash($_POST['request_ids']));
    }
    if (!empty($_POST['request_id'])) {
        $ids[] = absint($_POST['request_id']);
    }
    return array_values(array_unique(array_filter($ids)));
}

add_action('admin_post_mlr_greenpay_admin_action', 'mlr_greenpay_admin_action_handler');
function mlr_greenpay_admin_action_handler() {
    if (!current_user_can('manage_options')) {
        wp_die('دسترسی غیرمجاز.');
    }
    check_admin_referer('mlr_greenpay_admin_action');

    $operation = sanitize_key($_POST['operation'] ?? '');
    $request_id = absint($_POST['request_id'] ?? 0);
    $redirect = admin_url('admin.php?page=mlr-greenpay-transactions');

    if (in_array($operation, ['mark_eligible','mark_ineligible'], true)) {
        $ids = mlr_greenpay_admin_selected_ids();
        if (!$ids) {
            mlr_greenpay_set_admin_notice('error', 'هیچ پرونده‌ای انتخاب نشده است.');
        } else {
            $want_eligible = $operation === 'mark_eligible';
            $ok = 0;
            $errors = [];
            foreach ($ids as $id) {
                $result = mlr_greenpay_set_eligibility($id, $want_eligible, 'admin_selection');
                if (is_wp_error($result)) {
                    $errors[] = '#' . $id . ': ' . $result->get_error_message();
                } else {
                    $ok++;
                }
            }
            $message = number_format_i18n($ok) . ' پرونده به‌روزرسانی شد.';
            if ($errors) {
                $message .= ' خطا: ' . implode(' | ', array_slice($errors, 0, 5));
                mlr_greenpay_set_admin_notice('error', $message);
            } else {
                mlr_greenpay_set_admin_notice('success', $message);
            }
        }
    } elseif ($operation === 'queue_ready') {
        global $wpdb;
        $requests_table = $wpdb->prefix . 'loan_requests';
        $tx_table = mlr_greenpay_transactions_table();
        $variants = function_exists('mlr_get_status_sql_variants') ? mlr_get_status_sql_variants('تأیید مدارک') : ['تأیید مدارک','تایید مدارک'];
        $variants = array_values(array_unique(array_filter(array_map('strval', (array) $variants))));
        $placeholders = implode(',', array_fill(0, count($variants), '%s'));
        $sql = $wpdb->prepare(
            "SELECT r.id FROM {$requests_table} r INNER JOIN {$tx_table} g ON g.request_id = r.id
             WHERE g.eligible = 1 AND g.status IN ('not_started','cancelled')
             AND TRIM(COALESCE(r.status,'')) IN ({$placeholders}) ORDER BY r.id ASC LIMIT 500",
            $variants
        );
        $ids = $wpdb->get_col($sql);
        $queued = 0;
        foreach ((array) $ids as $id) {
            if (mlr_greenpay_queue_request($id, 'admin_queue_ready')) {
                $queued++;
            }
        }
        mlr_greenpay_set_admin_notice('success', number_format_i18n($queued) . ' پرونده مشمول و آماده در صف کسری قرار گرفت.');
    } elseif ($operation === 'queue_now') {
        if (mlr_greenpay_queue_request($request_id, 'admin_queue_now')) {
            mlr_greenpay_set_admin_notice('success', 'پرونده در صف کسری GreenPay قرار گرفت.');
        } else {
            mlr_greenpay_set_admin_notice('error', 'پرونده باید مشمول GreenPay، در مرحله مناسب و بدون تراکنش فعال/موفق باشد.');
        }
    } elseif ($operation === 'confirm_otp') {
        $result = mlr_greenpay_confirm_with_admin_otp($request_id, $_POST['otp'] ?? '');
        if (is_wp_error($result)) {
            mlr_greenpay_set_admin_notice('error', $result->get_error_message());
        } else {
            mlr_greenpay_set_admin_notice('success', 'کسری GreenPay با موفقیت نهایی شد.');
        }
    } elseif ($operation === 'retry') {
        if (mlr_greenpay_retry_failed_request($request_id)) {
            mlr_greenpay_set_admin_notice('success', 'تراکنش برای تلاش مجدد در صف قرار گرفت.');
        } else {
            mlr_greenpay_set_admin_notice('error', 'فقط پرونده مشمول با تراکنش ناموفق قطعی قابل تلاش مجدد است.');
        }
    } elseif ($operation === 'resend_otp') {
        if (mlr_greenpay_resend_otp($request_id)) {
            mlr_greenpay_set_admin_notice('success', 'درخواست ارسال مجدد OTP در صف قرار گرفت.');
        } else {
            mlr_greenpay_set_admin_notice('error', 'این تراکنش مشمول GreenPay و در وضعیت انتظار OTP نیست.');
        }
    } elseif ($operation === 'process_now') {
        mlr_greenpay_process_debit_callback($request_id);
        mlr_greenpay_set_admin_notice('success', 'پردازش اجرا شد؛ نتیجه را در جدول بررسی کنید.');
    } elseif ($operation === 'test_connection') {
        $settings = mlr_greenpay_get_settings();
        $api = new MLR_GreenPay_API($settings);
        $token = $api->get_token();
        if (is_wp_error($token)) {
            mlr_greenpay_set_admin_notice('error', 'تست اتصال ناموفق: ' . $token->get_error_message());
        } else {
            mlr_greenpay_set_admin_notice('success', 'اتصال و دریافت توکن GreenPay با موفقیت انجام شد.');
        }
    }

    wp_safe_redirect($redirect);
    exit;
}

function mlr_greenpay_transactions_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم را ندارید.');
    }

    global $wpdb;
    mlr_greenpay_maybe_install_schema();
    $tx_table = mlr_greenpay_transactions_table();
    $requests_table = $wpdb->prefix . 'loan_requests';
    $settings = mlr_greenpay_get_settings();
    $notice = mlr_greenpay_get_admin_notice();

    $scope = sanitize_key($_GET['gp_scope'] ?? '');
    $loan_status = sanitize_text_field(wp_unslash($_GET['loan_status'] ?? ''));
    $search = sanitize_text_field(wp_unslash($_GET['s'] ?? ''));

    $where = ['1=1'];
    $args = [];
    if ($scope === 'eligible') {
        $where[] = 'COALESCE(t.eligible,0) = 1';
    } elseif ($scope === 'not_eligible') {
        $where[] = 'COALESCE(t.eligible,0) = 0';
    } elseif ($scope === 'debited') {
        $where[] = "COALESCE(t.eligible,0) = 1 AND t.status = 'success'";
    } elseif ($scope === 'not_debited') {
        $where[] = "COALESCE(t.eligible,0) = 1 AND COALESCE(t.status,'not_started') <> 'success'";
    } elseif ($scope === 'attention') {
        $where[] = "COALESCE(t.eligible,0) = 1 AND t.status IN ('failed','unknown','awaiting_otp')";
    }
    if ($loan_status !== '') {
        $variants = function_exists('mlr_get_status_sql_variants') ? mlr_get_status_sql_variants($loan_status) : [$loan_status];
        $variants = array_values(array_unique(array_filter(array_map('strval', (array) $variants))));
        if ($variants) {
            $where[] = 'TRIM(COALESCE(r.status,\'\')) IN (' . implode(',', array_fill(0, count($variants), '%s')) . ')';
            foreach ($variants as $variant) {
                $args[] = $variant;
            }
        }
    }
    if ($search !== '') {
        $where[] = '(CAST(r.id AS CHAR) = %s OR r.full_name LIKE %s OR r.national_code LIKE %s)';
        $args[] = $search;
        $args[] = '%' . $wpdb->esc_like($search) . '%';
        $args[] = '%' . $wpdb->esc_like($search) . '%';
    }

    $sql = "SELECT r.id, r.full_name, r.national_code, r.status AS loan_status, r.loan_amount, r.facility_amount,
                   t.id AS tx_id, t.eligible, t.status AS gp_status, t.amount AS gp_amount, t.ref_number,
                   t.provider_reference, t.from_pocket, t.last_http_code, t.last_error, t.updated_at, t.debited_at
            FROM {$requests_table} r
            LEFT JOIN {$tx_table} t ON t.request_id = r.id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY r.id DESC LIMIT 300";
    if ($args) {
        $sql = $wpdb->prepare($sql, $args);
    }
    $rows = $wpdb->get_results($sql);

    $loan_statuses = ['در حال بررسی','نقص مدارک','رد شده','تأیید کارشناس','تکمیل مدارک','تأیید مدارک','اعطا شده'];
    ?>
    <div class="wrap mlr-admin-wrap" dir="rtl">
        <h1>مدیریت GreenPay</h1>
        <p>GreenPay یک قابلیت مستقل و اختیاری است. <strong>هیچ پرونده‌ای تا زمانی که صراحتاً «مشمول GreenPay» نشود وارد کسری نخواهد شد.</strong> مبلغ کسری همان «مبلغ تسهیلات» پرونده است.</p>

        <?php if ($notice): ?>
            <div class="notice notice-<?php echo esc_attr($notice['type'] === 'error' ? 'error' : 'success'); ?> is-dismissible"><p><?php echo esc_html($notice['message']); ?></p></div>
        <?php endif; ?>

        <?php if (empty($settings['enabled'])): ?>
            <div class="notice notice-warning"><p>اتصال GreenPay غیرفعال است. انتخاب «مشمول» ذخیره می‌شود ولی تا فعال‌سازی اتصال، کسری ارسال نمی‌شود.</p></div>
        <?php endif; ?>
        <?php if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON): ?>
            <div class="notice notice-warning"><p>WP-Cron غیرفعال است. برای پردازش خودکار صف باید Cron واقعی سرور wp-cron.php را اجرا کند.</p></div>
        <?php endif; ?>

        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:14px 0;align-items:center;">
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=mlr-api-settings')); ?>">تنظیمات API</a>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;">
                <input type="hidden" name="action" value="mlr_greenpay_admin_action">
                <input type="hidden" name="operation" value="test_connection">
                <?php wp_nonce_field('mlr_greenpay_admin_action'); ?>
                <button type="submit" class="button">تست اتصال GreenPay</button>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;" onsubmit="return confirm('فقط پرونده‌های مشمول GreenPay که اکنون در وضعیت تأیید مدارک و هنوز کسر نشده‌اند صف‌بندی می‌شوند. ادامه می‌دهید؟');">
                <input type="hidden" name="action" value="mlr_greenpay_admin_action">
                <input type="hidden" name="operation" value="queue_ready">
                <?php wp_nonce_field('mlr_greenpay_admin_action'); ?>
                <button type="submit" class="button button-primary">صف‌بندی مشمول‌های آماده</button>
            </form>
        </div>

        <form method="get" style="margin:12px 0;padding:12px;background:#fff;border:1px solid #dcdcde;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <input type="hidden" name="page" value="mlr-greenpay-transactions">
            <input type="search" name="s" placeholder="شناسه، نام یا کد ملی" value="<?php echo esc_attr($search); ?>">
            <select name="loan_status">
                <option value="">همه وضعیت‌های پرونده</option>
                <?php foreach ($loan_statuses as $st): ?><option value="<?php echo esc_attr($st); ?>" <?php selected($loan_status, $st); ?>><?php echo esc_html($st); ?></option><?php endforeach; ?>
            </select>
            <select name="gp_scope">
                <option value="">همه پرونده‌ها</option>
                <option value="eligible" <?php selected($scope, 'eligible'); ?>>فقط مشمول GreenPay</option>
                <option value="not_eligible" <?php selected($scope, 'not_eligible'); ?>>فقط غیرمشمول</option>
                <option value="debited" <?php selected($scope, 'debited'); ?>>فقط کسر شده</option>
                <option value="not_debited" <?php selected($scope, 'not_debited'); ?>>مشمول و کسر نشده</option>
                <option value="attention" <?php selected($scope, 'attention'); ?>>نیازمند رسیدگی</option>
            </select>
            <button class="button">فیلتر</button>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=mlr-greenpay-transactions')); ?>">پاک کردن فیلتر</a>
        </form>

        <form id="mlr-gp-bulk-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:10px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap;" onsubmit="var op=this.querySelector('[name=operation]').value; return op !== 'mark_eligible' || confirm('پرونده‌های انتخاب‌شده مشمول GreenPay می‌شوند؛ مواردی که هم‌اکنون در «تأیید مدارک» هستند ممکن است بلافاصله وارد صف کسری شوند. ادامه می‌دهید؟');">
            <input type="hidden" name="action" value="mlr_greenpay_admin_action">
            <?php wp_nonce_field('mlr_greenpay_admin_action'); ?>
            <select name="operation" required>
                <option value="">عملیات گروهی…</option>
                <option value="mark_eligible">مشمول GreenPay شود</option>
                <option value="mark_ineligible">از GreenPay خارج شود</option>
            </select>
            <button class="button">اعمال به پرونده‌های انتخاب‌شده</button>
            <span class="description">پرونده کسرشده، درحال‌پردازش یا با وضعیت نامشخص برای حفظ سابقه مالی قابل خروج نیست.</span>
        </form>

        <div style="overflow:auto;background:#fff;border:1px solid #dcdcde;border-radius:6px;">
            <table class="widefat striped" style="min-width:1250px;">
                <thead><tr>
                    <th style="width:36px;"><input type="checkbox" id="mlr-gp-select-all"></th>
                    <th>پرونده</th><th>متقاضی</th><th>مبلغ تسهیلات</th><th>وضعیت پرونده</th><th>مشمول GreenPay</th><th>وضعیت کیف پول</th><th>مرجع / جزئیات</th><th>آخرین پیام</th><th>عملیات</th>
                </tr></thead>
                <tbody>
                <?php if (!$rows): ?>
                    <tr><td colspan="10" style="text-align:center;padding:28px;">پرونده‌ای مطابق فیلتر پیدا نشد.</td></tr>
                <?php else: foreach ($rows as $row):
                    $eligible = (int) ($row->eligible ?? 0) === 1;
                    $gp_status = $row->gp_status ?: ($eligible ? 'not_started' : 'not_applicable');
                    $facility = ($row->facility_amount !== null && $row->facility_amount !== '') ? (float) $row->facility_amount : (float) $row->loan_amount;
                    $snapshot = $row->gp_amount !== null ? (float) $row->gp_amount : $facility;
                    $locked = $eligible && in_array($gp_status, ['success','processing','awaiting_otp','unknown'], true);
                    $docs_approved = mlr_greenpay_status_is_docs_approved($row->loan_status);
                    ?>
                    <tr>
                        <td><input form="mlr-gp-bulk-form" class="mlr-gp-row-check" type="checkbox" name="request_ids[]" value="<?php echo esc_attr($row->id); ?>"></td>
                        <td><strong>#<?php echo esc_html($row->id); ?></strong><br><a href="<?php echo esc_url(admin_url('admin.php?page=mlr-loan-requests&s=' . absint($row->id))); ?>">نمایش در پرونده‌ها</a></td>
                        <td><?php echo esc_html($row->full_name ?: '—'); ?><br><small><?php echo esc_html($row->national_code ?: ''); ?></small></td>
                        <td><strong><?php echo esc_html(number_format($facility)); ?></strong> ریال<?php if ($row->tx_id && !in_array($gp_status, ['not_started','not_applicable','cancelled'], true) && (float)$snapshot !== (float)$facility): ?><br><small style="color:#996800;">مبلغ Snapshot تراکنش: <?php echo esc_html(number_format($snapshot)); ?></small><?php endif; ?></td>
                        <td><?php echo esc_html($row->loan_status ?: '—'); ?></td>
                        <td>
                            <?php if ($eligible): ?>
                                <span style="display:inline-block;padding:4px 8px;border-radius:14px;background:#edfaef;color:#116329;border:1px solid #8fd19e;">✓ مشمول</span>
                            <?php else: ?>
                                <span style="display:inline-block;padding:4px 8px;border-radius:14px;background:#f0f0f1;color:#50575e;border:1px solid #c3c4c7;">— غیرمشمول</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span style="display:inline-block;padding:4px 8px;border-radius:14px;<?php echo esc_attr(mlr_greenpay_status_badge_style($gp_status, $eligible)); ?>"><strong><?php echo esc_html(mlr_greenpay_status_label($gp_status)); ?></strong></span>
                            <?php if ($gp_status === 'success' && !empty($row->debited_at)): ?><br><small><?php echo esc_html(function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($row->debited_at, 'Y/m/d H:i') : $row->debited_at); ?></small><?php endif; ?>
                        </td>
                        <td class="ltr" style="direction:ltr;text-align:left;">
                            <?php echo $row->ref_number ? esc_html($row->ref_number) : '—'; ?>
                            <?php if (!empty($row->provider_reference)): ?><br><small><?php echo esc_html($row->provider_reference); ?></small><?php endif; ?>
                            <?php if (!empty($row->from_pocket)): ?><br><small><?php echo esc_html(mlr_greenpay_mask_pocket($row->from_pocket)); ?></small><?php endif; ?>
                            <?php if ($row->last_http_code !== null): ?><br><small>HTTP <?php echo esc_html($row->last_http_code); ?></small><?php endif; ?>
                        </td>
                        <td style="max-width:280px;white-space:normal;"><?php echo esc_html($row->last_error ?: ($gp_status === 'success' ? 'کسری با موفقیت انجام شده است.' : '—')); ?></td>
                        <td style="min-width:270px;">
                            <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
                                <?php if (!$eligible): ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('این پرونده مشمول GreenPay شود؟ اگر اکنون در «تأیید مدارک» باشد، ممکن است بلافاصله وارد صف کسری شود.');">
                                        <input type="hidden" name="action" value="mlr_greenpay_admin_action"><input type="hidden" name="operation" value="mark_eligible"><input type="hidden" name="request_id" value="<?php echo esc_attr($row->id); ?>"><?php wp_nonce_field('mlr_greenpay_admin_action'); ?><button class="button button-small button-primary">مشمول GreenPay شود</button>
                                    </form>
                                <?php elseif (!$locked): ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('این پرونده از فرآیند GreenPay خارج شود؟');">
                                        <input type="hidden" name="action" value="mlr_greenpay_admin_action"><input type="hidden" name="operation" value="mark_ineligible"><input type="hidden" name="request_id" value="<?php echo esc_attr($row->id); ?>"><?php wp_nonce_field('mlr_greenpay_admin_action'); ?><button class="button button-small">خروج از GreenPay</button>
                                    </form>
                                <?php endif; ?>

                                <?php if ($eligible && in_array($gp_status, ['not_started','cancelled'], true) && $docs_approved): ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                        <input type="hidden" name="action" value="mlr_greenpay_admin_action"><input type="hidden" name="operation" value="queue_now"><input type="hidden" name="request_id" value="<?php echo esc_attr($row->id); ?>"><?php wp_nonce_field('mlr_greenpay_admin_action'); ?><button class="button button-small">صف کسری</button>
                                    </form>
                                <?php elseif ($eligible && $gp_status === 'queued'): ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                        <input type="hidden" name="action" value="mlr_greenpay_admin_action"><input type="hidden" name="operation" value="process_now"><input type="hidden" name="request_id" value="<?php echo esc_attr($row->id); ?>"><?php wp_nonce_field('mlr_greenpay_admin_action'); ?><button class="button button-small">پردازش اکنون</button>
                                    </form>
                                <?php elseif ($eligible && $gp_status === 'failed'): ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                        <input type="hidden" name="action" value="mlr_greenpay_admin_action"><input type="hidden" name="operation" value="retry"><input type="hidden" name="request_id" value="<?php echo esc_attr($row->id); ?>"><?php wp_nonce_field('mlr_greenpay_admin_action'); ?><button class="button button-small">تلاش مجدد</button>
                                    </form>
                                <?php elseif ($eligible && $gp_status === 'awaiting_otp'): ?>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:4px;align-items:center;">
                                        <input type="hidden" name="action" value="mlr_greenpay_admin_action"><input type="hidden" name="operation" value="confirm_otp"><input type="hidden" name="request_id" value="<?php echo esc_attr($row->id); ?>"><?php wp_nonce_field('mlr_greenpay_admin_action'); ?><input type="text" name="otp" maxlength="6" inputmode="numeric" class="small-text ltr" placeholder="OTP" required><button class="button button-small button-primary">تأیید کسری</button>
                                    </form>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                        <input type="hidden" name="action" value="mlr_greenpay_admin_action"><input type="hidden" name="operation" value="resend_otp"><input type="hidden" name="request_id" value="<?php echo esc_attr($row->id); ?>"><?php wp_nonce_field('mlr_greenpay_admin_action'); ?><button class="button button-small">ارسال مجدد OTP</button>
                                    </form>
                                <?php elseif ($eligible && $gp_status === 'unknown'): ?>
                                    <span style="color:#b32d2e;">برای جلوگیری از دوبارکسر، Retry غیرفعال است؛ ابتدا از GreenPay استعلام شود.</span>
                                <?php elseif ($eligible && $gp_status === 'success'): ?>
                                    <span style="color:#116329;font-weight:600;">✓ کسری نهایی شده</span>
                                <?php elseif ($eligible && !$docs_approved): ?>
                                    <span class="description">منتظر ورود پرونده به «تأیید مدارک»</span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <p class="description" style="margin-top:10px;">حداکثر ۳۰۰ پرونده مطابق فیلتر نمایش داده می‌شود. برای پرونده‌های قدیمی از جستجو یا فیلتر استفاده کنید.</p>
    </div>
    <script>
    (function(){
        var all = document.getElementById('mlr-gp-select-all');
        if (!all) return;
        all.addEventListener('change', function(){
            document.querySelectorAll('.mlr-gp-row-check').forEach(function(cb){ cb.checked = all.checked; });
        });
    })();
    </script>
    <?php
}
