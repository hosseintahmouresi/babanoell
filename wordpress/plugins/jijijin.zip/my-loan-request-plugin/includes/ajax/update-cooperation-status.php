<?php
if (!defined('ABSPATH')) { exit; }

add_action('wp_ajax_mlr_update_cooperation_status', 'mlr_update_cooperation_status_callback');

function mlr_update_cooperation_status_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $new_status = isset($_POST['status']) ? sanitize_text_field(wp_unslash($_POST['status'])) : '';
    if (!$request_id || $new_status === '') {
        wp_send_json_error(['message' => 'اطلاعات نامعتبر است.']);
        return;
    }

    $allowed_statuses = mlr_get_cooperation_statuses();
    if (!in_array($new_status, $allowed_statuses, true)) {
        wp_send_json_error(['message' => 'وضعیت انتخاب شده مجاز نیست.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cooperation_requests';
    if (function_exists('mlr_table_supports_transactions') && !mlr_table_supports_transactions($table_name)) {
        wp_send_json_error(['message' => 'موتور جدول درخواست‌های همکاری از بروزرسانی اتمیک پشتیبانی نمی‌کند. ابتدا ساختار دیتابیس را بررسی کنید.']);
        return;
    }

    if ($wpdb->query('START TRANSACTION') === false) {
        wp_send_json_error(['message' => 'شروع تراکنش بروزرسانی وضعیت ممکن نشد. هیچ تغییری ثبت نشد.']);
        return;
    }
    $current_request = $wpdb->get_row($wpdb->prepare(
        "SELECT id, status, contract_token FROM `{$table_name}` WHERE id = %d FOR UPDATE",
        $request_id
    ));
    if (!$current_request) {
        $wpdb->query('ROLLBACK');
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    $data_to_update = ['status' => $new_status];
    $token = $current_request->contract_token;
    $new_token_generated = false;

    if ($new_status === 'تایید مدارک' && empty($token)) {
        // Same strong token format used by new cooperation submissions (256 bits / 64 hex chars).
        do {
            $token = bin2hex(random_bytes(32));
        } while ($wpdb->get_var($wpdb->prepare("SELECT id FROM `{$table_name}` WHERE contract_token = %s", $token)));
        $data_to_update['contract_token'] = $token;
        $new_token_generated = true;
    }

    $updated = $wpdb->update($table_name, $data_to_update, ['id' => $request_id]);
    if ($updated === false || $wpdb->query('COMMIT') === false) {
        $wpdb->query('ROLLBACK');
        if (function_exists('mlr_log')) {
            mlr_log('Cooperation status update failed.', ['request_id' => $request_id, 'db_error' => $wpdb->last_error]);
        }
        wp_send_json_error(['message' => 'خطا در به‌روزرسانی وضعیت؛ هیچ تغییر ناقصی ثبت نشد.']);
        return;
    }

    if ($new_token_generated && function_exists('mlr_log')) {
        mlr_log('Generated a new strong contract token.', ['request_id' => $request_id]);
    }

    if ($current_request->status !== $new_status) {
        $updated_request_for_sms = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$table_name}` WHERE id = %d", $request_id));
        if ($updated_request_for_sms && function_exists('mlr_send_sms_on_cooperation_status_change')) {
            mlr_send_sms_on_cooperation_status_change($request_id, $new_status, $updated_request_for_sms);
        }
        if (function_exists('mlr_create_notification')) {
            mlr_create_notification('status_change', 'وضعیت درخواست همکاری #' . $request_id . ' به «' . $new_status . '» تغییر کرد.', admin_url('admin.php?page=mlr-cooperation-main&s=' . $request_id));
        }
    }

    $response_data = ['message' => 'وضعیت با موفقیت به‌روزرسانی شد.'];
    if (in_array($new_status, ['تایید مدارک', 'عقد قرارداد'], true) && !empty($token)) {
        $contract_page = get_page_by_path('cooperation-contract');
        if ($contract_page) {
            $contract_page_url = get_permalink($contract_page->ID);
            if ($contract_page_url) {
                $response_data['contract_link'] = esc_url(add_query_arg('token', $token, $contract_page_url));
            }
        }
    }

    wp_send_json_success($response_data);
}
