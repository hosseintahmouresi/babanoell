<?php
if (!defined('ABSPATH')) {
    exit;
}

// AJAX action for sending OTP
add_action('wp_ajax_mlr_send_cooperation_otp', 'mlr_send_cooperation_otp_callback');
add_action('wp_ajax_nopriv_mlr_send_cooperation_otp', 'mlr_send_cooperation_otp_callback'); // Allow logged-out if needed, adjust nonce check below

function mlr_send_cooperation_otp_callback() {
    check_ajax_referer('mlr_send_cooperation_otp_nonce', 'nonce');

    $token = isset($_POST['request_token']) ? sanitize_text_field(wp_unslash($_POST['request_token'])) : '';
    if ($token === '') {
        wp_send_json_error(['message' => 'شناسه قرارداد نامعتبر است.']);
        return;
    }
    if (function_exists('mlr_rate_limit_check')) {
        $limit = mlr_rate_limit_check('cooperation_otp_send', 5, HOUR_IN_SECONDS, [$token]);
        if (is_wp_error($limit)) {
            wp_send_json_error(['message' => $limit->get_error_message()]);
            return;
        }
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cooperation_requests';
    $request = $wpdb->get_row($wpdb->prepare("SELECT id, data, otp_expires_at, contract_signed_status FROM {$table_name} WHERE contract_token = %s", $token));
    if (!$request) {
        wp_send_json_error(['message' => 'درخواست همکاری یافت نشد.']);
        return;
    }
    if ($request->contract_signed_status === 'signed') {
        wp_send_json_error(['message' => 'این قرارداد قبلاً امضا شده است.']);
        return;
    }
    if ($request->otp_expires_at && strtotime($request->otp_expires_at) > time()) {
        $remaining_time = max(1, strtotime($request->otp_expires_at) - time());
        wp_send_json_error(['message' => "لطفاً {$remaining_time} ثانیه دیگر برای ارسال مجدد کد صبر کنید."]);
        return;
    }

    $sms_options = get_option('mlr_sms_settings', []);
    $otp_settings = $sms_options['otp_settings']['cooperation_sign'] ?? [];
    if (empty($otp_settings['enabled']) || empty($otp_settings['bodyId'])) {
        if (function_exists('mlr_log')) mlr_log('Cooperation OTP SMS configuration unavailable.', ['request_id' => (int) $request->id]);
        wp_send_json_error(['message' => 'امکان ارسال کد تأیید در حال حاضر وجود ندارد.']);
        return;
    }

    $request_data = json_decode($request->data, true);
    if (!is_array($request_data)) $request_data = [];
    $mobile_number = null;
    foreach (['mobile_number', 'mobile', 'phone_number', 'phone', 'شماره همراه', 'موبایل'] as $key) {
        if (isset($request_data[$key]) && $request_data[$key] !== '') {
            $mobile_number = mlr_normalize_mobile_for_cooperation($request_data[$key]);
            if ($mobile_number) break;
        }
    }
    if (!$mobile_number) {
        foreach ($request_data as $value) {
            if (is_scalar($value) && $value !== '') {
                $mobile_number = mlr_normalize_mobile_for_cooperation($value);
                if ($mobile_number) break;
            }
        }
    }
    if (!$mobile_number) {
        if (function_exists('mlr_log')) mlr_log('Cooperation OTP mobile missing.', ['request_id' => (int) $request->id]);
        wp_send_json_error(['message' => 'شماره موبایل معتبری برای ارسال کد یافت نشد.']);
        return;
    }

    $otp_code = (string) random_int(100000, 999999);
    $otp_expiry_time = time() + 60;
    $otp_hash = wp_hash_password($otp_code);
    $updated = $wpdb->update(
        $table_name,
        ['otp_code' => $otp_hash, 'otp_expires_at' => date('Y-m-d H:i:s', $otp_expiry_time)],
        ['id' => $request->id],
        ['%s', '%s'],
        ['%d']
    );
    if ($updated === false) {
        if (function_exists('mlr_log')) mlr_log('Cooperation OTP DB save failed.', ['request_id' => (int) $request->id, 'db_error' => $wpdb->last_error]);
        wp_send_json_error(['message' => 'خطا در ذخیره‌سازی کد تأیید.']);
        return;
    }

    $attempt_key = 'mlr_coop_otp_attempts_' . substr(hash('sha256', $request->id . '|' . $token), 0, 32);
    delete_transient($attempt_key);

    $sms_provider = new MLR_MeliPayamak_Provider();
    $result = $sms_provider->send_otp_pattern($mobile_number, $otp_settings['bodyId'], [$otp_code]);
    if (is_wp_error($result)) {
        // Never leave an OTP active when the provider failed to deliver it.
        $wpdb->update($table_name, ['otp_code' => null, 'otp_expires_at' => null], ['id' => $request->id], ['%s', '%s'], ['%d']);
        if (function_exists('mlr_log')) mlr_log('Cooperation OTP SMS send failed.', ['request_id' => (int) $request->id, 'provider_error' => $result->get_error_message()]);
        wp_send_json_error(['message' => 'خطا در ارسال پیامک کد تأیید. لطفاً دوباره تلاش کنید.']);
        return;
    }

    if (function_exists('mlr_log')) mlr_log('Cooperation OTP SMS sent.', ['request_id' => (int) $request->id]);
    wp_send_json_success(['message' => 'کد تأیید به شماره موبایل شما ارسال شد.', 'cooldown' => 60]);
}


// AJAX action for verifying OTP
add_action('wp_ajax_mlr_verify_cooperation_otp', 'mlr_verify_cooperation_otp_callback');
add_action('wp_ajax_nopriv_mlr_verify_cooperation_otp', 'mlr_verify_cooperation_otp_callback'); // Allow logged-out if needed

function mlr_verify_cooperation_otp_callback() {
    check_ajax_referer('mlr_verify_cooperation_otp_nonce', 'nonce');

    $token = isset($_POST['request_token']) ? sanitize_text_field(wp_unslash($_POST['request_token'])) : '';
    $raw_otp = isset($_POST['otp_code']) ? wp_unslash($_POST['otp_code']) : '';
    $otp_entered = function_exists('mlr_normalize_digits') ? mlr_normalize_digits($raw_otp, true) : preg_replace('/[^0-9]/', '', (string) $raw_otp);
    // 5 digits remain accepted only for OTPs issued before this upgrade.
    if ($token === '' || !in_array(strlen($otp_entered), [5, 6], true)) {
        wp_send_json_error(['message' => 'اطلاعات ارسال‌شده نامعتبر است (توکن یا فرمت کد).']);
        return;
    }
    if (function_exists('mlr_rate_limit_check')) {
        $limit = mlr_rate_limit_check('cooperation_otp_verify', 12, 15 * MINUTE_IN_SECONDS, [$token]);
        if (is_wp_error($limit)) {
            wp_send_json_error(['message' => $limit->get_error_message()]);
            return;
        }
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cooperation_requests';
    $request = $wpdb->get_row($wpdb->prepare("SELECT id, otp_code, otp_expires_at, contract_signed_status FROM {$table_name} WHERE contract_token = %s", $token));
    if (!$request) {
        wp_send_json_error(['message' => 'درخواست همکاری یافت نشد.']);
        return;
    }
    if ($request->contract_signed_status === 'signed') {
        wp_send_json_error(['message' => 'این قرارداد قبلاً امضا شده است.']);
        return;
    }

    $attempt_key = 'mlr_coop_otp_attempts_' . substr(hash('sha256', $request->id . '|' . $token), 0, 32);
    $attempts = (int) get_transient($attempt_key);
    if ($attempts >= 5) {
        $wpdb->update($table_name, ['otp_code' => null, 'otp_expires_at' => null], ['id' => $request->id], ['%s', '%s'], ['%d']);
        delete_transient($attempt_key);
        wp_send_json_error(['message' => 'تعداد تلاش‌های ناموفق بیش از حد مجاز بود. لطفاً کد جدید دریافت کنید.']);
        return;
    }

    if (!$request->otp_expires_at || strtotime($request->otp_expires_at) < time() || empty($request->otp_code)) {
        $wpdb->update($table_name, ['otp_code' => null, 'otp_expires_at' => null], ['id' => $request->id], ['%s', '%s'], ['%d']);
        delete_transient($attempt_key);
        wp_send_json_error(['message' => 'کد تأیید منقضی شده است. لطفاً کد جدید دریافت کنید.']);
        return;
    }

    $stored = (string) $request->otp_code;
    $valid = false;
    if (strpos($stored, '$') === 0) {
        $valid = wp_check_password($otp_entered, $stored);
    } else {
        // Backward compatibility for a plaintext 5-digit OTP issued immediately before upgrade.
        $valid = hash_equals($stored, $otp_entered);
    }
    if (!$valid) {
        $attempts++;
        set_transient($attempt_key, $attempts, 10 * MINUTE_IN_SECONDS);
        if ($attempts >= 5) {
            $wpdb->update($table_name, ['otp_code' => null, 'otp_expires_at' => null], ['id' => $request->id], ['%s', '%s'], ['%d']);
            delete_transient($attempt_key);
            wp_send_json_error(['message' => 'تعداد تلاش‌های ناموفق بیش از حد مجاز بود. لطفاً کد جدید دریافت کنید.']);
            return;
        }
        wp_send_json_error(['message' => 'کد تأیید واردشده صحیح نمی‌باشد.']);
        return;
    }

    $signed_time = current_time('mysql');
    $expiry_time_mysql = date('Y-m-d H:i:s', strtotime('+1 year', strtotime($signed_time)));
    $updated = $wpdb->update(
        $table_name,
        [
            'contract_signed_status' => 'signed',
            'contract_signed_at' => $signed_time,
            'contract_expires_at' => $expiry_time_mysql,
            'otp_code' => null,
            'otp_expires_at' => null,
        ],
        ['id' => $request->id],
        ['%s', '%s', '%s', '%s', '%s'],
        ['%d']
    );
    if ($updated === false) {
        if (function_exists('mlr_log')) mlr_log('Cooperation contract sign DB update failed.', ['request_id' => (int) $request->id, 'db_error' => $wpdb->last_error]);
        wp_send_json_error(['message' => 'خطا در ثبت امضای قرارداد.']);
        return;
    }

    delete_transient($attempt_key);
    if (function_exists('mlr_log')) mlr_log('Cooperation contract signed.', ['request_id' => (int) $request->id]);
    wp_send_json_success(['message' => 'قرارداد با موفقیت امضا شد.']);
}

