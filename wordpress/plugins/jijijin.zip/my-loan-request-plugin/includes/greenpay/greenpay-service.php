<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/class-mlr-greenpay-api.php';

if (!function_exists('mlr_greenpay_default_settings')) {
    function mlr_greenpay_default_settings() {
        return [
            // Safe-by-default: upgrading the working system never starts a financial debit by itself.
            'enabled'                       => 0,
            'auto_debit_on_docs_approved'   => 1,
            'environment'                   => 'test',
            'username'                      => '',
            'password'                      => '',
            'api_key'                       => '',
            'terminal_number'               => '',
            'merchant_id'                   => '',
            // Sandbox values supplied for the online-purchase test flow.
            'from_pocket_number'            => '1262010000002551',
            'to_pocket_number'              => '',
            'test_otp'                      => '123456',
            'test_skip_otp_request'         => 1,
            'auth_base_url'                 => 'https://wallet.bki.ir/walletbackend/api/sandbox',
            'purchase_base_url'             => 'https://wallet.bki.ir/walletbackend/api/purchase',
            'request_timeout'               => 25,
            'otp_time_buffer'               => 10,
        ];
    }
}

if (!function_exists('mlr_greenpay_to_english_digits')) {
    function mlr_greenpay_to_english_digits($value) {
        return strtr((string) $value, [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ]);
    }
}

if (!function_exists('mlr_greenpay_get_settings')) {
    function mlr_greenpay_get_settings() {
        $stored = get_option('mlr_greenpay_settings', []);
        if (!is_array($stored)) {
            $stored = [];
        }
        return array_merge(mlr_greenpay_default_settings(), $stored);
    }
}

if (!function_exists('mlr_greenpay_sanitize_settings')) {
    function mlr_greenpay_sanitize_settings($input) {
        $current = get_option('mlr_greenpay_settings', []);
        $current = is_array($current) ? $current : [];
        $input = is_array($input) ? $input : [];
        $defaults = mlr_greenpay_default_settings();

        $out = [];
        $out['enabled'] = isset($input['enabled']) ? 1 : 0;
        $out['auto_debit_on_docs_approved'] = isset($input['auto_debit_on_docs_approved']) ? 1 : 0;
        $out['environment'] = (($input['environment'] ?? 'test') === 'live') ? 'live' : 'test';
        $out['username'] = sanitize_text_field(trim((string) ($input['username'] ?? '')));

        // Sensitive values stay untouched when their password fields are left empty.
        foreach (['password', 'api_key'] as $secret_key) {
            $incoming = trim((string) ($input[$secret_key] ?? ''));
            if ($incoming === '' && !empty($current[$secret_key])) {
                $out[$secret_key] = (string) $current[$secret_key];
            } else {
                $out[$secret_key] = sanitize_text_field($incoming);
            }
        }

        $out['terminal_number'] = sanitize_text_field(trim((string) ($input['terminal_number'] ?? '')));
        $out['merchant_id'] = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits($input['merchant_id'] ?? ''));
        $out['from_pocket_number'] = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits($input['from_pocket_number'] ?? ''));
        $out['to_pocket_number'] = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits($input['to_pocket_number'] ?? ''));
        $out['test_otp'] = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits($input['test_otp'] ?? '123456'));
        if ($out['test_otp'] === '') {
            $out['test_otp'] = '123456';
        }
        $out['test_skip_otp_request'] = isset($input['test_skip_otp_request']) ? 1 : 0;

        $out['auth_base_url'] = esc_url_raw(trim((string) ($input['auth_base_url'] ?? $defaults['auth_base_url'])));
        $out['purchase_base_url'] = esc_url_raw(trim((string) ($input['purchase_base_url'] ?? $defaults['purchase_base_url'])));
        $out['request_timeout'] = max(5, min(60, absint($input['request_timeout'] ?? $defaults['request_timeout'])));
        $out['otp_time_buffer'] = max(0, min(60, absint($input['otp_time_buffer'] ?? $defaults['otp_time_buffer'])));

        // Keep sandbox defaults if the administrator intentionally left the test-only fields empty.
        if ($out['environment'] === 'test') {
            if ($out['from_pocket_number'] === '') {
                $out['from_pocket_number'] = '1262010000002551';
            }
            if ($out['test_otp'] === '') {
                $out['test_otp'] = '123456';
            }
        }

        return $out;
    }
}

/**
 * Existing Shahkar fields on the shared API settings page must not be erased
 * simply because a masked/empty input is submitted.
 */
if (!function_exists('mlr_sanitize_preserve_shahkar_client_id')) {
    function mlr_sanitize_preserve_shahkar_client_id($value) {
        $value = sanitize_text_field(trim((string) $value));
        if ($value === '') {
            $current = get_option('mlr_shahkar_client_id', '');
            return is_scalar($current) ? (string) $current : '';
        }
        return $value;
    }
}
if (!function_exists('mlr_sanitize_preserve_shahkar_client_secret')) {
    function mlr_sanitize_preserve_shahkar_client_secret($value) {
        $value = sanitize_text_field(trim((string) $value));
        if ($value === '') {
            $current = get_option('mlr_shahkar_client_secret', '');
            return is_scalar($current) ? (string) $current : '';
        }
        return $value;
    }
}
if (!function_exists('mlr_sanitize_preserve_shahkar_owner_nid')) {
    function mlr_sanitize_preserve_shahkar_owner_nid($value) {
        $value = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits($value));
        if ($value === '') {
            $current = get_option('mlr_shahkar_owner_nid', '');
            return is_scalar($current) ? (string) $current : '';
        }
        return sanitize_text_field($value);
    }
}

add_action('admin_init', 'mlr_greenpay_register_settings', 20);
function mlr_greenpay_register_settings() {
    register_setting('mlr_api_settings_group', 'mlr_greenpay_settings', [
        'sanitize_callback' => 'mlr_greenpay_sanitize_settings',
    ]);
}

/**
 * Keep a second, non-autoloaded snapshot of API credentials. WordPress plugin
 * file updates normally do not delete options, but this makes the settings
 * self-healing if an update/deployment accidentally writes empty values.
 */
function mlr_api_settings_persistence_bootstrap() {
    $backup = get_option('mlr_api_settings_persistent_backup', []);
    if (!is_array($backup)) $backup = [];
    $changed_backup = false;

    // The secondary snapshot deliberately contains no passwords/API secrets.
    foreach (['shahkar_client_secret'] as $secret_backup_key) {
        if (array_key_exists($secret_backup_key, $backup)) {
            unset($backup[$secret_backup_key]);
            $changed_backup = true;
        }
    }
    $legacy_map = [
        'mlr_shahkar_client_id' => 'shahkar_client_id',
        'mlr_shahkar_owner_nid' => 'shahkar_owner_nid',
        'mlr_calculator_plan_selector_mode' => 'calculator_plan_selector_mode',
    ];
    foreach ($legacy_map as $option_name => $backup_key) {
        $current = get_option($option_name, '');
        $current = is_scalar($current) ? trim((string) $current) : '';
        $saved = isset($backup[$backup_key]) && is_scalar($backup[$backup_key]) ? trim((string) $backup[$backup_key]) : '';
        if ($current !== '') {
            if ($saved !== $current) {
                $backup[$backup_key] = $current;
                $changed_backup = true;
            }
        } elseif ($saved !== '') {
            update_option($option_name, $backup[$backup_key], false);
        }
    }

    $greenpay_raw = get_option('mlr_greenpay_settings', null);
    $greenpay = is_array($greenpay_raw) ? $greenpay_raw : [];
    $saved_greenpay = isset($backup['greenpay']) && is_array($backup['greenpay']) ? $backup['greenpay'] : [];
    foreach (['password', 'api_key'] as $secret_key) {
        if (array_key_exists($secret_key, $saved_greenpay)) {
            unset($saved_greenpay[$secret_key]);
            $changed_backup = true;
        }
    }

    // Only non-secret operational configuration can self-heal from the secondary snapshot.
    $safe_backup_keys = [
        'enabled', 'auto_debit_on_docs_approved', 'environment', 'username',
        'terminal_number', 'merchant_id', 'from_pocket_number', 'to_pocket_number',
        'test_otp', 'test_skip_otp_request', 'auth_base_url', 'purchase_base_url',
        'request_timeout', 'otp_time_buffer',
    ];
    if (empty($greenpay) && !empty($saved_greenpay)) {
        foreach ($safe_backup_keys as $key) {
            if (array_key_exists($key, $saved_greenpay)) $greenpay[$key] = $saved_greenpay[$key];
        }
    }

    // Existing WooCommerce gateway remains an intentional primary-source migration path.
    $wc_greenpay = get_option('woocommerce_bki_wallet_settings', []);
    if (is_array($wc_greenpay) && !empty($wc_greenpay)) {
        $mapping = [
            'username' => 'username',
            'password' => 'password',
            'api_key' => 'api_key',
            'terminal_number' => 'terminal_number',
            'merchant_id' => 'merchant_id',
            'to_pocket_number' => 'to_pocket_number',
        ];
        foreach ($mapping as $new_key => $old_key) {
            if (empty($greenpay[$new_key]) && !empty($wc_greenpay[$old_key])) $greenpay[$new_key] = $wc_greenpay[$old_key];
        }
    }

    foreach ($safe_backup_keys as $key) {
        $current = isset($greenpay[$key]) && is_scalar($greenpay[$key]) ? trim((string) $greenpay[$key]) : '';
        $saved = isset($saved_greenpay[$key]) && is_scalar($saved_greenpay[$key]) ? trim((string) $saved_greenpay[$key]) : '';
        if ($current === '' && $saved !== '') $greenpay[$key] = $saved_greenpay[$key];
    }

    if (!empty($greenpay)) {
        update_option('mlr_greenpay_settings', $greenpay, false);
        $safe_snapshot = [];
        foreach ($safe_backup_keys as $key) {
            if (!array_key_exists($key, $greenpay)) continue;
            $value = $greenpay[$key];
            if (is_scalar($value) && trim((string) $value) !== '') {
                $safe_snapshot[$key] = $value;
            } elseif (in_array($key, ['enabled', 'auto_debit_on_docs_approved', 'test_skip_otp_request'], true)) {
                $safe_snapshot[$key] = $value;
            }
        }
        if ($safe_snapshot !== $saved_greenpay) {
            $backup['greenpay'] = $safe_snapshot;
            $changed_backup = true;
        }
    } elseif (isset($backup['greenpay']) && $saved_greenpay !== $backup['greenpay']) {
        $backup['greenpay'] = $saved_greenpay;
        $changed_backup = true;
    }

    if ($changed_backup || get_option('mlr_api_settings_persistent_backup', null) === null) {
        update_option('mlr_api_settings_persistent_backup', $backup, false);
    }
}

add_action('plugins_loaded', 'mlr_api_settings_persistence_bootstrap', 30);

function mlr_api_settings_persistence_on_update($option, $old_value, $value) {
    if (!in_array($option, [
        'mlr_shahkar_client_id',
        'mlr_shahkar_client_secret',
        'mlr_shahkar_owner_nid',
        'mlr_calculator_plan_selector_mode',
        'mlr_greenpay_settings',
    ], true)) {
        return;
    }

    // Defer the snapshot until the just-updated option is readable normally.
    if (!wp_next_scheduled('mlr_api_settings_snapshot_event')) {
        wp_schedule_single_event(time() + 1, 'mlr_api_settings_snapshot_event');
    }
}
add_action('updated_option', 'mlr_api_settings_persistence_on_update', 10, 3);
add_action('mlr_api_settings_snapshot_event', 'mlr_api_settings_persistence_bootstrap');

// Capture the credentials before WordPress replaces plugin files and restore/check them immediately after upgrade.
function mlr_api_settings_before_plugin_upgrade($response, $hook_extra) {
    mlr_api_settings_persistence_bootstrap();
    return $response;
}
add_filter('upgrader_pre_install', 'mlr_api_settings_before_plugin_upgrade', 10, 2);

function mlr_api_settings_after_plugin_upgrade($upgrader, $hook_extra) {
    if (!is_array($hook_extra) || ($hook_extra['type'] ?? '') !== 'plugin') {
        return;
    }
    mlr_api_settings_persistence_bootstrap();
}
add_action('upgrader_process_complete', 'mlr_api_settings_after_plugin_upgrade', 10, 2);

function mlr_greenpay_transactions_table() {
    global $wpdb;
    return $wpdb->prefix . 'mlr_greenpay_transactions';
}

function mlr_greenpay_install_schema() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $table = mlr_greenpay_transactions_table();
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE {$table} (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_id bigint(20) UNSIGNED NOT NULL,
        amount DECIMAL(15,2) NOT NULL DEFAULT 0,
        from_pocket varchar(32) NOT NULL DEFAULT '',
        to_pocket varchar(32) NOT NULL DEFAULT '',
        ref_number varchar(100) NOT NULL DEFAULT '',
        environment varchar(20) NOT NULL DEFAULT 'test',
        status varchar(30) NOT NULL DEFAULT 'queued',
        eligible tinyint(1) NOT NULL DEFAULT 0,
        eligibility_updated_at datetime DEFAULT NULL,
        eligibility_updated_by bigint(20) UNSIGNED NOT NULL DEFAULT 0,
        trigger_source varchar(50) NOT NULL DEFAULT '',
        attempts int(11) NOT NULL DEFAULT 0,
        otp_requested_at datetime DEFAULT NULL,
        send_time varchar(20) DEFAULT NULL,
        provider_status varchar(100) DEFAULT NULL,
        provider_reference varchar(191) DEFAULT NULL,
        last_http_code int(11) DEFAULT NULL,
        last_error text DEFAULT NULL,
        last_response longtext DEFAULT NULL,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        debited_at datetime DEFAULT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY request_id (request_id),
        UNIQUE KEY ref_number (ref_number),
        KEY status (status),
        KEY eligible_status (eligible, status),
        KEY updated_at (updated_at)
    ) {$charset_collate};";
    dbDelta($sql);
    update_option('mlr_greenpay_db_version', '1.1', false);

    // 8.4.6.25 had no per-file opt-in. Preserve only financial/in-flight history automatically.
    // Old queued jobs are stopped and require an explicit administrator selection in 8.4.6.26.
    if (!get_option('mlr_greenpay_eligibility_migrated_1_1')) {
        $old_queued = $wpdb->get_col("SELECT request_id FROM {$table} WHERE status = 'queued'");
        foreach ((array) $old_queued as $old_request_id) {
            wp_clear_scheduled_hook('mlr_greenpay_process_debit', [absint($old_request_id)]);
        }
        $wpdb->query("UPDATE {$table} SET eligible = 1 WHERE status IN ('success','unknown','processing','awaiting_otp')");
        $wpdb->query("UPDATE {$table} SET eligible = 0, status = 'not_applicable' WHERE status = 'queued'");
        update_option('mlr_greenpay_eligibility_migrated_1_1', 1, false);
    }
}

function mlr_greenpay_maybe_install_schema() {
    global $wpdb;
    if (get_option('mlr_greenpay_db_version') === '1.1' && get_transient('mlr_greenpay_schema_ok')) {
        return;
    }

    $table = mlr_greenpay_transactions_table();
    $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
    if ($exists !== $table || get_option('mlr_greenpay_db_version') !== '1.1') {
        mlr_greenpay_install_schema();
    }
    set_transient('mlr_greenpay_schema_ok', 1, DAY_IN_SECONDS);
}
add_action('plugins_loaded', 'mlr_greenpay_maybe_install_schema', 40);

function mlr_greenpay_mask_pocket($pocket) {
    $pocket = preg_replace('/\D+/', '', (string) $pocket);
    if (strlen($pocket) <= 8) {
        return $pocket;
    }
    return substr($pocket, 0, 4) . str_repeat('*', max(4, strlen($pocket) - 8)) . substr($pocket, -4);
}

function mlr_greenpay_redact_response($value, $depth = 0) {
    if ($depth > 8) {
        return '[truncated]';
    }
    if (is_array($value)) {
        $out = [];
        foreach ($value as $key => $item) {
            $key_l = strtolower((string) $key);
            if (preg_match('/token|password|secret|apikey|api_key|authorization|otp/', $key_l)) {
                $out[$key] = '***';
                continue;
            }
            if (preg_match('/pocket/', $key_l) && is_scalar($item)) {
                $out[$key] = mlr_greenpay_mask_pocket((string) $item);
                continue;
            }
            $out[$key] = mlr_greenpay_redact_response($item, $depth + 1);
        }
        return $out;
    }
    if (is_object($value)) {
        return mlr_greenpay_redact_response((array) $value, $depth + 1);
    }
    if (is_string($value) && strlen($value) > 2000) {
        return substr($value, 0, 2000) . '…';
    }
    return $value;
}

function mlr_greenpay_encode_response($response) {
    if (is_wp_error($response)) {
        $response = [
            'error_code' => $response->get_error_code(),
            'error_message' => $response->get_error_message(),
            'error_data' => $response->get_error_data(),
        ];
    }
    return wp_json_encode(mlr_greenpay_redact_response($response), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function mlr_greenpay_extract_error_message($response, $fallback = 'خطای نامشخص GreenPay') {
    if (is_wp_error($response)) {
        return $response->get_error_message();
    }
    if (!is_array($response)) {
        return $fallback;
    }
    if (!empty($response['Errors']) && is_array($response['Errors'])) {
        $first = reset($response['Errors']);
        if (is_array($first)) {
            foreach (['ErrorMessage','Message','message'] as $key) {
                if (!empty($first[$key])) {
                    return sanitize_text_field((string) $first[$key]);
                }
            }
        }
    }
    foreach (['Message','message','ErrorMessage','error'] as $key) {
        if (!empty($response[$key]) && is_scalar($response[$key])) {
            return sanitize_text_field((string) $response[$key]);
        }
    }
    return $fallback;
}

function mlr_greenpay_response_is_success($response) {
    if (!is_array($response)) {
        return false;
    }
    $http = (int) ($response['http_code'] ?? 0);
    if ($http < 200 || $http >= 300) {
        return false;
    }
    $status = strtolower(trim((string) ($response['Status'] ?? $response['status'] ?? '')));
    if (in_array($status, ['success','successful','ok'], true)) {
        return true;
    }
    $success = $response['Success'] ?? $response['success'] ?? null;
    return $success === true || $success === 1 || $success === '1' || strtolower((string) $success) === 'true';
}

function mlr_greenpay_extract_send_time($response, $buffer_seconds = 10) {
    $send_time = '';
    if (is_array($response)) {
        foreach (['SendTime','OtpSendTime','TransactionTime','sendTime'] as $key) {
            if (!empty($response[$key])) {
                $send_time = sanitize_text_field((string) $response[$key]);
                break;
            }
        }
    }
    if ($send_time === '') {
        try {
            $dt = new DateTime('now', new DateTimeZone('Asia/Tehran'));
            $send_time = $dt->format('H:i:s');
        } catch (Exception $e) {
            $send_time = current_time('H:i:s');
        }
    }

    if ($buffer_seconds > 0) {
        $timestamp = strtotime($send_time);
        if ($timestamp !== false) {
            $send_time = date('H:i:s', $timestamp + $buffer_seconds);
        }
    }
    return $send_time;
}

function mlr_greenpay_extract_provider_reference($response) {
    if (!is_array($response)) {
        return '';
    }
    foreach (['TransactionId','TransactionID','transactionId','ReferenceNumber','RefNumber','TraceNumber','TrackingCode','RequestId','requestId'] as $key) {
        if (isset($response[$key]) && is_scalar($response[$key]) && trim((string) $response[$key]) !== '') {
            return sanitize_text_field((string) $response[$key]);
        }
    }
    return '';
}

function mlr_greenpay_classify_failure($response) {
    if (is_wp_error($response)) {
        $data = $response->get_error_data();
        if (is_array($data) && !empty($data['transport_error'])) {
            return 'unknown';
        }
        return 'failed';
    }
    if (!is_array($response)) {
        return 'unknown';
    }
    $http = (int) ($response['http_code'] ?? 0);
    if ($http === 0 || $http >= 500) {
        return 'unknown';
    }
    if ($http >= 400 && $http < 500) {
        return 'failed';
    }
    if ($http >= 200 && $http < 300) {
        $status = strtolower(trim((string) ($response['Status'] ?? $response['status'] ?? '')));
        $has_explicit_error = !empty($response['Errors'])
            || !empty($response['ErrorMessage'])
            || !empty($response['error'])
            || in_array($status, ['failed','failure','error','invalid','rejected'], true)
            || (($response['Success'] ?? null) === false);
        // An explicit business rejection is a definite failure and can be retried after correction.
        // An opaque/malformed 2xx result is unknown because the debit may already have happened.
        return $has_explicit_error ? 'failed' : 'unknown';
    }
    return 'failed';
}

function mlr_greenpay_add_event($request_id, $type, $details) {
    if (function_exists('mlr_add_request_event')) {
        mlr_add_request_event((int) $request_id, $type, $details);
    }
}

function mlr_greenpay_notify_admin($request_id, $message) {
    if (function_exists('mlr_create_notification')) {
        mlr_create_notification(
            'greenpay',
            $message,
            admin_url('admin.php?page=mlr-greenpay-transactions&request_id=' . absint($request_id))
        );
    }
}


function mlr_greenpay_get_transaction($request_id) {
    global $wpdb;
    $request_id = absint($request_id);
    if (!$request_id) {
        return null;
    }
    mlr_greenpay_maybe_install_schema();
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . mlr_greenpay_transactions_table() . " WHERE request_id = %d",
        $request_id
    ));
}

function mlr_greenpay_is_eligible($request_id) {
    $tx = mlr_greenpay_get_transaction($request_id);
    return $tx && (int) $tx->eligible === 1;
}

function mlr_greenpay_current_amount_for_request($request) {
    if (!$request) {
        return 0.0;
    }
    $value = (isset($request->facility_amount) && $request->facility_amount !== '' && $request->facility_amount !== null)
        ? (float) $request->facility_amount
        : (float) $request->loan_amount;
    return round($value, 2);
}

function mlr_greenpay_status_is_docs_approved($status) {
    $status = function_exists('mlr_normalize_status') ? mlr_normalize_status($status) : trim((string) $status);
    return $status === 'تأیید مدارک';
}

/**
 * Explicit per-file GreenPay enrollment. Default is always non-eligible.
 * Financial/in-flight records cannot be detached because doing so would hide
 * an already completed or uncertain debit.
 */
function mlr_greenpay_set_eligibility($request_id, $eligible, $source = 'admin') {
    global $wpdb;
    $request_id = absint($request_id);
    $eligible = $eligible ? 1 : 0;
    if (!$request_id) {
        return new WP_Error('greenpay_invalid_request', 'شناسه پرونده معتبر نیست.');
    }

    mlr_greenpay_maybe_install_schema();
    $requests_table = $wpdb->prefix . 'loan_requests';
    $tx_table = mlr_greenpay_transactions_table();
    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT id, loan_amount, facility_amount, status FROM {$requests_table} WHERE id = %d",
        $request_id
    ));
    if (!$request) {
        return new WP_Error('greenpay_request_not_found', 'پرونده پیدا نشد.');
    }

    $tx = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tx_table} WHERE request_id = %d", $request_id));
    $now = current_time('mysql');
    $user_id = get_current_user_id();

    if (!$eligible) {
        if ($tx && in_array($tx->status, ['success','processing','awaiting_otp','unknown'], true)) {
            return new WP_Error('greenpay_eligibility_locked', 'این پرونده تراکنش انجام‌شده/درحال‌پردازش/نامشخص دارد و برای حفظ سابقه مالی نمی‌توان آن را از GreenPay خارج کرد.');
        }
        if (!$tx) {
            return true; // Default state is already non-eligible.
        }
        if ($tx->status === 'queued') {
            wp_clear_scheduled_hook('mlr_greenpay_process_debit', [$request_id]);
        }
        $new_status = 'not_applicable';
        $updated = $wpdb->update($tx_table, [
            'eligible' => 0,
            'status' => $new_status,
            'eligibility_updated_at' => $now,
            'eligibility_updated_by' => $user_id,
            'last_error' => $tx->status === 'queued' ? 'کسری پیش از ارسال توسط مدیر لغو و پرونده از GreenPay خارج شد.' : $tx->last_error,
            'updated_at' => $now,
        ], ['request_id' => $request_id]);
        if ($updated === false) {
            return new WP_Error('greenpay_db_error', 'ذخیره وضعیت GreenPay پرونده انجام نشد.');
        }
        mlr_greenpay_add_event($request_id, 'greenpay_eligibility_off', 'پرونده از فرآیند کسری GreenPay خارج شد.');
        return true;
    }

    $settings = mlr_greenpay_get_settings();
    $amount = mlr_greenpay_current_amount_for_request($request);
    $from_pocket = preg_replace('/\D+/', '', (string) ($settings['from_pocket_number'] ?? ''));
    if (($settings['environment'] ?? 'test') === 'test' && $from_pocket === '') {
        $from_pocket = '1262010000002551';
    }
    $to_pocket = preg_replace('/\D+/', '', (string) ($settings['to_pocket_number'] ?? ''));
    $from_pocket = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits(apply_filters('mlr_greenpay_from_pocket_number', $from_pocket, $request, $settings)));
    $to_pocket = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits(apply_filters('mlr_greenpay_to_pocket_number', $to_pocket, $request, $settings)));

    if ($tx) {
        $updates = [
            'eligible' => 1,
            'eligibility_updated_at' => $now,
            'eligibility_updated_by' => $user_id,
            'updated_at' => $now,
        ];
        if (in_array($tx->status, ['not_applicable','cancelled'], true)) {
            $updates['status'] = 'not_started';
            $updates['amount'] = $amount;
            $updates['from_pocket'] = $from_pocket;
            $updates['to_pocket'] = $to_pocket;
            $updates['environment'] = (($settings['environment'] ?? 'test') === 'live' ? 'live' : 'test');
            $updates['last_error'] = null;
            $updates['last_http_code'] = null;
            $updates['last_response'] = null;
            $updates['provider_status'] = null;
            $updates['provider_reference'] = null;
            $updates['otp_requested_at'] = null;
            $updates['send_time'] = null;
        }
        $updated = $wpdb->update($tx_table, $updates, ['request_id' => $request_id]);
        if ($updated === false) {
            return new WP_Error('greenpay_db_error', 'ذخیره وضعیت GreenPay پرونده انجام نشد.');
        }
    } else {
        $inserted = $wpdb->insert($tx_table, [
            'request_id' => $request_id,
            'amount' => $amount,
            'from_pocket' => $from_pocket,
            'to_pocket' => $to_pocket,
            'ref_number' => 'MLR-GP-' . $request_id,
            'environment' => (($settings['environment'] ?? 'test') === 'live' ? 'live' : 'test'),
            'status' => 'not_started',
            'eligible' => 1,
            'eligibility_updated_at' => $now,
            'eligibility_updated_by' => $user_id,
            'trigger_source' => sanitize_key($source),
            'attempts' => 0,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        if (!$inserted) {
            return new WP_Error('greenpay_db_error', 'ثبت پرونده در GreenPay انجام نشد.');
        }
    }

    mlr_greenpay_add_event($request_id, 'greenpay_eligibility_on', 'پرونده به‌عنوان مشمول کسری GreenPay علامت‌گذاری شد.');

    // If the file is already at the intended stage, opt-in can immediately queue it.
    if (mlr_greenpay_status_is_docs_approved($request->status) && !empty($settings['enabled']) && !empty($settings['auto_debit_on_docs_approved'])) {
        mlr_greenpay_queue_request($request_id, 'eligibility_enabled');
    }
    return true;
}

function mlr_greenpay_schedule_request($request_id) {
    $request_id = absint($request_id);
    if (!$request_id) {
        return;
    }
    if (!wp_next_scheduled('mlr_greenpay_process_debit', [$request_id])) {
        wp_schedule_single_event(time() + 1, 'mlr_greenpay_process_debit', [$request_id]);
    }
    // Ask WP-Cron to spawn without making the current status transition depend on the API request.
    if ((!defined('DISABLE_WP_CRON') || !DISABLE_WP_CRON) && function_exists('spawn_cron')) {
        spawn_cron(time());
    }
}

function mlr_greenpay_queue_request($request_id, $source = 'status_transition') {
    global $wpdb;
    $request_id = absint($request_id);
    if (!$request_id) {
        return false;
    }

    mlr_greenpay_maybe_install_schema();
    $requests_table = $wpdb->prefix . 'loan_requests';
    $tx_table = mlr_greenpay_transactions_table();
    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT id, loan_amount, facility_amount, status FROM {$requests_table} WHERE id = %d",
        $request_id
    ));
    if (!$request) {
        return false;
    }

    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$tx_table} WHERE request_id = %d", $request_id));
    // Per-file opt-in is mandatory. A global GreenPay switch never enrolls files by itself.
    if (!$existing || (int) $existing->eligible !== 1) {
        return false;
    }
    if (in_array($existing->status, ['success','unknown','processing','awaiting_otp','queued'], true)) {
        return false;
    }
    // A definite failed debit is retried only by an explicit administrator action.
    if ($existing->status === 'failed') {
        return false;
    }
    if (!in_array($existing->status, ['not_started','cancelled'], true)) {
        return false;
    }

    $settings = mlr_greenpay_get_settings();
    if (empty($settings['enabled']) || !mlr_greenpay_status_is_docs_approved($request->status)) {
        return false;
    }
    $amount = mlr_greenpay_current_amount_for_request($request);
    $from_pocket = preg_replace('/\D+/', '', (string) ($settings['from_pocket_number'] ?? ''));
    if (($settings['environment'] ?? 'test') === 'test' && $from_pocket === '') {
        $from_pocket = '1262010000002551';
    }
    $to_pocket = preg_replace('/\D+/', '', (string) ($settings['to_pocket_number'] ?? ''));
    $from_pocket = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits(apply_filters('mlr_greenpay_from_pocket_number', $from_pocket, $request, $settings)));
    $to_pocket = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits(apply_filters('mlr_greenpay_to_pocket_number', $to_pocket, $request, $settings)));
    $now = current_time('mysql');

    $updated = $wpdb->update($tx_table, [
        'amount' => $amount,
        'from_pocket' => $from_pocket,
        'to_pocket' => $to_pocket,
        'environment' => (($settings['environment'] ?? 'test') === 'live' ? 'live' : 'test'),
        'status' => 'queued',
        'trigger_source' => sanitize_key($source),
        'last_error' => null,
        'last_http_code' => null,
        'last_response' => null,
        'provider_status' => null,
        'updated_at' => $now,
    ], ['request_id' => $request_id, 'eligible' => 1, 'status' => $existing->status]);

    // Atomic state transition: a concurrent worker/admin action may have changed the row.
    if ((int) $updated !== 1) {
        mlr_greenpay_add_event($request_id, 'greenpay_queue_failed', 'ثبت صف GreenPay ناموفق بود؛ هیچ درخواست مالی به GreenPay ارسال نشد.');
        mlr_greenpay_notify_admin($request_id, 'ثبت صف GreenPay برای پرونده #' . $request_id . ' در دیتابیس ناموفق بود؛ هیچ کسری ارسال نشد.');
        if (function_exists('mlr_log')) {
            mlr_log([
                'event' => 'greenpay_queue_state_transition_failed',
                'request_id' => $request_id,
                'expected_status' => $existing->status,
                'db_error' => $wpdb->last_error,
            ]);
        }
        return false;
    }

    mlr_greenpay_add_event($request_id, 'greenpay_queued', 'کسری GreenPay در صف قرار گرفت. مبلغ: ' . number_format($amount) . ' ریال؛ مرجع: ' . $existing->ref_number);
    mlr_greenpay_schedule_request($request_id);
    return true;
}

function mlr_greenpay_on_status_changed($request_id, $old_status, $new_status, $source = '') {
    $old = function_exists('mlr_normalize_status') ? mlr_normalize_status($old_status) : trim((string) $old_status);
    $new = function_exists('mlr_normalize_status') ? mlr_normalize_status($new_status) : trim((string) $new_status);
    if ($old === $new) {
        return;
    }

    // If a file is sent back before the queued debit starts, cancel only that unsent job.
    // Eligibility remains selected so re-entering «تأیید مدارک» can queue it again.
    if ($old === 'تأیید مدارک' && in_array($new, ['تکمیل مدارک','نقص مدارک','رد شده','در حال بررسی','تأیید کارشناس'], true)) {
        $tx = mlr_greenpay_get_transaction($request_id);
        if ($tx && (int) $tx->eligible === 1 && $tx->status === 'queued') {
            wp_clear_scheduled_hook('mlr_greenpay_process_debit', [absint($request_id)]);
            mlr_greenpay_mark_transaction($request_id, [
                'status' => 'not_started',
                'last_error' => 'پرونده پیش از شروع کسری از وضعیت تأیید مدارک خارج شد؛ درخواست مالی ارسال نشد.',
            ]);
            mlr_greenpay_add_event($request_id, 'greenpay_queue_cancelled', 'صف کسری GreenPay به دلیل بازگشت/رد پرونده پیش از شروع پردازش لغو شد.');
        }
    }

    if ($new !== 'تأیید مدارک') {
        return;
    }

    $settings = mlr_greenpay_get_settings();
    if (empty($settings['enabled']) || empty($settings['auto_debit_on_docs_approved']) || !mlr_greenpay_is_eligible($request_id)) {
        return;
    }

    // Financial work is queued and isolated; the loan workflow has already succeeded.
    mlr_greenpay_queue_request($request_id, $source ?: 'status_transition');
}
add_action('mlr_loan_status_changed', 'mlr_greenpay_on_status_changed', 10, 4);

function mlr_greenpay_mark_transaction($request_id, array $updates) {
    global $wpdb;
    $updates['updated_at'] = current_time('mysql');
    return $wpdb->update(mlr_greenpay_transactions_table(), $updates, ['request_id' => absint($request_id)]);
}

function mlr_greenpay_process_debit_callback($request_id) {
    global $wpdb;
    $request_id = absint($request_id);
    if (!$request_id) {
        return;
    }

    mlr_greenpay_maybe_install_schema();
    $table = mlr_greenpay_transactions_table();
    $tx = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE request_id = %d", $request_id));
    if (!$tx || $tx->status !== 'queued' || (int) $tx->eligible !== 1) {
        return;
    }

    // Atomic claim prevents two cron/admin workers from debiting the same request.
    $claimed = $wpdb->query($wpdb->prepare(
        "UPDATE {$table}
         SET status = 'processing', attempts = attempts + 1, updated_at = %s
         WHERE request_id = %d AND status = 'queued' AND eligible = 1",
        current_time('mysql'),
        $request_id
    ));
    if ((int) $claimed !== 1) {
        return;
    }

    $tx = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE request_id = %d", $request_id));
    $settings = mlr_greenpay_get_settings();
    if (empty($settings['enabled'])) {
        mlr_greenpay_mark_transaction($request_id, ['status' => 'failed', 'last_error' => 'GreenPay در تنظیمات غیرفعال شده است.']);
        return;
    }

    if ((float) $tx->amount <= 0) {
        mlr_greenpay_mark_transaction($request_id, ['status' => 'failed', 'last_error' => 'مبلغ تسهیلات پرونده معتبر نیست.']);
        mlr_greenpay_add_event($request_id, 'greenpay_failed', 'کسری GreenPay انجام نشد: مبلغ تسهیلات معتبر نیست.');
        return;
    }
    if (strlen((string) $tx->from_pocket) !== 16 || !ctype_digit((string) $tx->from_pocket)) {
        mlr_greenpay_mark_transaction($request_id, ['status' => 'failed', 'last_error' => 'FromPocketNumber باید ۱۶ رقمی باشد.']);
        mlr_greenpay_add_event($request_id, 'greenpay_failed', 'کسری GreenPay انجام نشد: FromPocketNumber معتبر نیست.');
        mlr_greenpay_notify_admin($request_id, 'تنظیمات GreenPay برای پرونده #' . $request_id . ' ناقص است: FromPocketNumber نامعتبر.');
        return;
    }
    if (($settings['environment'] ?? 'test') === 'live' && (string) $tx->from_pocket === '1262010000002551') {
        mlr_greenpay_mark_transaction($request_id, ['status' => 'failed', 'last_error' => 'FromPocketNumber تستی در محیط عملیاتی مجاز نیست.']);
        mlr_greenpay_add_event($request_id, 'greenpay_failed', 'کسری GreenPay متوقف شد: شماره Pocket تستی در محیط عملیاتی تنظیم شده است.');
        mlr_greenpay_notify_admin($request_id, 'برای پرونده #' . $request_id . ' شماره FromPocket عملیاتی GreenPay را در تنظیمات وارد کنید.');
        return;
    }

    $api = new MLR_GreenPay_API($settings);
    $valid = $api->validate_configuration();
    if (is_wp_error($valid)) {
        mlr_greenpay_mark_transaction($request_id, ['status' => 'failed', 'last_error' => $valid->get_error_message()]);
        mlr_greenpay_add_event($request_id, 'greenpay_failed', 'کسری GreenPay انجام نشد: ' . $valid->get_error_message());
        mlr_greenpay_notify_admin($request_id, 'کسری GreenPay پرونده #' . $request_id . ' انجام نشد: تنظیمات API ناقص است.');
        return;
    }

    $token = $api->get_token();
    if (is_wp_error($token)) {
        mlr_greenpay_mark_transaction($request_id, [
            'status' => 'failed',
            'last_error' => $token->get_error_message(),
            'last_response' => mlr_greenpay_encode_response($token),
        ]);
        mlr_greenpay_add_event($request_id, 'greenpay_failed', 'دریافت توکن GreenPay ناموفق بود: ' . $token->get_error_message());
        mlr_greenpay_notify_admin($request_id, 'دریافت توکن GreenPay برای پرونده #' . $request_id . ' ناموفق بود.');
        return;
    }

    $is_test = (($settings['environment'] ?? 'test') !== 'live');
    $skip_otp_request = $is_test && !empty($settings['test_skip_otp_request']);
    $send_time = '';

    if (!$skip_otp_request) {
        $otp_response = $api->send_otp($token, $tx->from_pocket, $tx->amount);
        if (is_wp_error($otp_response) || !mlr_greenpay_response_is_success($otp_response)) {
            $failure_status = is_wp_error($otp_response) ? 'failed' : mlr_greenpay_classify_failure($otp_response);
            $error = mlr_greenpay_extract_error_message($otp_response, 'درخواست OTP GreenPay ناموفق بود.');
            mlr_greenpay_mark_transaction($request_id, [
                'status' => $failure_status,
                'last_http_code' => is_array($otp_response) ? (int) ($otp_response['http_code'] ?? 0) : 0,
                'last_error' => $error,
                'last_response' => mlr_greenpay_encode_response($otp_response),
            ]);
            mlr_greenpay_add_event($request_id, 'greenpay_' . $failure_status, 'درخواست OTP GreenPay ناموفق بود: ' . $error);
            mlr_greenpay_notify_admin($request_id, 'درخواست OTP GreenPay پرونده #' . $request_id . ' ناموفق بود.');
            return;
        }

        $send_time = mlr_greenpay_extract_send_time($otp_response, absint($settings['otp_time_buffer'] ?? 10));
        mlr_greenpay_mark_transaction($request_id, [
            'otp_requested_at' => current_time('mysql'),
            'send_time' => $send_time,
            'provider_status' => sanitize_text_field((string) ($otp_response['Status'] ?? 'success')),
            'last_http_code' => (int) ($otp_response['http_code'] ?? 200),
            'last_error' => null,
            'last_response' => mlr_greenpay_encode_response($otp_response),
        ]);
        mlr_greenpay_add_event($request_id, 'greenpay_otp_requested', 'OTP گرین‌پی درخواست شد. مرجع: ' . $tx->ref_number);

        if (!$is_test) {
            // Production OTP is never stored. An administrator completes it from the GreenPay transactions screen.
            mlr_greenpay_mark_transaction($request_id, ['status' => 'awaiting_otp']);
            mlr_greenpay_notify_admin($request_id, 'برای تکمیل کسری GreenPay پرونده #' . $request_id . ' رمز OTP را در صفحه مدیریت GreenPay وارد کنید.');
            return;
        }
    } else {
        $send_time = mlr_greenpay_extract_send_time([], 0);
        mlr_greenpay_mark_transaction($request_id, [
            'send_time' => $send_time,
            'otp_requested_at' => null,
        ]);
    }

    // Sandbox fixed OTP: the provider explicitly does not send an OTP in this environment.
    $otp = preg_replace('/\D+/', '', (string) ($settings['test_otp'] ?? '123456'));
    if ($otp === '') {
        $otp = '123456';
    }
    if (strlen($otp) !== 6) {
        mlr_greenpay_mark_transaction($request_id, ['status' => 'failed', 'last_error' => 'OTP تست باید دقیقاً ۶ رقم باشد.']);
        mlr_greenpay_add_event($request_id, 'greenpay_failed', 'کسری GreenPay انجام نشد: OTP تست نامعتبر است.');
        return;
    }

    $result = $api->confirm_debit($token, $tx->from_pocket, $otp, $tx->amount, $tx->ref_number, $send_time);
    mlr_greenpay_finalize_transfer_result($request_id, $result);
}
add_action('mlr_greenpay_process_debit', 'mlr_greenpay_process_debit_callback', 10, 1);

function mlr_greenpay_finalize_transfer_result($request_id, $response) {
    global $wpdb;
    $table = mlr_greenpay_transactions_table();
    $tx = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE request_id = %d", absint($request_id)));
    if (!$tx) {
        return false;
    }

    $http = is_array($response) ? (int) ($response['http_code'] ?? 0) : 0;
    $provider_status = is_array($response) ? sanitize_text_field((string) ($response['Status'] ?? $response['status'] ?? '')) : '';
    $provider_reference = is_array($response) ? mlr_greenpay_extract_provider_reference($response) : '';

    if (mlr_greenpay_response_is_success($response)) {
        mlr_greenpay_mark_transaction($request_id, [
            'status' => 'success',
            'provider_status' => $provider_status !== '' ? $provider_status : 'success',
            'provider_reference' => $provider_reference,
            'last_http_code' => $http,
            'last_error' => null,
            'last_response' => mlr_greenpay_encode_response($response),
            'debited_at' => current_time('mysql'),
        ]);
        mlr_greenpay_add_event($request_id, 'greenpay_success', 'کسری GreenPay با موفقیت انجام شد. مبلغ: ' . number_format((float) $tx->amount) . ' ریال؛ مرجع: ' . $tx->ref_number);
        return true;
    }

    $status = mlr_greenpay_classify_failure($response);
    $error = mlr_greenpay_extract_error_message($response, $status === 'unknown' ? 'نتیجه تراکنش GreenPay نامشخص است و نباید خودکار تکرار شود.' : 'کسری GreenPay ناموفق بود.');
    mlr_greenpay_mark_transaction($request_id, [
        'status' => $status,
        'provider_status' => $provider_status,
        'provider_reference' => $provider_reference,
        'last_http_code' => $http,
        'last_error' => $error,
        'last_response' => mlr_greenpay_encode_response($response),
    ]);

    mlr_greenpay_add_event($request_id, 'greenpay_' . $status, 'کسری GreenPay ' . ($status === 'unknown' ? 'با نتیجه نامشخص' : 'ناموفق') . ' بود: ' . $error . '؛ مرجع: ' . $tx->ref_number);
    mlr_greenpay_notify_admin(
        $request_id,
        $status === 'unknown'
            ? 'وضعیت کسری GreenPay پرونده #' . $request_id . ' نامشخص است؛ پیش از هر تلاش مجدد استعلام انجام دهید.'
            : 'کسری GreenPay پرونده #' . $request_id . ' ناموفق بود.'
    );
    return false;
}

function mlr_greenpay_confirm_with_admin_otp($request_id, $otp) {
    global $wpdb;
    $request_id = absint($request_id);
    $otp = preg_replace('/\D+/', '', mlr_greenpay_to_english_digits($otp));
    if (strlen($otp) !== 6) {
        return new WP_Error('greenpay_invalid_otp', 'OTP باید دقیقاً ۶ رقم باشد.');
    }

    $table = mlr_greenpay_transactions_table();
    $tx = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE request_id = %d", $request_id));
    if (!$tx || $tx->status !== 'awaiting_otp') {
        return new WP_Error('greenpay_not_awaiting_otp', 'این تراکنش در وضعیت انتظار OTP نیست.');
    }

    $claimed = $wpdb->query($wpdb->prepare(
        "UPDATE {$table} SET status = 'processing', attempts = attempts + 1, updated_at = %s WHERE request_id = %d AND status = 'awaiting_otp'",
        current_time('mysql'),
        $request_id
    ));
    if ((int) $claimed !== 1) {
        return new WP_Error('greenpay_concurrent_processing', 'تراکنش هم‌اکنون در حال پردازش است.');
    }

    $settings = mlr_greenpay_get_settings();
    $api = new MLR_GreenPay_API($settings);
    $token = $api->get_token();
    if (is_wp_error($token)) {
        mlr_greenpay_mark_transaction($request_id, [
            'status' => 'failed',
            'last_error' => $token->get_error_message(),
            'last_response' => mlr_greenpay_encode_response($token),
        ]);
        return $token;
    }

    $send_time = trim((string) $tx->send_time);
    if ($send_time === '') {
        mlr_greenpay_mark_transaction($request_id, ['status' => 'failed', 'last_error' => 'زمان درخواست OTP موجود نیست.']);
        return new WP_Error('greenpay_send_time_missing', 'زمان درخواست OTP موجود نیست؛ OTP را مجدداً درخواست کنید.');
    }

    $result = $api->confirm_debit($token, $tx->from_pocket, $otp, $tx->amount, $tx->ref_number, $send_time);
    $success = mlr_greenpay_finalize_transfer_result($request_id, $result);
    if (!$success) {
        return new WP_Error('greenpay_debit_failed', mlr_greenpay_extract_error_message($result, 'کسری GreenPay ناموفق بود.'), $result);
    }
    return true;
}

function mlr_greenpay_requeue_transaction($request_id, array $allowed_statuses, $refresh_financial_snapshot = true) {
    global $wpdb;
    $request_id = absint($request_id);
    if (!$request_id) {
        return false;
    }

    $table = mlr_greenpay_transactions_table();
    $tx = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE request_id = %d", $request_id));
    if (!$tx || (int) $tx->eligible !== 1 || !in_array($tx->status, $allowed_statuses, true)) {
        return false;
    }

    $updates = [
        'status' => 'queued',
        'last_error' => null,
        'last_http_code' => null,
        'last_response' => null,
        'provider_status' => null,
        'provider_reference' => null,
        'otp_requested_at' => null,
        'send_time' => null,
        'updated_at' => current_time('mysql'),
    ];

    $settings = mlr_greenpay_get_settings();
    $updates['from_pocket'] = preg_replace('/\D+/', '', (string) ($settings['from_pocket_number'] ?? $tx->from_pocket));
    if (($settings['environment'] ?? 'test') === 'test' && $updates['from_pocket'] === '') {
        $updates['from_pocket'] = '1262010000002551';
    }
    $updates['to_pocket'] = preg_replace('/\D+/', '', (string) ($settings['to_pocket_number'] ?? ''));
    $updates['environment'] = (($settings['environment'] ?? 'test') === 'live') ? 'live' : 'test';

    if ($refresh_financial_snapshot) {
        $requests_table = $wpdb->prefix . 'loan_requests';
        $request = $wpdb->get_row($wpdb->prepare(
            "SELECT loan_amount, facility_amount FROM {$requests_table} WHERE id = %d",
            $request_id
        ));
        if ($request) {
            $updates['amount'] = (isset($request->facility_amount) && $request->facility_amount !== '' && $request->facility_amount !== null)
                ? round((float) $request->facility_amount, 2)
                : round((float) $request->loan_amount, 2);
        }
    }

    $updated = $wpdb->update($table, $updates, ['request_id' => $request_id]);
    if ($updated !== false) {
        mlr_greenpay_add_event($request_id, 'greenpay_queued', 'کسری GreenPay برای پردازش مجدد در صف قرار گرفت.');
        mlr_greenpay_schedule_request($request_id);
        return true;
    }
    return false;
}

function mlr_greenpay_retry_failed_request($request_id) {
    // failed means the provider returned a definite non-debit result; refreshing the configured
    // pocket and current facility amount before retry is therefore safe.
    return mlr_greenpay_requeue_transaction($request_id, ['failed'], true);
}

function mlr_greenpay_resend_otp($request_id) {
    // No debit has happened in awaiting_otp. Keep the original amount snapshot but refresh endpoint/pocket settings.
    return mlr_greenpay_requeue_transaction($request_id, ['awaiting_otp'], false);
}

/**
 * Recover jobs after deployments or cron loss. Never auto-retry an unknown
 * transaction; a stale processing transaction is deliberately marked unknown.
 */
function mlr_greenpay_recover_jobs() {
    if (get_transient('mlr_greenpay_recovery_lock')) {
        return;
    }
    set_transient('mlr_greenpay_recovery_lock', 1, MINUTE_IN_SECONDS);

    global $wpdb;
    mlr_greenpay_maybe_install_schema();
    $table = mlr_greenpay_transactions_table();

    $stale_before = date('Y-m-d H:i:s', current_time('timestamp') - (15 * MINUTE_IN_SECONDS));
    $stale_processing = $wpdb->get_col($wpdb->prepare(
        "SELECT request_id FROM {$table} WHERE status = 'processing' AND updated_at < %s LIMIT 20",
        $stale_before
    ));
    foreach ((array) $stale_processing as $request_id) {
        mlr_greenpay_mark_transaction($request_id, [
            'status' => 'unknown',
            'last_error' => 'پردازش قبلی بدون نتیجه قطعی متوقف شده است؛ برای جلوگیری از دوبارکسر، تلاش خودکار متوقف شد.',
        ]);
        mlr_greenpay_notify_admin($request_id, 'وضعیت تراکنش GreenPay پرونده #' . absint($request_id) . ' نامشخص شده است؛ استعلام لازم است.');
    }

    $queued = $wpdb->get_col("SELECT request_id FROM {$table} WHERE status = 'queued' AND eligible = 1 ORDER BY updated_at ASC LIMIT 20");
    foreach ((array) $queued as $request_id) {
        mlr_greenpay_schedule_request($request_id);
    }
}
add_action('init', 'mlr_greenpay_recover_jobs', 50);

function mlr_greenpay_render_api_settings_section() {
    $settings = mlr_greenpay_get_settings();
    $stored_settings = get_option('mlr_greenpay_settings', []);
    $stored_settings = is_array($stored_settings) ? $stored_settings : [];
    $password_saved = !empty($stored_settings['password']);
    $api_key_saved = !empty($stored_settings['api_key']);
    ?>
    <div class="mlr-settings-card" style="margin-top:16px;">
        <h2>اتصال GreenPay / BKI</h2>
        <p class="description">این اتصال مستقل از منطق اصلی بابانوئل است. فقط برای پرونده‌هایی که مدیر صراحتاً «مشمول GreenPay» کرده است، با ورود پرونده به «تأیید مدارک» و در صورت فعال بودن، کسری بر اساس <strong>فیلد مبلغ تسهیلات محاسبه‌شده (facility_amount؛ با fallback به loan_amount برای پرونده‌های قدیمی) و با واحد ریال</strong> در صف پردازش قرار می‌گیرد. خطای GreenPay وضعیت پرونده را تغییر نمی‌دهد.</p>
        <table class="form-table">
            <tr>
                <th>فعال‌سازی</th>
                <td>
                    <label><input type="checkbox" name="mlr_greenpay_settings[enabled]" value="1" <?php checked(!empty($settings['enabled'])); ?>> اتصال GreenPay فعال باشد</label><br>
                    <label><input type="checkbox" name="mlr_greenpay_settings[auto_debit_on_docs_approved]" value="1" <?php checked(!empty($settings['auto_debit_on_docs_approved'])); ?>> برای پرونده‌های مشمول، هنگام ورود به «تأیید مدارک» کسری در صف قرار گیرد</label>
                    <p class="description">برای ایمنی، نسخه جدید پس از نصب خودکار GreenPay را فعال نمی‌کند؛ پس از کنترل تنظیمات این گزینه را روشن کنید.</p>
                </td>
            </tr>
            <tr>
                <th><label for="mlr_gp_environment">محیط</label></th>
                <td>
                    <select id="mlr_gp_environment" name="mlr_greenpay_settings[environment]">
                        <option value="test" <?php selected($settings['environment'], 'test'); ?>>تست / Sandbox</option>
                        <option value="live" <?php selected($settings['environment'], 'live'); ?>>عملیاتی / Production</option>
                    </select>
                    <p class="description">در محیط عملیاتی فقط HTTPS پذیرفته می‌شود.</p>
                </td>
            </tr>
            <tr><th>Username</th><td><input type="text" name="mlr_greenpay_settings[username]" value="<?php echo esc_attr($settings['username']); ?>" class="regular-text ltr" autocomplete="off"></td></tr>
            <tr><th>Password</th><td><input type="password" name="mlr_greenpay_settings[password]" value="" class="regular-text ltr" autocomplete="new-password" placeholder="<?php echo esc_attr($password_saved ? '•••••••• (ذخیره شده؛ برای تغییر مقدار جدید وارد کنید)' : 'در تست اگر خالی باشد مقدار 1 استفاده می‌شود'); ?>"><p class="description">مقدار خالی، رمز ذخیره‌شده را پاک نمی‌کند. در Sandbox اگر هیچ رمزی ذخیره نشده باشد، مقدار تستی 1 استفاده می‌شود.</p></td></tr>
            <tr><th>API Key</th><td><input type="password" name="mlr_greenpay_settings[api_key]" value="" class="regular-text ltr" autocomplete="new-password" placeholder="<?php echo esc_attr($api_key_saved ? '•••••••• (ذخیره شده؛ برای تغییر مقدار جدید وارد کنید)' : 'API Key'); ?>"><p class="description">مقدار خالی، API Key ذخیره‌شده را پاک نمی‌کند.</p></td></tr>
            <tr><th>Terminal Number</th><td><input type="text" name="mlr_greenpay_settings[terminal_number]" value="<?php echo esc_attr($settings['terminal_number']); ?>" class="regular-text ltr"></td></tr>
            <tr><th>Merchant ID</th><td><input type="text" name="mlr_greenpay_settings[merchant_id]" value="<?php echo esc_attr($settings['merchant_id']); ?>" class="regular-text ltr" inputmode="numeric"></td></tr>
            <tr><th>FromPocketNumber</th><td><input type="text" name="mlr_greenpay_settings[from_pocket_number]" value="<?php echo esc_attr($settings['from_pocket_number']); ?>" class="regular-text ltr" maxlength="16" inputmode="numeric"><p class="description">مقدار تست پیش‌فرض: 1262010000002551. در محیط عملیاتی شماره واقعی قراردادی GreenPay را تنظیم کنید.</p></td></tr>
            <tr><th>ToPocketNumber</th><td><input type="text" name="mlr_greenpay_settings[to_pocket_number]" value="<?php echo esc_attr($settings['to_pocket_number']); ?>" class="regular-text ltr" maxlength="16" inputmode="numeric"><p class="description">طبق سناریوی فعلی می‌تواند خالی باشد و به صورت رشته خالی ارسال می‌شود.</p></td></tr>
            <tr>
                <th>OTP محیط تست</th>
                <td>
                    <input type="text" name="mlr_greenpay_settings[test_otp]" value="<?php echo esc_attr($settings['test_otp']); ?>" class="small-text ltr" maxlength="6" inputmode="numeric">
                    <label style="margin-right:14px;"><input type="checkbox" name="mlr_greenpay_settings[test_skip_otp_request]" value="1" <?php checked(!empty($settings['test_skip_otp_request'])); ?>> در تست، API ارسال OTP فراخوانی نشود</label>
                    <p class="description">پیش‌فرض تست 123456 است. OTP در دیتابیس تراکنش ذخیره نمی‌شود.</p>
                </td>
            </tr>
            <tr><th>Auth Base URL</th><td><input type="url" name="mlr_greenpay_settings[auth_base_url]" value="<?php echo esc_attr($settings['auth_base_url']); ?>" class="large-text ltr"></td></tr>
            <tr><th>Purchase Base URL</th><td><input type="url" name="mlr_greenpay_settings[purchase_base_url]" value="<?php echo esc_attr($settings['purchase_base_url']); ?>" class="large-text ltr"></td></tr>
            <tr><th>Timeout</th><td><input type="number" min="5" max="60" name="mlr_greenpay_settings[request_timeout]" value="<?php echo esc_attr($settings['request_timeout']); ?>" class="small-text"> ثانیه</td></tr>
            <tr><th>بافر زمان OTP</th><td><input type="number" min="0" max="60" name="mlr_greenpay_settings[otp_time_buffer]" value="<?php echo esc_attr($settings['otp_time_buffer']); ?>" class="small-text"> ثانیه <p class="description">برای سازگاری با نمونه GreenPay، پیش‌فرض ۱۰ ثانیه است.</p></td></tr>
        </table>
        <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=mlr-greenpay-transactions')); ?>">مدیریت GreenPay</a></p>
    </div>
    <?php
}
add_action('mlr_api_settings_page_extra_sections', 'mlr_greenpay_render_api_settings_section');
