<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Minimal GreenPay/BKI API client used by the Babanoell loan workflow.
 *
 * This client intentionally uses the WordPress HTTP API and leaves TLS
 * certificate verification enabled. It does not depend on WooCommerce.
 */
class MLR_GreenPay_API {
    private $settings = [];
    private $environment = 'test';
    private $auth_base_url = '';
    private $purchase_base_url = '';
    private $username = '';
    private $password = '';
    private $api_key = '';
    private $terminal_number = '';
    private $merchant_id = '';
    private $to_pocket_number = '';
    private $timeout = 25;

    public function __construct($settings = null) {
        if (!is_array($settings)) {
            $settings = function_exists('mlr_greenpay_get_settings') ? mlr_greenpay_get_settings() : [];
        }

        $this->settings = $settings;
        $this->environment = (($settings['environment'] ?? 'test') === 'live') ? 'live' : 'test';
        $this->auth_base_url = rtrim((string) ($settings['auth_base_url'] ?? ''), '/');
        $this->purchase_base_url = rtrim((string) ($settings['purchase_base_url'] ?? ''), '/');
        $this->username = trim((string) ($settings['username'] ?? ''));
        $this->password = (string) ($settings['password'] ?? '');
        $this->api_key = trim((string) ($settings['api_key'] ?? ''));
        $this->terminal_number = trim((string) ($settings['terminal_number'] ?? ''));
        $this->merchant_id = trim((string) ($settings['merchant_id'] ?? ''));
        $this->to_pocket_number = trim((string) ($settings['to_pocket_number'] ?? ''));
        $this->timeout = max(5, min(60, absint($settings['request_timeout'] ?? 25)));

        // Test credential supplied by GreenPay for the sandbox.
        if ($this->environment === 'test' && $this->password === '') {
            $this->password = '1';
        }
    }

    public function validate_configuration() {
        $missing = [];
        foreach ([
            'username' => $this->username,
            'password' => $this->password,
            'api_key' => $this->api_key,
            'terminal_number' => $this->terminal_number,
            'merchant_id' => $this->merchant_id,
            'auth_base_url' => $this->auth_base_url,
            'purchase_base_url' => $this->purchase_base_url,
        ] as $key => $value) {
            if ($value === '') {
                $missing[] = $key;
            }
        }

        if (!empty($missing)) {
            return new WP_Error('greenpay_config_missing', 'تنظیمات GreenPay ناقص است: ' . implode(', ', $missing));
        }

        if ($this->environment === 'live') {
            foreach ([$this->auth_base_url, $this->purchase_base_url] as $url) {
                if (strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) !== 'https') {
                    return new WP_Error('greenpay_https_required', 'در محیط عملیاتی GreenPay استفاده از HTTPS الزامی است.');
                }
            }
        }

        return true;
    }

    public function get_token() {
        $valid = $this->validate_configuration();
        if (is_wp_error($valid)) {
            return $valid;
        }

        $response = $this->post_json(
            $this->auth_base_url . '/submit',
            [
                'Username' => $this->username,
                'Password' => $this->password,
                'ApiKey'   => $this->api_key,
            ]
        );

        if (is_wp_error($response)) {
            return $response;
        }

        if ((int) ($response['http_code'] ?? 0) !== 200) {
            return new WP_Error(
                'greenpay_token_http_error',
                $this->extract_error_message($response, 'خطا در دریافت توکن GreenPay.'),
                $response
            );
        }

        $token = trim((string) ($response['Token'] ?? $response['token'] ?? ''));
        if ($token === '') {
            return new WP_Error(
                'greenpay_token_missing',
                $this->extract_error_message($response, 'توکن از GreenPay دریافت نشد.'),
                $response
            );
        }

        return $token;
    }

    public function send_otp($token, $pocket_number, $amount) {
        return $this->post_json(
            $this->purchase_base_url . '/sendPurchaseOTP',
            [
                'PocketNumber'   => (string) $pocket_number,
                'Amount'         => (int) round((float) $amount),
                'ApiKey'         => $this->api_key,
                'TerminalNumber' => $this->terminal_number,
                'MerchantID'     => (int) $this->merchant_id,
            ],
            $token
        );
    }

    public function confirm_debit($token, $from_pocket_number, $otp, $amount, $ref_number, $send_time) {
        return $this->post_json(
            $this->purchase_base_url . '/transferByPocket',
            [
                'ApiKey'           => $this->api_key,
                'FromPocketNumber' => (string) $from_pocket_number,
                'ToPocketNumber'   => $this->to_pocket_number !== '' ? $this->to_pocket_number : '',
                // Babanoell stores loan_amount in Rial; do not multiply by 10.
                'Amount'           => (string) ((int) round((float) $amount)),
                'TerminalNumber'   => $this->terminal_number,
                'OTP'              => (string) $otp,
                'SendTime'         => (string) $send_time,
                'RefNumber'        => (string) $ref_number,
            ],
            $token
        );
    }

    public function is_ready($token, $value = '') {
        $value = $value !== '' ? $value : ('MLR-' . wp_generate_password(8, false, false));
        $url = $this->auth_base_url . '/isReady/' . rawurlencode($value);
        $response = $this->request('GET', $url, null, $token);
        if (is_wp_error($response)) {
            return $response;
        }
        return isset($response['Value']) && (string) $response['Value'] === (string) $value;
    }

    private function post_json($url, array $payload, $token = null) {
        return $this->request('POST', $url, $payload, $token);
    }

    private function request($method, $url, $payload = null, $token = null) {
        if (!wp_http_validate_url($url)) {
            return new WP_Error('greenpay_invalid_url', 'آدرس API گرین‌پی معتبر نیست.');
        }

        if ($this->environment === 'live' && strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) !== 'https') {
            return new WP_Error('greenpay_https_required', 'در محیط عملیاتی GreenPay استفاده از HTTPS الزامی است.');
        }

        $headers = [
            'Accept'       => 'application/json',
            'Content-Type' => 'application/json; charset=utf-8',
        ];
        if (is_string($token) && $token !== '') {
            $headers['Authorization'] = 'Bearer ' . $token;
        }

        $args = [
            'method'      => strtoupper($method),
            'timeout'     => $this->timeout,
            'redirection' => 2,
            'headers'     => $headers,
            // Keep WordPress' secure default explicitly documented.
            'sslverify'   => true,
            'user-agent'  => 'Babanoell-MLR/' . (defined('MLR_VERSION') ? MLR_VERSION : 'unknown') . '; ' . home_url('/'),
        ];
        if ($payload !== null) {
            $args['body'] = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        $raw = wp_remote_request($url, $args);
        if (is_wp_error($raw)) {
            $data = [
                'transport_error' => true,
                'error_code'      => $raw->get_error_code(),
                'error_message'   => $raw->get_error_message(),
                'url_host'        => (string) wp_parse_url($url, PHP_URL_HOST),
            ];
            return new WP_Error('greenpay_transport_error', 'خطا در ارتباط با GreenPay: ' . $raw->get_error_message(), $data);
        }

        $http_code = (int) wp_remote_retrieve_response_code($raw);
        $body = trim((string) wp_remote_retrieve_body($raw));
        $content_type = (string) wp_remote_retrieve_header($raw, 'content-type');

        if ($body === '') {
            return [
                'http_code'    => $http_code,
                'content_type' => $content_type,
                'raw_response' => '',
            ];
        }

        // Remove UTF-8 BOM before JSON decoding.
        $body = preg_replace('/^\xEF\xBB\xBF/', '', $body);
        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            return [
                'http_code'    => $http_code,
                'content_type' => $content_type,
                'raw_response' => substr($body, 0, 2000),
                'json_error'   => json_last_error_msg(),
            ];
        }

        $decoded['http_code'] = $http_code;
        return $decoded;
    }

    private function extract_error_message(array $response, $fallback) {
        if (!empty($response['Errors']) && is_array($response['Errors'])) {
            $first = reset($response['Errors']);
            if (is_array($first)) {
                foreach (['ErrorMessage', 'Message', 'message'] as $key) {
                    if (!empty($first[$key])) {
                        return sanitize_text_field((string) $first[$key]);
                    }
                }
            }
        }
        foreach (['Message', 'message', 'ErrorMessage', 'error'] as $key) {
            if (!empty($response[$key]) && is_scalar($response[$key])) {
                return sanitize_text_field((string) $response[$key]);
            }
        }
        return $fallback;
    }
}
