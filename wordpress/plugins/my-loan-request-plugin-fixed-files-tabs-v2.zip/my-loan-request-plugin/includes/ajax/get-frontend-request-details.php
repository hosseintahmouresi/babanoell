<?php
// FILE: my-loan-request-plugin/includes/ajax/get-frontend-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');

function mlr_get_frontend_request_details_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً ابتدا وارد سایت شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $is_admin = current_user_can('manage_options');
    $is_bank_expert = in_array('bank', (array) $current_user->roles);

    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';

    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }

    // بررسی سطح دسترسی
    if (!$is_admin) {
        if ($is_bank_expert) {
            if ($request->assigned_bank_user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این پرونده ندارید.']);
                return;
            }
        } else {
            if ($request->user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این درخواست ندارید.']);
                return;
            }
        }
    }

    $uploaded_documents = maybe_unserialize($request->required_documents);
    if (!is_array($uploaded_documents)) {
        $uploaded_documents = [];
    }
    
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    $form_data = !empty($request->form_data) ? json_decode($request->form_data, true) : [];
    if (!is_array($form_data)) { $form_data = []; }
    
    // استخراج گزارش اعتبارسنجی (اولویت با ستون اختصاصی، سپس form_data)
    $credit_report = null;
    if (!empty($request->credit_report_json)) {
        $credit_report = json_decode($request->credit_report_json, true);
    } elseif (isset($form_data['credit_report_json'])) {
        // اگر در form_data باشد، ممکن است رشته JSON باشد یا آرایه
        $cr_data = $form_data['credit_report_json'];
        $credit_report = is_string($cr_data) ? json_decode($cr_data, true) : $cr_data;
    }

    // حذف فیلد گزارش اعتبارسنجی از لیست داده‌های فرم برای جلوگیری از نمایش تکراری و خام
    if (isset($form_data['credit_report_json'])) {
        unset($form_data['credit_report_json']);
    }
    

    $form_data_labels = [
        'full_name'            => 'نام کامل',
        'national_code'        => 'کد ملی',
        'mobile_number'        => 'شماره موبایل',
        'phone_number'         => 'تلفن ثابت',
        'birth_date'           => 'تاریخ تولد',
        'birth_day'            => 'روز تولد',
        'birth_month'          => 'ماه تولد',
        'birth_year'           => 'سال تولد',
        'occupation'           => 'شغل',
        'postal_code'          => 'کد پستی',
        'residential_address'  => 'آدرس محل سکونت',
        'order_items'          => 'اقلام سفارش',
        'installment_plan_id'  => 'شناسه طرح اقساط',
        'plan_id'              => 'شناسه طرح',
        'loan_amount'          => 'مبلغ وام',
        'installment_count'    => 'تعداد اقساط',
        'installment_interval' => 'فاصله اقساط (ماه)',
    ];
    $request_events = function_exists('mlr_get_request_events') ? mlr_get_request_events($request_id, 500) : [];
    $request_messages = function_exists('mlr_get_request_messages') ? mlr_get_request_messages($request_id, 500) : [];

    // فایل‌های تکمیلی
    $extra_files = [];
    $extra_files['bank_validation_file'] = $request->bank_validation_file ?? '';
    $extra_files['signature_image'] = $request->signature_image ?? '';
    $extra_files['contract_file'] = $request->contract_file ?? '';

    $parsed_check_images = [];
    if (!empty($request->check_images)) {
        $maybe = maybe_unserialize($request->check_images);
        if (is_array($maybe)) {
            $parsed_check_images = $maybe;
        } else {
            $json = json_decode($request->check_images, true);
            if (is_array($json)) {
                $parsed_check_images = $json;
            } else {
                $parts = preg_split('/[\r\n,]+/', (string)$request->check_images);
                $parts = array_filter(array_map('trim', $parts));
                $parsed_check_images = $parts ? $parts : [(string)$request->check_images];
            }
        }
    }
    if (!empty($parsed_check_images)) {
        $extra_files['check_images'] = $parsed_check_images;
    }

    $extra_file_labels = [
        'bank_validation_file' => 'فایل اعتبارسنجی بانک',
        'signature_image'      => 'تصویر امضا',
        'contract_file'        => 'فایل قرارداد',
        'check_images'         => 'تصاویر چک',
    ];
    
    $occupations = [
        'official_employee' => 'کارمند رسمی', 
        'contract_employee' => 'کارمند قراردادی', 
        'worker' => 'کارگر', 
        'freelancer' => 'آزاد', 
        'retired' => 'بازنشسته', 
        'pensioner' => 'مستمری بگیر', 
        'employer' => 'کارفرما', 
        'other' => 'سایر'
    ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : $request->occupation;
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    // تولید شناسه‌های کاملاً یکتا برای جلوگیری از تداخل DOM
    $uniq = uniqid('req_');
    $form_id = 'mlr_upload_form_' . $uniq;
    $input_file_id = 'mlr_file_' . $uniq;
    $input_note_id = 'mlr_note_' . $uniq;
    $input_req_id = 'mlr_req_' . $uniq;

    // --- Data Preparation for Unified View ---
    $sections = [
        'identity' => [
            'title' => 'اطلاعات هویتی و تماس',
            'icon' => 'dashicons-id',
            'fields' => [
                ['label' => 'نام و نام خانوادگی', 'value' => $request->full_name],
                ['label' => 'کد ملی', 'value' => $request->national_code],
                ['label' => 'نام پدر', 'value' => $form_data['father_name'] ?? '-'],
                ['label' => 'شماره شناسنامه', 'value' => $form_data['certificate_number'] ?? '-'],
                ['label' => 'صادره از', 'value' => $form_data['certificate_city'] ?? '-'],
                ['label' => 'تاریخ تولد', 'value' => function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->birth_date) : $request->birth_date],
                ['label' => 'شماره موبایل', 'value' => $request->mobile_number],
                ['label' => 'تلفن ثابت', 'value' => $request->phone_number ?: '-'],
            ]
        ],
        'job_addr' => [
            'title' => 'اطلاعات شغلی و سکونت',
            'icon' => 'dashicons-location',
            'fields' => [
                ['label' => 'شغل', 'value' => $occupation_display],
                ['label' => 'کد پستی', 'value' => $request->postal_code ?: '-'],
                ['label' => 'آدرس سکونت', 'value' => $request->residential_address ?: '-', 'wide' => true],
                ['label' => 'آدرس محل کار', 'value' => $request->work_address ?: '-', 'wide' => true],
            ]
        ],
        'financial' => [
            'title' => 'اطلاعات مالی و طرح',
            'icon' => 'dashicons-chart-line',
            'fields' => [
                ['label' => 'نام طرح', 'value' => $request->plan_name],
                ['label' => 'مبلغ تسهیلات', 'value' => number_format($request->loan_amount) . ' ریال'],
                ['label' => 'تعداد اقساط', 'value' => $request->installment_count . ' قسط'],
                ['label' => 'مبلغ هر قسط', 'value' => number_format($request->installment_amount) . ' ریال'],
                ['label' => 'پیش‌پرداخت', 'value' => number_format($request->prepayment) . ' ریال'],
                ['label' => 'مبلغ چک ضمانت (اصل)', 'value' => isset($form_data['guarantee_check_principal']) ? number_format((float)$form_data['guarantee_check_principal']) . ' ریال' : '-'],
                ['label' => 'مبلغ چک ضمانت (کل)', 'value' => isset($form_data['guarantee_check_total']) ? number_format((float)$form_data['guarantee_check_total']) . ' ریال' : '-'],
                ['label' => 'وضعیت درخواست', 'value' => $request->status, 'is_status' => true],
            ]
        ]
    ];

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست <span style="color:var(--mlr-primary); margin-right: 5px;">#<?php echo esc_html($request->id); ?></span></h3>
        <span class="mlr-status-badge status-<?php echo sanitize_html_class($request->status); ?>"><?php echo esc_html($request->status); ?></span>
    </div>
    
    <div class="mlr-modal-body">
        
        <?php if ($request->status === 'نقص مدارک' && !$is_bank_expert && !$is_admin): ?>
            <div class="mlr-reupload-section" style="margin-bottom: 25px; padding: 20px; border: 2px dashed #f39c12; background: #fffdf6; border-radius: 8px;">
                <h4 style="color: #d35400; margin-top: 0; margin-bottom: 10px; display: flex; align-items: center;">
                    <span class="dashicons dashicons-warning" style="margin-left: 5px;"></span> رفع نقص مدارک
                </h4>
                <p style="margin-bottom: 15px; font-size: 0.95em; line-height: 1.6; color: #444;">
                    پرونده شما به دلیل نقص در مدارک بازگردانده شده است. لطفاً بخش "سوابق و پیام‌ها" را مطالعه کنید تا از علت نقص مطلع شوید، سپس مدارک صحیح را بارگذاری کنید.
                    <br><strong>پس از ارسال، وضعیت پرونده به "در حال بررسی" تغییر خواهد کرد.</strong>
                </p>
                
                <form id="<?php echo esc_attr($form_id); ?>" class="mlr-universal-upload-form" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" id="<?php echo esc_attr($input_req_id); ?>" value="<?php echo esc_attr($request->id); ?>">
                    
                    <div class="mlr-form-group">
                        <label for="<?php echo esc_attr($input_file_id); ?>" style="font-weight: bold; display: block; margin-bottom: 8px; color: #333;">انتخاب مدارک جدید (تصویر یا PDF):</label>
                        <input type="file" id="<?php echo esc_attr($input_file_id); ?>" name="additional_files[]" multiple accept=".jpg,.jpeg,.png,.pdf" required style="width: 100%; padding: 10px; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
                        <p class="description" style="font-size: 0.85em; color: #666; margin-top: 5px;">می‌توانید چند فایل را همزمان انتخاب کنید.</p>
                    </div>

                    <div class="mlr-form-group" style="margin-top: 15px;">
                        <label for="<?php echo esc_attr($input_note_id); ?>" style="font-weight: bold; display: block; margin-bottom: 8px; color: #333;">توضیحات شما (اختیاری):</label>
                        <textarea id="<?php echo esc_attr($input_note_id); ?>" name="user_note" rows="3" style="width: 100%; border: 1px solid #ddd; border-radius: 4px; padding: 8px; min-height: 80px;" placeholder="توضیحات رفع نقص..."></textarea>
                    </div>

                    <button type="submit" class="button button-primary mlr-submit-docs-btn" style="margin-top: 15px; width: 100%; height: 40px; display:flex; justify-content:center; align-items:center; font-size: 14px;">ارسال مدارک و بررسی مجدد</button>
                    <div class="mlr-upload-status" style="display:none; margin-top: 15px; padding: 10px; border-radius: 4px; text-align: center;"></div>
                </form>
            </div>
        <?php endif; ?>

        <?php echo function_exists('mlr_build_request_details_sections') ? mlr_build_request_details_sections($request, $form_data, 'frontend') : ''; ?>



        <?php if (in_array($request->status, ['تکمیل مدارک', 'در انتظار مدارک', 'در انتظار تکمیل', 'در انتظار تکمیل مدارک'], true) && !$is_bank_expert && !$is_admin): ?>
            <?php
                // Load installment plan contract settings
                $plan_settings = [];
                if (!empty($request->installment_plan_id)) {
                    $plan_row = $wpdb->get_row($wpdb->prepare("SELECT settings FROM {$plans_table} WHERE id = %d", $request->installment_plan_id));
                    if ($plan_row && !empty($plan_row->settings)) {
                        $plan_settings = maybe_unserialize($plan_row->settings);
                        if (!is_array($plan_settings)) {
                            $decoded = json_decode($plan_row->settings, true);
                            if (is_array($decoded)) {
                                $plan_settings = $decoded;
                            } else {
                                $plan_settings = [];
                            }
                        }
                    }
                }

                $contract_letterhead_url = isset($plan_settings['plan_letterhead_url']) ? $plan_settings['plan_letterhead_url'] : '';
                $contract_footer_url     = isset($plan_settings['plan_footer_url']) ? $plan_settings['plan_footer_url'] : '';
                $contract_text_raw       = isset($plan_settings['plan_contract_text']) ? $plan_settings['plan_contract_text'] : '';
                
                // Product Name Logic (Fallback to order items if product_name is empty)
                $product_name_display = $request->product_name ?? '';
                if (empty($product_name_display) && !empty($form_data['order_items'])) {
                    $items = is_string($form_data['order_items']) ? json_decode($form_data['order_items'], true) : $form_data['order_items'];
                    if (is_array($items)) {
                        $names = array_map(function($item) {
                            return is_array($item) ? ($item['name'] ?? '') : $item;
                        }, $items);
                        $product_name_display = implode('، ', array_filter($names));
                    }
                }

                $placeholder_map = [
                    '[request_id]'          => $request->id ?? '',
                    '[full_name]'           => $request->full_name ?? '',
                    '[national_code]'       => $request->national_code ?? '',
                    '[mobile_number]'       => $request->mobile_number ?? '',
                    '[loan_amount]'         => isset($request->loan_amount) ? number_format(floatval($request->loan_amount)) : '0',
                    '[installment_count]'   => isset($request->installment_count) ? intval($request->installment_count) : '',
                    '[installment_amount]'  => isset($request->installment_amount) ? number_format(floatval($request->installment_amount)) : '0',
                    '[total_payment]'       => isset($request->total_payment) ? number_format(floatval($request->total_payment)) : '0',
                    '[plan_name]'           => $request->plan_name ?? '',
                    '[created_at]'          => !empty($request->created_at) ? mlr_gregorian_to_jalali($request->created_at, 'Y/m/d') : '',
                    
                    // New Fields
                    '[father_name]'         => $form_data['father_name'] ?? '',
                    '[certificate_number]'  => $form_data['certificate_number'] ?? '',
                    '[certificate_city]'    => $form_data['certificate_city'] ?? '',
                    '[birth_date]'          => !empty($request->birth_date) ? (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->birth_date, 'Y/m/d') : $request->birth_date) : '',
                    '[residential_address]' => $request->residential_address ?? '',
                    '[postal_code]'         => $request->postal_code ?? '',
                    '[work_address]'        => $request->work_address ?? '',
                    '[phone_number]'        => $request->phone_number ?? '',
                    '[prepayment]'          => isset($request->prepayment) ? number_format(floatval($request->prepayment)) : '0',
                    '[guarantee_check_principal]' => isset($form_data['guarantee_check_principal']) ? number_format(floatval($form_data['guarantee_check_principal'])) : '0',
                    '[guarantee_check_total]'     => isset($form_data['guarantee_check_total']) ? number_format(floatval($form_data['guarantee_check_total'])) : '0',
                    '[contract_date]'       => function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali(current_time('mysql'), 'Y/m/d') : date('Y/m/d'),
                    '[occupation]'          => $occupation_display ?? '',
                    '[product_name]'        => $product_name_display,
                ];

                $contract_text_rendered = $contract_text_raw;
                if (!empty($contract_text_rendered)) {
                    $contract_text_rendered = strtr($contract_text_rendered, $placeholder_map);
                    $contract_text_rendered = wpautop($contract_text_rendered);
                }

                $contract_acc_id = 'mlr_contract_acc_' . $uniq;
                $invoice_acc_id  = 'mlr_invoice_acc_' . $uniq;
                $contract_print_id = 'mlr_contract_print_' . $uniq;
                $invoice_print_id  = 'mlr_invoice_print_' . $uniq;
            ?>
            <style>
                .mlr-accordion{border:1px solid var(--mlr-border);border-radius:12px;overflow:hidden;background:#fff;margin:0 0 15px 0}
                .mlr-acc-btn{width:100%;text-align:right;background:#f7f7f7;border:0;padding:12px 14px;cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:700}
                .mlr-acc-btn:focus{outline:none}
                .mlr-acc-content{display:none;padding:14px}
                .mlr-acc-content.is-open{display:block}
                .mlr-print-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:10px 0 0 0}
                .mlr-print-area{background:#fff}
                @media print{
                    body{background:#fff!important}
                    .mlr-no-print{display:none!important}
                    .mlr-print-area{box-shadow:none!important;border:0!important}
                }
            </style>

            <div class="mlr-reupload-section" style="margin-bottom: 25px; padding: 25px; border: 2px dashed var(--mlr-primary); background: #eff6ff; border-radius: 16px;">
                <h4 style="color: var(--mlr-primary); margin-top: 0; margin-bottom: 10px; display: flex; align-items: center;">
                    <span class="dashicons dashicons-yes-alt" style="margin-left: 5px;"></span> تکمیل مدارک
                </h4>
                <p style="margin-bottom: 15px; font-size: 0.95em; line-height: 1.8; color: #444;">
                    لطفاً قرارداد و فاکتور را مشاهده و در صورت نیاز چاپ کنید، سپس مدارک تکمیلی را بارگذاری نمایید.
                </p>

                <div class="mlr-accordion">
                    <button type="button" class="mlr-acc-btn mlr-no-print" data-target="<?php echo esc_attr($contract_acc_id); ?>">
                        <span>مشاهده و پرینت قرارداد</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div id="<?php echo esc_attr($contract_acc_id); ?>" class="mlr-acc-content">
                        <div id="<?php echo esc_attr($contract_print_id); ?>" class="mlr-print-area">
                            <?php if (!empty($contract_letterhead_url)): ?>
                                <div style="text-align:center; margin-bottom: 10px;">
                                    <img src="<?php echo esc_url($contract_letterhead_url); ?>" alt="سربرگ قرارداد" style="max-width:100%; height:auto;">
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($contract_text_rendered)): ?>
                                <div class="mlr-contract-body" style="font-size: 12.5px; line-height: 2; color:#111;">
                                    <?php echo wp_kses_post($contract_text_rendered); ?>
                                </div>
                            <?php else: ?>
                                <p>برای این طرح، متن قرارداد تنظیم نشده است.</p>
                            <?php endif; ?>

                            <?php if (!empty($contract_footer_url)): ?>
                                <div style="text-align:center; margin-top: 10px;">
                                    <img src="<?php echo esc_url($contract_footer_url); ?>" alt="پابرگ قرارداد" style="max-width:100%; height:auto;">
                                </div>
                            <?php endif; ?>

                            <?php
                                $plan_files = [];
                                if (isset($plan_settings['plan_downloadable_files']) && is_array($plan_settings['plan_downloadable_files'])) {
                                    $plan_files = array_values(array_filter($plan_settings['plan_downloadable_files']));
                                }
                            ?>
                            <?php if (!empty($plan_files)): ?>
                                <div class="mlr-no-print" style="margin-top: 12px;">
                                    <div style="font-weight:600; margin-bottom:8px;">فایل‌های پیوست قابل دانلود</div>
                                    <div style="display:flex; flex-wrap:wrap; gap:8px;">
                                        <?php foreach ($plan_files as $file_url): ?>
                                            <a class="button button-secondary" href="<?php echo esc_url($file_url); ?>" target="_blank" rel="noopener noreferrer">دانلود فایل</a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="mlr-print-actions mlr-no-print">
                            <button type="button" class="mlr-btn mlr-btn-secondary" data-print="<?php echo esc_attr($contract_print_id); ?>">چاپ قرارداد</button>
                        </div>
                    </div>
                </div>

                <div class="mlr-glass-accordion">
                    <button type="button" class="mlr-glass-acc-btn mlr-no-print" data-target="<?php echo esc_attr($invoice_acc_id); ?>">
                        <span>مشاهده و پرینت فاکتور</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div id="<?php echo esc_attr($invoice_acc_id); ?>" class="mlr-glass-acc-content">
                        <div id="<?php echo esc_attr($invoice_print_id); ?>" class="mlr-print-area">
                            <?php echo do_shortcode('[mlr_invoice id="' . intval($request->id) . '"]'); ?>
                        </div>
                        <div class="mlr-print-actions mlr-no-print">
                            <button type="button" class="mlr-btn mlr-btn-secondary" data-print="<?php echo esc_attr($invoice_print_id); ?>">چاپ فاکتور</button>
                        </div>
                    </div>
                </div>

                <?php
                    $completed_docs_form_id = 'mlr_completed_docs_form_' . $uniq;
                ?>
                <form id="mlr-complete-docs-form" class="mlr-completed-docs-form" enctype="multipart/form-data" style="margin-top: 15px;">
                    <input type="hidden" name="action" value="mlr_submit_completed_docs">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                    <div class="mlr-grid-2">
                        <div class="mlr-form-group">
                            <strong>تصاویر چک (ضروری)</strong>
                            <input type="file" name="completed_check_files[]" multiple accept=".jpg,.jpeg,.png,.pdf" class="mlr-glass-input" required>
                        </div>

                        <div class="mlr-form-group">
                            <strong>قرارداد امضا‌شده</strong>
                            <input type="file" name="signed_contract" accept=".jpg,.jpeg,.png,.pdf" class="mlr-glass-input" required>
                        </div>
                        <div class="mlr-form-group">
                            <strong>فاکتور امضا/مهر‌شده</strong>
                            <input type="file" name="signed_invoice" accept=".jpg,.jpeg,.png,.pdf" class="mlr-glass-input" required>
                        </div>
                        <div class="mlr-form-group">
                            <strong>سایر مدارک (اختیاری)</strong>
                            <input type="file" name="other_completed_files[]" multiple accept=".jpg,.jpeg,.png,.pdf" class="mlr-glass-input">
                        </div>
                    </div>

                    <div style="margin-top: 15px; display:flex; gap:10px; align-items:center;">
                        <button type="submit" class="mlr-btn mlr-btn-primary">ارسال مدارک</button>
                        <span class="mlr-doc-upload-msg" style="font-size:0.9em; color:#555;"></span>
                    </div>
                </form>

                <script>
                    (function(){
                        function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
                        qsa('.mlr-acc-btn', document).forEach(function(btn){
                            btn.addEventListener('click', function(){
                                var id = btn.getAttribute('data-target');
                                var el = document.getElementById(id);
                                if(!el) return;
                                if(el.classList.contains('is-open')){ el.classList.remove('is-open'); }
                                else{ el.classList.add('is-open'); }
                            });
                        });
                        qsa('[data-print]', document).forEach(function(btn){
                            btn.addEventListener('click', function(){
                                var targetId = btn.getAttribute('data-print');
                                var target = document.getElementById(targetId);
                                if(!target) return;

                                var w = window.open('', '_blank');
                                if(!w) return;

                                var css = '<style>@media print{body{direction:rtl;font-family:tahoma,arial,sans-serif} .mlr-no-print{display:none!important}}</style>';
                                w.document.open();
                                w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Print</title>' + css + '</head><body dir="rtl">' + target.innerHTML + '</body></html>');
                                w.document.close();
                                w.focus();
                                w.print();
                                w.close();
                            });
                        });
                    })();
                </script>
            </div>
        <?php endif; ?>

        <!-- Unified Info Sections -->
        <div class="mlr-data-grid">
            <?php foreach ($sections as $key => $section): ?>
                <div class="mlr-glass-card">
                    <h5 class="mlr-card-title"><span class="dashicons <?php echo esc_attr($section['icon']); ?>"></span> <?php echo esc_html($section['title']); ?></h5>
                    <?php foreach ($section['fields'] as $field): ?>
                        <div class="mlr-data-row <?php echo !empty($field['wide']) ? 'mlr-row-wide' : ''; ?>">
                            <span class="mlr-data-label"><?php echo esc_html($field['label']); ?></span>
                            <span class="mlr-data-value <?php echo !empty($field['is_status']) ? 'mlr-status-text' : ''; ?>">
                                <?php echo esc_html($field['value']); ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="mlr-glass-card" style="margin-top: 20px;">
            <h4 class="mlr-card-title"><span class="dashicons dashicons-info"></span> اطلاعات تکمیلی سفارش</h4>
            <div class="mlr-info-grid">
                <?php if (!empty($request->product_name)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">نام کالا/خدمت</span><strong class="mlr-data-value"><?php echo esc_html($request->product_name); ?></strong></div>
                <?php endif; ?>
            </div>
            <?php if (!empty($request->description)): ?>
                <div style="margin-top:12px;">
                    <div style="font-weight:800; color: var(--mlr-text-dark); margin-bottom: 5px;">توضیحات متقاضی:</div>
                    <div class="mlr-long-text" style="background: #f9f9f9; padding: 10px; border-radius: 4px; border: 1px solid #eee;"><?php echo nl2br(esc_html($request->description)); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($extra_files) && is_array($extra_files)): ?>
        <div class="mlr-glass-card">
            <h4 class="mlr-card-title"><span class="dashicons dashicons-media-document"></span> فایل‌های سیستمی و قرارداد</h4>
            <div class="mlr-file-grid">
                <?php foreach ($extra_files as $fkey => $fval): 
                    if (empty($fval)) continue;
                    $label = isset($extra_file_labels[$fkey]) ? $extra_file_labels[$fkey] : (function_exists('mlr_get_field_label') ? mlr_get_field_label($fkey) : ucfirst(str_replace('_',' ', $fkey)));
                ?>
                    <div class="mlr-file-item">
                        <div class="mlr-file-label"><?php echo esc_html($label); ?></div>
                        <div class="mlr-file-actions">
                            <?php if (is_array($fval)): ?>
                                <?php foreach ($fval as $idx => $url): if (empty($url)) continue; ?>
                                    <a class="mlr-view-file-btn" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" data-no-lightbox="true" data-elementor-open-lightbox="no">مشاهده <?php echo intval($idx)+1; ?></a>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <a class="mlr-view-file-btn" href="<?php echo esc_url($fval); ?>" target="_blank" rel="noopener noreferrer" data-no-lightbox="true" data-elementor-open-lightbox="no">مشاهده فایل</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php
        $grouped_docs = function_exists('mlr_group_uploaded_documents_by_category') ? mlr_group_uploaded_documents_by_category($uploaded_documents, $all_doc_labels) : [];
        $cat_labels = function_exists('mlr_get_document_category_labels') ? mlr_get_document_category_labels() : [];
        $default_cat = '';
        if (!empty($grouped_docs) && is_array($grouped_docs)) {
            $keys = array_keys($grouped_docs);
            $default_cat = isset($keys[0]) ? (string)$keys[0] : '';
        }
?>
        <?php if (!empty($grouped_docs)): ?>
        <div class="mlr-glass-card mlr-docs-card" data-default-cat="<?php echo esc_attr($default_cat); ?>">
            <h4 class="mlr-card-title"><span class="dashicons dashicons-paperclip"></span> مدارک بارگذاری شده</h4>

            <div class="mlr-docs-categories" role="tablist" aria-label="دسته‌بندی مدارک">
                <?php foreach ($grouped_docs as $cat => $items): 
                    $lbl = isset($cat_labels[$cat]) ? $cat_labels[$cat] : $cat;
                ?>
                    <button type="button" class="mlr-btn mlr-btn-secondary mlr-doc-cat-btn" data-cat="<?php echo esc_attr($cat); ?>">
                        <?php echo esc_html($lbl); ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <div class="mlr-docs-sections">
                <?php foreach ($grouped_docs as $cat => $items): ?>
                    <div class="mlr-doc-cat-section" data-cat="<?php echo esc_attr($cat); ?>" style="display:none;">
                        <div class="mlr-docs-list">
                            <?php foreach ($items as $doc): ?>
                                <div class="mlr-doc-item">
                                    <strong><?php echo esc_html($doc['label']); ?>:</strong>
                                    <?php foreach ($doc['urls'] as $i => $url): ?>
                                        <a href="<?php echo esc_url($url); ?>" target="_blank" class="mlr-view-file-btn" rel="noopener noreferrer" data-no-lightbox="true" data-elementor-open-lightbox="no">
                                            <?php echo (count($doc['urls']) > 1) ? ('مشاهده ' . intval($i + 1)) : 'مشاهده فایل'; ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <style>
                .mlr-docs-categories { display:flex; flex-wrap:wrap; gap:8px; margin: 10px 0 14px; }
                .mlr-doc-cat-btn.is-active { box-shadow: 0 0 0 3px rgba(237,169,0,0.18) !important; border-color: rgba(237,169,0,0.7) !important; }
            </style>
        </div>
        <?php endif; ?>

        <?php if (!empty($comments)): ?>
        <div class="mlr-glass-card">
            <h4 class="mlr-card-title"><span class="dashicons dashicons-format-chat"></span> سوابق و پیام‌ها (یادداشت‌های کارشناس)</h4>
            <div class="mlr-comments-list">
                <?php foreach($comments as $cm): ?>
                    <div class="mlr-comment">
                        <div style="font-size: 0.85em; color: #777; margin-bottom: 5px;">
                            <span style="font-weight: bold; color: #333;"><?php echo esc_html($cm['display_name']); ?></span> - 
                            <?php echo (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($cm['timestamp'], 'Y/m/d H:i') : $cm['timestamp']); ?>
                        </div>
                        <p style="margin: 0; line-height: 1.5;"><?php echo nl2br(esc_html($cm['text'])); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($is_bank_expert && $request->assigned_bank_user_id == $user_id): ?>
             <div class="mlr-glass-card mlr-action-box">
                 <h4 class="mlr-card-title text-primary">بررسی و تغییر وضعیت پرونده</h4>
                 <?php 
                 $action_form_id = 'mlr_expert_action_' . $uniq;
                 $status_id = 'status_' . $uniq;
                 $expert_comment_id = 'expert_comment_' . $uniq;
                 ?>
                 <form id="<?php echo esc_attr($action_form_id); ?>" class="mlr-bank-expert-action-form">
                     <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                     <div class="mlr-form-group">
                         <label for="<?php echo esc_attr($status_id); ?>">تغییر وضعیت به:</label>
                         <select name="new_status" id="<?php echo esc_attr($status_id); ?>" class="mlr-glass-input">
                            <?php 
                            $request_status_norm = function_exists('mlr_normalize_status') ? mlr_normalize_status($request->status) : $request->status;
                            $opts = ($request_status_norm == 'تایید کارشناس') 
                                ? ['تکمیل مدارک'=>'ارسال برای تکمیل مدارک','نقص مدارک'=>'اعلام نقص مدارک','رد شده'=>'رد درخواست'] 
                                : ['اعطا شده'=>'تأیید نهایی و اعطا شده','رد شده'=>'رد درخواست','تکمیل مدارک'=>'بازگشت به تکمیل مدارک'];
                            foreach($opts as $v => $l): echo "<option value='$v'>$l</option>"; endforeach; 
                            ?>
                         </select>
                     </div>
                     <div class="mlr-form-group">
                         <label for="<?php echo esc_attr($expert_comment_id); ?>">توضیحات (اختیاری):</label>
                         <textarea name="comment_text" id="<?php echo esc_attr($expert_comment_id); ?>" rows="3" class="mlr-glass-input" placeholder="توضیحاتی برای کاربر یا سیستم..."></textarea>
                     </div>
                     <div class="mlr-action-message" style="display:none; margin-bottom:10px;"></div>
                     <button type="submit" class="mlr-btn mlr-btn-primary" style="width:100%;">ثبت بررسی</button>
                 </form>
             </div>
        <?php endif; ?>


        <?php if (isset($form_data['order_items'])): 
             $v = $form_data['order_items'];
             $items = is_string($v) ? json_decode($v, true) : $v;
        ?>
            <div class="mlr-glass-card" style="margin-top: 20px;">
                <h5 class="mlr-card-title"><span class="dashicons dashicons-cart"></span> اقلام سفارش (فرم)</h5>
                <?php if (is_array($items)): ?>
                    <ul class="mlr-order-items-list">
                    <?php foreach ($items as $item): 
                        if (is_array($item)) {
                            $i_name = isset($item['name']) ? $item['name'] : '';
                            $i_qty = isset($item['qty']) ? $item['qty'] : 1;
                            $i_price = isset($item['price']) ? $item['price'] : 0;
                            echo '<li>' . sprintf('<strong>%s</strong> <span class="mlr-item-meta">(تعداد: %s | قیمت: %s ریال)</span>', esc_html($i_name), esc_html($i_qty), number_format((float)$i_price)) . '</li>';
                        } else {
                            echo '<li>' . esc_html($item) . '</li>';
                        }
                    endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p><?php echo esc_html((string)$v); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

<div class="mlr-glass-card">
    <h4 class="mlr-card-title"><span class="dashicons dashicons-list-view"></span>مراحل و رویدادهای پرونده</h4>
    <div class="mlr-events-container">
        <?php echo function_exists('mlr_render_request_events_html') ? mlr_render_request_events_html($request_events) : ''; ?>
    </div>
</div>

<div class="mlr-glass-card mlr-modal-messages-section">
    <h4 class="mlr-card-title"><span class="dashicons dashicons-email"></span>مکالمات پرونده</h4>
    <div class="mlr-messages-history" id="mlr-messages-history-container" data-request-id="<?php echo esc_attr($request->id); ?>">
        <?php echo function_exists('mlr_render_request_messages_html') ? mlr_render_request_messages_html($request_messages) : ''; ?>
    </div>
    <div class="mlr-add-message-form" style="margin-top:10px;">
        <textarea class="mlr-glass-input mlr-new-message-text" rows="3" placeholder="پیام..."></textarea>
        <div style="display:flex;gap:8px;margin-top:8px;">
            <button type="button" class="mlr-btn mlr-btn-primary mlr-send-message-btn" data-request-id="<?php echo esc_attr($request->id); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('mlr_frontend_nonce')); ?>">ارسال پیام</button>
            <button type="button" class="mlr-btn mlr-btn-secondary mlr-refresh-messages-btn" data-request-id="<?php echo esc_attr($request->id); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('mlr_frontend_nonce')); ?>">به‌روزرسانی</button>
        </div>
    </div>
</div>

<?php if ($credit_report): ?>
    <?php
        // Helper for formatting
        $fmt = function($n) { return number_format((float)$n); };
        
        // Extract Data
        $scoreObj = $credit_report['score'] ?? [];
        $reportObj = $credit_report['report'] ?? [];
        
        $score = $scoreObj['score'] ?? 0;
        $risk = $scoreObj['risk'] ?? 'نامشخص';
        $desc = $scoreObj['description'] ?? '';
        
        // اصلاح محدوده امتیاز برای نمودار
        $minScore = $scoreObj['minLimit'] ?? 0;
        $maxScore = $scoreObj['maxLimit'] ?? 1000;
        if ($maxScore < $score) $maxScore = 1000;
        
        $percent = ($maxScore > $minScore) ? (($score - $minScore) / ($maxScore - $minScore)) * 100 : 0;
        $percent = max(0, min(100, $percent));
        
        // Risk Color
        $riskClass = 'mlr-risk-unknown';
        if (strpos($risk, 'کم') !== false || strpos($risk, 'Low') !== false || in_array($risk, ['A1','A2','A3'])) $riskClass = 'mlr-risk-low';
        elseif (strpos($risk, 'متوسط') !== false || strpos($risk, 'Medium') !== false || in_array($risk, ['B1','B2','B3'])) $riskClass = 'mlr-risk-medium';
        else $riskClass = 'mlr-risk-high';
        
        // Summary
        $summary = ($reportObj['summaryInformationRelatedToContractsSum'][0]) ?? [];
        $bouncedObj = $credit_report['bouncedCheque'] ?? [];
        $bouncedCount = isset($bouncedObj['bouncedCheques']) && is_array($bouncedObj['bouncedCheques']) ? count($bouncedObj['bouncedCheques']) : 0;
    ?>
    
    <div class="mlr-glass-card mlr-report-container" style="margin-top: 20px; padding: 0; overflow: hidden;">
        <!-- Header -->
        <div class="mlr-report-header <?php echo $riskClass; ?>">
            <div class="mlr-score-circle">
                <svg viewBox="0 0 36 36" class="mlr-circular-chart">
                    <path class="mlr-circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path class="mlr-circle" stroke-dasharray="<?php echo $percent; ?>, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <text x="18" y="20.35" class="mlr-percentage"><?php echo $score; ?></text>
                </svg>
                <span class="mlr-score-label">امتیاز</span>
            </div>
            <div>
                <div style="font-size: 18px; font-weight: 700;">ریسک: <?php echo esc_html($risk); ?></div>
                <div style="font-size: 13px; opacity: 0.9;"><?php echo esc_html($desc); ?></div>
            </div>
        </div>

        <!-- Person Info -->
        <?php 
        $pInfo = $scoreObj['personInformation'] ?? ($reportObj['personInformation'] ?? []);
        if (!empty($pInfo)): ?>
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-id-alt"></span> اطلاعات هویتی</h4>
            <div class="mlr-report-content mlr-data-grid">
                <div class="mlr-data-row"><span class="mlr-data-label">نام و نام خانوادگی</span><span class="mlr-data-value"><?php echo esc_html(($pInfo['name'] ?? $pInfo['firstName'] ?? '') . ' ' . ($pInfo['family'] ?? $pInfo['lastName'] ?? '')); ?></span></div>
                <div class="mlr-data-row"><span class="mlr-data-label">کد ملی</span><span class="mlr-data-value"><?php echo esc_html($pInfo['nationalCode'] ?? '-'); ?></span></div>
                <div class="mlr-data-row"><span class="mlr-data-label">نام پدر</span><span class="mlr-data-value"><?php echo esc_html($pInfo['fatherName'] ?? '-'); ?></span></div>
                <div class="mlr-data-row"><span class="mlr-data-label">تاریخ تولد</span><span class="mlr-data-value"><?php echo esc_html($pInfo['dateOfBirth'] ?? $pInfo['birthDate'] ?? '-'); ?></span></div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Summary Cards -->
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-chart-bar"></span> خلاصه وضعیت مالی</h4>
            <div class="mlr-report-content mlr-summary-cards">
                <div class="mlr-summary-card">
                    <span class="mlr-summary-val"><?php echo $summary['inProgressContractsCount'] ?? 0; ?></span>
                    <span class="mlr-summary-lbl">تسهیلات جاری</span>
                </div>
                <div class="mlr-summary-card">
                    <span class="mlr-summary-val"><?php echo $fmt($summary['overdueAmount'] ?? 0); ?></span>
                    <span class="mlr-summary-lbl">معوقات (ریال)</span>
                </div>
                <div class="mlr-summary-card">
                    <span class="mlr-summary-val"><?php echo $bouncedCount; ?></span>
                    <span class="mlr-summary-lbl">چک برگشتی</span>
                </div>
                <div class="mlr-summary-card">
                    <span class="mlr-summary-val"><?php echo $fmt($summary['totalAmount'] ?? 0); ?></span>
                    <span class="mlr-summary-lbl">کل تسهیلات (ریال)</span>
                </div>
            </div>
        </div>

        <!-- Loans (Direct Contracts) -->
        <?php if (!empty($reportObj['directContracts'])): ?>
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-bank"></span> تسهیلات بانکی (وام‌ها)</h4>
            <div class="mlr-report-content mlr-cards-container">
                <?php foreach($reportObj['directContracts'] as $loan): 
                    $statusText = $loan['negativeContractStatus'] ?? 'جاری';
                    $statusClass = (strpos($statusText, 'معوق') !== false || strpos($statusText, 'مشکوک') !== false) ? 'mlr-badge-danger' : ((strpos($statusText, 'گذشته') !== false) ? 'mlr-badge-warning' : 'mlr-badge-success');
                ?>
                <div class="mlr-contract-card">
                    <div class="mlr-contract-header">
                        <span class="mlr-contract-org"><?php echo esc_html($loan['organizationName'] ?? 'بانک'); ?></span>
                        <span class="mlr-contract-badge <?php echo $statusClass; ?>"><?php echo esc_html($statusText); ?></span>
                    </div>
                    <div class="mlr-contract-body">
                        <div class="mlr-contract-row"><span>نوع:</span> <strong><?php echo esc_html($loan['typeOfFinancingTitle'] ?? '-'); ?></strong></div>
                        <div class="mlr-contract-row"><span>مبلغ کل:</span> <strong><?php echo $fmt($loan['totalAmount'] ?? 0); ?> ریال</strong></div>
                        <div class="mlr-contract-row"><span>مانده بدهی:</span> <strong><?php echo $fmt($loan['overdueAmount'] ?? 0); ?> ریال</strong></div>
                        <div class="mlr-contract-row"><span>شروع:</span> <strong><?php echo esc_html($loan['startDate'] ?? '-'); ?></strong></div>
                        <div class="mlr-contract-row"><span>پایان:</span> <strong><?php echo esc_html($loan['expectedEndDate'] ?? '-'); ?></strong></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Guarantees (Indirect Contracts) -->
        <?php if (!empty($reportObj['indirectContracts'])): ?>
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-groups"></span> تعهدات (ضمانت‌ها)</h4>
            <div class="mlr-report-content mlr-cards-container">
                <?php foreach($reportObj['indirectContracts'] as $g): 
                    $statusText = $g['negativeContractStatus'] ?? 'جاری';
                    $statusClass = (strpos($statusText, 'معوق') !== false) ? 'mlr-badge-danger' : 'mlr-badge-success';
                ?>
                <div class="mlr-contract-card">
                    <div class="mlr-contract-header">
                        <span class="mlr-contract-org"><?php echo esc_html($g['organizationName'] ?? 'بانک'); ?> (ضامن)</span>
                        <span class="mlr-contract-badge <?php echo $statusClass; ?>"><?php echo esc_html($statusText); ?></span>
                    </div>
                    <div class="mlr-contract-body">
                        <div class="mlr-contract-row"><span>مبلغ ضمانت:</span> <strong><?php echo $fmt($g['totalAmount'] ?? 0); ?> ریال</strong></div>
                        <div class="mlr-contract-row"><span>معوقات وام‌گیرنده:</span> <strong><?php echo $fmt($g['overdueAmount'] ?? 0); ?> ریال</strong></div>
                        <div class="mlr-contract-row"><span>سررسید:</span> <strong><?php echo esc_html($g['expectedEndDate'] ?? '-'); ?></strong></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Pichak (Cheques) -->
        <?php 
        $pichakItems = $credit_report['pichak']['personChequesData']['personChequeItems'] ?? [];
        if (!empty($pichakItems)): ?>
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-tickets-alt"></span> وضعیت چک‌های صیادی (پیچک)</h4>
            <div class="mlr-report-content">
                <table class="mlr-table">
                    <thead><tr><th>وضعیت</th><th>تعداد</th><th>مبلغ کل (ریال)</th></tr></thead>
                    <tbody>
                        <?php foreach($pichakItems as $item): 
                            if (($item['count'] ?? 0) == 0) continue;
                        ?>
                        <tr>
                            <td><?php echo esc_html($item['checkStatusTitle'] ?? '-'); ?></td>
                            <td><?php echo esc_html($item['count'] ?? 0); ?></td>
                            <td><?php echo $fmt($item['totalAmount'] ?? 0); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Bounced Cheques -->
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-warning"></span> سوابق چک برگشتی</h4>
            <div class="mlr-report-content">
                <?php if (!empty($bouncedObj['bouncedCheques'])): ?>
                <table class="mlr-table">
                    <thead><tr><th>بانک</th><th>مبلغ (ریال)</th><th>تاریخ برگشت</th><th>تاریخ رفع سوءاثر</th></tr></thead>
                    <tbody>
                        <?php foreach($bouncedObj['bouncedCheques'] as $item): 
                            $bouncedDate = isset($item['bouncedDate']) ? preg_split('/[ T]/', $item['bouncedDate'])[0] : '-';
                            $clearedDate = isset($item['clearedDate']) ? preg_split('/[ T]/', $item['clearedDate'])[0] : '---';
                        ?>
                        <tr>
                            <td><?php echo esc_html($item['organizationName'] ?? '-'); ?></td>
                            <td><?php echo $fmt($item['amount'] ?? 0); ?></td>
                            <td><?php echo esc_html($bouncedDate); ?></td>
                            <td><?php echo esc_html($clearedDate); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div class="mlr-badge mlr-badge-success" style="display:inline-block; font-size:13px; padding:5px 10px;">✅ فاقد چک برگشتی</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tax -->
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-money"></span> وضعیت مالیاتی</h4>
            <div class="mlr-report-content">
                <?php 
                $taxItems = $credit_report['tax']['taxResult'] ?? [];
                $hasTax = false;
                foreach($taxItems as $t) { if(!empty($t['year'])) $hasTax = true; }
                
                if ($hasTax): ?>
                <table class="mlr-table">
                    <thead><tr><th>سال</th><th>درآمد ابرازی</th><th>مالیات قطعی</th><th>بدهی</th></tr></thead>
                    <tbody>
                        <?php foreach($taxItems as $item): if(empty($item['year'])) continue; ?>
                        <tr>
                            <td><?php echo esc_html($item['year']); ?></td>
                            <td><?php echo $fmt($item['daramadEbrazi'] ?? 0); ?></td>
                            <td><?php echo $fmt($item['maliatGhati'] ?? 0); ?></td>
                            <td><?php echo $fmt($item['bedehiMaliatAmalkard'] ?? 0); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div class="mlr-badge mlr-badge-success" style="display:inline-block; font-size:13px; padding:5px 10px;">✅ فاقد بدهی مالیاتی</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Judiciary -->
        <?php 
        $jud = $credit_report['judiciary']['judiciaryData'] ?? [];
        if (($jud['sumExecuteCount'] ?? 0) > 0 || ($jud['sumNotExecuteCount'] ?? 0) > 0): 
        ?>
        <div class="mlr-report-section">
            <h4><span class="dashicons dashicons-gavel"></span> پرونده‌های قضایی</h4>
            <div class="mlr-report-content mlr-grid-view">
                <div class="mlr-info-item">پرونده‌های اجرا شده: <strong><?php echo esc_html($jud['sumExecuteCount']); ?></strong></div>
                <div class="mlr-info-item">پرونده‌های اجرا نشده: <strong><?php echo esc_html($jud['sumNotExecuteCount']); ?></strong></div>
                <div class="mlr-info-item">محکومیت اجرا نشده: <strong><?php echo $fmt($jud['sumNotExecuteSumPenaltyAmount'] ?? 0); ?> ریال</strong></div>
            </div>
        </div>
        <?php endif; ?>

    </div>
    
    <style>
        :root {
            --mlr-blue-dark: #1D3558;
            --mlr-blue-light: #D0E2F2;
            --mlr-gold: #eda900;
            --mlr-white-glass: rgba(255, 255, 255, 0.75);
            --mlr-white-glass-strong: rgba(255, 255, 255, 0.9);
            --mlr-border-glass: 1px solid rgba(255, 255, 255, 0.6);
            --mlr-shadow-soft: 0 10px 40px -10px rgba(29, 53, 88, 0.15);
            --mlr-radius-lg: 24px;
            --mlr-radius-md: 14px;
            --mlr-font-family: 'Vazirmatn', Tahoma, sans-serif;
        }

        .mlr-glass-wrapper {
            font-family: var(--mlr-font-family);
            direction: rtl;
            background: linear-gradient(135deg, #f0f5f9 0%, var(--mlr-blue-light) 100%);
            padding: 30px;
            border-radius: var(--mlr-radius-lg);
            box-shadow: var(--mlr-shadow-soft);
            color: var(--mlr-blue-dark);
            max-width: 1000px;
            margin: 0 auto;
        }

        .mlr-glass-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(29, 53, 88, 0.1);
        }

        .mlr-header-title h3 {
            margin: 0;
            font-size: 24px;
            font-weight: 800;
            color: var(--mlr-blue-dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .mlr-header-title .dashicons { font-size: 28px; width: 28px; height: 28px; color: var(--mlr-gold); }
        .mlr-highlight { color: var(--mlr-blue-dark); opacity: 0.7; }

        .mlr-glass-badge {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
            background: var(--mlr-white-glass-strong);
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            color: var(--mlr-blue-dark);
        }

        .mlr-glass-card {
            background: var(--mlr-white-glass);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: var(--mlr-border-glass);
            border-radius: var(--mlr-radius-md);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.05);
            padding: 25px;
            margin-bottom: 25px;
            transition: transform 0.3s ease;
        }
        .mlr-glass-card:hover { transform: translateY(-3px); background: var(--mlr-white-glass-strong); }

        .mlr-card-title {
            margin: 0 0 20px 0;
            font-size: 16px;
            font-weight: 700;
            color: var(--mlr-blue-dark);
            display: flex;
            align-items: center;
            gap: 8px;
            border-bottom: 1px solid rgba(29, 53, 88, 0.08);
            padding-bottom: 10px;
        }
        .mlr-card-title .dashicons { color: var(--mlr-gold); }

        .mlr-data-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        
        .mlr-data-row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 14px; border-bottom: 1px dashed rgba(29, 53, 88, 0.1); padding-bottom: 8px; }
        .mlr-data-row:last-child { border-bottom: none; margin-bottom: 0; }
        .mlr-data-label { color: rgba(29, 53, 88, 0.7); }
        .mlr-data-value { font-weight: 600; color: var(--mlr-blue-dark); text-align: left; }
        .mlr-row-wide { flex-direction: column; gap: 5px; align-items: flex-start; }

        /* Report Specifics */
        .mlr-report-header { display: flex; align-items: center; padding: 25px; color: #fff; margin-bottom: 0; }
        .mlr-risk-low { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .mlr-risk-medium { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
        .mlr-risk-high { background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); }
        .mlr-risk-unknown { background: linear-gradient(135deg, #64748b 0%, #475569 100%); }
        
        .mlr-score-circle { width: 80px; height: 80px; margin-left: 20px; position: relative; flex-shrink: 0; text-align: center; }
        .mlr-circular-chart { display: block; margin: 0 auto; max-width: 100%; max-height: 100%; }
        .mlr-circle-bg { fill: none; stroke: rgba(255,255,255,0.3); stroke-width: 3.8; }
        .mlr-circle { fill: none; stroke: #fff; stroke-width: 2.8; stroke-linecap: round; transition: stroke-dasharray 1s ease-out; }
        .mlr-percentage { fill: #fff; font-family: sans-serif; font-weight: bold; font-size: 0.5em; text-anchor: middle; }
        
        .mlr-score-label { font-size: 10px; font-weight: normal; margin-top: 2px; opacity: 0.9; }
        
        .mlr-report-section { padding: 20px; border-bottom: 1px solid rgba(29, 53, 88, 0.08); }
        .mlr-report-section h4 { margin: 0 0 15px 0; font-size: 15px; color: var(--mlr-blue-dark); border-right: 3px solid var(--mlr-gold); padding-right: 10px; display: flex; align-items: center; gap: 8px; }
        .mlr-report-content { padding: 15px; }
        
        .mlr-summary-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px; }
        .mlr-summary-card { background: rgba(208, 226, 242, 0.4); border: 1px solid rgba(255,255,255,0.6); border-radius: 12px; padding: 15px; text-align: center; }
        .mlr-summary-val { font-size: 16px; font-weight: 800; color: var(--mlr-blue-dark); display: block; margin-bottom: 4px; }
        .mlr-summary-lbl { font-size: 11px; color: rgba(29, 53, 88, 0.7); }
        
        .mlr-table { width: 100%; border-collapse: collapse; font-size: 12px; }
        .mlr-table th { background: rgba(208, 226, 242, 0.6); padding: 10px; text-align: right; color: var(--mlr-blue-dark); border-bottom: 1px solid rgba(29, 53, 88, 0.1); white-space: nowrap; }
        .mlr-table td { padding: 10px; border-bottom: 1px solid rgba(29, 53, 88, 0.05); color: var(--mlr-blue-dark); }
        .mlr-table tr:last-child td { border-bottom: none; }

        .mlr-cards-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px; }
        .mlr-contract-card { border: 1px solid rgba(29, 53, 88, 0.15); border-radius: 12px; overflow: hidden; background: var(--mlr-white-glass); }
        .mlr-contract-header { background: rgba(208, 226, 242, 0.6); padding: 10px 15px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(29, 53, 88, 0.1); }
        .mlr-contract-org { font-weight: 700; font-size: 13px; color: var(--mlr-blue-dark); }
        .mlr-contract-badge { font-size: 11px; padding: 3px 8px; border-radius: 12px; color: #fff; font-weight: 600; }
        .mlr-contract-body { padding: 15px; font-size: 13px; }
        .mlr-contract-row { display: flex; justify-content: space-between; margin-bottom: 8px; border-bottom: 1px dashed rgba(29, 53, 88, 0.1); padding-bottom: 4px; }
        .mlr-contract-row:last-child { margin-bottom: 0; border-bottom: none; }
        
        .mlr-badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; color: #fff; display: inline-block; }
        .mlr-badge-success { background: #10b981; }
        .mlr-badge-warning { background: #f59e0b; }
        .mlr-badge-danger { background: #ef4444; }

        /* Inputs & Buttons */
        .mlr-glass-input { width: 100%; padding: 10px; border: 1px solid rgba(29, 53, 88, 0.2); border-radius: 8px; background: rgba(255,255,255,0.8); transition: all 0.3s; }
        .mlr-glass-input:focus { background: #fff; border-color: var(--mlr-blue-dark); outline: none; box-shadow: 0 0 0 3px rgba(29, 53, 88, 0.1); }
        
        .mlr-btn { padding: 10px 20px; border-radius: 8px; border: none; cursor: pointer; font-weight: 700; transition: all 0.3s; display: inline-flex; align-items: center; justify-content: center; gap: 5px; }
        .mlr-btn-primary { background: var(--mlr-blue-dark); color: #fff; }
        .mlr-btn-primary:hover { background: var(--mlr-gold); color: var(--mlr-blue-dark); }
        .mlr-btn-secondary { background: rgba(255,255,255,0.6); color: var(--mlr-blue-dark); border: 1px solid rgba(29, 53, 88, 0.1); }
        .mlr-btn-secondary:hover { background: #fff; }

        /* Accordion */
        .mlr-glass-accordion { border: 1px solid rgba(29, 53, 88, 0.15); border-radius: 12px; overflow: hidden; background: var(--mlr-white-glass); margin-bottom: 10px; }
        .mlr-glass-acc-btn { width: 100%; text-align: right; background: rgba(208, 226, 242, 0.3); border: 0; padding: 12px 15px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; font-weight: 700; color: var(--mlr-blue-dark); }
        .mlr-glass-acc-content { display: none; padding: 15px; background: rgba(255,255,255,0.4); }
        .mlr-glass-acc-content.is-open { display: block; }

        /* Files */
        .mlr-file-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
        .mlr-file-item { background: #fff; padding: 10px; border-radius: 8px; border: 1px solid rgba(29, 53, 88, 0.1); text-align: center; }
        .mlr-file-label { font-size: 12px; margin-bottom: 5px; color: rgba(29, 53, 88, 0.7); }

        /* Comments */
        .mlr-comment { background: rgba(255,255,255,0.6); padding: 12px; border-radius: 8px; margin-bottom: 10px; border: 1px solid rgba(29, 53, 88, 0.05); }

        .mlr-order-items-list { list-style: none; padding: 0; margin: 0; }
        .mlr-order-items-list li { padding: 8px 0; border-bottom: 1px solid rgba(29, 53, 88, 0.05); }
        .mlr-order-items-list li:last-child { border-bottom: none; }
        .mlr-item-meta { color: rgba(29, 53, 88, 0.6); font-size: 0.9em; }

        @media (max-width: 768px) {
            .mlr-glass-wrapper { padding: 15px; }
            .mlr-data-grid { grid-template-columns: 1fr; }
        }
    </style>
<?php endif; ?>


    </div>
    <?php
    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}
?>