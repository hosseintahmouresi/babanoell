<?php
/**
 * Consolidated AJAX Handlers for MLR Plugin
 * This file centralizes all AJAX-related functions for better organization and maintenance.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Actions for Admin Panel (wp-admin)
add_action('wp_ajax_mlr_get_request_details', 'mlr_get_request_details_callback');
add_action('wp_ajax_mlr_add_comment', 'mlr_add_comment_callback');
add_action('wp_ajax_mlr_update_cooperation_status', 'mlr_update_cooperation_status_callback');
add_action('wp_ajax_mlr_get_cooperation_request_details', 'mlr_get_cooperation_request_details_callback');
add_action('wp_ajax_mlr_get_sms_credit', 'mlr_get_sms_credit_callback');
add_action('wp_ajax_mlr_admin_calculate_loan', 'mlr_admin_calculate_loan_callback');
add_action('wp_ajax_mlr_get_cycle_details', 'mlr_get_cycle_details_callback');

// Actions for Frontend (User-facing pages)
add_action('wp_ajax_mlr_get_user_requests', 'mlr_get_user_requests_callback');
add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');
add_action('wp_ajax_mlr_upload_additional_docs', 'mlr_upload_additional_docs_callback');
add_action('wp_ajax_mlr_submit_completed_docs', 'mlr_submit_completed_docs_callback');
add_action('wp_ajax_mlr_get_bank_expert_requests', 'mlr_get_bank_expert_requests_callback');
add_action('wp_ajax_mlr_get_verified_docs_requests', 'mlr_get_verified_docs_requests_callback');
add_action('wp_ajax_mlr_submit_bank_expert_review', 'mlr_submit_bank_expert_review_callback');
add_action('wp_ajax_mlr_get_user_cycle_details', 'mlr_get_user_cycle_details_callback');
add_action('wp_ajax_mlr_submit_loan_request', 'mlr_submit_loan_request_callback');


// Actions for both Logged-in and Logged-out Users (Public forms/calculators)
add_action('wp_ajax_nopriv_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');
add_action('wp_ajax_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');
add_action('wp_ajax_nopriv_mlr_submit_cooperation_request', 'mlr_submit_cooperation_request_callback');
add_action('wp_ajax_mlr_submit_cooperation_request', 'mlr_submit_cooperation_request_callback');
add_action('wp_ajax_nopriv_mlr_get_plan_documents', 'mlr_get_plan_documents_callback');
add_action('wp_ajax_mlr_get_plan_documents', 'mlr_get_plan_documents_callback');


/**
 * ===================================================================
 * CALCULATOR AJAX HANDLER (FRONTEND) - ROBUST VERSION
 * ===================================================================
 */
function mlr_frontend_calculate_loan_callback() {
    try {
        check_ajax_referer('mlr_frontend_calc_nonce', 'nonce');

        // 1. Sanitize and Validate Inputs
        $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
        $amount = isset($_POST['amount']) ? floatval(str_replace(',', '', $_POST['amount'])) : 0;
        $installments = isset($_POST['installments']) ? intval($_POST['installments']) : 0;
        $installment_interval = isset($_POST['installment_interval']) ? intval($_POST['installment_interval']) : 1;
        $user_commission = (isset($_POST['user_commission']) && is_numeric($_POST['user_commission'])) ? floatval($_POST['user_commission']) : null;

        if (!$plan_id) {
            wp_send_json_error(['message' => 'لطفاً یک طرح معتبر را انتخاب کنید.']);
        }
        if ($amount <= 0 || $installments <= 0) {
            wp_send_json_error(['message' => 'مبلغ و تعداد اقساط باید اعداد مثبت باشند.']);
        }

        // 2. Fetch Plan Details
        global $wpdb;
        $table_name = $wpdb->prefix . 'installment_plans';
        $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND is_active = 1", $plan_id));

        if (!$plan) {
            wp_send_json_error(['message' => 'طرح انتخاب شده یافت نشد یا در حال حاضر غیرفعال است.']);
        }

        $settings = maybe_unserialize($plan->settings);
        $display_fields = maybe_unserialize($plan->display_fields);

        // 3. Validate Amount Against Plan Limits
        $min_amount = floatval($settings['min_amount'] ?? 0);
        $max_amount = floatval($settings['max_amount'] ?? 0);

        if (($min_amount > 0 && $amount < $min_amount) || ($max_amount > 0 && $amount > $max_amount)) {
            $message = sprintf('مبلغ وارد شده باید بین %s و %s ریال باشد.', number_format($min_amount), number_format($max_amount));
            wp_send_json_error(['message' => $message]);
        }
        
        // 4. Perform Calculation
        $results = [];
        if ($plan->type === 'market') {
            $results = calculateMarketLoan($amount, $installments, $settings, $user_commission);
        } elseif ($plan->type === 'leasing') {
            $results = calculateLeasingLoan($amount, $installments, $installment_interval, $settings, $user_commission);
        }

        if (empty($results)) {
            wp_send_json_error(['message' => 'محاسبات برای این طرح انجام نشد. لطفاً تنظیمات طرح را بررسی کنید.']);
        }

        // 5. Generate and Send HTML Response
        $labels_with_units = mlr_get_calculation_labels();
        ob_start();
        echo '<table>';
        foreach ($results as $key => $value) {
            if (!empty($display_fields) && is_array($display_fields) && in_array($key, $display_fields)) {
                $label_info = $labels_with_units[$key] ?? ['label' => ucwords(str_replace('_', ' ', $key)), 'unit' => ''];
                $label = $label_info['label'];
                $unit = $label_info['unit'];
                $formatted_value = '';

                if (strpos($key, 'Percent') !== false || $unit === 'درصد') {
                     $formatted_value = number_format_i18n($value * 100, 2) . ' ' . $unit;
                } else {
                    $formatted_value = number_format_i18n(round($value)) . ' ' . $unit;
                }
                
                echo '<tr>';
                echo '<td><strong>' . esc_html($label) . '</strong></td>';
                echo '<td>' . esc_html($formatted_value) . '</td>';
                echo '</tr>';
            }
        }
        echo '</table>';
        $html = ob_get_clean();

        if (empty(trim(strip_tags($html)))) {
            $html = '<p>هیچ فیلدی برای نمایش در این طرح تنظیم نشده است. لطفاً با مدیر سایت تماس بگیرید.</p>';
        }

        wp_send_json_success(['html' => $html]);

    } catch (Exception $e) {
        mlr_log('MLR Frontend Calculator Error: ' . $e->getMessage());
        wp_send_json_error(['message' => 'خطای داخلی سرور هنگام محاسبه رخ داد.']);
    }
}


/**
 * Fetches full details for a single loan request for the admin modal.
 */
function mlr_get_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }
    
    $occupations = [ 'official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر' ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : esc_html($request->occupation);
    $all_doc_labels = mlr_get_all_document_options();
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];

    ob_start();
    ?>
    <div class="mlr-modal-content">
        <h3 class="mlr-modal-title">جزئیات کامل درخواست (شناسه: <?php echo esc_html($request->id); ?>)</h3>
        
        <div class="mlr-modal-comments-section">
            <h4><span class="dashicons dashicons-format-chat"></span> یادداشت‌های کارشناسان</h4>
            <div class="mlr-comments-history" id="mlr-comments-history-container">
                <?php if (!empty($comments) && is_array($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                        <div class="mlr-comment-bubble">
                            <div class="mlr-comment-header">
                                <strong class="mlr-comment-author"><?php echo esc_html($comment['display_name'] ?? 'کاربر'); ?></strong>
                                <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i'); ?></span>
                            </div>
                            <div class="mlr-comment-body">
                                <?php echo nl2br(esc_html($comment['text'] ?? '')); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p id="mlr-no-comments-yet">هنوز یادداشتی ثبت نشده است.</p>
                <?php endif; ?>
            </div>
            <div class="mlr-add-comment-form">
                <textarea id="mlr_new_comment_text" rows="4" class="widefat" placeholder="یادداشت جدید خود را اینجا بنویسید..."></textarea>
                <button type="button" class="button button-primary" id="mlr-add-comment-btn" data-id="<?php echo esc_attr($request->id); ?>">افزودن یادداشت</button>
                <span class="spinner"></span>
            </div>
        </div>

        <div class="mlr-modal-grid">
            <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">اطلاعات متقاضی</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام متقاضی:</strong></td><td><?php echo esc_html($request->full_name); ?></td></tr>
                    <tr><td><strong>کدملی:</strong></td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td><strong>شماره موبایل:</strong></td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td><strong>شماره تلفن ثابت:</strong></td><td><?php echo esc_html($request->phone_number ?: 'ثبت نشده'); ?></td></tr>
                    <tr><td><strong>تاریخ تولد:</strong></td><td><?php echo mlr_gregorian_to_jalali($request->birth_date); ?></td></tr>
                    <tr><td><strong>شغل:</strong></td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td><strong>آدرس محل سکونت:</strong></td><td><?php echo nl2br(esc_html($request->residential_address ?: 'ثبت نشده')); ?></td></tr>
                    <tr><td><strong>کد پستی:</strong></td><td><?php echo esc_html($request->postal_code ?: 'ثبت نشده'); ?></td></tr>
                    <tr><td><strong>آدرس محل فعالیت:</strong></td><td><?php echo nl2br(esc_html($request->work_address ?: 'ثبت نشده')); ?></td></tr>
                </table>

                <h4 class="mlr-modal-subtitle">اطلاعات تسهیلات</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام طرح:</strong></td><td><?php echo esc_html($request->plan_name ?: '---'); ?></td></tr>
                    <tr><td><strong>مبلغ تسهیلات:</strong></td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td><strong>مبلغ پیش پرداخت:</strong></td><td><?php echo number_format($request->prepayment); ?> ریال</td></tr>
                    <tr><td><strong>تعداد اقساط:</strong></td><td><?php echo esc_html($request->installment_count); ?> ماه</td></tr>
                    <tr><td><strong>فاصله اقساط:</strong></td><td><?php echo esc_html($request->installment_interval); ?> ماه</td></tr>
                    <tr><td><strong>مبلغ هر قسط:</strong></td><td><?php echo number_format($request->installment_amount); ?> ریال</td></tr>
                    <tr><td><strong>مبلغ کل بازپرداخت:</strong></td><td><?php echo number_format($request->total_payment); ?> ریال</td></tr>
                    <tr><td><strong>مبلغ شارژ کیف پول:</strong></td><td><?php echo number_format($request->wallet_charge); ?> ریال</td></tr>
                    <tr><td><strong>نام کامل محصول:</strong></td><td><?php echo nl2br(esc_html($request->product_name ?: '---')); ?></td></tr>
                    <tr><td><strong>وضعیت فعلی:</strong></td><td><?php echo esc_html($request->status); ?></td></tr>
                </table>
            </div>

            <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">مدارک بارگذاری شده</h4>
                <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                    <ul class="mlr-file-list">
                        <?php foreach($uploaded_documents as $doc_key => $doc_value): ?>
                            <li>
                                <strong><?php echo esc_html($all_doc_labels[$doc_key] ?? ucfirst(str_replace('_', ' ', $doc_key))); ?>:</strong>
                                <?php if (is_array($doc_value)): ?>
                                    <ul>
                                        <?php foreach ($doc_value as $index => $url): ?>
                                            <li><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">مشاهده فایل <?php echo $index + 1; ?></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php elseif (is_string($doc_value) && !empty($doc_value)): ?>
                                    <a href="<?php echo esc_url($doc_value); ?>" target="_blank" rel="noopener noreferrer">مشاهده فایل</a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>هیچ مدرکی برای این درخواست بارگذاری نشده است.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
    $html_output = ob_get_clean();

    wp_send_json_success(['html' => $html_output]);
}


/**
 * Adds a new comment from the admin panel to a loan request.
 */
function mlr_add_comment_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $comment_text = isset($_POST['comment']) ? sanitize_textarea_field(stripslashes($_POST['comment'])) : '';

    if (!$request_id || empty($comment_text)) {
        wp_send_json_error(['message' => 'شناسه درخواست یا متن یادداشت نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $existing_comments_json = $wpdb->get_var($wpdb->prepare("SELECT comments FROM $table_name WHERE id = %d", $request_id));
    $comments = !empty($existing_comments_json) ? json_decode($existing_comments_json, true) : [];
    if (!is_array($comments)) $comments = [];
    
    $current_user = wp_get_current_user();
    $new_comment = [
        'user_id'      => $current_user->ID,
        'display_name' => $current_user->display_name,
        'text'         => $comment_text,
        'timestamp'    => current_time('mysql'),
    ];
    $comments[] = $new_comment;

    $updated = $wpdb->update($table_name, ['comments' => json_encode($comments, JSON_UNESCAPED_UNICODE)], ['id' => $request_id]);
    if ($updated === false) {
        wp_send_json_error(['message' => 'خطایی در هنگام ذخیره یادداشت رخ داد.']);
        return;
    }

    ob_start();
    ?>
    <div class="mlr-comment-bubble">
        <div class="mlr-comment-header">
            <strong class="mlr-comment-author"><?php echo esc_html($new_comment['display_name']); ?></strong>
            <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($new_comment['timestamp'], 'Y/m/d H:i'); ?></span>
        </div>
        <div class="mlr-comment-body"><?php echo nl2br(esc_html($new_comment['text'])); ?></div>
    </div>
    <?php
    $new_comment_html = ob_get_clean();

    wp_send_json_success(['message' => 'یادداشت با موفقیت اضافه شد.', 'new_comment_html' => $new_comment_html]);
}