<?php
add_shortcode('mlr_invoice', 'mlr_invoice_shortcode');
function mlr_invoice_shortcode($atts) {
    if (!is_user_logged_in()) {
        return '<p>لطفاً ابتدا وارد شوید.</p>';
    }

    $atts = shortcode_atts(['id' => 0], $atts, 'mlr_invoice');
    $request_id = absint($atts['id']);

    if (!$request_id) {
        return '<p>شناسه درخواست معتبر نیست.</p>';
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $user_id = get_current_user_id();

    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND status = 'تأیید نهایی' AND user_id = %d", $request_id, $user_id));

    if (!$request) {
        return '<p>درخواست یافت نشد، تأیید نهایی نشده یا متعلق به شما نیست.</p>';
    }
    
    $acceptor_user_data = get_userdata($request->user_id);

    ob_start();
    ?>
    <div style="font-family:Tahoma, sans-serif; font-size: 8pt; color: black; direction: rtl; max-width: 806pt; margin: auto; padding: 15px; background: #fff;">
        <table style="width: 100%; border-collapse: collapse;">
            <tr>
                <td style="width: 20%; text-align: right;"><img width="90" height="90" src="https://babanoell.com/wp-content/uploads/لوگو-واتر-سایت-1.png" alt="logo"></td>
                <td style="width: 60%; text-align: center; font-size: 16pt; font-weight: bold;">صورتحساب نیابتی فروش کالا و خدمات</td>
                <td style="width: 20%; text-align: left; vertical-align: top;">
                    <div style="border: 1px solid black; padding: 5px; font-size: 8pt;">
                        شماره سریال: <?php echo esc_html($request->id); ?><br>
                        تاریخ: <?php echo mlr_gregorian_to_jalali($request->created_at, 'Y/m/d'); ?>
                    </div>
                </td>
            </tr>
        </table>
        <table style="width:100%; border-collapse: collapse; margin-top: 10px; font-size: 8pt;">
            <tr><th style="border:1pt solid black; text-align: center; padding: 4px; font-size: 10pt; font-weight: bold;">مشخصات تسهیل گر</th></tr>
            <tr>
                <td style="border:1pt solid black; padding: 8px;">
                    <table style="width: 100%; font-size: 8pt; border-collapse: collapse;">
                        <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>نام شخص حقیقی / حقوقی:</b> شرکت آرمان فراز هیوا</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره اقتصادی:</b> ۱۴۰۱۱۱۲۶۶۵۳</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره / شناسه ملی:</b> ۱۴۰۱۱۱۲۶۶۵۳</td>
                        </tr>
                        <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره ثبت:</b> ۷۰۹۳۵</td>
                            <td colspan="2" style="padding: 2px; text-align: right;"><b>آدرس:</b> اصفهان - بلوار کشاورز - مجتمع اداری ملل - طبقه ۱ - واحد ۱۰۴</td>
                        </tr>
                        <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>کد پستی:</b> ۸۱۷۶۹۹۵۵۹۵</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره تماس:</b> ۰۳۱ - ۹۱۰۰۱۰۵۵</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr><th style="border:1pt solid black; text-align: center; padding: 4px; font-size: 10pt; font-weight: bold;">مشخصات فروشنده (آمر)</th></tr>
            <tr>
                <td style="border:1pt solid black; padding: 8px;">
                    <table style="width: 100%; font-size: 8pt; border-collapse: collapse;">
                         <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>نام شخص حقیقی / حقوقی:</b> <?php echo esc_html($acceptor_user_data->display_name ?? '-'); ?></td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره اقتصادی:</b> -</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره / شناسه ملی:</b> -</td>
                        </tr>
                        <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره ثبت:</b> -</td>
                            <td colspan="2" style="padding: 2px; text-align: right;"><b>آدرس:</b> -</td>
                        </tr>
                        <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>کد پستی:</b> -</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره تماس:</b> -</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr><th style="border:1pt solid black; text-align: center; padding: 4px; font-size: 10pt; font-weight: bold;">مشخصات خریدار</th></tr>
            <tr>
                <td style="border:1pt solid black; padding: 8px;">
                    <table style="width: 100%; font-size: 8pt; border-collapse: collapse;">
                         <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>نام شخص حقیقی / حقوقی:</b> <?php echo esc_html($request->full_name ?? '-'); ?></td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره اقتصادی:</b> -</td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره / شناسه ملی:</b> <?php echo esc_html($request->national_code ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره ثبت:</b> -</td>
                            <td colspan="2" style="padding: 2px; text-align: right;"><b>آدرس:</b> <?php echo esc_html($request->residential_address ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>کد پستی:</b> <?php echo esc_html($request->postal_code ?? '-'); ?></td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"><b>شماره تماس:</b> <?php echo esc_html($request->mobile_number ?? '-'); ?></td>
                            <td style="width: 33.33%; padding: 2px; text-align: right;"></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p style="font-weight: bold; margin-top: 10px;">مشخصات کالا یا خدمات</p>
        <table style="width:100%; border-collapse: collapse; font-size: 8pt;">
            <thead style="font-size: 6pt;">
                <tr style="text-align: center;">
                    <th style="border:1pt solid black; padding: 5px; width: 2.5%;">ردیف</th>
                    <th style="border:1pt solid black; padding: 5px; width: 5%;">کد کالا</th>
                    <th style="border:1pt solid black; padding: 5px; width: 22.5%;">شرح کالا یا خدمات</th>
                    <th style="border:1pt solid black; padding: 5px; width: 5%;">مقدار</th>
                    <th style="border:1pt solid black; padding: 5px; width: 5%;">واحد</th>
                    <th style="border:1pt solid black; padding: 5px; width: 10%;">مبلغ واحد (ريال)</th>
                    <th style="border:1pt solid black; padding: 5px; width: 10%;">مبلغ كل (ریال)</th>
                    <th style="border:1pt solid black; padding: 5px; width: 10%;">مبلغ تخفیف</th>
                    <th style="border:1pt solid black; padding: 5px; width: 10%;">مبلغ کل پس از تخفیف (ریال)</th>
                    <th style="border:1pt solid black; padding: 5px; width: 5%;">جمع مالیات و عوارض (ریال)</th>
                    <th style="border:1pt solid black; padding: 5px; width: 10%;">جمع مبلغ كل بعلاوه جمع مالیات و عوارض (ریال)</th>
                </tr>
            </thead>
            <tbody>
                <tr style="text-align: center;">
                    <td style="border:1pt solid black; padding: 5px;">۱</td>
                    <td style="border:1pt solid black; padding: 5px;">-</td>
                    <td style="border:1pt solid black; padding: 5px; text-align: right;"><?php echo esc_html($request->product_name ?: 'تسهیلات خرید کالا'); ?></td>
                    <td style="border:1pt solid black; padding: 5px;">1.0</td>
                    <td style="border:1pt solid black; padding: 5px;">عدد</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->loan_amount); ?></td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->loan_amount); ?></td>
                    <td style="border:1pt solid black; padding: 5px;">0</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->loan_amount); ?></td>
                    <td style="border:1pt solid black; padding: 5px;">0</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->loan_amount); ?></td>
                </tr>
                <tr style="text-align: center;">
                    <td style="border:1pt solid black; padding: 5px;">۲</td>
                    <td style="border:1pt solid black; padding: 5px;">-</td>
                    <td style="border:1pt solid black; padding: 5px; text-align: right;">هزینه بیمه، کارمزد و تسهیلگری</td>
                    <td style="border:1pt solid black; padding: 5px;">1.0</td>
                    <td style="border:1pt solid black; padding: 5px;">مجموعه</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->profit); ?></td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->profit); ?></td>
                    <td style="border:1pt solid black; padding: 5px;">0</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->profit); ?></td>
                    <td style="border:1pt solid black; padding: 5px;">0</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->profit); ?></td>
                </tr>
            </tbody>
            <tfoot>
                <tr style="background-color:#D8D8D8; font-weight: bold; text-align: center;">
                    <td colspan="6" style="border:1pt solid black; text-align: left; padding: 5px;">جمع</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->total_payment); ?></td>
                    <td style="border:1pt solid black; padding: 5px;">0</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->total_payment); ?></td>
                    <td style="border:1pt solid black; padding: 5px;">0</td>
                    <td style="border:1pt solid black; padding: 5px;"><?php echo number_format($request->total_payment); ?></td>
                </tr>
                <tr style="background-color:#D8D8D8; font-weight: bold;">
                    <td colspan="11" style="border:1pt solid black; padding: 5px; text-align: right;">جمع کل فاکتور مبلغ درخواست تسهیلات: <?php echo number_format($request->total_payment); ?> ریال</td>
                </tr>
            </tfoot>
        </table>
        <table style="width:100%; border-collapse: collapse; margin-top: 10px;" cellspacing="0">
            <tr style="vertical-align: top;">
                <td style="width: 70%; border:1pt solid black;">
                    <p style="text-align: center; font-weight: bold; border-bottom: 1px solid black; padding: 5px; margin: 0;">شرایط و نحوه فروش</p>
                    <div style="padding: 5px; line-height: 1.8;">
                        <span>نقدی <span style="display: inline-block; width: 12px; height: 12px; border: 1px solid #000; vertical-align: middle;"></span></span>
                        <span style="margin-right: 20px;">غیرنقدی <span style="display: inline-block; width: 12px; height: 12px; border: 1px solid #000; background-color:#000; vertical-align: middle;"></span></span>
                        <div style="margin-top: 10px; border-top: 1px solid #000; padding-top: 5px;">
                            <b>مبلغ کل تسهیلات:</b> <?php echo number_format($request->total_payment); ?> ریال<br>
                            <b>تعداد اقساط:</b> <?php echo esc_html($request->installment_count); ?><br>
                            <b>مبلغ هر قسط:</b> <?php echo number_format($request->installment_amount); ?> ریال
                        </div>
                    </div>
                </td>
                <td style="width: 30%; border:1pt solid black; text-align: center;">
                    <p style="padding: 5px; font-weight: bold; margin: 0;">مهر و امضاء فروشنده</p>
                </td>
            </tr>
        </table>
        <div class="mlr-invoice-actions" style="text-align: center; margin-top: 20px;">
            <button onclick="window.print()" style="padding: 10px 20px; font-size: 14px; cursor: pointer;">چاپ فاکتور</button>
        </div>
    </div>
    <style>
        @media print {
            .mlr-invoice-actions { display: none; }
            body { -webkit-print-color-adjust: exact !important; color-adjust: exact !important; }
        }
    </style>
    <?php
    return ob_get_clean();
}