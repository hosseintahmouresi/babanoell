<?php
// AJAX handler for updating invoice
add_action('wp_ajax_mlr_update_invoice', 'mlr_update_invoice_callback');
function mlr_update_invoice_callback() {
    check_ajax_referer('mlr_ajax_nonce', 'nonce');
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز']);
    }

    $request_id = absint($_POST['request_id']);
    $items_json = isset($_POST['items']) ? stripslashes($_POST['items']) : '[]';
    $items = json_decode($items_json, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        wp_send_json_error(['message' => 'اطلاعات اقلام فاکتور نامعتبر است.']);
        return;
    }

    $cleaned_items = [];
    foreach ($items as $item) {
        if (is_array($item)) {
            $cleaned_items[] = [
                'code' => sanitize_text_field($item['code'] ?? ''),
                'description' => sanitize_text_field($item['description'] ?? ''),
                'order_qty' => intval($item['order_qty'] ?? 0),
                'sent_qty' => intval($item['sent_qty'] ?? 0),
                'returned_qty' => intval($item['returned_qty'] ?? 0),
                'unit' => sanitize_text_field($item['unit'] ?? ''),
                'unit_price' => floatval($item['unit_price'] ?? 0),
                'total_price' => floatval($item['total_price'] ?? 0),
            ];
        }
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $wpdb->update(
        $table_name,
        [
            'order_items' => wp_json_encode($cleaned_items),
            'order_total' => array_sum(array_column($cleaned_items, 'total_price'))
        ],
        ['id' => $request_id]
    );

    wp_send_json_success(['message' => 'تغییرات با موفقیت ذخیره شد.']);
}