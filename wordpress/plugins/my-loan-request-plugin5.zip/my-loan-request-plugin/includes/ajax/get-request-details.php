<?php
// FILE: my-loan-request-plugin/includes/ajax/get-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_request_details', 'mlr_get_request_details_callback');

function mlr_get_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'عدم دسترسی.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }
    
    // Occupations Mapping
    $occupations = [
        'official_employee' => 'کارمند رسمی',
        'contract_employee' => 'کارمند قراردادی',
        'worker' => 'کارگر',
        'freelancer' => 'آزاد',
        'retired' => 'بازنشسته',
        'pensioner' => 'مستمری بگیر',
        'employer' => 'کارفرما',
        'other' => 'سایر'
    ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : esc_html($request->occupation);

    // Documents & Items Processing
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $order_items = !empty($request->order_items) ? json_decode($request->order_items, true) : [];
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    
    // Get document labels from helper if exists, or use keys
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست #<?php echo esc_html($request->id); ?></h3>
    </div>
    
    <div class="mlr-modal-body">
        
        <div class="mlr-modal-card mlr-modal-comments-section">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-format-chat"></span>یادداشت‌های پرونده</h4>
            <div class="mlr-comments-history" id="mlr-comments-history-container">
                <?php if (!empty($comments) && is_array($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                        <div class="mlr-comment-bubble">
                            <div class="mlr-comment-header">
                                <strong class="mlr-comment-author"><?php echo esc_html($comment['display_name'] ?? 'کاربر'); ?></strong>
                                <span class="mlr-comment-date"><?php echo function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i') : ($comment['timestamp'] ?? ''); ?></span>
                            </div>
                            <div class="mlr-comment-body"><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="text-align:center;color:#999;padding:10px;">یادداشتی وجود ندارد.</p>
                <?php endif; ?>
            </div>
            <div class="mlr-add-comment-form">
                <textarea id="mlr_new_comment_text" rows="3" class="widefat" placeholder="یادداشت محرمانه کارشناس..."></textarea>
                <button type="button" class="button button-primary" id="mlr-add-comment-btn" data-id="<?php echo esc_attr($request->id); ?>" style="margin-top:10px;">ثبت یادداشت</button>
            </div>
        </div>

        <div class="mlr-modal-grid">
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-id"></span> مشخصات متقاضی</h4>
                <table class="mlr-details-table">
                    <tr><td>نام کامل:</td><td><strong><?php echo esc_html($request->full_name); ?></strong></td></tr>
                    <tr><td>کد ملی:</td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td>موبایل:</td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td>تلفن ثابت:</td><td><?php echo esc_html($request->phone_number ?: '-'); ?></td></tr>
                    <tr><td>شغل:</td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td>تاریخ تولد:</td><td><?php echo function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->birth_date) : $request->birth_date; ?></td></tr>
                    <tr><td>کد پستی:</td><td><?php echo esc_html($request->postal_code ?: '-'); ?></td></tr>
                </table>
                <div style="margin-top:10px; border-top:1px solid #eee; padding-top:5px;">
                    <strong>آدرس سکونت:</strong>
                    <p style="margin:5px 0; color:#555;"><?php echo nl2br(esc_html($request->residential_address ?: '-')); ?></p>
                </div>
                <div style="margin-top:10px; border-top:1px solid #eee; padding-top:5px;">
                    <strong>آدرس محل کار:</strong>
                    <p style="margin:5px 0; color:#555;"><?php echo nl2br(esc_html($request->work_address ?: '-')); ?></p>
                </div>
            </div>

            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-chart-line"></span> محاسبات مالی</h4>
                <table class="mlr-details-table">
                    <tr><td>طرح:</td><td><?php echo esc_html($request->plan_name); ?></td></tr>
                    <tr><td>مبلغ تسهیلات:</td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td>تعداد اقساط:</td><td><?php echo esc_html($request->installment_count); ?> ماه</td></tr>
                    <tr><td>مبلغ هر قسط:</td><td><?php echo number_format($request->installment_amount); ?> ریال</td></tr>
                    <tr><td>پیش پرداخت:</td><td><?php echo number_format($request->prepayment); ?> ریال</td></tr>
                    <tr><td>کل بازپرداخت:</td><td><?php echo number_format($request->total_payment); ?> ریال</td></tr>
                    <tr style="background:#f0f6fc;"><td><strong>وضعیت:</strong></td><td><strong><?php echo esc_html($request->status); ?></strong></td></tr>
                </table>
            </div>
        </div>

        <?php if (!empty($order_items)): ?>
        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-cart"></span> ریز اقلام درخواستی</h4>
            <table class="widefat striped" style="border:1px solid #ddd;">
                <thead>
                    <tr>
                        <th>نام کالا</th>
                        <th>تعداد</th>
                        <th>قیمت واحد (ریال)</th>
                        <th>قیمت کل (ریال)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($order_items as $item): 
                        $price = floatval($item['price'] ?? 0);
                        $qty = intval($item['qty'] ?? 1);
                    ?>
                    <tr>
                        <td><?php echo esc_html($item['name']); ?></td>
                        <td><?php echo $qty; ?></td>
                        <td><?php echo number_format($price); ?></td>
                        <td><?php echo number_format($price * $qty); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-paperclip"></span> مدارک و فایل‌ها</h4>
            <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                <div class="mlr-file-grid">
                <?php foreach($uploaded_documents as $doc_key => $doc_value): 
                    $label = isset($all_doc_labels[$doc_key]) ? $all_doc_labels[$doc_key] : ucfirst(str_replace('_', ' ', $doc_key));
                ?>
                    <div class="mlr-file-item" style="border:1px solid #ddd; padding:10px; border-radius:4px; margin-bottom:5px; background:#fff;">
                        <div style="font-weight:bold; margin-bottom:5px;"><?php echo esc_html($label); ?>:</div>
                        
                        <?php if (is_array($doc_value)): // Multiple files for this key ?>
                            <div style="display:flex; flex-wrap:wrap; gap:5px;">
                                <?php foreach ($doc_value as $idx => $url): ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank" class="button button-small" style="text-decoration:none;">
                                        <span class="dashicons dashicons-download" style="vertical-align:middle;"></span> فایل <?php echo $idx + 1; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif (is_string($doc_value) && !empty($doc_value)): // Single file ?>
                             <a href="<?php echo esc_url($doc_value); ?>" target="_blank" class="button button-small">
                                <span class="dashicons dashicons-visibility" style="vertical-align:middle;"></span> مشاهده فایل
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>هیچ مدرکی بارگذاری نشده است.</p>
            <?php endif; ?>
        </div>

    </div>
    <?php
    $html_output = ob_get_clean();
    wp_send_json_success(['html' => $html_output]);
}
?>