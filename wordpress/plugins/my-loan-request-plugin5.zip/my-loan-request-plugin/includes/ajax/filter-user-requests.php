<?php
add_action('wp_ajax_mlr_get_user_requests', 'mlr_get_user_requests_callback');
function mlr_get_user_requests_callback() {
    check_ajax_referer('mlr_user_requests_nonce', 'nonce');

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $user_id = get_current_user_id();

    if (!$user_id) {
        wp_send_json_error(['message' => 'کاربر وارد نشده است.']);
    }

    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
    $settlement_status = isset($_POST['settlement_status']) ? sanitize_text_field($_POST['settlement_status']) : '';
    $date_from_jalali = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '';
    $date_to_jalali = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '';
    $allowed_statuses = isset($_POST['allowed_statuses']) && is_array($_POST['allowed_statuses']) ? array_map('sanitize_text_field', $_POST['allowed_statuses']) : [];
    
    $date_from_gregorian = !empty($date_from_jalali) ? mlr_jalali_to_gregorian($date_from_jalali) : '';
    $date_to_gregorian = !empty($date_to_jalali) ? mlr_jalali_to_gregorian($date_to_jalali) : '';

    $where_sql = $wpdb->prepare(" WHERE r.user_id = %d", $user_id);
    
    if (!empty($search)) {
        $search_term = '%' . $wpdb->esc_like($search) . '%';
        $where_sql .= $wpdb->prepare(" AND (r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s OR r.id LIKE %s)", $search_term, $search_term, $search_term, $search_term);
    }
    if (!empty($status)) {
        $where_sql .= $wpdb->prepare(" AND r.status = %s", $status);
    }
    if (!empty($settlement_status)) {
        $where_sql .= $wpdb->prepare(" AND r.settlement_status = %s", $settlement_status);
    }
    if (!empty($date_from_gregorian)) {
        $where_sql .= $wpdb->prepare(" AND r.created_at >= %s", $date_from_gregorian . ' 00:00:00');
    }
    if (!empty($date_to_gregorian)) {
        $where_sql .= $wpdb->prepare(" AND r.created_at <= %s", $date_to_gregorian . ' 23:59:59');
    }
    if (!empty($allowed_statuses)) {
        $status_placeholders = implode(', ', array_fill(0, count($allowed_statuses), '%s'));
        $where_sql .= $wpdb->prepare(" AND r.status IN ($status_placeholders)", $allowed_statuses);
    }

    $query = "
        SELECT r.id, r.full_name, r.mobile_number, r.national_code, r.loan_amount, r.status, r.settlement_status, r.created_at, p.name as plan_name 
        FROM {$table_name} as r
        LEFT JOIN {$plans_table} as p ON r.installment_plan_id = p.id
        {$where_sql}
        ORDER BY r.created_at DESC
    ";
    
    $requests = $wpdb->get_results($query);
    
    if ($wpdb->last_error) {
        wp_send_json_error(['message' => 'خطا در بازیابی درخواست‌ها: ' . $wpdb->last_error]);
    }

    $html_output = '';
    if (empty($requests)) {
        $html_output = '<tr><td colspan="10" style="text-align:center; padding: 20px;">هیچ درخواستی با این مشخصات یافت نشد.</td></tr>';
    } else {
        foreach ($requests as $request) {
            $settlement_status_display = $request->settlement_status ?: '---';
            $html_output .= '<tr data-id="' . esc_attr($request->id) . '">';
            $html_output .= '<td data-label="شناسه">' . esc_html($request->id) . '</td>';
            $html_output .= '<td data-label="متقاضی">' . esc_html($request->full_name) . '</td>';
            $html_output .= '<td data-label="شماره موبایل">' . esc_html($request->mobile_number) . '</td>';
            $html_output .= '<td data-label="کد ملی">' . esc_html($request->national_code) . '</td>';
            $html_output .= '<td data-label="مبلغ">' . number_format($request->loan_amount) . '</td>';
            $html_output .= '<td data-label="طرح">' . esc_html($request->plan_name ?: '---') . '</td>';
            $html_output .= '<td data-label="وضعیت"><span class="mlr-status-badge" data-status="' . esc_attr($request->status) . '">' . esc_html($request->status) . '</span></td>';
            $html_output .= '<td data-label="تسویه"><span class="mlr-status-badge" data-settlement-status="' . esc_attr($settlement_status_display) . '">' . esc_html($settlement_status_display) . '</span></td>';
            $html_output .= '<td data-label="تاریخ ثبت">' . mlr_gregorian_to_jalali($request->created_at, 'Y/m/d H:i') . '</td>';
            $html_output .= '<td data-label="عملیات"><button class="mlr-view-details-btn" title="مشاهده جزئیات"><span class="dashicons dashicons-admin-generic"></span></button></td>';
            $html_output .= '</tr>';
        }
    }

    wp_send_json_success(['html' => $html_output]);
}