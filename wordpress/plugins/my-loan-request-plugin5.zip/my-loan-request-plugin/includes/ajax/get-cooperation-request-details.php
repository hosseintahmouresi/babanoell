<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_cooperation_request_details', 'mlr_get_cooperation_request_details_callback');

function mlr_get_cooperation_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cooperation_requests';
    // Select all necessary fields including new contract status/date fields
    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT id, request_type, status, data, files, contract_token, contract_signed_status, contract_signed_at, contract_expires_at
         FROM $table_name WHERE id = %d",
        $request_id
    ));


    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }

    $data = json_decode($request->data, true);
    $files = json_decode($request->files, true);

    // Labels for data fields
    $data_labels = [
        'store_name' => 'نام فروشگاه', 'store_owner_name' => 'نام مالک فروشگاه',
        'company_name' => 'نام شرکت', 'contact_person' => 'نام رابط',
        'activity_field' => 'زمینه فعالیت', 'activity_description' => 'شرح فعالیت',
        'store_address' => 'آدرس فروشگاه', 'company_address' => 'آدرس شرکت',
        'postal_code' => 'کد پستی', 'mobile_number' => 'شماره همراه',
        'phone_number' => 'تلفن ثابت', 'email' => 'ایمیل',
        'website' => 'آدرس سایت', 'branches' => 'آدرس شعب', 'description' => 'توضیحات',
        'how_heard' => 'نحوه آشنایی با ما', // Label added here
    ];

    // Labels for file fields
    $file_labels = [
        'national_card' => 'کارت ملی', 'id_card' => 'شناسنامه', 'business_license' => 'جواز کسب',
        'ownership_or_lease' => 'سند مالکیت یا اجاره‌نامه', 'thana_certificate' => 'گواهی ثبت ثنا',
        'store_images' => 'تصاویر فروشگاه', 'company_images' => 'تصاویر شرکت',
        'company_docs' => 'اساسنامه و روزنامه رسمی', 'logo' => 'لوگو', 'check_image' => 'تصویر چک',
        'signature_certificate' => 'گواهی امضا', 'tax_info' => 'اطلاعات سامانه مالیاتی', 'enamad' => 'تصویر اینماد',
    ];

    // *** MODIFIED: Construct Contract Link if token exists ***
    $contract_link = '';
    // Generate the link as long as a token exists, regardless of current status
    if (!empty($request->contract_token)) {
        $contract_page = get_page_by_path('cooperation-contract');
        if ($contract_page) {
            $contract_page_url = get_permalink($contract_page->ID);
            if ($contract_page_url) {
                $contract_link = esc_url(add_query_arg('token', $request->contract_token, $contract_page_url));
            }
        }
    }
    // *** END Modification ***

    // Prepare Contract Signature Details
    $signed_status_display = ($request->contract_signed_status === 'signed') ? 'امضا شده' : 'امضا نشده';
    $signed_at_jalali = ($request->contract_signed_at) ? mlr_gregorian_to_jalali($request->contract_signed_at, 'Y/m/d H:i') : '---';
    $expires_at_jalali = ($request->contract_expires_at) ? mlr_gregorian_to_jalali($request->contract_expires_at, 'Y/m/d') : '---';


    ob_start(); // Start output buffering
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title" id="mlr-modal-title">جزئیات درخواست همکاری (شناسه: <?php echo esc_html($request->id); ?>)</h3>
    </div>
    <div class="mlr-modal-body">

        <?php // Display Contract Link Section (if link was generated) ?>
        <?php if ($contract_link): ?>
            <div class="mlr-modal-card mlr-contract-link-card">
                 <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-admin-links"></span> لینک قرارداد آنلاین</h4>
                 <div class="mlr-contract-link-content">
                    <p>این لینک یکتا برای مشاهده و امضای آنلاین قرارداد ایجاد شده است:</p>
                    <input type="text" value="<?php echo $contract_link; ?>" readonly class="mlr-link-input" aria-label="لینک قرارداد">
                    <button type="button" class="button button-secondary mlr-copy-link-btn" data-link="<?php echo $contract_link; ?>">کپی لینک</button>
                    <a href="<?php echo $contract_link; ?>" target="_blank" class="button button-primary">مشاهده قرارداد</a>
                 </div>
            </div>
        <?php endif; ?>

        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-info"></span> اطلاعات ثبت شده</h4>
            <table class="mlr-details-table modern">
                <tbody>
                    <tr>
                        <td><strong>وضعیت درخواست</strong></td>
                        <td><?php echo esc_html($request->status); ?></td>
                    </tr>
                    <?php // Display Contract Signature Info (Always show status, show dates if signed) ?>
                    <tr>
                        <td><strong>وضعیت امضای قرارداد</strong></td>
                        <td>
                            <span class="mlr-signature-status-badge status-<?php echo esc_attr($request->contract_signed_status); ?>">
                                <?php echo esc_html($signed_status_display); ?>
                            </span>
                        </td>
                    </tr>
                    <?php if ($request->contract_signed_status === 'signed'): ?>
                        <tr>
                            <td><strong>تاریخ امضای قرارداد</strong></td>
                            <td><?php echo esc_html($signed_at_jalali); ?></td>
                        </tr>
                        <tr>
                            <td><strong>تاریخ انقضای قرارداد</strong></td>
                            <td><?php echo esc_html($expires_at_jalali); ?></td>
                        </tr>
                    <?php endif; ?>

                    <?php // Loop through submitted data ?>
                    <?php if (is_array($data)): // Check if $data is an array ?>
                        <?php foreach ($data as $key => $value):
                            if (empty($value) && $value !== '0') continue; // Skip empty fields, but allow '0'
                            // Determine the label: use predefined, fallback to formatted key
                            $label = $data_labels[$key] ?? ucwords(str_replace('_', ' ', $key));
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html($label); ?></strong></td>
                                <td><?php echo nl2br(esc_html($value)); // Use nl2br for textareas ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="2">اطلاعاتی برای نمایش وجود ندارد.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php // Display Uploaded Files ?>
        <?php if (!empty($files) && is_array($files)): // Check if $files is a non-empty array ?>
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-media-default"></span> فایل‌های بارگذاری شده</h4>
                <div class="mlr-file-grid">
                    <?php foreach ($files as $key => $file_group):
                        if (empty($file_group)) continue; // Skip if no files for this key
                        // Determine the label
                        $label = $file_labels[$key] ?? ucwords(str_replace('_', ' ', $key));
                    ?>
                        <div class="mlr-file-item">
                            <strong><?php echo esc_html($label); ?>:</strong>
                            <div class="mlr-file-links">
                                <?php // Ensure $file_group is iterable ?>
                                <?php foreach ((array)$file_group as $index => $file_url): ?>
                                    <a href="<?php echo esc_url($file_url); ?>" target="_blank" rel="noopener noreferrer">
                                        <span class="dashicons dashicons-download"></span>
                                        <?php // Provide better link text if multiple files ?>
                                        مشاهده فایل <?php echo (count((array)$file_group) > 1) ? ('#' . ($index + 1)) : ''; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php
    $html_output = ob_get_clean(); // Get buffered HTML

    // Add JavaScript for copy button functionality within the response
    // Ensure this script runs reliably even if the modal content is reloaded multiple times.
    $html_output .= '
    <script>
    jQuery(document).ready(function($){
        // Use event delegation on a static parent (#mlr-details-inner or higher if needed)
        $("#mlr-details-inner").off("click.copybtn", ".mlr-copy-link-btn").on("click.copybtn", ".mlr-copy-link-btn", function(){
            var button = $(this);
            var link = button.data("link");
            // Use modern clipboard API if available, fallback to execCommand
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(link).then(function() {
                    var originalText = button.text();
                    button.text("کپی شد!");
                    // Disable button briefly to prevent spamming
                    button.prop("disabled", true);
                    setTimeout(() => {
                        button.text(originalText).prop("disabled", false);
                    }, 1500);
                }).catch(function(err) {
                    // Fallback or show error
                    button.text("خطا!");
                    console.error("Clipboard API error:", err);
                     setTimeout(() => { button.text("کپی لینک"); }, 1500);
                     // Maybe try execCommand here as a fallback
                });
            } else {
                // Fallback using execCommand (less reliable)
                var tempInput = $("<input>");
                $("body").append(tempInput);
                tempInput.val(link).select();
                try {
                    var successful = document.execCommand("copy");
                    var originalText = button.text();
                    if(successful) {
                        button.text("کپی شد!");
                        button.prop("disabled", true);
                        setTimeout(() => { button.text(originalText).prop("disabled", false); }, 1500);
                    } else {
                         button.text("خطا!");
                         console.error("execCommand copy failed");
                          setTimeout(() => { button.text(originalText); }, 1500);
                    }
                } catch (err) {
                     button.text("خطا!");
                     console.error("execCommand copy error:", err);
                      setTimeout(() => { button.text(originalText); }, 1500);
                }
                tempInput.remove();
            }
        });
    });
    </script>
    <style>
        .mlr-contract-link-card { background-color: #eef5fa; border-color: #bee3f8; }
        .mlr-contract-link-card .mlr-modal-subtitle { color: #2a4365; border-bottom-color: #90cdf4; }
        .mlr-contract-link-content { padding: 15px 20px; }
        .mlr-contract-link-content p { margin-top: 0; margin-bottom: 10px; color: #4a5568; font-size: 13px; }
        .mlr-link-input { width: calc(100% - 210px); /* Adjust width based on buttons */ padding: 8px 10px; margin-bottom: 10px; border: 1px solid #cbd5e0; border-radius: 4px; background-color: #f7fafc; direction: ltr; text-align: left; font-size: 13px; display: inline-block; vertical-align: middle; margin-left: 5px;}
        .mlr-copy-link-btn { margin-left: 5px; vertical-align: middle; }
        .mlr-contract-link-content a.button { vertical-align: middle; }
        /* Badge for signature status */
        .mlr-signature-status-badge { display: inline-block; padding: 4px 12px; border-radius: 15px; font-size: 12px; font-weight: 600; white-space: nowrap; vertical-align: middle; }
        .mlr-signature-status-badge.status-pending { background-color: #fef9c3; color: #854d0e; border: 1px solid #fde68a; } /* Amber */
        .mlr-signature-status-badge.status-signed { background-color: #dcfce7; color: #166534; border: 1px solid #86efac; } /* Green */

         /* Responsive adjustments for link input/buttons */
        @media (max-width: 600px) {
            .mlr-link-input { width: 100%; display: block; margin-bottom: 8px; margin-left: 0;}
            .mlr-copy-link-btn { margin-left: 0; margin-right: 5px; }
        }
    </style>';


    wp_send_json_success(['html' => $html_output]);
}