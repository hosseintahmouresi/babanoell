<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

add_action('wp_ajax_mlr_upload_additional_docs', 'mlr_upload_additional_docs_callback');

function mlr_upload_additional_docs_callback() {
    // 1. Security and Permission Checks
    // Nonce is checked against 'mlr_frontend_nonce' which is localized as 'details_nonce' in mlr-user-requests.js
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای بارگذاری مدارک، لطفاً ابتدا وارد شوید.']);
        return;
    }

    // 2. Input Validation
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    // Use a more specific key if possible, otherwise check generally
    $file_input_key = 'additional_documents'; // Assuming this is the name attribute in your form
    if (empty($_FILES[$file_input_key])) {
        wp_send_json_error(['message' => 'هیچ فایلی برای بارگذاری انتخاب نشده است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $user_id = get_current_user_id();

    // Verify the user owns this request and it's in the correct status ('نقص مدارک')
    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT required_documents FROM $table_name WHERE id = %d AND user_id = %d AND status = 'نقص مدارک'",
        $request_id, $user_id
    ));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد یا در حال حاضر در وضعیت "نقص مدارک" نیست.']);
        return;
    }

    // 3. File Upload Handling
    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }

    $files = $_FILES[$file_input_key]; // Use the specific key
    $uploaded_urls = [];
    $errors = [];
    $upload_overrides = array('test_form' => false); // Standard override

    // Define allowed mime types for security
    $allowed_mimes = [
        'jpg|jpeg|jpe' => 'image/jpeg',
        'png'          => 'image/png',
        'pdf'          => 'application/pdf',
        // Add more types if needed
    ];

    // Rearrange the $_FILES array into a more manageable structure
    $rearranged_files = [];
    if(isset($files['name']) && is_array($files['name'])){
        foreach ($files['name'] as $key => $value) {
             // Only process if a file was actually attempted (error is not NO_FILE)
            if ($files['name'][$key] && $files['error'][$key] !== UPLOAD_ERR_NO_FILE) {
                // Check for upload errors provided by PHP
                if ($files['error'][$key] !== UPLOAD_ERR_OK) {
                     // Provide more specific error messages
                     $upload_errors = [
                         UPLOAD_ERR_INI_SIZE => 'بیش از حد مجاز سرور', UPLOAD_ERR_FORM_SIZE => 'بیش از حد مجاز فرم',
                         UPLOAD_ERR_PARTIAL => 'بارگذاری ناقص', UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت یافت نشد',
                         UPLOAD_ERR_CANT_WRITE => 'خطا در نوشتن فایل', UPLOAD_ERR_EXTENSION => 'پسوند غیرمجاز توسط افزونه‌ای دیگر',
                     ];
                     $error_msg = $upload_errors[$files['error'][$key]] ?? 'خطای نامشخص آپلود (کد: '.$files['error'][$key].')';
                     $errors[] = 'خطا در فایل "' . esc_html($files['name'][$key]) . '": ' . $error_msg;
                     mlr_log("PHP Upload error for additional_docs, request {$request_id}, file {$files['name'][$key]}: {$error_msg}");
                     continue; // Skip this file
                }

                $rearranged_files[] = [
                    'name'     => $files['name'][$key],
                    'type'     => $files['type'][$key],
                    'tmp_name' => $files['tmp_name'][$key],
                    'error'    => $files['error'][$key],
                    'size'     => $files['size'][$key]
                ];
            }
        }
    } else if (isset($files['name']) && $files['error'] !== UPLOAD_ERR_NO_FILE) {
         // Handle single file upload case if error is not NO_FILE
         if ($files['error'] === UPLOAD_ERR_OK) {
             $rearranged_files[] = $files;
         } else {
             $upload_errors = [ /* ... as above ... */ ];
             $error_msg = $upload_errors[$files['error']] ?? 'خطای نامشخص آپلود (کد: '.$files['error'].')';
             $errors[] = 'خطا در فایل "' . esc_html($files['name']) . '": ' . $error_msg;
             mlr_log("PHP Upload error for additional_docs (single), request {$request_id}, file {$files['name']}: {$error_msg}");
         }
    }


    // If array is still empty after processing and no other errors occurred yet
    if (empty($rearranged_files) && empty($errors)) {
         wp_send_json_error(['message' => 'هیچ فایل معتبری برای بارگذاری انتخاب نشده است.']);
         return;
    }

    // Loop through and upload each valid file entry
    foreach ($rearranged_files as $file) {
         // Validate file type using wp_check_filetype
         $file_type = wp_check_filetype(basename($file['name']), $allowed_mimes);
         if (empty($file_type['ext']) || !in_array($file_type['type'], array_values($allowed_mimes), true)) {
             $errors[] = 'خطا: نوع فایل "' . esc_html($file['name']) . '" مجاز نیست (فقط jpg, png, pdf).';
             mlr_log("File type error for additional_docs, request {$request_id}, file {$file['name']}");
             continue; // Skip this file
         }

         // Check file size (example: max 5MB) - Adjust as needed
         $max_size = 5 * 1024 * 1024; // 5MB in bytes
         if ($file['size'] > $max_size) {
              $errors[] = 'خطا: حجم فایل "' . esc_html($file['name']) . '" بیشتر از حد مجاز (5 مگابایت) است.';
              mlr_log("File size error for additional_docs, request {$request_id}, file {$file['name']}, size: {$file['size']}");
              continue; // Skip this file
         }

        // Sanitize filename
        $clean_name = sanitize_file_name($file['name']);
        $file['name'] = $clean_name;


        $movefile = wp_handle_upload($file, $upload_overrides);

        if ($movefile && !isset($movefile['error'])) {
            $uploaded_urls[] = $movefile['url']; // Store the URL
            mlr_log("Additional doc uploaded successfully for request {$request_id}: {$movefile['url']}");
        } else {
            $error_msg = $movefile['error'] ?? 'خطای نامشخص در آپلود فایل.';
            $errors[] = 'خطا در آپلود فایل "' . esc_html($file['name']) . '": ' . $error_msg;
            mlr_log("wp_handle_upload error for additional_docs, request {$request_id}, file {$file['name']}: {$error_msg}");

        }
    }


    if (!empty($errors)) {
        // If some files failed, but others succeeded, decide how to handle.
        // Current logic: Fail if *any* error occurred during validation or upload.
        wp_send_json_error(['message' => 'خطا در پردازش فایل‌ها: <br>' . implode('<br>', $errors)]);
        return;
    }

    if(empty($uploaded_urls)){
        // This case means files were submitted, but *all* failed validation (type/size) before wp_handle_upload was called.
        wp_send_json_error(['message' => 'هیچ‌کدام از فایل‌های انتخاب شده معتبر نبودند (بررسی نوع و حجم فایل).']);
        return;
    }

    // 4. Update Database
    // Merge new files with existing ones
    $existing_documents = maybe_unserialize($request->required_documents);
    if (!is_array($existing_documents)) {
         $existing_documents = [];
    }

    // Add new files under the 'additional_documents' key
    // This key groups files uploaded specifically during the 'نقص مدارک' step
    if (!isset($existing_documents['additional_documents']) || !is_array($existing_documents['additional_documents'])) {
        $existing_documents['additional_documents'] = [];
    }
    // Append new URLs to the existing ones under this key
    $existing_documents['additional_documents'] = array_merge($existing_documents['additional_documents'], $uploaded_urls);

    // *** Set the new status to 'در حال بررسی' ***
    $new_status = 'در حال بررسی';

    $updated = $wpdb->update(
        $table_name,
        [
            'required_documents' => serialize($existing_documents), // Save all documents back
            'status'             => $new_status,                   // Update status
            'last_edited_at'     => current_time('mysql')          // Update modification time
        ],
        ['id' => $request_id] // Where clause
    );

    if ($updated === false) {
        mlr_log("Database Error updating request ID {$request_id} after additional doc upload: " . $wpdb->last_error);
        wp_send_json_error(['message' => 'خطایی در به‌روزرسانی درخواست رخ داد.']);
        return;
    }

    // 5. Send Notifications
    mlr_send_sms_on_loan_status_change($request_id, $new_status);

    // 6. Send Success Response
    wp_send_json_success(['message' => 'مدارک با موفقیت ارسال شد. درخواست شما مجدداً برای "در حال بررسی" ارسال گردید.']);
}
?>