<?php
// FILE: my-loan-request-plugin/includes/ajax/get-frontend-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');

function mlr_get_frontend_request_details_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر.']);
        return;
    }

    global $wpdb;
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $is_admin = current_user_can('manage_options');
    $is_bank_expert = in_array('bank', (array) $current_user->roles);

    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';

    // Fetch Request
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    // Security Check: User can only see their own requests, unless they are admin or assigned bank expert
    if (!$is_admin) {
        if ($is_bank_expert) {
            if ($request->assigned_bank_user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این پرونده ندارید.']);
                return;
            }
        } else {
            if ($request->user_id != $user_id) {
                wp_send_json_error(['message' => 'عدم دسترسی.']);
                return;
            }
        }
    }

    // Data Processing
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $order_items = !empty($request->order_items) ? json_decode($request->order_items, true) : [];
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    
    // Helpers
    $occupations = ['official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر'];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : $request->occupation;
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست #<?php echo esc_html($request->id); ?></h3>
        <span class="mlr-status-badge status-<?php echo sanitize_html_class($request->status); ?>"><?php echo esc_html($request->status); ?></span>
    </div>
    
    <div class="mlr-modal-body">
        
        <div class="mlr-info-box">
            <h4>مشخصات فردی</h4>
            <div class="mlr-info-grid">
                <div><span>نام:</span> <strong><?php echo esc_html($request->full_name); ?></strong></div>
                <div><span>کد ملی:</span> <?php echo esc_html($request->national_code); ?></div>
                <div><span>موبایل:</span> <?php echo esc_html($request->mobile_number); ?></div>
                <div><span>شغل:</span> <?php echo esc_html($occupation_display); ?></div>
                <div style="grid-column: 1 / -1;"><span>آدرس:</span> <?php echo esc_html($request->residential_address); ?></div>
            </div>
        </div>

        <div class="mlr-info-box">
            <h4>اطلاعات مالی</h4>
            <div class="mlr-info-grid">
                <div><span>طرح:</span> <?php echo esc_html($request->plan_name); ?></div>
                <div><span>مبلغ وام:</span> <?php echo number_format($request->loan_amount); ?> ریال</div>
                <div><span>اقساط:</span> <?php echo esc_html($request->installment_count); ?> ماهه</div>
                <div><span>مبلغ قسط:</span> <?php echo number_format($request->installment_amount); ?> ریال</div>
            </div>
        </div>

        <?php if (!empty($uploaded_documents)): ?>
        <div class="mlr-info-box">
            <h4>مدارک</h4>
            <div class="mlr-docs-list">
                <?php foreach($uploaded_documents as $key => $val): 
                     $label = $all_doc_labels[$key] ?? $key;
                ?>
                    <div class="mlr-doc-item">
                        <strong><?php echo esc_html($label); ?>:</strong>
                        <?php if(is_array($val)): ?>
                            <?php foreach($val as $i => $url): ?>
                                <a href="<?php echo esc_url($url); ?>" target="_blank" class="mlr-btn-small">فایل <?php echo $i+1; ?></a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <a href="<?php echo esc_url($val); ?>" target="_blank" class="mlr-btn-small">مشاهده</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($order_items)): ?>
        <div class="mlr-info-box">
            <h4>محصولات</h4>
            <ul style="list-style: disc; padding-right: 20px;">
                <?php foreach($order_items as $item): ?>
                    <li><?php echo esc_html($item['name']); ?> (<?php echo intval($item['qty']); ?> عدد)</li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <?php if (!empty($comments)): ?>
        <div class="mlr-info-box">
            <h4>سوابق و پیام‌ها</h4>
            <div class="mlr-comments-list">
                <?php foreach($comments as $cm): ?>
                    <div class="mlr-comment">
                        <small><?php echo esc_html($cm['display_name']); ?> - <?php echo (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($cm['timestamp'], 'Y/m/d H:i') : $cm['timestamp']); ?></small>
                        <p><?php echo esc_html($cm['text']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($is_bank_expert && $request->assigned_bank_user_id == $user_id): ?>
            
            <?php 
            $can_take_action = false;
            $options = [];
            
            if ($request->status == 'تأیید کارشناس') {
                $can_take_action = true;
                $options = [
                    'تکمیل مدارک' => 'ارسال برای تکمیل مدارک',
                    'نقص مدارک' => 'اعلام نقص مدارک',
                    'رد شده' => 'رد درخواست'
                ];
            } elseif ($request->status == 'تأیید مدارک') {
                // HERE IS THE FIX FOR VERIFIED DOCS STAGE
                $can_take_action = true;
                $options = [
                    'اعطا شده' => 'تأیید نهایی و اعطا شده',
                    'رد شده' => 'رد درخواست',
                    'تکمیل مدارک' => 'بازگشت به تکمیل مدارک'
                ];
            }
            ?>

            <?php if ($can_take_action): ?>
            <div class="mlr-action-box" style="background: #e8f0fe; padding: 15px; border-radius: 8px; margin-top: 20px; border: 1px solid #b3d7ff;">
                <h4 style="margin-top:0; color:#0056b3;">بررسی کارشناس بانک</h4>
                <form id="mlr-bank-expert-action-form">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                    
                    <div class="mlr-form-group">
                        <label for="new_status">تغییر وضعیت به:</label>
                        <select name="new_status" id="new_status" class="mlr-select" style="width:100%; margin-bottom:10px;">
                            <?php foreach($options as $val => $label): ?>
                                <option value="<?php echo esc_attr($val); ?>"><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mlr-form-group">
                        <label for="comment_text">توضیحات (اختیاری):</label>
                        <textarea name="comment_text" id="comment_text" rows="3" class="mlr-textarea" style="width:100%;" placeholder="علت رد یا توضیحات تکمیلی..."></textarea>
                    </div>

                    <div class="mlr-action-message" style="display:none; margin-bottom:10px;"></div>
                    
                    <button type="submit" class="mlr-btn mlr-btn-primary" style="width:100%;">ثبت بررسی</button>
                </form>
            </div>
            <?php endif; ?>

        <?php endif; ?>
        
    </div>
    <?php
    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}
?>