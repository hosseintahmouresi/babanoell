jQuery(document).ready(function($) {
    if ($('.mlr-user-requests[id^="mlr-verified-dashboard-"]').length === 0) {
        return;
    }

    try {
        if (typeof $.fn.persianDatepicker === 'function') {
            $('.jalali-datepicker').persianDatepicker({
                format: 'YYYY/MM/DD',
                autoClose: true
            });
        }
    } catch (e) {
        console.error("Error initializing Persian Datepicker:", e);
    }

    function loadVerifiedRequests() {
        var container = $('.mlr-user-requests'); 
        var search = container.find('#mlr-search').val();
        var tableBody = container.find('#mlr-requests-table-body');

        $.ajax({
            url: mlr_verified_ajax_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_get_verified_docs_requests', // New AJAX action
                nonce: mlr_verified_ajax_obj.nonce,
                search: search,
            },
            beforeSend: function() {
                tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px;">در حال بارگذاری...</td></tr>');
            },
            success: function(response) {
                if (response.success) {
                    tableBody.html(response.data.html);
                } else {
                    tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">' + (response.data.message || 'خطا در دریافت اطلاعات.') + '</td></tr>');
                }
            },
            error: function() {
                tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">خطا در ارتباط با سرور.</td></tr>');
            }
        });
    }

    function showDetailsModal(requestId, container) {
        const modalOverlay = container.find('.mlr-modal-overlay');
        const modal = container.find('.mlr-modal');
        const modalContent = container.find('.mlr-modal-content');

        if (!requestId) return;

        modalOverlay.fadeIn(200);
        modal.fadeIn(200);
        modalContent.html('<p style="text-align:center; padding: 40px;">در حال بارگذاری جزئیات...</p>');

        $.ajax({
            url: mlr_verified_ajax_obj.ajax_url, 
            type: 'POST',
            data: {
                action: 'mlr_get_frontend_request_details',
                nonce: mlr_verified_ajax_obj.nonce,
                request_id: requestId
            },
            success: function(response) {
                if (response.success) {
                    modalContent.html(response.data.html);
                } else {
                    modalContent.html('<p style="color:red; text-align:center; padding: 40px;">' + (response.data.message || 'خطا در دریافت جزئیات.') + '</p>');
                }
            }
        });
    }
    
    loadVerifiedRequests();

    $(document).on('click', '#mlr-filter-btn', function() {
        loadVerifiedRequests();
    });

    $(document).on('keyup', '#mlr-search', function(e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            loadVerifiedRequests();
        }
    });

    $(document).on('click', '.mlr-view-details-btn, #mlr-requests-table-body tr', function(e) {
        if ($(e.target).closest('form, a').length > 0) return;
        e.stopPropagation();
        const row = $(this).closest('tr');
        const container = row.closest('.mlr-user-requests');
        const requestId = row.data('id');
        showDetailsModal(requestId, container);
    });

    $(document).on('submit', '#mlr-bank-expert-action-form', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var button = form.find('button[type="submit"]');
        var messageDiv = form.find('.mlr-action-message');
        var formData = {
            action: 'mlr_submit_bank_expert_review',
            nonce: mlr_verified_ajax_obj.nonce,
            request_id: form.find('input[name="request_id"]').val(),
            new_status: form.find('select[name="new_status"]').val(),
            comment_text: form.find('textarea[name="comment_text"]').val()
        };

        $.ajax({
            url: mlr_verified_ajax_obj.ajax_url,
            type: 'POST',
            data: formData,
            beforeSend: function() {
                button.prop('disabled', true).text('در حال ثبت...');
                messageDiv.removeClass().addClass('mlr-action-message loading').text('لطفا صبر کنید...').slideDown();
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass().addClass('mlr-action-message success').text(response.data.message);
                    setTimeout(function() {
                        $('.mlr-modal-overlay, .mlr-modal').fadeOut(200);
                        loadVerifiedRequests();
                    }, 2000);
                } else {
                    messageDiv.removeClass().addClass('mlr-action-message error').text(response.data.message || 'خطای ناشناخته.');
                    button.prop('disabled', false).text('ثبت بررسی');
                }
            },
            error: function() {
                messageDiv.removeClass().addClass('mlr-action-message error').text('خطا در ارتباط با سرور.');
                button.prop('disabled', false).text('ثبت بررسی');
            }
        });
    });

    $(document).on('click', '.mlr-modal-overlay, .mlr-modal-close', function() {
        $(this).closest('.mlr-user-requests').find('.mlr-modal-overlay, .mlr-modal').fadeOut(200);
    });
});