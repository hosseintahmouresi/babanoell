jQuery(document).ready(function($) {
    // --- 1. Fix Z-Index & Modal Placement ---
    if ($('#mlr-global-modal-overlay').length === 0) {
        $('body').append(`
            <div id="mlr-global-modal-overlay" class="mlr-modal-overlay"></div>
            <div id="mlr-global-modal" class="mlr-modal">
                <button class="mlr-modal-close">&times;</button>
                <div class="mlr-modal-content"></div>
            </div>
        `);
    }

    $('.mlr-user-requests .mlr-modal, .mlr-user-requests .mlr-modal-overlay').remove();

    // --- START: CUSTOM JALALI DATEPICKER V4 ---
    (function() {
        if ($('.jalali-datepicker').length === 0) return;
        let activeInput = null, datepicker, yearSelect, monthSelect, grid, currentYear, currentMonth;
        const dayNames = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
        const monthNames = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];

        function createDatePickerUI() {
            if ($('.mlr-custom-datepicker').length > 0) return;
            let yearOptions = '<option value="" disabled>سال</option>';
            const currentJalaliYear = parseInt(new Date().toLocaleDateString('fa-IR-u-nu-latn').split('/')[0]) || 1403;
            for (let y = currentJalaliYear + 1; y >= 1390; y--) yearOptions += `<option value="${y}">${y}</option>`;
            let monthOptions = '<option value="" disabled>ماه</option>';
            monthNames.forEach((name, index) => monthOptions += `<option value="${index + 1}">${name}</option>`);

            const dp_html = `
                <div class="mlr-custom-datepicker" style="display:none; position:absolute; z-index:2147483647; background:#fff; border:1px solid #ccc; border-radius:4px; padding:10px; width:220px; box-shadow: 0 3px 6px rgba(0,0,0,0.1);">
                    <div class="mlr-dp-header" style="display:flex; justify-content:space-between; margin-bottom:10px;">
                        <select class="mlr-dp-select year-select" required style="width:48%; padding: 4px; border:1px solid #ddd; border-radius:3px;">${yearOptions}</select>
                        <select class="mlr-dp-select month-select" required style="width:48%; padding: 4px; border:1px solid #ddd; border-radius:3px;">${monthOptions}</select>
                    </div>
                    <div class="mlr-dp-grid" style="display:grid; grid-template-columns:repeat(7, 1fr); gap:2px; text-align:center;"></div>
                </div>`;
            $('body').append(dp_html);
            datepicker = $('.mlr-custom-datepicker');
            yearSelect = datepicker.find('.year-select');
            monthSelect = datepicker.find('.month-select');
            grid = datepicker.find('.mlr-dp-grid');

            yearSelect.on('change', () => { currentYear = parseInt(yearSelect.val()); if (currentMonth) renderCalendar(); });
            monthSelect.on('change', () => { currentMonth = parseInt(monthSelect.val()); if (currentYear) renderCalendar(); });
            grid.on('click', '.mlr-dp-day:not(.disabled)', selectDate);
            $(document).on('click', function(e) {
                if (datepicker.is(":visible") && !$(e.target).closest('.mlr-custom-datepicker').length && !$(e.target).is(activeInput)) {
                    datepicker.fadeOut(200); activeInput = null;
                }
            });
        }
        function isJalaliLeap(year) { return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(year % 33) > -1; }
        function toGregorian(jy, jm, jd) {
            var sal_a, gy, gm, gd, days; jy += 1595; days = -355668 + (365 * jy) + (~~(jy / 33) * 8) + ~~(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
            gy = 400 * ~~(days / 146097); days %= 146097; if (days > 36524) { gy += 100 * ~~(--days / 36524); days %= 36524; if (days >= 365) days++; }
            gy += 4 * ~~(days / 1461); days %= 1461; if (days > 365) { gy += ~~((days - 1) / 365); days = (days - 1) % 365; }
            gd = days + 1; sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
            return new Date(gy, gm - 1, gd);
        }
        function renderCalendar() {
            grid.empty(); dayNames.forEach(name => grid.append(`<span class="mlr-dp-day-name" style="font-size:12px; font-weight:bold; color:#666; padding:4px 0;">${name}</span>`));
            const daysInMonth = (currentMonth <= 6) ? 31 : (currentMonth <= 11) ? 30 : (isJalaliLeap(currentYear)) ? 30 : 29;
            const startDayIndex = (new Date(toGregorian(currentYear, currentMonth, 1)).getDay() + 1) % 7;
            for (let i = 0; i < startDayIndex; i++) grid.append('<span class="disabled"></span>');
            for (let day = 1; day <= daysInMonth; day++) grid.append($(`<span class="mlr-dp-day" style="padding:6px 2px; cursor:pointer; border-radius:3px;">${day}</span>`).data('day', day).hover(function(){ $(this).css('background','#f0f0f0'); }, function(){ $(this).css('background','transparent'); }));
        }
        function selectDate() {
            if (!activeInput) return;
            $(activeInput).val(`${currentYear}/${String(currentMonth).padStart(2, '0')}/${String($(this).data('day')).padStart(2, '0')}`);
            datepicker.fadeOut(200); activeInput = null;
        }
        $(document).on('click', '.jalali-datepicker', function() {
            activeInput = this; grid.empty();
            const existingDate = $(this).val(), now = new Date(), todayJalali = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: 'numeric' }).format(now).split('/');
            if (existingDate && existingDate.match(/^\d{4}\/\d{2}\/\d{2}$/)) { const parts = existingDate.split('/'); currentYear = parseInt(parts[0]); currentMonth = parseInt(parts[1]); } else { currentYear = parseInt(todayJalali[0]); currentMonth = parseInt(todayJalali[1]); }
            yearSelect.val(currentYear); monthSelect.val(currentMonth); renderCalendar();
            const inputPos = $(activeInput).offset();
            datepicker.css({ top: inputPos.top + $(activeInput).outerHeight() + 5, left: inputPos.left, right: 'auto' }).fadeIn(200);
        });
        createDatePickerUI();
    })();
    // --- END: DATEPICKER ---

    // --- Function to load requests via AJAX ---
    function loadRequests() {
        var container = $('.mlr-user-requests:not(.mlr-settlement-cycles)');
        if (container.length === 0) return;
        if (typeof mlr_ajax_obj === 'undefined' || typeof mlr_ajax_obj.filter_nonce === 'undefined') return;

        var data = {
            action: 'mlr_get_user_requests',
            nonce: mlr_ajax_obj.filter_nonce,
            search: container.find('#mlr-search').val(),
            status: container.find('#mlr-status').val(),
            settlement_status: container.find('#mlr-settlement-status').val(),
            date_from: container.find('#mlr-date-from').val(),
            date_to: container.find('#mlr-date-to').val(),
            allowed_statuses: mlr_ajax_obj.allowed_statuses || []
        };

        $.ajax({
            url: mlr_ajax_obj.ajax_url, type: 'POST', data: data,
            beforeSend: () => container.find('#mlr-requests-table-body').html('<tr><td colspan="10" style="text-align:center; padding: 20px;">در حال بارگذاری...</td></tr>'),
            success: (res) => {
                if (res.success) {
                    container.find('#mlr-requests-table-body').html(res.data.html);
                    container.find('#mlr-requests-table-body tr[data-id]').addClass('mlr-request-row-frontend');
                } else {
                    container.find('#mlr-requests-table-body').html(`<tr><td colspan="10" style="text-align:center; color: red;">خطا: ${res.data.message}</td></tr>`);
                }
            },
            error: () => container.find('#mlr-requests-table-body').html('<tr><td colspan="10" style="text-align:center; color: red;">خطای ارتباط با سرور.</td></tr>')
        });
    }

    // --- Function to show details modal ---
    function showDetailsModal(requestId) {
        const modalOverlay = $('#mlr-global-modal-overlay');
        const modal = $('#mlr-global-modal');
        const modalContent = modal.find('.mlr-modal-content');

        if (!requestId || typeof mlr_ajax_obj === 'undefined') { alert('خطای سیستمی'); return; }

        $('body').addClass('mlr-modal-open');
        modalOverlay.fadeIn(200);
        modal.css('display', 'flex').hide().fadeIn(200);
        modalContent.html('<p style="text-align:center; padding: 40px;">در حال بارگذاری جزئیات...</p>');

        $.post(mlr_ajax_obj.ajax_url, {
            action: 'mlr_get_frontend_request_details',
            nonce: mlr_ajax_obj.details_nonce,
            request_id: requestId
        })
        .done((res) => {
            if (res.success) {
                modalContent.html(res.data.html);
                if (typeof $.fn.persianDatepicker === 'function') {
                    modalContent.find('.jalali-datepicker').persianDatepicker({ format: 'YYYY/MM/DD', autoClose: true });
                }
            } else {
                 modalContent.html(`<p style="color:red; text-align:center;">${res.data.message}</p>`);
            }
        })
        .fail(() => modalContent.html('<p class="mlr-error">خطای ارتباط با سرور.</p>'));
    }

    // --- Global Modal Event Handlers ---
    $(document).on('click', '#mlr-global-modal-overlay, .mlr-modal-close', function() {
        $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200, function(){
            $('body').removeClass('mlr-modal-open');
        });
    });
    $(document).on('click', '#mlr-global-modal', function(e) { e.stopPropagation(); });

    // *** FORCE OPEN FILE LINKS IN NEW TAB ***
    $(document).on('click', '.mlr-view-file-btn', function(e) {
        e.preventDefault(); 
        e.stopPropagation();
        var url = $(this).attr('href');
        if(url && url !== '#') {
            window.open(url, '_blank');
        }
    });

    // --- AJAX Handler for Additional Docs Form (Rejection Fix) ---
    $(document).on('submit', '#mlr-additional-docs-form', function(e) {
        e.preventDefault();
        const form = $(this);
        const messageDiv = form.find('#mlr-upload-message');
        const fileInput = form.find('#additional_documents_upload');

        if (!fileInput[0].files.length) { messageDiv.removeClass().addClass('mlr-upload-status error').html('لطفاً فایل انتخاب کنید.').slideDown(); return; }

        var formData = new FormData(this);
        formData.append('action', 'mlr_upload_additional_docs');
        formData.append('nonce', mlr_ajax_obj.details_nonce);

        $.ajax({
            url: mlr_ajax_obj.ajax_url, type: 'POST', data: formData, processData: false, contentType: false,
            beforeSend: function() { messageDiv.removeClass().addClass('mlr-upload-status loading').html('در حال ارسال...').slideDown(); form.find('button').prop('disabled', true); },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass().addClass('mlr-upload-status success').html(response.data.message);
                    setTimeout(function() { $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200); loadRequests(); }, 2000);
                } else {
                    messageDiv.removeClass().addClass('mlr-upload-status error').html(response.data.message);
                    form.find('button').prop('disabled', false);
                }
            },
            error: function() { messageDiv.addClass('error').html('خطای سرور'); form.find('button').prop('disabled', false); }
        });
    });
    
    // --- COMPLETE DOCS FORM SUBMISSION (THIS WAS MISSING) ---
    $(document).on('submit', '#mlr-complete-docs-form', function(e) {
        e.preventDefault();
        var form = $(this);
        var messageDiv = form.find('#mlr-complete-upload-message');
        
        var formData = new FormData(this);
        formData.append('action', 'mlr_submit_completed_docs');
        formData.append('nonce', mlr_ajax_obj.details_nonce);

        $.ajax({
            url: mlr_ajax_obj.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function() {
                messageDiv.removeClass().addClass('mlr-upload-status loading').html('در حال ارسال مدارک و ثبت نهایی...').slideDown();
                form.find('button').prop('disabled', true);
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass().addClass('mlr-upload-status success').html(response.data.message);
                    setTimeout(function() {
                        $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200);
                        loadRequests(); // Refresh list to show new status
                    }, 2000);
                } else {
                    messageDiv.removeClass().addClass('mlr-upload-status error').html(response.data.message);
                    form.find('button').prop('disabled', false);
                }
            },
            error: function() {
                messageDiv.removeClass().addClass('mlr-upload-status error').html('خطای ارتباط با سرور.');
                form.find('button').prop('disabled', false);
            }
        });
    });

    // --- Cycle Row Click ---
    $(document).on('click', '.mlr-cycle-row-frontend', function() {
        const cycleRow = $(this);
        const cycleId = cycleRow.data('cycle-id');
        const detailsRow = $('#cycle-details-frontend-' + cycleId);
        const detailsContainer = detailsRow.find('.cycle-details-container');
        
        cycleRow.toggleClass('open');
        detailsRow.toggle();

        if (!cycleRow.data('loaded') && detailsRow.is(':visible')) {
            detailsContainer.find('.spinner-container').show();
            $.post(mlr_ajax_obj.ajax_url, { action: 'mlr_get_user_cycle_details', nonce: mlr_ajax_obj.cycle_nonce, cycle_id: cycleId })
            .done((res) => {
                if (res.success) { detailsContainer.html(res.data.html); detailsContainer.find('tr[data-id]').addClass('mlr-request-row-frontend'); cycleRow.data('loaded', true); }
                else { detailsContainer.html(`<p style="color:red; text-align:center;">${res.data.message}</p>`); }
            });
        }
    });

    $(document).on('click', '#mlr-requests-table-body tr.mlr-request-row-frontend', function(e) {
        if ($(e.target).closest('button, a, input, select, textarea').length > 0) return;
        const requestId = $(this).data('id');
        if (requestId) showDetailsModal(requestId);
    });
    
    // --- PRINT FUNCTIONS ---
    function mlrPrintElement(elementSelector) {
        var content = $(elementSelector).html();
        if (!content) { alert('محتوایی برای چاپ یافت نشد.'); return; }
        
        var printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>چاپ</title>');
        printWindow.document.write('<style>body{font-family:Tahoma,sans-serif;direction:rtl;text-align:right;} table{width:100%;border-collapse:collapse;} td,th{border:1px solid #000;padding:5px;} img{max-width:100%;}</style>');
        printWindow.document.write('</head><body>');
        printWindow.document.write(content);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        setTimeout(function() { printWindow.print(); }, 500);
    }

    $(document).on('click', '.mlr-print-contract-step-btn', function() { mlrPrintElement('.printable-contract-area'); });
    $(document).on('click', '.mlr-print-invoice-step-btn', function() { mlrPrintElement('.printable-invoice-area'); });

    // --- Filter & Search ---
    if ($('.mlr-user-requests:not(.mlr-settlement-cycles)').length > 0) loadRequests();
    $(document).on('click', '#mlr-filter-btn', () => { if (!$('#mlr-search').closest('.mlr-settlement-cycles').length) loadRequests(); });
    $(document).on('keyup', '#mlr-search', (e) => { if (e.key === 'Enter' && !$(e.target).closest('.mlr-settlement-cycles').length) loadRequests(); });
    
    // --- COMPLETE DOCS STEPPER LOGIC ---
    $(document).on('click', '.mlr-next-step-btn', function() {
        var form = $(this).closest('form');
        var currentPane = form.find('.mlr-step-pane.active');
        
        // Validation
        var valid = true;
        currentPane.find('input[required]').each(function() {
             if (!$(this).val() && !$(this)[0].files.length) {
                 valid = false;
                 $(this).css('border-color', 'red');
             } else {
                 $(this).css('border-color', '');
             }
        });

        if(!valid) {
            alert('لطفاً موارد خواسته شده را تکمیل یا بارگذاری نمایید.');
            return;
        }

        var nextPane = currentPane.next('.mlr-step-pane');
        if (nextPane.length > 0) {
            currentPane.removeClass('active');
            nextPane.addClass('active');
            var stepNum = nextPane.data('step-pane');
            form.closest('.mlr-complete-docs-section').find('.mlr-step[data-step="' + (stepNum - 1) + '"]').addClass('completed');
            form.closest('.mlr-complete-docs-section').find('.mlr-step[data-step="' + stepNum + '"]').addClass('active');
            updateStepperButtons(nextPane);
        }
    });

    $(document).on('click', '.mlr-prev-step-btn', function() {
        var form = $(this).closest('form');
        var currentPane = form.find('.mlr-step-pane.active');
        var prevPane = currentPane.prev('.mlr-step-pane');
        if (prevPane.length > 0) {
            currentPane.removeClass('active');
            prevPane.addClass('active');
            var stepNum = currentPane.data('step-pane');
            form.closest('.mlr-complete-docs-section').find('.mlr-step[data-step="' + stepNum + '"]').removeClass('active');
            updateStepperButtons(prevPane);
        }
    });

    function updateStepperButtons(activePane) {
        var isFirst = activePane.is(':first-child');
        var isLast = activePane.is(':last-child');
        var form = activePane.closest('form');
        form.find('.mlr-prev-step-btn').toggle(!isFirst);
        form.find('.mlr-next-step-btn').toggle(!isLast);
        form.find('.mlr-submit-btn').toggle(isLast);
    }
});