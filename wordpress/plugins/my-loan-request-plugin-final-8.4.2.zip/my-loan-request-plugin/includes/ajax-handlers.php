<?php
/**
 * Consolidated AJAX Handlers
 */

if (!defined('ABSPATH')) {
    exit;
}

// Admin Actions
add_action('wp_ajax_mlr_get_request_details', 'mlr_get_request_details_callback');
add_action('wp_ajax_mlr_add_comment', 'mlr_add_comment_callback');
add_action('wp_ajax_mlr_add_request_message', 'mlr_add_request_message_callback');
add_action('wp_ajax_mlr_admin_calculate_loan', 'mlr_admin_calculate_loan_callback');

// Frontend Actions
add_action('wp_ajax_mlr_get_user_requests', 'mlr_get_user_requests_callback');
add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');
add_action('wp_ajax_mlr_upload_additional_docs', 'mlr_upload_additional_docs_callback');
add_action('wp_ajax_mlr_submit_completed_docs', 'mlr_submit_completed_docs_callback');
add_action('wp_ajax_mlr_get_user_cycle_details', 'mlr_get_user_cycle_details_callback');

// Public Actions
add_action('wp_ajax_nopriv_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');
add_action('wp_ajax_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');


/**
 * ===================================================================
 * UPLOAD HANDLER (FIXED)
 * ===================================================================
 */
function mlr_upload_additional_docs_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً وارد شوید.']);
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $user_note = isset($_POST['user_note']) ? sanitize_textarea_field($_POST['user_note']) : '';
    $user_id = get_current_user_id();

    // Check limits
    if (empty($_FILES) && empty($_POST) && isset($_SERVER['REQUEST_METHOD']) && strtolower($_SERVER['REQUEST_METHOD']) == 'post') {
        wp_send_json_error(['message' => "خطا: حجم فایل ارسالی بیشتر از محدودیت سرور است."]);
    }

    // Check existence
    if (!isset($_FILES['additional_files']) || empty($_FILES['additional_files']['name'])) {
         wp_send_json_error(['message' => 'هیچ فایلی دریافت نشد. لطفاً مجدداً تلاش کنید.']);
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_requests} WHERE id = %d AND user_id = %d", $request_id, $user_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست نامعتبر است.']);
    }

    if ($request->status !== 'نقص مدارک') {
        wp_send_json_error(['message' => 'فقط درخواست‌های دارای وضعیت نقص مدارک امکان آپلود مجدد دارند.']);
    }

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');

    $uploaded_urls = [];
    $files = $_FILES['additional_files'];

    // Handle Upload
    if (is_array($files['name'])) {
        foreach ($files['name'] as $key => $value) {
            if (!empty($files['name'][$key])) {
                $file = [
                    'name' => $files['name'][$key],
                    'type' => $files['type'][$key],
                    'tmp_name' => $files['tmp_name'][$key],
                    'error' => $files['error'][$key],
                    'size' => $files['size'][$key]
                ];

                $upload_error = '';
                $validated_file = mlr_validate_uploaded_file($file, $upload_error);
                if (!$validated_file) {
                    continue;
                }
                $file = $validated_file;

                $upload_overrides = ['test_form' => false];
                $movefile = wp_handle_upload($file, $upload_overrides);

                if ($movefile && !isset($movefile['error'])) {
                    $uploaded_urls[] = $movefile['url'];
                }
            }
        }
    }

    if (empty($uploaded_urls)) {
        wp_send_json_error(['message' => 'خطا در ذخیره‌سازی فایل‌ها.']);
    }

    // Update DB
    $current_docs = maybe_unserialize($request->required_documents);
    if (!is_array($current_docs)) $current_docs = [];

    if (!isset($current_docs['additional_documents'])) {
        $current_docs['additional_documents'] = [];
    }
    if (!is_array($current_docs['additional_documents'])) {
         $existing = $current_docs['additional_documents'];
         $current_docs['additional_documents'] = !empty($existing) ? [$existing] : [];
    }
    
    $current_docs['additional_documents'] = array_merge($current_docs['additional_documents'], $uploaded_urls);

    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    $comments[] = [
        'user_id' => $user_id,
        'display_name' => 'کاربر (رفع نقص)',
        'text' => 'مدارک تکمیلی آپلود شد.' . (!empty($user_note) ? "\nتوضیحات: $user_note" : ''),
        'timestamp' => current_time('mysql')
    ];

    $updated = $wpdb->update($table_requests, [
        'required_documents' => serialize($current_docs),
        'comments' => json_encode($comments, JSON_UNESCAPED_UNICODE),
        'status' => 'در حال بررسی',
        'last_edited_at' => current_time('mysql')
    ], ['id' => $request_id]);

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطای دیتابیس رخ داد.']);
    }

    wp_send_json_success(['message' => 'مدارک ارسال شد و وضعیت پرونده به "در حال بررسی" تغییر یافت.']);
}


// --- CALCULATOR HANDLER ---
function mlr_frontend_calculate_loan_callback() {
    try {
        check_ajax_referer('mlr_frontend_calc_nonce', 'nonce');

        $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
        $amount = isset($_POST['amount']) ? floatval(str_replace(',', '', $_POST['amount'])) : 0;
        $installments = isset($_POST['installments']) ? intval($_POST['installments']) : 0;
        $installment_interval = isset($_POST['installment_interval']) ? intval($_POST['installment_interval']) : 1;
        $user_commission = (isset($_POST['user_commission']) && is_numeric($_POST['user_commission'])) ? floatval($_POST['user_commission']) : null;

        if (!$plan_id) wp_send_json_error(['message' => 'لطفاً یک طرح معتبر را انتخاب کنید.']);
        if ($amount <= 0 || $installments <= 0) wp_send_json_error(['message' => 'مبلغ و تعداد اقساط باید اعداد مثبت باشند.']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'installment_plans';
        $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND is_active = 1", $plan_id));

        if (!$plan) wp_send_json_error(['message' => 'طرح انتخاب شده یافت نشد.']);

        $settings = maybe_unserialize($plan->settings);
        $display_fields = maybe_unserialize($plan->display_fields);

        $min_amount = floatval($settings['min_amount'] ?? 0);
        $max_amount = floatval($settings['max_amount'] ?? 0);

        if (($min_amount > 0 && $amount < $min_amount) || ($max_amount > 0 && $amount > $max_amount)) {
            $message = sprintf('مبلغ وارد شده باید بین %s و %s ریال باشد.', number_format($min_amount), number_format($max_amount));
            wp_send_json_error(['message' => $message]);
        }
        
        $results = [];
        if ($plan->type === 'market') {
            $results = calculateMarketLoan($amount, $installments, $settings, $user_commission);
        } elseif ($plan->type === 'leasing') {
            $results = calculateLeasingLoan($amount, $installments, $installment_interval, $settings, $user_commission);
        }

        if (empty($results)) wp_send_json_error(['message' => 'خطا در انجام محاسبات.']);

        $labels_with_units = mlr_get_calculation_labels();
        ob_start();
        echo '<table>';
        foreach ($results as $key => $value) {
            if (!empty($display_fields) && is_array($display_fields) && in_array($key, $display_fields)) {
                $label_info = $labels_with_units[$key] ?? ['label' => ucwords(str_replace('_', ' ', $key)), 'unit' => ''];
                $formatted_value = (strpos($key, 'Percent') !== false || $label_info['unit'] === 'درصد') 
                    ? number_format_i18n($value * 100, 2) . ' ' . $label_info['unit'] 
                    : number_format_i18n(round($value)) . ' ' . $label_info['unit'];
                
                echo '<tr><td><strong>' . esc_html($label_info['label']) . '</strong></td><td>' . esc_html($formatted_value) . '</td></tr>';
            }
        }
        echo '</table>';
        wp_send_json_success(['html' => ob_get_clean()]);

    } catch (Exception $e) {
        wp_send_json_error(['message' => 'خطای داخلی سرور.']);
    }
}

// --- ADMIN DETAILS HANDLER ---
function mlr_get_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'عدم دسترسی.']);
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) wp_send_json_error(['message' => 'درخواست یافت نشد.']);
    
    $occupations = [ 'official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر' ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : esc_html($request->occupation);
    $all_doc_labels = mlr_get_all_document_options();
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];

    ob_start();
    ?>
    <div class="mlr-modal-content">
        <h3 class="mlr-modal-title">جزئیات درخواست (شناسه: <?php echo esc_html($request->id); ?>)</h3>
        
        <div class="mlr-modal-comments-section">
            <h4>یادداشت‌های کارشناسان</h4>
            <div class="mlr-comments-history">
                <?php if (!empty($comments) && is_array($comments)): foreach ($comments as $comment): ?>
                        <div class="mlr-comment-bubble">
                            <div class="mlr-comment-header">
                                <strong class="mlr-comment-author"><?php echo esc_html($comment['display_name'] ?? 'کاربر'); ?></strong>
                                <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i'); ?></span>
                            </div>
                            <div class="mlr-comment-body"><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></div>
                        </div>
                <?php endforeach; else: echo '<p>هنوز یادداشتی ثبت نشده است.</p>'; endif; ?>
            </div>
            <div class="mlr-add-comment-form">
                <textarea id="mlr_new_comment_text" rows="3" class="widefat" placeholder="یادداشت جدید..."></textarea>
                <button type="button" class="button button-primary" id="mlr-add-comment-btn" data-id="<?php echo esc_attr($request->id); ?>">افزودن یادداشت</button>
            </div>
        </div>

        <div class="mlr-modal-grid">
            <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">اطلاعات متقاضی و تسهیلات</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام:</strong></td><td><?php echo esc_html($request->full_name); ?></td></tr>
                    <tr><td><strong>کدملی:</strong></td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td><strong>موبایل:</strong></td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td><strong>شغل:</strong></td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td><strong>نام طرح:</strong></td><td><?php echo esc_html($request->plan_name); ?></td></tr>
                    <tr><td><strong>مبلغ وام:</strong></td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td><strong>وضعیت:</strong></td><td><?php echo esc_html($request->status); ?></td></tr>
                </table>
            </div>

            <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">مدارک</h4>
                <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                    <ul class="mlr-file-list">
                        <?php foreach($uploaded_documents as $doc_key => $doc_value): ?>
                            <li>
                                <strong><?php echo esc_html($all_doc_labels[$doc_key] ?? $doc_key); ?>:</strong>
                                <?php if (is_array($doc_value)): foreach ($doc_value as $i => $url): ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank">فایل <?php echo $i+1; ?></a>
                                <?php endforeach; elseif (is_string($doc_value)): ?>
                                    <a href="<?php echo esc_url($doc_value); ?>" target="_blank">مشاهده فایل</a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>مدارکی یافت نشد.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
    wp_send_json_success(['html' => ob_get_clean()]);
}

// --- ADD COMMENT HANDLER ---
function mlr_add_comment_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'عدم دسترسی.']);

    $request_id = intval($_POST['request_id']);
    $comment_text = sanitize_textarea_field($_POST['comment']);

    if (!$request_id || empty($comment_text)) wp_send_json_error(['message' => 'اطلاعات نامعتبر.']);

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $comments = json_decode($wpdb->get_var($wpdb->prepare("SELECT comments FROM $table_name WHERE id = %d", $request_id)), true) ?: [];
    
    $current_user = wp_get_current_user();
    $new_comment = [
        'user_id' => $current_user->ID,
        'display_name' => $current_user->display_name,
        'text' => $comment_text,
        'timestamp' => current_time('mysql'),
    ];
    $comments[] = $new_comment;

    $updated = $wpdb->update($table_name, ['comments' => json_encode($comments, JSON_UNESCAPED_UNICODE)], ['id' => $request_id]);
    
    if ($updated === false) wp_send_json_error(['message' => 'خطا در ذخیره.']);

    ob_start();
    ?>
    <div class="mlr-comment-bubble">
        <div class="mlr-comment-header">
            <strong class="mlr-comment-author"><?php echo esc_html($new_comment['display_name']); ?></strong>
            <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($new_comment['timestamp'], 'Y/m/d H:i'); ?></span>
        </div>
        <div class="mlr-comment-body"><?php echo nl2br(esc_html($new_comment['text'])); ?></div>
    </div>
    <?php
    wp_send_json_success(['message' => 'ثبت شد.', 'new_comment_html' => ob_get_clean()]);
}

function mlr_admin_calculate_loan_callback() {
    // This function acts as a placeholder if needed for admin specific calculations via AJAX
    wp_send_json_success(['message' => 'Admin calculation endpoint ready.']);
}
?>

function mlr_add_request_message_callback() {
    if (!function_exists('mlr_verify_any_nonce') || !mlr_verify_any_nonce('nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی (nonce نامعتبر).']);
        return;
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $message = isset($_POST['message']) ? wp_unslash($_POST['message']) : '';
    $message = wp_kses_post($message);

    if (!$request_id || empty(trim(wp_strip_all_tags($message)))) {
        wp_send_json_error(['message' => 'اطلاعات نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_requests} WHERE id = %d", $request_id));
    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    if (!function_exists('mlr_can_access_loan_request') || !mlr_can_access_loan_request($request)) {
        wp_send_json_error(['message' => 'شما دسترسی به این درخواست ندارید.']);
        return;
    }

    $inserted_id = function_exists('mlr_add_request_message') ? mlr_add_request_message($request_id, $message) : 0;
    if (!$inserted_id) {
        wp_send_json_error(['message' => 'خطا در ذخیره پیام.']);
        return;
    }

    if (function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'message', 'ارسال پیام/یادداشت');
    }

    $current_user = wp_get_current_user();
    ob_start();
    ?>
    <div class="mlr-message-bubble" style="padding:8px 10px; margin:0 0 8px; border:1px solid #f2f2f2; border-radius:8px;">
        <div style="font-size:12px; color:#666; margin-bottom:6px;">
            <?php echo esc_html($current_user->display_name); ?> — <?php echo esc_html(mlr_gregorian_to_jalali(current_time('mysql'), 'Y/m/d H:i')); ?>
        </div>
        <div><?php echo wp_kses_post(nl2br($message)); ?></div>
    </div>
    <?php
    wp_send_json_success(['message' => 'ارسال شد.', 'html' => ob_get_clean()]);
}
