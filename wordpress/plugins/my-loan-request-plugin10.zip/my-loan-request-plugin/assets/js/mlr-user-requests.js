jQuery(document).ready(function($) {
    
    // =========================================================
    // 1. GLOBAL MODAL SETUP
    // =========================================================
    if ($('#mlr-global-modal-overlay').length === 0) {
        $('body').append(`
            <div id="mlr-global-modal-overlay" class="mlr-modal-overlay"></div>
            <div id="mlr-global-modal" class="mlr-modal">
                <button class="mlr-modal-close">&times;</button>
                <div class="mlr-modal-content"></div>
            </div>
        `);
    }
    $('.mlr-user-requests .mlr-modal, .mlr-user-requests .mlr-modal-overlay').remove();

    // =========================================================
    // 2. CUSTOM JALALI DATEPICKER V4
    // =========================================================
    (function() {
        if ($('.jalali-datepicker').length === 0) return;
        let activeInput = null, datepicker, yearSelect, monthSelect, grid, currentYear, currentMonth;
        const dayNames = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
        const monthNames = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];

        function createDatePickerUI() {
            if ($('.mlr-custom-datepicker').length > 0) return;
            let yearOptions = '<option value="" disabled>سال</option>';
            const currentJalaliYear = parseInt(new Date().toLocaleDateString('fa-IR-u-nu-latn').split('/')[0]) || 1403;
            for (let y = currentJalaliYear + 1; y >= 1350; y--) yearOptions += `<option value="${y}">${y}</option>`;
            let monthOptions = '<option value="" disabled>ماه</option>';
            monthNames.forEach((name, index) => monthOptions += `<option value="${index + 1}">${name}</option>`);

            const dp_html = `
                <div class="mlr-custom-datepicker" style="display:none; position:absolute; z-index:2147483647; background:#fff; border:1px solid #ccc; border-radius:4px; padding:10px; width:220px; box-shadow: 0 3px 6px rgba(0,0,0,0.1);">
                    <div class="mlr-dp-header" style="display:flex; justify-content:space-between; margin-bottom:10px;">
                        <select class="mlr-dp-select year-select" required style="width:48%; padding: 4px; border:1px solid #ddd; border-radius:3px;">${yearOptions}</select>
                        <select class="mlr-dp-select month-select" required style="width:48%; padding: 4px; border:1px solid #ddd; border-radius:3px;">${monthOptions}</select>
                    </div>
                    <div class="mlr-dp-grid" style="display:grid; grid-template-columns:repeat(7, 1fr); gap:2px; text-align:center;"></div>
                </div>`;
            $('body').append(dp_html);
            datepicker = $('.mlr-custom-datepicker');
            yearSelect = datepicker.find('.year-select');
            monthSelect = datepicker.find('.month-select');
            grid = datepicker.find('.mlr-dp-grid');

            yearSelect.on('change', () => { currentYear = parseInt(yearSelect.val()); if (currentMonth) renderCalendar(); });
            monthSelect.on('change', () => { currentMonth = parseInt(monthSelect.val()); if (currentYear) renderCalendar(); });
            grid.on('click', '.mlr-dp-day:not(.disabled)', selectDate);
            $(document).on('click', function(e) {
                if (datepicker.is(":visible") && !$(e.target).closest('.mlr-custom-datepicker').length && !$(e.target).is(activeInput)) {
                    datepicker.fadeOut(200); activeInput = null;
                }
            });
        }
        function isJalaliLeap(year) { return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(year % 33) > -1; }
        function toGregorian(jy, jm, jd) {
            var sal_a, gy, gm, gd, days; jy += 1595; days = -355668 + (365 * jy) + (~~(jy / 33) * 8) + ~~(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
            gy = 400 * ~~(days / 146097); days %= 146097; if (days > 36524) { gy += 100 * ~~(--days / 36524); days %= 36524; if (days >= 365) days++; }
            gy += 4 * ~~(days / 1461); days %= 1461; if (days > 365) { gy += ~~((days - 1) / 365); days = (days - 1) % 365; }
            gd = days + 1; sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
            return new Date(gy, gm - 1, gd);
        }
        function renderCalendar() {
            grid.empty(); dayNames.forEach(name => grid.append(`<span class="mlr-dp-day-name" style="font-size:12px; font-weight:bold; color:#666; padding:4px 0;">${name}</span>`));
            const daysInMonth = (currentMonth <= 6) ? 31 : (currentMonth <= 11) ? 30 : (isJalaliLeap(currentYear)) ? 30 : 29;
            const startDayIndex = (new Date(toGregorian(currentYear, currentMonth, 1)).getDay() + 1) % 7;
            for (let i = 0; i < startDayIndex; i++) grid.append('<span class="disabled"></span>');
            for (let day = 1; day <= daysInMonth; day++) grid.append($(`<span class="mlr-dp-day" style="padding:6px 2px; cursor:pointer; border-radius:3px;">${day}</span>`).data('day', day).hover(function(){ $(this).css('background','#f0f0f0'); }, function(){ $(this).css('background','transparent'); }));
        }
        function selectDate() {
            if (!activeInput) return;
            $(activeInput).val(`${currentYear}/${String(currentMonth).padStart(2, '0')}/${String($(this).data('day')).padStart(2, '0')}`);
            datepicker.fadeOut(200); activeInput = null;
        }
        $(document).on('click', '.jalali-datepicker', function() {
            activeInput = this; grid.empty();
            const existingDate = $(this).val(), now = new Date(), todayJalali = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: 'numeric' }).format(now).split('/');
            if (existingDate && existingDate.match(/^\d{4}\/\d{2}\/\d{2}$/)) { const parts = existingDate.split('/'); currentYear = parseInt(parts[0]); currentMonth = parseInt(parts[1]); } else { currentYear = parseInt(todayJalali[0]); currentMonth = parseInt(todayJalali[1]); }
            yearSelect.val(currentYear); monthSelect.val(currentMonth); renderCalendar();
            const inputPos = $(activeInput).offset();
            datepicker.css({ top: inputPos.top + $(activeInput).outerHeight() + 5, left: inputPos.left, right: 'auto' }).fadeIn(200);
        });
        createDatePickerUI();
    })();

    // =========================================================
    // 3. CORE: LOAD REQUESTS & MODALS
    // =========================================================
    function loadRequests() {
        var container = $('.mlr-user-requests:not(.mlr-settlement-cycles)');
        if (!container.length) return;

        var data = {
            action: 'mlr_get_user_requests',
            nonce: mlr_ajax_obj.filter_nonce,
            search: container.find('#mlr-search').val(),
            status: container.find('#mlr-status').val(),
            settlement_status: container.find('#mlr-settlement-status').val(),
            date_from: container.find('#mlr-date-from').val(),
            date_to: container.find('#mlr-date-to').val(),
            allowed_statuses: mlr_ajax_obj.allowed_statuses || []
        };

        $.ajax({
            url: mlr_ajax_obj.ajax_url, 
            type: 'POST', 
            data: data,
            beforeSend: function() {
                container.find('#mlr-requests-table-body').html('<tr><td colspan="10" style="text-align:center; padding: 20px;">در حال بارگذاری لیست...</td></tr>');
            },
            success: function(res) {
                if (res.success) {
                    container.find('#mlr-requests-table-body').html(res.data.html);
                    container.find('#mlr-requests-table-body tr[data-id]').addClass('mlr-request-row-frontend');
                } else {
                    container.find('#mlr-requests-table-body').html(`<tr><td colspan="10" style="text-align:center; color: red;">${res.data.message}</td></tr>`);
                }
            },
            error: function() {
                container.find('#mlr-requests-table-body').html('<tr><td colspan="10" style="text-align:center; color: red;">خطای ارتباط با سرور.</td></tr>');
            }
        });
    }

    function showDetailsModal(requestId) {
        const modal = $('#mlr-global-modal');
        const content = modal.find('.mlr-modal-content');
        $('body').addClass('mlr-modal-open');
        $('#mlr-global-modal-overlay').fadeIn(200);
        modal.css('display', 'flex').hide().fadeIn(200);
        content.html('<p style="text-align:center; padding: 40px; font-size:16px;">در حال دریافت اطلاعات پرونده...</p>');

        $.post(mlr_ajax_obj.ajax_url, {
            action: 'mlr_get_frontend_request_details',
            nonce: mlr_ajax_obj.details_nonce,
            request_id: requestId
        })
        .done(function(res) {
            if (res.success) {
                content.html(res.data.html);
                if (typeof $.fn.persianDatepicker === 'function') {
                    content.find('.jalali-datepicker').persianDatepicker({ format: 'YYYY/MM/DD', autoClose: true });
                }
            } else {
                 content.html(`<p style="color:red; text-align:center; padding:20px;">${res.data.message}</p>`);
            }
        })
        .fail(function() {
            content.html('<p class="mlr-error" style="text-align:center; padding:20px;">خطای برقراری ارتباط با سرور.</p>');
        });
    }

    $(document).on('click', '#mlr-global-modal-overlay, .mlr-modal-close', function() {
        $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200, function(){ $('body').removeClass('mlr-modal-open'); });
    });
    $(document).on('click', '#mlr-global-modal', (e) => e.stopPropagation());
    
    $(document).on('click', '#mlr-requests-table-body tr.mlr-request-row-frontend', function(e) {
        if (!$(e.target).closest('button, a, input, select, textarea').length) {
            showDetailsModal($(this).data('id'));
        }
    });

    // =========================================================
    // 4. FIX: UPLOAD ADDITIONAL DOCS - MANUAL APPEND
    // =========================================================
    $(document).on('submit', '.mlr-universal-upload-form', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var submitBtn = form.find('button[type="submit"]');
        var messageDiv = form.find('.mlr-upload-status');
        
        // 1. Locate the file input
        var fileInput = form.find('input[type="file"]')[0];

        // 2. Validate existence
        if (!fileInput || fileInput.files.length === 0) {
            messageDiv.show().removeClass('loading success').addClass('error').css({'background':'#fde8e8', 'color':'#c0392b', 'border':'1px solid #c0392b'}).html('لطفاً حداقل یک فایل را انتخاب کنید.');
            return;
        }

        // 3. Manually build FormData
        var formData = new FormData();
        formData.append('action', 'mlr_upload_additional_docs');
        formData.append('nonce', mlr_ajax_obj.details_nonce);
        formData.append('request_id', form.find('input[name="request_id"]').val());
        
        var userNote = form.find('textarea[name="user_note"]').val();
        if(userNote) formData.append('user_note', userNote);

        // 4. Append files manually
        $.each(fileInput.files, function(i, file) {
            formData.append('additional_files[]', file);
        });

        // 5. Send AJAX
        $.ajax({
            url: mlr_ajax_obj.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function() {
                messageDiv.show().removeClass('error success').addClass('loading').css({'background':'#e8f4fd', 'color':'#2980b9', 'border':'1px solid #2980b9'}).html('در حال آپلود و پردازش... لطفاً شکیبا باشید.');
                submitBtn.prop('disabled', true).text('در حال ارسال...');
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass('error loading').addClass('success').css({'background':'#d4edda', 'color':'#155724', 'border':'1px solid #155724'}).html(response.data.message);
                    submitBtn.text('ارسال شد');
                    setTimeout(function() {
                        $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200);
                        loadRequests(); // Refresh the list
                    }, 2500);
                } else {
                    messageDiv.removeClass('success loading').addClass('error').css({'background':'#fde8e8', 'color':'#c0392b', 'border':'1px solid #c0392b'}).html(response.data.message);
                    submitBtn.prop('disabled', false).text('ارسال مدارک و بررسی مجدد');
                }
            },
            error: function() {
                messageDiv.removeClass('success loading').addClass('error').css({'background':'#fde8e8', 'color':'#c0392b', 'border':'1px solid #c0392b'}).html('خطای غیرمنتظره در ارتباط با سرور.');
                submitBtn.prop('disabled', false).text('ارسال مدارک و بررسی مجدد');
            }
        });
    });
    
    // =========================================================
    // 5. COMPLETE DOCS FORM
    // =========================================================
    $(document).on('submit', '#mlr-complete-docs-form', function(e) {
        e.preventDefault();
        var form = $(this);
        var messageDiv = form.find('.mlr-upload-status');
        if(!messageDiv.length) { form.prepend('<div class="mlr-upload-status" style="display:none; margin:10px 0; padding:10px;"></div>'); messageDiv = form.find('.mlr-upload-status'); }
        
        var formData = new FormData(this);
        formData.append('action', 'mlr_submit_completed_docs');
        formData.append('nonce', mlr_ajax_obj.details_nonce);

        $.ajax({
            url: mlr_ajax_obj.ajax_url, type: 'POST', data: formData, processData: false, contentType: false,
            beforeSend: () => { messageDiv.show().removeClass().addClass('mlr-upload-status loading').css({'background':'#e8f4fd', 'color':'#2980b9', 'border':'1px solid #2980b9'}).html('در حال ارسال...'); form.find('button').prop('disabled', true); },
            success: (res) => {
                if (res.success) {
                    messageDiv.removeClass().addClass('mlr-upload-status success').css({'background':'#d4edda', 'color':'#155724', 'border':'1px solid #155724'}).html(res.data.message);
                    setTimeout(() => { $('#mlr-global-modal-overlay, #mlr-global-modal').fadeOut(200); loadRequests(); }, 2500);
                } else {
                    messageDiv.removeClass().addClass('mlr-upload-status error').css({'background':'#fde8e8', 'color':'#c0392b', 'border':'1px solid #c0392b'}).html(res.data.message);
                    form.find('button').prop('disabled', false);
                }
            },
            error: () => { messageDiv.removeClass().addClass('mlr-upload-status error').css({'background':'#fde8e8', 'color':'#c0392b', 'border':'1px solid #c0392b'}).html('خطای سرور.'); form.find('button').prop('disabled', false); }
        });
    });

    // =========================================================
    // 6. OTHER EVENTS
    // =========================================================
    $(document).on('click', '.mlr-view-file-btn', function(e) { e.preventDefault(); e.stopPropagation(); window.open($(this).attr('href'), '_blank'); });
    $(document).on('click', '.mlr-print-contract-step-btn', function() { mlrPrintElement('.printable-contract-area'); });
    $(document).on('click', '.mlr-print-invoice-step-btn', function() { mlrPrintElement('.printable-invoice-area'); });
    $(document).on('click', '.mlr-print-btn', function() { mlrPrintElement('.mlr-modal-content'); });
    
    function mlrPrintElement(s) {
        var c = $(s).html(); if (!c) { alert('محتوا یافت نشد'); return; }
        var w = window.open('','','height=600,width=800'); w.document.write('<html><head><title>Print</title><style>body{font-family:Tahoma;direction:rtl;text-align:right;} table{width:100%;border-collapse:collapse;} td,th{border:1px solid #000;padding:5px;} img{max-width:100%;}</style></head><body>'+c+'</body></html>'); w.document.close(); w.focus(); setTimeout(()=>w.print(),500);
    }

    if ($('.mlr-user-requests:not(.mlr-settlement-cycles)').length > 0) loadRequests();
    $(document).on('click', '#mlr-filter-btn', () => { if (!$('#mlr-search').closest('.mlr-settlement-cycles').length) loadRequests(); });
    $(document).on('keyup', '#mlr-search', (e) => { if (e.key === 'Enter' && !$(e.target).closest('.mlr-settlement-cycles').length) loadRequests(); });

    $(document).on('click', '.mlr-next-step-btn', function() {
        var form = $(this).closest('form'), current = form.find('.mlr-step-pane.active'), valid = true;
        current.find('input[required], select[required], textarea[required]').each(function() {
             if (!$(this).val() && (!$(this)[0].files || !$(this)[0].files.length)) { valid = false; $(this).css('border-color', 'red'); } else { $(this).css('border-color', ''); }
        });
        if(!valid) { alert('لطفاً فیلدهای اجباری را پر کنید.'); return; }
        var next = current.next('.mlr-step-pane');
        if (next.length) { current.removeClass('active'); next.addClass('active'); var step = next.data('step-pane'); form.closest('.mlr-complete-docs-section').find(`.mlr-step[data-step="${step-1}"]`).addClass('completed'); form.closest('.mlr-complete-docs-section').find(`.mlr-step[data-step="${step}"]`).addClass('active'); updateStepper(next); }
    });
    $(document).on('click', '.mlr-prev-step-btn', function() {
        var form = $(this).closest('form'), current = form.find('.mlr-step-pane.active'), prev = current.prev('.mlr-step-pane');
        if (prev.length) { current.removeClass('active'); prev.addClass('active'); var step = current.data('step-pane'); form.closest('.mlr-complete-docs-section').find(`.mlr-step[data-step="${step}"]`).removeClass('active'); updateStepper(prev); }
    });
    function updateStepper(p) { var f = p.closest('form'); f.find('.mlr-prev-step-btn').toggle(!p.is(':first-child')); f.find('.mlr-next-step-btn').toggle(!p.is(':last-child')); f.find('.mlr-submit-btn').toggle(p.is(':last-child')); }

    $(document).on('click', '.mlr-cycle-row-frontend', function() {
        var row = $(this), id = row.data('cycle-id'), det = $('#cycle-details-frontend-' + id), con = det.find('.cycle-details-container');
        row.toggleClass('open'); det.toggle();
        if (!row.data('loaded') && det.is(':visible')) {
            con.find('.spinner-container').show();
            $.post(mlr_ajax_obj.ajax_url, { action: 'mlr_get_user_cycle_details', nonce: mlr_ajax_obj.cycle_nonce, cycle_id: id }).done((res) => {
                if (res.success) { con.html(res.data.html).find('tr[data-id]').addClass('mlr-request-row-frontend'); row.data('loaded', true); } else { con.html(res.data.message); }
            });
        }
    });
});