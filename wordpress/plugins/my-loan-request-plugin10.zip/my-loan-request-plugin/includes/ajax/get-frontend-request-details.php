<?php
// FILE: my-loan-request-plugin/includes/ajax/get-frontend-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');

function mlr_get_frontend_request_details_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً ابتدا وارد سایت شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $is_admin = current_user_can('manage_options');
    $is_bank_expert = in_array('bank', (array) $current_user->roles);

    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';

    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }

    // بررسی سطح دسترسی
    if (!$is_admin) {
        if ($is_bank_expert) {
            if ($request->assigned_bank_user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این پرونده ندارید.']);
                return;
            }
        } else {
            if ($request->user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این درخواست ندارید.']);
                return;
            }
        }
    }

    $uploaded_documents = maybe_unserialize($request->required_documents);
    if (!is_array($uploaded_documents)) {
        $uploaded_documents = [];
    }
    
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];

    // فایل‌های تکمیلی
    $extra_files = [];
    $extra_files['bank_validation_file'] = $request->bank_validation_file ?? '';
    $extra_files['signature_image'] = $request->signature_image ?? '';
    $extra_files['contract_file'] = $request->contract_file ?? '';

    $parsed_check_images = [];
    if (!empty($request->check_images)) {
        $maybe = maybe_unserialize($request->check_images);
        if (is_array($maybe)) {
            $parsed_check_images = $maybe;
        } else {
            $json = json_decode($request->check_images, true);
            if (is_array($json)) {
                $parsed_check_images = $json;
            } else {
                $parts = preg_split('/[\r\n,]+/', (string)$request->check_images);
                $parts = array_filter(array_map('trim', $parts));
                $parsed_check_images = $parts ? $parts : [(string)$request->check_images];
            }
        }
    }
    if (!empty($parsed_check_images)) {
        $extra_files['check_images'] = $parsed_check_images;
    }

    $extra_file_labels = [
        'bank_validation_file' => 'فایل اعتبارسنجی بانک',
        'signature_image'      => 'تصویر امضا',
        'contract_file'        => 'فایل قرارداد',
        'check_images'         => 'تصاویر چک',
    ];
    
    $occupations = [
        'official_employee' => 'کارمند رسمی', 
        'contract_employee' => 'کارمند قراردادی', 
        'worker' => 'کارگر', 
        'freelancer' => 'آزاد', 
        'retired' => 'بازنشسته', 
        'pensioner' => 'مستمری بگیر', 
        'employer' => 'کارفرما', 
        'other' => 'سایر'
    ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : $request->occupation;
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    // تولید شناسه‌های کاملاً یکتا برای جلوگیری از تداخل DOM
    $uniq = uniqid('req_');
    $form_id = 'mlr_upload_form_' . $uniq;
    $input_file_id = 'mlr_file_' . $uniq;
    $input_note_id = 'mlr_note_' . $uniq;
    $input_req_id = 'mlr_req_' . $uniq;

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست #<?php echo esc_html($request->id); ?></h3>
        <span class="mlr-status-badge status-<?php echo sanitize_html_class($request->status); ?>"><?php echo esc_html($request->status); ?></span>
    </div>
    
    <div class="mlr-modal-body">
        
        <?php if ($request->status === 'نقص مدارک' && !$is_bank_expert && !$is_admin): ?>
            <div class="mlr-reupload-section" style="margin-bottom: 25px; padding: 20px; border: 2px dashed #f39c12; background: #fffdf6; border-radius: 8px;">
                <h4 style="color: #d35400; margin-top: 0; margin-bottom: 10px; display: flex; align-items: center;">
                    <span class="dashicons dashicons-warning" style="margin-left: 5px;"></span> رفع نقص مدارک
                </h4>
                <p style="margin-bottom: 15px; font-size: 0.95em; line-height: 1.6; color: #444;">
                    پرونده شما به دلیل نقص در مدارک بازگردانده شده است. لطفاً بخش "سوابق و پیام‌ها" را مطالعه کنید تا از علت نقص مطلع شوید، سپس مدارک صحیح را بارگذاری کنید.
                    <br><strong>پس از ارسال، وضعیت پرونده به "در حال بررسی" تغییر خواهد کرد.</strong>
                </p>
                
                <form id="<?php echo esc_attr($form_id); ?>" class="mlr-universal-upload-form" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" id="<?php echo esc_attr($input_req_id); ?>" value="<?php echo esc_attr($request->id); ?>">
                    
                    <div class="mlr-form-group">
                        <label for="<?php echo esc_attr($input_file_id); ?>" style="font-weight: bold; display: block; margin-bottom: 8px; color: #333;">انتخاب مدارک جدید (تصویر یا PDF):</label>
                        <input type="file" id="<?php echo esc_attr($input_file_id); ?>" name="additional_files[]" multiple accept=".jpg,.jpeg,.png,.pdf" required style="width: 100%; padding: 10px; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
                        <p class="description" style="font-size: 0.85em; color: #666; margin-top: 5px;">می‌توانید چند فایل را همزمان انتخاب کنید.</p>
                    </div>

                    <div class="mlr-form-group" style="margin-top: 15px;">
                        <label for="<?php echo esc_attr($input_note_id); ?>" style="font-weight: bold; display: block; margin-bottom: 8px; color: #333;">توضیحات شما (اختیاری):</label>
                        <textarea id="<?php echo esc_attr($input_note_id); ?>" name="user_note" rows="3" style="width: 100%; border: 1px solid #ddd; border-radius: 4px; padding: 8px; min-height: 80px;" placeholder="توضیحات رفع نقص..."></textarea>
                    </div>

                    <button type="submit" class="button button-primary mlr-submit-docs-btn" style="margin-top: 15px; width: 100%; height: 40px; display:flex; justify-content:center; align-items:center; font-size: 14px;">ارسال مدارک و بررسی مجدد</button>
                    <div class="mlr-upload-status" style="display:none; margin-top: 15px; padding: 10px; border-radius: 4px; text-align: center;"></div>
                </form>
            </div>
        <?php endif; ?>

        <div class="mlr-info-box">
            <h4>مشخصات فردی</h4>
            <div class="mlr-info-grid">
                <div><span>نام:</span> <strong><?php echo esc_html($request->full_name); ?></strong></div>
                <div><span>کد ملی:</span> <?php echo esc_html($request->national_code); ?></div>
                <div><span>موبایل:</span> <?php echo esc_html($request->mobile_number); ?></div>
                <div><span>شغل:</span> <?php echo esc_html($occupation_display); ?></div>
                <div style="grid-column: 1 / -1;"><span>آدرس:</span> <?php echo esc_html($request->residential_address); ?></div>
            </div>
        </div>

        <div class="mlr-info-box">
            <h4>اطلاعات تسهیلات</h4>
            <div class="mlr-info-grid">
                <div><span>طرح:</span> <?php echo esc_html($request->plan_name); ?></div>
                <div><span>مبلغ وام:</span> <?php echo number_format($request->loan_amount); ?> ریال</div>
                <div><span>اقساط:</span> <?php echo esc_html($request->installment_count); ?> ماهه</div>
                <div><span>مبلغ قسط:</span> <?php echo number_format($request->installment_amount); ?> ریال</div>
            </div>
        </div>

        <div class="mlr-info-box">
            <h4>اطلاعات تکمیلی</h4>
            <div class="mlr-info-grid">
                <?php if (!empty($request->product_name)): ?>
                    <div><span>نام کالا:</span> <strong><?php echo esc_html($request->product_name); ?></strong></div>
                <?php endif; ?>
                <?php if (!empty($request->created_at)): ?>
                    <div><span>تاریخ ثبت نام:</span> <strong><?php echo esc_html(function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->created_at) : $request->created_at); ?></strong></div>
                <?php endif; ?>
            </div>
            <?php if (!empty($request->description)): ?>
                <div style="margin-top:12px;">
                    <div style="font-weight:800; color: var(--mlr-text-dark); margin-bottom: 5px;">توضیحات متقاضی:</div>
                    <div class="mlr-long-text" style="background: #f9f9f9; padding: 10px; border-radius: 4px; border: 1px solid #eee;"><?php echo nl2br(esc_html($request->description)); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($extra_files) && is_array($extra_files)): ?>
        <div class="mlr-info-box">
            <h4>فایل‌های سیستمی و قرارداد</h4>
            <div class="mlr-file-grid">
                <?php foreach ($extra_files as $fkey => $fval): 
                    if (empty($fval)) continue;
                    $label = isset($extra_file_labels[$fkey]) ? $extra_file_labels[$fkey] : ucfirst(str_replace('_',' ', $fkey));
                ?>
                    <div class="mlr-file-item">
                        <div class="mlr-file-label"><?php echo esc_html($label); ?></div>
                        <div class="mlr-file-actions">
                            <?php if (is_array($fval)): ?>
                                <?php foreach ($fval as $idx => $url): if (empty($url)) continue; ?>
                                    <a class="mlr-view-file-btn" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">مشاهده <?php echo intval($idx)+1; ?></a>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <a class="mlr-view-file-btn" href="<?php echo esc_url($fval); ?>" target="_blank" rel="noopener noreferrer">مشاهده فایل</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($uploaded_documents)): ?>
        <div class="mlr-info-box">
            <h4>مدارک بارگذاری شده</h4>
            <div class="mlr-docs-list">
                <?php foreach($uploaded_documents as $key => $val): 
                     $label = $all_doc_labels[$key] ?? $key;
                ?>
                    <div class="mlr-doc-item">
                        <strong><?php echo esc_html($label); ?>:</strong>
                        <?php if(is_array($val)): ?>
                            <?php foreach($val as $i => $url): ?>
                                <a href="<?php echo esc_url($url); ?>" target="_blank" class="mlr-btn-small">فایل <?php echo $i+1; ?></a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <a href="<?php echo esc_url($val); ?>" target="_blank" class="mlr-btn-small">مشاهده</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($comments)): ?>
        <div class="mlr-info-box">
            <h4>سوابق و پیام‌ها (یادداشت‌های کارشناس)</h4>
            <div class="mlr-comments-list">
                <?php foreach($comments as $cm): ?>
                    <div class="mlr-comment" style="background: #f1f1f1; padding: 10px; margin-bottom: 10px; border-radius: 5px;">
                        <div style="font-size: 0.85em; color: #777; margin-bottom: 5px;">
                            <span style="font-weight: bold; color: #333;"><?php echo esc_html($cm['display_name']); ?></span> - 
                            <?php echo (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($cm['timestamp'], 'Y/m/d H:i') : $cm['timestamp']); ?>
                        </div>
                        <p style="margin: 0; line-height: 1.5;"><?php echo nl2br(esc_html($cm['text'])); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($is_bank_expert && $request->assigned_bank_user_id == $user_id): ?>
             <div class="mlr-action-box" style="background: #e8f0fe; padding: 20px; border-radius: 8px; margin-top: 25px; border: 1px solid #b3d7ff;">
                 <h4 style="margin-top:0; color:#0056b3;">بررسی و تغییر وضعیت پرونده</h4>
                 <?php 
                 $action_form_id = 'mlr_expert_action_' . $uniq;
                 $status_id = 'status_' . $uniq;
                 $expert_comment_id = 'expert_comment_' . $uniq;
                 ?>
                 <form id="<?php echo esc_attr($action_form_id); ?>" class="mlr-bank-expert-action-form">
                     <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                     <div class="mlr-form-group">
                         <label for="<?php echo esc_attr($status_id); ?>" style="font-weight:bold;">تغییر وضعیت به:</label>
                         <select name="new_status" id="<?php echo esc_attr($status_id); ?>" class="mlr-select" style="width:100%; margin-bottom:15px; padding: 8px;">
                            <?php 
                            $opts = ($request->status == 'تأیید کارشناس') 
                                ? ['تکمیل مدارک'=>'ارسال برای تکمیل مدارک','نقص مدارک'=>'اعلام نقص مدارک','رد شده'=>'رد درخواست'] 
                                : ['اعطا شده'=>'تأیید نهایی و اعطا شده','رد شده'=>'رد درخواست','تکمیل مدارک'=>'بازگشت به تکمیل مدارک'];
                            foreach($opts as $v => $l): echo "<option value='$v'>$l</option>"; endforeach; 
                            ?>
                         </select>
                     </div>
                     <div class="mlr-form-group">
                         <label for="<?php echo esc_attr($expert_comment_id); ?>" style="font-weight:bold;">توضیحات (اختیاری):</label>
                         <textarea name="comment_text" id="<?php echo esc_attr($expert_comment_id); ?>" rows="3" class="mlr-textarea" style="width:100%; padding: 8px;" placeholder="توضیحاتی برای کاربر یا سیستم..."></textarea>
                     </div>
                     <div class="mlr-action-message" style="display:none; margin-bottom:10px;"></div>
                     <button type="submit" class="mlr-btn mlr-btn-primary" style="width:100%; height: 40px;">ثبت بررسی</button>
                 </form>
             </div>
        <?php endif; ?>

    </div>
    <?php
    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}
?>