<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_save_guarantor_info', 'mlr_save_guarantor_info_callback');

function mlr_save_guarantor_info_callback() {
    // Accept both frontend and admin nonce so form works from shortcodes and from admin modal
    if (!function_exists('mlr_verify_any_nonce') || !mlr_verify_any_nonce('nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی. لطفاً صفحه را رفرش کرده و دوباره تلاش کنید.']);
        return;
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً ابتدا وارد شوید.']);
        return;
    }

    // request_id: از GET (برای multipart)، POST و REQUEST خوانده می‌شود تا در هر سرور درست کار کند
    $request_id = 0;
    if (isset($_GET['request_id']) && absint($_GET['request_id']) > 0) {
        $request_id = absint($_GET['request_id']);
    } elseif (isset($_POST['request_id'])) {
        $request_id = absint($_POST['request_id']);
    } elseif (isset($_REQUEST['request_id'])) {
        $request_id = absint($_REQUEST['request_id']);
    }
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';
    $uid = get_current_user_id();
    $current_user = wp_get_current_user();
    $is_admin = current_user_can('manage_options');
    $is_bank_expert = in_array('bank', (array) $current_user->roles, true);

    // Load upload handler if not already loaded
    if (!function_exists('mlr_handle_wp_upload')) {
        wp_send_json_error(['message' => 'سیستم آپلود در دسترس نیست.']);
        return;
    }

    // Check access: admin, applicant (owner), or assigned bank expert
    $req = $wpdb->get_row($wpdb->prepare(
        "SELECT user_id, assigned_bank_user_id, guarantor_info FROM {$table} WHERE id = %d",
        $request_id
    ));
    if (!$req) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    $can_edit = $is_admin
        || ( (int) $req->user_id === $uid )
        || ( $is_bank_expert && (int) $req->assigned_bank_user_id === $uid );
    if (!$can_edit) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز.']);
        return;
    }

    // Ensure guarantor_info column exists (legacy installs)
    $col = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `{$table}` LIKE %s", 'guarantor_info'));
    if (empty($col)) {
        $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN guarantor_info LONGTEXT DEFAULT NULL AFTER comments");
    }

    $info = !empty($req->guarantor_info) ? json_decode($req->guarantor_info, true) : [];
    if (!is_array($info)) {
        $info = [];
    }

    // Text fields (use wp_unslash for POST data)
    $text_fields = ['full_name', 'national_code', 'father_name', 'id_number', 'issued_from', 'birth_date', 'mobile', 'phone', 'job', 'postal_code', 'address'];
    foreach ($text_fields as $f) {
        if (isset($_POST[$f])) {
            $info[$f] = sanitize_text_field(wp_unslash($_POST[$f]));
        }
    }

    // File fields: mlr_handle_wp_upload returns URL string on success
    $file_fields = ['national_card', 'id_card', 'payslip', 'sana', 'check', 'residence_deed', 'work_deed', 'account_statement', 'extra_docs'];
    foreach ($file_fields as $f) {
        if (!empty($_FILES[$f]['name']) && $_FILES[$f]['error'] !== UPLOAD_ERR_NO_FILE) {
            $upload = mlr_handle_wp_upload($_FILES[$f]);
            if (!is_wp_error($upload)) {
                $info[$f] = is_array($upload) ? ($upload['url'] ?? '') : $upload;
            }
        }
    }

    $json = wp_json_encode($info, JSON_UNESCAPED_UNICODE);
    $updated = $wpdb->update(
        $table,
        ['guarantor_info' => $json],
        ['id' => $request_id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        $err = $wpdb->last_error ? $wpdb->last_error : 'خطای نامشخص دیتابیس';
        if (function_exists('mlr_log')) {
            mlr_log('save_guarantor_info update failed: ' . $err);
        }
        wp_send_json_error(['message' => 'خطا در ذخیره اطلاعات. لطفاً دوباره تلاش کنید.']);
        return;
    }

    wp_send_json_success(['message' => 'اطلاعات و مدارک ضامن با موفقیت ذخیره شد.']);
}