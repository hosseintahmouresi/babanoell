<?php
// FILE: my-loan-request-plugin/includes/shortcodes/bank-expert-dashboard.php
if (!defined('ABSPATH')) {
    exit;
}

add_shortcode('mlr_bank_expert_dashboard', 'mlr_bank_expert_dashboard_shortcode');

function mlr_bank_expert_dashboard_shortcode() {
    // Check if user is logged in and has the 'bank' role
    if (!is_user_logged_in()) {
        return '<p>برای دسترسی به این بخش، لطفاً ابتدا وارد شوید.</p>';
    }

    $current_user = wp_get_current_user();
    if (!in_array('bank', (array) $current_user->roles)) {
        return '<p>شما دسترسی لازم برای مشاهده این صفحه را ندارید.</p>';
    }

    // Enqueue necessary scripts and styles
    wp_enqueue_style('dashicons');
    
    // Persian Datepicker Assets (CDN)
    wp_enqueue_style('persian-datepicker-style', 'https://unpkg.com/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css');
    wp_enqueue_script('persian-date', 'https://unpkg.com/persian-date@1.1.0/dist/persian-date.min.js', [], '1.1.0', true);
    wp_enqueue_script('persian-datepicker-script', 'https://unpkg.com/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js', ['jquery', 'persian-date'], '1.2.0', true);
    
    // Enqueue the main frontend CSS
    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], '6.6.0');
    // Enqueue the specific CSS for this dashboard
    wp_enqueue_style('mlr-bank-expert-dashboard-css', MLR_PLUGIN_URL . 'assets/css/bank-expert-dashboard.css', [], '1.0.0');

    // Enqueue the specific JS for this dashboard
    wp_enqueue_script('mlr-bank-expert-dashboard-js', MLR_PLUGIN_URL . 'assets/js/bank-expert-dashboard.js', ['jquery'], '1.0.1', true);
    
    // Localize script for AJAX
    wp_localize_script('mlr-bank-expert-dashboard-js', 'mlr_bank_ajax_obj', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
    ]);
    
    $unique_id = uniqid('mlr-bank-dashboard-');

    ob_start();
    ?>
    <div class="mlr-glass-dashboard" id="<?php echo esc_attr($unique_id); ?>">
        <div class="mlr-glass-blob blob-1"></div>
        <div class="mlr-glass-blob blob-2"></div>
        
        <div class="mlr-dashboard-wrapper">
            <h2 class="mlr-dashboard-title"><span class="dashicons dashicons-businessman"></span> داشبورد کارشناس بانک</h2>
        
            <div class="mlr-glass-card mlr-filter-section">
                <div class="mlr-filter-form">
                    <button type="button" class="mlr-btn mlr-btn-secondary" id="mlr-export-excel">خروجی اکسل</button>
                    <input type="text" id="mlr-search" class="mlr-glass-input" placeholder="کدملی، متقاضی، شماره موبایل، شناسه">
                    <input type="text" class="jalali-datepicker mlr-glass-input" id="mlr-date-from" placeholder="از تاریخ..." autocomplete="off">
                    <input type="text" class="jalali-datepicker mlr-glass-input" id="mlr-date-to" placeholder="تا تاریخ..." autocomplete="off">
                    <button type="button" id="mlr-filter-btn" class="mlr-btn mlr-btn-primary">فیلتر</button>
                </div>
            </div>

            <div class="mlr-glass-card mlr-table-section">
                <div class="mlr-table-responsive-wrapper">
                    <table class="mlr-requests-table" id="mlr-requests-table">
                        <thead>
                            <tr>
                                <th>شناسه</th>
                                <th>متقاضی</th>
                                <th>شماره موبایل</th>
                                <th>کد ملی</th>
                                <th>مبلغ (ریال)</th>
                                <th>طرح</th>
                                <th>وضعیت</th>
                                <th>تاریخ ارجاع</th>
                                <th>عملیات</th>
                            </tr>
                        </thead>
                        <tbody id="mlr-requests-table-body" class="mlr-requests-table-body">
                            <tr><td colspan="9" style="text-align: center; padding: 20px;">در حال بارگذاری درخواست‌ها...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="mlr-modal-overlay" style="display:none;"></div>
        <div class="mlr-modal" style="display:none;">
            <button class="mlr-modal-close">&times;</button>
            <div class="mlr-modal-content"></div>
        </div>
    </div>
    
    <style>
        :root {
            --mlr-blue-dark: #1D3558;
            --mlr-blue-light: #D0E2F2;
            --mlr-gold: #eda900;
            --mlr-white-glass: rgba(255, 255, 255, 0.75);
            --mlr-white-glass-strong: rgba(255, 255, 255, 0.9);
            --mlr-border-glass: 1px solid rgba(255, 255, 255, 0.6);
            --mlr-shadow-soft: 0 10px 40px -10px rgba(29, 53, 88, 0.15);
            --mlr-radius-lg: 24px;
            --mlr-radius-md: 14px;
            --mlr-font-family: 'Vazirmatn', Tahoma, sans-serif;
        }

        .mlr-glass-dashboard {
            font-family: var(--mlr-font-family) !important;
            background: linear-gradient(135deg, #f0f5f9 0%, var(--mlr-blue-light) 100%) !important;
            border-radius: var(--mlr-radius-lg) !important;
            box-shadow: var(--mlr-shadow-soft) !important;
            padding: 30px !important;
            margin: 30px 0 !important;
            position: relative !important;
            overflow: hidden !important;
            color: var(--mlr-blue-dark) !important;
            direction: rtl !important;
        }

        .mlr-glass-blob { position: absolute; border-radius: 50%; filter: blur(80px); z-index: 0; }
        .blob-1 { width: 450px; height: 450px; background: var(--mlr-blue-light); top: -100px; left: -100px; opacity: 0.8; }
        .blob-2 { width: 350px; height: 350px; background: var(--mlr-gold); bottom: -80px; right: -80px; opacity: 0.15; }

        .mlr-dashboard-wrapper { position: relative; z-index: 1; }

        .mlr-dashboard-title {
            font-size: 24px !important;
            font-weight: 800 !important;
            color: var(--mlr-blue-dark) !important;
            margin-bottom: 25px !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .mlr-dashboard-title .dashicons { font-size: 28px; width: 28px; height: 28px; color: var(--mlr-gold); }

        .mlr-glass-card {
            background: var(--mlr-white-glass) !important;
            backdrop-filter: blur(12px) !important;
            -webkit-backdrop-filter: blur(12px) !important;
            border: var(--mlr-border-glass) !important;
            border-radius: var(--mlr-radius-md) !important;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.05) !important;
            padding: 25px !important;
            margin-bottom: 25px !important;
        }

        .mlr-filter-form { display: flex; flex-wrap: wrap; gap: 15px; align-items: center; }
        .mlr-glass-input {
            flex: 1;
            min-width: 150px;
            padding: 12px 15px !important;
            border: 1px solid rgba(29, 53, 88, 0.2) !important;
            border-radius: 10px !important;
            background: rgba(255,255,255,0.8) !important;
            color: var(--mlr-blue-dark) !important;
            font-family: var(--mlr-font-family) !important;
            transition: all 0.3s !important;
        }
        .mlr-glass-input:focus { background: #fff !important; border-color: var(--mlr-blue-dark) !important; outline: none !important; box-shadow: 0 0 0 3px rgba(29, 53, 88, 0.1) !important; }

        .mlr-btn { padding: 12px 25px !important; border-radius: 10px !important; border: none !important; cursor: pointer !important; font-weight: 700 !important; transition: all 0.3s !important; font-family: var(--mlr-font-family) !important; }
        .mlr-btn-primary { background: var(--mlr-blue-dark) !important; color: #fff !important; }
        .mlr-btn-primary:hover { background: var(--mlr-gold) !important; color: var(--mlr-blue-dark) !important; }
        .mlr-btn-secondary { background: rgba(255,255,255,0.6) !important; color: var(--mlr-blue-dark) !important; border: 1px solid rgba(29, 53, 88, 0.1) !important; }
        .mlr-btn-secondary:hover { background: #fff !important; }

        .mlr-requests-table { width: 100%; border-collapse: collapse; }
        .mlr-requests-table th { background: rgba(208, 226, 242, 0.6) !important; color: var(--mlr-blue-dark) !important; font-weight: 700 !important; padding: 15px !important; text-align: right !important; border-bottom: 1px solid rgba(29, 53, 88, 0.1) !important; }
        .mlr-requests-table td { padding: 15px !important; border-bottom: 1px solid rgba(29, 53, 88, 0.05) !important; color: var(--mlr-blue-dark) !important; }
        .mlr-requests-table tr:last-child td { border-bottom: none !important; }
        .mlr-requests-table tr:hover td { background: rgba(208, 226, 242, 0.2) !important; }
    </style>

    <script>
    (function($){
        var $wrap = $('#<?php echo esc_js($unique_id); ?>');
        if (!$wrap.length) return;
        $wrap.on('click', '#mlr-export-excel', function(){
            // Search input id is "mlr-search" inside this shortcode.
            var search = $wrap.find('#mlr-search').val() || '';
            var date_from = $wrap.find('#mlr-date-from').val() || '';
            var date_to = $wrap.find('#mlr-date-to').val() || '';
            // Export current tab (default تأیید کارشناس). If dashboard has data-status, use it.
            var status = $wrap.find('[data-mlr-current-status]').data('mlr-current-status') || 'تأیید کارشناس';
            var url = mlr_bank_ajax_obj.ajax_url + '?action=mlr_export_bank_expert_requests'
                + '&nonce=' + encodeURIComponent(mlr_bank_ajax_obj.nonce)
                + '&status=' + encodeURIComponent(status)
                + '&search=' + encodeURIComponent(search)
                + '&date_from=' + encodeURIComponent(date_from)
                + '&date_to=' + encodeURIComponent(date_to);
            window.location.href = url;
        });
    })(jQuery);
    </script>
    <?php
    return ob_get_clean();
}
?>