<?php
if (!defined('ABSPATH')) {
    exit;
}

function mlr_render_user_requests_table($title, $allowed_statuses = []) {
    if (!is_user_logged_in()) {
        return '<p>برای مشاهده این بخش، لطفاً ابتدا وارد شوید.</p>';
    }

    wp_enqueue_style('dashicons');
    
    $version = '8.4.2.1'; // Version bump
    wp_enqueue_script('mlr-user-requests-js', MLR_PLUGIN_URL . 'assets/js/mlr-user-requests.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
    wp_localize_script('mlr-user-requests-js', 'mlr_ajax_obj', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'filter_nonce'    => wp_create_nonce('mlr_user_requests_nonce'),
        'details_nonce'   => wp_create_nonce('mlr_frontend_nonce'),
        'cycle_nonce'     => wp_create_nonce('mlr_user_cycle_nonce'),
        'allowed_statuses' => $allowed_statuses
    ]);
    
    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], '8.4.2.2');

    $unique_id = uniqid('mlr-table-');
    
    $ordered_statuses = [
        'در حال بررسی', 'نقص مدارک', 'رد شده', 'تأیید کارشناس', 
        'تکمیل مدارک', 'تأیید مدارک', 'اعطا شده',
    ];

    ob_start();
    ?>
    <div class="mlr-glass-dashboard mlr-user-requests <?php if ($title === 'سیکل‌های تسویه حساب') echo 'mlr-settlement-cycles'; ?>" id="<?php echo esc_attr($unique_id); ?>">
        <div class="mlr-glass-blob blob-1"></div>
        <div class="mlr-glass-blob blob-2"></div>
        
        <div class="mlr-dashboard-wrapper">
        <?php if(!empty($title)): ?>
            <h2 class="mlr-dashboard-title"><span class="dashicons dashicons-list-view"></span> <?php echo esc_html($title); ?></h2>
        <?php endif; ?>

        <div class="mlr-glass-card mlr-filter-section">
            <div class="mlr-filter-form">
                <input type="text" id="mlr-search" class="mlr-glass-input" placeholder="کدملی، متقاضی، شماره موبایل، شناسه">
                <select id="mlr-status" class="mlr-glass-input">
                    <option value="">وضعیت درخواست</option>
                    <?php foreach ($ordered_statuses as $status): ?>
                        <option value="<?php echo esc_attr($status); ?>"><?php echo esc_html($status); ?></option>
                    <?php endforeach; ?>
                </select>
                <select id="mlr-settlement-status" class="mlr-glass-input">
                    <option value="">وضعیت تسویه</option>
                    <option value="منتظر تعیین تاریخ">منتظر تعیین تاریخ</option>
                    <option value="در انتظار تسویه">در انتظار تسویه</option>
                    <option value="تسویه شده">تسویه شده</option>
                </select>
                <input type="text" class="jalali-datepicker mlr-glass-input" id="mlr-date-from" placeholder="از تاریخ..." autocomplete="off" readonly>
                <input type="text" class="jalali-datepicker mlr-glass-input" id="mlr-date-to" placeholder="تا تاریخ..." autocomplete="off" readonly>
                <button type="button" id="mlr-filter-btn" class="mlr-btn mlr-btn-primary">فیلتر</button>
            </div>
        </div>

        <div class="mlr-glass-card mlr-table-section">
            <div class="mlr-table-responsive-wrapper">
                <table class="mlr-requests-table" id="mlr-requests-table">
                    <thead>
                        <tr>
                            <th>شناسه</th> <th>متقاضی</th> <th>شماره موبایل</th> <th>کد ملی</th>
                            <th>مبلغ (ریال)</th> <th>طرح</th> <th>وضعیت</th> <th>تسویه</th>
                            <th>تاریخ ثبت</th> <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody id="mlr-requests-table-body" class="mlr-requests-table-body">
                        <tr><td colspan="10" style="text-align: center; padding: 20px;">در حال بارگذاری درخواست‌ها...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
        
        <div class="mlr-modal-overlay" style="display:none;"></div>
        <div class="mlr-modal" style="display:none;">
            <button class="mlr-modal-close">&times;</button>
            <div class="mlr-modal-content"></div>
        </div>
    </div>
    <style>
        /* === START: Unified Design System Styles === */
        :root {
            --mlr-blue-dark: #1D3558;
            --mlr-blue-light: #D0E2F2;
            --mlr-gold: #eda900;
            --mlr-white-glass: rgba(255, 255, 255, 0.75);
            --mlr-white-glass-strong: rgba(255, 255, 255, 0.9);
            --mlr-border-glass: 1px solid rgba(255, 255, 255, 0.6);
            --mlr-shadow-soft: 0 10px 40px -10px rgba(29, 53, 88, 0.15);
            --mlr-radius-lg: 24px;
            --mlr-radius-md: 14px;
            --mlr-font-family: 'Vazirmatn', Tahoma, sans-serif;
        }

        .mlr-glass-dashboard {
            font-family: var(--mlr-font-family) !important;
            background: linear-gradient(135deg, #f0f5f9 0%, var(--mlr-blue-light) 100%) !important;
            border-radius: var(--mlr-radius-lg) !important;
            box-shadow: var(--mlr-shadow-soft) !important;
            padding: 30px !important;
            margin: 30px 0 !important;
            position: relative !important;
            overflow: hidden !important;
            color: var(--mlr-blue-dark) !important;
            direction: rtl !important;
        }

        .mlr-glass-blob { position: absolute; border-radius: 50%; filter: blur(80px); z-index: 0; }
        .blob-1 { width: 450px; height: 450px; background: var(--mlr-blue-light); top: -100px; left: -100px; opacity: 0.8; }
        .blob-2 { width: 350px; height: 350px; background: var(--mlr-gold); bottom: -80px; right: -80px; opacity: 0.15; }

        .mlr-dashboard-wrapper { position: relative; z-index: 1; }

        .mlr-dashboard-title {
            font-size: 24px !important;
            font-weight: 800 !important;
            color: var(--mlr-blue-dark) !important;
            margin-bottom: 25px !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .mlr-dashboard-title .dashicons { font-size: 28px; width: 28px; height: 28px; color: var(--mlr-gold); }

        .mlr-glass-card {
            background: var(--mlr-white-glass) !important;
            backdrop-filter: blur(12px) !important;
            -webkit-backdrop-filter: blur(12px) !important;
            border: var(--mlr-border-glass) !important;
            border-radius: var(--mlr-radius-md) !important;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.05) !important;
            padding: 25px !important;
            margin-bottom: 25px !important;
        }

        .mlr-filter-form { display: flex; flex-wrap: wrap; gap: 15px; }
        .mlr-glass-input {
            flex: 1;
            min-width: 150px;
            padding: 12px 15px !important;
            border: 1px solid rgba(29, 53, 88, 0.2) !important;
            border-radius: 10px !important;
            background: rgba(255,255,255,0.8) !important;
            color: var(--mlr-blue-dark) !important;
            font-family: var(--mlr-font-family) !important;
            transition: all 0.3s !important;
        }
        .mlr-glass-input:focus { background: #fff !important; border-color: var(--mlr-blue-dark) !important; outline: none !important; box-shadow: 0 0 0 3px rgba(29, 53, 88, 0.1) !important; }

        .mlr-btn {
            padding: 12px 25px !important;
            border-radius: 10px !important;
            border: none !important;
            cursor: pointer !important;
            font-weight: 700 !important;
            transition: all 0.3s !important;
            font-family: var(--mlr-font-family) !important;
        }
        .mlr-btn-primary { background: var(--mlr-blue-dark) !important; color: #fff !important; }
        .mlr-btn-primary:hover { background: var(--mlr-gold) !important; color: var(--mlr-blue-dark) !important; }

        .mlr-requests-table { width: 100%; border-collapse: collapse; }
        .mlr-requests-table th {
            background: rgba(208, 226, 242, 0.6) !important;
            color: var(--mlr-blue-dark) !important;
            font-weight: 700 !important;
            padding: 15px !important;
            text-align: right !important;
            border-bottom: 1px solid rgba(29, 53, 88, 0.1) !important;
        }
        .mlr-requests-table td {
            padding: 15px !important;
            border-bottom: 1px solid rgba(29, 53, 88, 0.05) !important;
            color: var(--mlr-blue-dark) !important;
        }
        .mlr-requests-table tr:last-child td { border-bottom: none !important; }
        .mlr-requests-table tr:hover td { background: rgba(208, 226, 242, 0.2) !important; }
    </style>


    <?php
    return ob_get_clean();
}

function mlr_jalali_to_gregorian($jalali_date_str) {
    if (empty($jalali_date_str)) return null;
    if (preg_match('/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/', $jalali_date_str, $matches)) {
        list($j_y, $j_m, $j_d) = array_map('intval', [$matches[1], $matches[2], $matches[3]]);
    } else { return null; }
    
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $jy = $j_y - 979; $jm = $j_m - 1; $jd = $j_d - 1;
    $j_day_no = 365 * $jy + floor($jy / 33) * 8 + floor((($jy % 33) + 3) / 4);
    for ($i = 0; $i < $jm; ++$i) { $j_day_no += $j_days_in_month[$i]; }
    $j_day_no += $jd; $g_day_no = $j_day_no + 79;
    $gy = 1600 + 400 * floor($g_day_no / 146097);
    $g_day_no = $g_day_no % 146097; $leap = true;
    if ($g_day_no >= 36525) { $g_day_no--; $gy += 100 * floor($g_day_no / 36524); $g_day_no = $g_day_no % 36524; if ($g_day_no >= 365) { $g_day_no++; } else { $leap = false; } }
    $gy += 4 * floor($g_day_no / 1461); $g_day_no %= 1461;
    if ($g_day_no >= 366) { $leap = false; $g_day_no--; $gy += floor($g_day_no / 365); $g_day_no = $g_day_no % 365; }
    for ($i = 0; $g_day_no >= $g_days_in_month[$i] + ($i == 1 && $leap); $i++) { $g_day_no -= $g_days_in_month[$i] + ($i == 1 && $leap); }
    $gm = $i + 1; $gd = $g_day_no + 1;
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

function mlr_gregorian_to_jalali($gregorian_date_str, $format = 'Y/m/d') {
    if (empty($gregorian_date_str) || $gregorian_date_str === '0000-00-00 00:00:00' || is_null($gregorian_date_str)) return '---';
    try {
        $g_date = new DateTime($gregorian_date_str, new DateTimeZone('Asia/Tehran'));
        $g_date->setTimezone(new DateTimeZone('Asia/Tehran')); // اطمینان از تبدیل به وقت ایران
        $g_y = (int)$g_date->format('Y'); $g_m = (int)$g_date->format('m'); $g_d = (int)$g_date->format('d');
    } catch (Exception $e) { return 'تاریخ نامعتبر'; }
    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    $gy = $g_y - 1600; $gm = $g_m - 1; $gd = $g_d - 1;
    $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);
    for ($i = 0; $i < $gm; ++$i) { $g_day_no += $g_days_in_month[$i]; }
    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0))) { $g_day_no++; }
    $g_day_no += $gd; $j_day_no = $g_day_no - 79; $j_np = floor($j_day_no / 12053);
    $j_day_no = $j_day_no % 12053; $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
    $j_day_no %= 1461; if ($j_day_no >= 366) { $jy += floor(($j_day_no - 1) / 365); $j_day_no = ($j_day_no - 1) % 365; }
    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) { $j_day_no -= $j_days_in_month[$i]; }
    $jm = $i + 1; $jd = $j_day_no + 1;
    $final_format = str_replace(['Y', 'm', 'd', 'H', 'i'], [sprintf('%04d', $jy), sprintf('%02d', $jm), sprintf('%02d', $jd), $g_date->format('H'), $g_date->format('i')], $format);
    return $final_format;
}

function mlr_get_all_document_options() {
    return [
        'national_card_front' => 'کارت ملی (رو)', 'national_card_back' => 'کارت ملی (پشت)', 'birth_certificate' => 'شناسنامه (تمام صفحات)',
        'payslip' => 'فیش حقوقی', 'employment_certificate' => 'گواهی اشتغال به کار', 'business_license' => 'جواز کسب',
        'sana_certificate' => 'گواهی ثبت ثنا', 'blank_check_image' => 'تصویر چک صیادی', 'residence_document' => 'سند یا اجاره‌نامه محل سکونت',
        'workplace_document' => 'سند یا اجاره‌نامه محل کار', 'account_statement' => 'گردش حساب ۳ ماهه', 'activity_license' => 'مجوز فعالیت (سایر)',
        'additional_documents' => 'مدارک تکمیلی', 'completed_check_files' => 'چک‌های تکمیل شده', 'signed_contract_files' => 'قرارداد امضا شده',
        'signed_invoice_files' => 'فاکتور امضا شده', 'other_completed_files' => 'سایر مدارک نهایی'
    ];
}

/**
 * Returns document category map for grouping uploaded documents in request details modals.
 * Keys are category slugs; values are arrays of document keys from required_documents.
 */
function mlr_get_document_category_map() {
    return [
        'identity' => [
            'national_card_front',
            'national_card_back',
            'birth_certificate',
            'sana_certificate',
        ],
        'job' => [
            'payslip',
            'employment_certificate',
            'business_license',
            'activity_license',
        ],
        'address' => [
            'residence_document',
            'workplace_document',
        ],
        'financial' => [
            'account_statement',
            'blank_check_image',
            'completed_check_files',
        ],
        'contracts' => [
            'signed_contract_files',
            'signed_invoice_files',
            'other_completed_files',
            'additional_documents',
        ],
    ];
}

/**
 * Groups uploaded documents by category.
 *
 * @param array $uploaded_documents
 * @param array $labels
 * @return array [category_slug => [ ['key'=>..., 'label'=>..., 'urls'=>[...]], ... ], ...]
 */
function mlr_group_uploaded_documents_by_category($uploaded_documents, $labels = []) {
    if (!is_array($uploaded_documents)) {
        return [];
    }

    $map = mlr_get_document_category_map();
    $cat_of = [];

    foreach ($map as $cat => $keys) {
        foreach ($keys as $k) {
            $cat_of[$k] = $cat;
        }
    }

    $grouped = [];

    foreach ($uploaded_documents as $doc_key => $doc_value) {
        if (empty($doc_value)) {
            continue;
        }

        $urls = [];
        if (is_array($doc_value)) {
            foreach ($doc_value as $u) {
                if (!empty($u) && is_string($u)) {
                    $urls[] = $u;
                }
            }
        } elseif (is_string($doc_value)) {
            $urls[] = $doc_value;
        }

        $urls = array_values(array_filter($urls));
        if (empty($urls)) {
            continue;
        }

        $cat = $cat_of[$doc_key] ?? 'other';
        $label = isset($labels[$doc_key]) ? $labels[$doc_key] : ucfirst(str_replace('_', ' ', (string)$doc_key));

        if (!isset($grouped[$cat])) {
            $grouped[$cat] = [];
        }

        $grouped[$cat][] = [
            'key' => $doc_key,
            'label' => $label,
            'urls' => $urls,
        ];
    }

    // Keep a stable category order
    $order = ['identity', 'job', 'address', 'financial', 'contracts', 'other'];
    $sorted = [];
    foreach ($order as $cat) {
        if (!empty($grouped[$cat])) {
            $sorted[$cat] = $grouped[$cat];
        }
    }

    return $sorted;
}

/**
 * Returns display labels for document categories.
 */
function mlr_get_document_category_labels() {
    return [
        'identity' => 'مدارک هویتی',
        'job' => 'مدارک شغلی',
        'address' => 'مدارک سکونت',
        'financial' => 'مدارک مالی و چک',
        'contracts' => 'قرارداد و مدارک نهایی',
        'other' => 'سایر',
    ];
}

function mlr_get_all_valid_statuses() {
    return ['در حال بررسی', 'نقص مدارک', 'رد شده', 'تأیید کارشناس', 'تکمیل مدارک', 'تأیید مدارک', 'اعطا شده'];
}

function mlr_get_calculation_labels() {
    return [
        'loanAmount' => ['label' => 'مبلغ تسهیلات', 'unit' => 'ریال'], 'installmentCount' => ['label' => 'تعداد اقساط', 'unit' => 'قسط'],
        'prepayment' => ['label' => 'پیش پرداخت', 'unit' => 'ریال'], 'totalPayment' => ['label' => 'مبلغ پرداخت نهایی', 'unit' => 'ریال'],
        'installmentAmount' => ['label' => 'مبلغ هر قسط', 'unit' => 'ریال'], 'profit' => ['label' => 'سود تسهیلات', 'unit' => 'ریال'],
        'operationCost' => ['label' => 'مبلغ هزینه عملیات', 'unit' => 'ریال'], 'walletCharge' => ['label' => 'مبلغ شارژ کیف پول', 'unit' => 'ریال'],
        'acceptorPayment' => ['label' => 'مبلغ واریزی برای پذیرنده', 'unit' => 'ریال'], 'guaranteeCheckPrincipal' => ['label' => 'مبلغ چک ضمانت (اصل)', 'unit' => 'ریال'],
        'guaranteeCheckTotal' => ['label' => 'مبلغ چک ضمانت (اصل و فرع)', 'unit' => 'ریال'], 'numberOfInstallments' => ['label' => 'تعداد قسط/چک', 'unit' => 'عدد'],
        'operationCostPercent' => ['label' => 'درصد هزینه عملیات', 'unit' => 'درصد'], 'operationCostWithVat' => ['label' => 'جمع هزینه عملیات + ارزش افزوده', 'unit' => 'ریال'],
        'netLeasingPayment' => ['label' => 'خالص واریزی لیزینگ', 'unit' => 'ریال'], 'acceptorCommission' => ['label' => 'کمیسیون پذیرنده', 'unit' => 'ریال'],
        'acceptorCommissionWithVat' => ['label' => 'کمیسیون پذیرنده + ارزش افزوده', 'unit' => 'ریال'],
    ];
}

/**
 * Returns a list of available placeholders for the INSTALLMENT CONTRACT.
 * Used in Admin Settings to show allowed variables.
 */
function mlr_get_installment_contract_placeholders() {
    return [
        '[request_id]'          => 'شناسه درخواست',
        '[full_name]'           => 'نام و نام خانوادگی',
        '[national_code]'       => 'کد ملی',
        '[mobile_number]'       => 'شماره موبایل',
        '[phone_number]'        => 'تلفن ثابت',
        '[father_name]'         => 'نام پدر',
        '[certificate_number]'  => 'شماره شناسنامه',
        '[certificate_city]'    => 'شهر صدور شناسنامه',
        '[birth_date]'          => 'تاریخ تولد',
        '[occupation]'          => 'شغل',
        '[residential_address]' => 'آدرس منزل',
        '[work_address]'        => 'آدرس محل کار',
        '[postal_code]'         => 'کد پستی',
        '[plan_name]'           => 'نام طرح',
        '[loan_amount]'         => 'مبلغ تسهیلات (ریال)',
        '[total_payment]'       => 'مبلغ پرداخت نهایی (ریال)',
        '[prepayment]'          => 'مبلغ پیش پرداخت (ریال)',
        '[installment_amount]'  => 'مبلغ هر قسط (ریال)',
        '[installment_count]'   => 'تعداد اقساط',
        '[guarantee_check_principal]' => 'مبلغ چک ضمانت (اصل)',
        '[guarantee_check_total]'     => 'مبلغ چک ضمانت (اصل و فرع)',
        '[product_name]'        => 'نام کالا/محصول',
        '[contract_date]'       => 'تاریخ عقد قرارداد',
        '[created_at]'          => 'تاریخ ثبت درخواست',
    ];
}

/**
 * Returns a list of available placeholders for the CONTRACT (Distinct from SMS placeholders).
 */
function mlr_get_contract_placeholders() {
    return [
        '{{request_id}}' => 'شناسه درخواست',
        '{{request_type}}' => 'نوع درخواست (حقیقی/حقوقی)',
        '{{status}}' => 'وضعیت',
        '{{created_at}}' => 'تاریخ ثبت درخواست',
        '{{contract_signed_date}}' => 'تاریخ امضای قرارداد',
        '{{contract_expiry_date}}' => 'تاریخ انقضای قرارداد',
        // Fields from JSON data
        '{{store_name}}' => 'نام فروشگاه',
        '{{company_name}}' => 'نام شرکت',
        '{{store_owner_name}}' => 'نام مالک فروشگاه',
        '{{contact_person}}' => 'نام رابط',
        '{{activity_field}}' => 'زمینه فعالیت',
        '{{store_address}}' => 'آدرس فروشگاه',
        '{{company_address}}' => 'آدرس شرکت',
        '{{postal_code}}' => 'کد پستی',
        '{{mobile_number}}' => 'شماره همراه',
        '{{phone_number}}' => 'تلفن ثابت',
        '{{email}}' => 'ایمیل',
        '{{website}}' => 'وب‌سایت',
        '{{description}}' => 'توضیحات',
        '{{shaba_number}}' => 'شماره شبا', 
        '{{applicant_id_number}}' => 'کد ملی / شناسه ملی',
    ];
}

/**
 * Replaces placeholders in the contract text with actual data.
 * Uses {{...}} format to avoid conflict with SMS [[...]] format.
 */
function mlr_replace_contract_placeholders($content, $request) {
    if (empty($content)) return '';

    // Decode JSON data from the request
    $data = [];
    if (!empty($request->data)) {
        $data = json_decode($request->data, true);
    }
    if (!is_array($data)) $data = [];

    // Prepare replacements
    $replacements = [
        '{{request_id}}' => $request->id,
        '{{request_type}}' => ($request->request_type === 'real' || $request->request_type === 'individual') ? 'حقیقی' : 'حقوقی',
        '{{status}}' => $request->status,
        '{{created_at}}' => isset($request->created_at) ? mlr_gregorian_to_jalali($request->created_at) : '---',
        
        '{{store_name}}' => $data['store_name'] ?? '',
        '{{company_name}}' => $data['company_name'] ?? '',
        '{{store_owner_name}}' => $data['store_owner_name'] ?? '',
        '{{contact_person}}' => $data['contact_person'] ?? '',
        '{{activity_field}}' => $data['activity_field'] ?? '',
        '{{store_address}}' => $data['store_address'] ?? '',
        '{{company_address}}' => $data['company_address'] ?? '',
        '{{postal_code}}' => $data['postal_code'] ?? '',
        '{{mobile_number}}' => $data['mobile_number'] ?? '',
        '{{phone_number}}' => $data['phone_number'] ?? '',
        '{{email}}' => $data['email'] ?? '',
        '{{website}}' => $data['website'] ?? '',
        '{{description}}' => $data['description'] ?? '',
        '{{shaba_number}}' => $data['shaba_number'] ?? '',
        // Map applicant_id_number
        '{{applicant_id_number}}' => !empty($data['applicant_id_number']) ? $data['applicant_id_number'] : (!empty($data['national_code']) ? $data['national_code'] : ($data['national_id'] ?? '')),
    ];

    // Handle contract dates
    if (isset($request->contract_signed_at)) {
         $replacements['{{contract_signed_date}}'] = mlr_gregorian_to_jalali($request->contract_signed_at, 'Y/m/d');
    } else {
         $replacements['{{contract_signed_date}}'] = '---';
    }
    
    if (isset($request->contract_expires_at)) {
         $replacements['{{contract_expiry_date}}'] = mlr_gregorian_to_jalali($request->contract_expires_at, 'Y/m/d');
    } else {
         $replacements['{{contract_expiry_date}}'] = '---';
    }

    return str_replace(array_keys($replacements), array_values($replacements), $content);
}

if (!function_exists('mlr_validate_uploaded_file')) {
    function mlr_validate_uploaded_file($file, &$error_message = '') {
        if (empty($file) || !isset($file['name'], $file['tmp_name'], $file['error'])) {
            $error_message = 'Invalid upload data.';
            return false;
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $error_message = 'Upload error.';
            return false;
        }

        // Sanitize filename
        $file['name'] = sanitize_file_name($file['name']);

        if (!is_uploaded_file($file['tmp_name'])) {
            $error_message = 'Invalid uploaded file.';
            return false;
        }

        $allowed_mimes = [
            'jpg|jpeg' => 'image/jpeg',
            'png'      => 'image/png',
            'pdf'      => 'application/pdf',
        ];

        $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], $allowed_mimes);
        $ext   = isset($check['ext']) ? strtolower($check['ext']) : '';
        $type  = isset($check['type']) ? strtolower($check['type']) : '';

        if (empty($ext) || empty($type)) {
            $error_message = 'File type not allowed.';
            return false;
        }

        // Explicit extension whitelist
        if (!in_array($ext, ['jpg','jpeg','png','pdf'], true)) {
            $error_message = 'File extension not allowed.';
            return false;
        }

        // Ensure mime matches allowed set
        if (!in_array($type, array_values($allowed_mimes), true)) {
            $error_message = 'File mime type not allowed.';
            return false;
        }

        return $file;
    }
}

if (!function_exists('mlr_handle_wp_upload')) {
    /**
     * Handles the upload of a single file using wp_handle_upload.
     *
     * @param array $file_data The file data from $_FILES array (e.g., $_FILES['my_file']).
     * @param array $overrides Optional. An array of overrides for wp_handle_upload.
     * @return string|WP_Error The URL of the uploaded file on success, or a WP_Error object on failure.
     */
    function mlr_handle_wp_upload($file_data, $overrides = []) {
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }

        if (empty($file_data) || $file_data['error'] === UPLOAD_ERR_NO_FILE) {
            return new WP_Error('no_file', 'فایلی برای آپلود انتخاب نشده است.');
        }

        if ($file_data['error'] !== UPLOAD_ERR_OK) {
            return new WP_Error('upload_error', 'خطای آپلود فایل (کد: ' . $file_data['error'] . ')');
        }

        $default_overrides = [
            'test_form' => false,
            'mimes' => ['jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf'],
        ];
        $final_overrides = array_merge($default_overrides, $overrides);

        $movefile = wp_handle_upload($file_data, $final_overrides);

        return ($movefile && !isset($movefile['error'])) ? $movefile['url'] : new WP_Error('wp_handle_upload_error', $movefile['error'] ?? 'خطای نامشخص در هنگام آپلود فایل.');
    }
}


// --- START: Request Events & Messages Helpers ---
if (!function_exists('mlr_verify_any_nonce')) {
    function mlr_verify_any_nonce($nonce_field = 'nonce') {
        $nonce = isset($_REQUEST[$nonce_field]) ? sanitize_text_field(wp_unslash($_REQUEST[$nonce_field])) : '';
        if (empty($nonce)) {
            return false;
        }
        // Try frontend nonce
        if (wp_verify_nonce($nonce, 'mlr_frontend_nonce')) return true;
        // Try admin nonce(s)
        if (wp_verify_nonce($nonce, 'mlr_ajax_nonce_action')) return true;
        if (wp_verify_nonce($nonce, 'mlr_ajax_nonce')) return true;
        if (wp_verify_nonce($nonce, 'mlr_user_requests_nonce')) return true;
        return false;
    }
}

if (!function_exists('mlr_get_current_user_role_slug')) {
    function mlr_get_current_user_role_slug() {
        if (!is_user_logged_in()) return '';
        $u = wp_get_current_user();
        $roles = (array) $u->roles;
        return !empty($roles) ? sanitize_key($roles[0]) : '';
    }
}

if (!function_exists('mlr_can_access_loan_request')) {
    function mlr_can_access_loan_request($request_row) {
        if (!$request_row) return false;
        if (!is_user_logged_in()) return false;

        $current_user = wp_get_current_user();
        $uid = $current_user->ID;
        $is_admin = current_user_can('manage_options');
        if ($is_admin) return true;

        $is_bank = in_array('bank', (array) $current_user->roles, true);
        if ($is_bank) {
            return (intval($request_row->assigned_bank_user_id) === intval($uid));
        }

        return (intval($request_row->user_id) === intval($uid));
    }
}

if (!function_exists('mlr_add_request_event')) {
    function mlr_add_request_event($request_id, $event_type, $details = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'mlr_request_events';

        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $role = is_user_logged_in() ? mlr_get_current_user_role_slug() : '';

        $wpdb->insert($table, [
            'request_id' => absint($request_id),
            'user_id'    => $user_id ? absint($user_id) : null,
            'user_role'  => $role,
            'event_type' => sanitize_text_field($event_type),
            'details'    => is_scalar($details) ? wp_kses_post((string)$details) : wp_json_encode($details, JSON_UNESCAPED_UNICODE),
            'created_at' => current_time('mysql'),
        ], [
            '%d','%d','%s','%s','%s','%s'
        ]);
    }
}

if (!function_exists('mlr_get_request_events')) {
    function mlr_get_request_events($request_id, $limit = 200) {
        global $wpdb;
        $table = $wpdb->prefix . 'mlr_request_events';
        $limit = max(1, min(500, intval($limit)));
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE request_id = %d ORDER BY id ASC LIMIT %d", absint($request_id), $limit));
    }
}

if (!function_exists('mlr_add_request_message')) {
    function mlr_add_request_message($request_id, $message) {
        global $wpdb;
        $table = $wpdb->prefix . 'mlr_request_messages';

        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        $role = is_user_logged_in() ? mlr_get_current_user_role_slug() : '';

        $wpdb->insert($table, [
            'request_id' => absint($request_id),
            'user_id'    => $user_id ? absint($user_id) : null,
            'user_role'  => $role,
            'message'    => wp_kses_post((string)$message),
            'created_at' => current_time('mysql'),
        ], ['%d','%d','%s','%s','%s']);

        return $wpdb->insert_id ? intval($wpdb->insert_id) : 0;
    }
}

if (!function_exists('mlr_get_request_messages')) {
    function mlr_get_request_messages($request_id, $limit = 500) {
        global $wpdb;
        $table = $wpdb->prefix . 'mlr_request_messages';
        $limit = max(1, min(1000, intval($limit)));
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE request_id = %d ORDER BY id ASC LIMIT %d", absint($request_id), $limit));
    }
}

if (!function_exists('mlr_render_request_messages_html')) {
    function mlr_render_request_messages_html($messages) {
        if (!is_array($messages) || empty($messages)) {
            return '<p style="text-align:center;color:#999;padding:10px;">پیامی وجود ندارد.</p>';
        }
        $out = '';
        foreach ($messages as $msg) {
            $author = 'کاربر';
            if (!empty($msg->user_id)) {
                $u = get_user_by('id', intval($msg->user_id));
                if ($u) {
                    $author = $u->display_name;
                }
            }
            $role = !empty($msg->user_role) ? esc_html($msg->user_role) : '';
            $date = !empty($msg->created_at) ? $msg->created_at : '';
            if (function_exists('mlr_gregorian_to_jalali') && !empty($date)) {
                $date = mlr_gregorian_to_jalali($date, 'Y/m/d H:i');
            }
            $out .= '<div class="mlr-comment-bubble mlr-message-bubble">';
            $out .= '<div class="mlr-comment-header">';
            $out .= '<strong class="mlr-comment-author">' . esc_html($author) . ($role ? ' <span style="opacity:.7;font-size:12px">(' . $role . ')</span>' : '') . '</strong>';
            $out .= '<span class="mlr-comment-date">' . esc_html($date) . '</span>';
            $out .= '</div>';
            $out .= '<div class="mlr-comment-body">' . wpautop(wp_kses_post($msg->message)) . '</div>';
            $out .= '</div>';
        }
        return $out;
    }
}

if (!function_exists('mlr_render_request_conversation_html')) {
    function mlr_render_request_conversation_html($comments, $messages) {
        $timeline = [];

        if (is_array($comments) && !empty($comments)) {
            foreach ($comments as $c) {
                if (!is_array($c)) { continue; }
                $ts_raw = isset($c['timestamp']) ? (string)$c['timestamp'] : '';
                $ts = $ts_raw ? strtotime($ts_raw) : 0;
                $timeline[] = [
                    'type' => 'note',
                    'ts' => $ts ?: 0,
                    'ts_raw' => $ts_raw,
                    'author' => isset($c['display_name']) ? (string)$c['display_name'] : 'کاربر',
                    'role' => 'note',
                    'message' => isset($c['text']) ? (string)$c['text'] : '',
                ];
            }
        }

        if (is_array($messages) && !empty($messages)) {
            foreach ($messages as $m) {
                if (!is_object($m)) { continue; }
                $author = 'کاربر';
                if (!empty($m->user_id)) {
                    $u = get_user_by('id', intval($m->user_id));
                    if ($u) { $author = $u->display_name; }
                }
                $ts_raw = !empty($m->created_at) ? (string)$m->created_at : '';
                $ts = $ts_raw ? strtotime($ts_raw) : 0;
                $timeline[] = [
                    'type' => 'message',
                    'ts' => $ts ?: 0,
                    'ts_raw' => $ts_raw,
                    'author' => $author,
                    'role' => !empty($m->user_role) ? (string)$m->user_role : '',
                    'message' => !empty($m->message) ? (string)$m->message : '',
                ];
            }
        }

        if (empty($timeline)) {
            return '<p style="text-align:center;color:#999;padding:10px;">گفتگویی وجود ندارد.</p>';
        }

        usort($timeline, function($a, $b){
            $at = isset($a['ts']) ? intval($a['ts']) : 0;
            $bt = isset($b['ts']) ? intval($b['ts']) : 0;
            if ($at === $bt) { return 0; }
            return ($at < $bt) ? -1 : 1;
        });

        $out = '';
        foreach ($timeline as $item) {
            $date = !empty($item['ts_raw']) ? $item['ts_raw'] : '';
            if (function_exists('mlr_gregorian_to_jalali') && !empty($date)) {
                $date = mlr_gregorian_to_jalali($date, 'Y/m/d H:i');
            }
            $badge = ($item['type'] === 'note') ? 'یادداشت' : 'پیام';
            $badge_class = ($item['type'] === 'note') ? 'mlr-conv-badge-note' : 'mlr-conv-badge-message';

            $out .= '<div class="mlr-comment-bubble mlr-conv-bubble mlr-conv-type-' . esc_attr($item['type']) . '">';
            $out .= '<div class="mlr-comment-header">';
            $out .= '<strong class="mlr-comment-author">' . esc_html($item['author']) . '</strong>';
            $out .= '<span class="mlr-comment-date">' . esc_html($date) . '</span>';
            $out .= '</div>';
            $out .= '<div class="mlr-conv-meta"><span class="mlr-conv-badge ' . esc_attr($badge_class) . '">' . esc_html($badge) . '</span>';
            if (!empty($item['role']) && $item['type'] !== 'note') {
                $out .= ' <span class="mlr-conv-role">(' . esc_html($item['role']) . ')</span>';
            }
            $out .= '</div>';
            if ($item['type'] === 'note') {
                $out .= '<div class="mlr-comment-body">' . nl2br(esc_html($item['message'])) . '</div>';
            } else {
                $out .= '<div class="mlr-comment-body">' . wpautop(wp_kses_post($item['message'])) . '</div>';
            }
            $out .= '</div>';
        }

        return $out;
    }
}


if (!function_exists('mlr_render_request_events_html')) {
    function mlr_render_request_events_html($events) {
        if (!is_array($events) || empty($events)) {
            return '<p style="text-align:center;color:#999;padding:10px;">رویدادی ثبت نشده است.</p>';
        }
        $out = '<ul class="mlr-events-timeline" style="margin:0;padding:0 18px;">';
        foreach ($events as $ev) {
            $date = !empty($ev->created_at) ? $ev->created_at : '';
            if (function_exists('mlr_gregorian_to_jalali') && !empty($date)) {
                $date = mlr_gregorian_to_jalali($date, 'Y/m/d H:i');
            }
            $desc = !empty($ev->description) ? $ev->description : '';
            $out .= '<li style="margin:6px 0;line-height:1.8;">';
            $out .= '<span style="opacity:.7;font-size:12px;">' . esc_html($date) . '</span> — ';
            $out .= esc_html($desc);
            $out .= '</li>';
        }
        $out .= '</ul>';
        return $out;
    }
}

// --- END: Request Events & Messages Helpers ---


// --- START: Human-friendly labels for keys (Frontend/Admin popups) ---
if (!function_exists('mlr_get_field_label')) {
    function mlr_get_field_label($key) {
        $key = (string) $key;

        $map = [
            'bank_validation_file' => 'فایل اعتبارسنجی بانک',
            'signature_image'      => 'تصویر امضا',
            'contract_file'        => 'فایل قرارداد',
            'check_images'         => 'تصاویر چک',
            'required_documents'   => 'مدارک مورد نیاز',
            'order_items'          => 'اقلام سفارش',
            'order_total'          => 'مبلغ سفارش',
            'product_name'         => 'نام کالا/خدمت',
            'full_name'            => 'نام کامل',
            'national_code'        => 'کد ملی',
            'mobile_number'        => 'شماره موبایل',
            'phone_number'         => 'تلفن ثابت',
            'birth_date'           => 'تاریخ تولد',
            'occupation'           => 'شغل',
            'residential_address'  => 'آدرس سکونت',
            'work_address'         => 'آدرس محل کار',
            'postal_code'          => 'کد پستی',
            'loan_amount'          => 'مبلغ وام',
            'installment_amount'   => 'مبلغ هر قسط',
            'installment_count'    => 'تعداد اقساط',
            'installment_interval' => 'بازه پرداخت اقساط',
            'prepayment'           => 'پیش‌پرداخت',
            'total_payment'        => 'مجموع پرداخت',
            'wallet_charge'        => 'شارژ کیف پول',
            'profit'               => 'سود',
            'acceptor_payment_amount' => 'مبلغ پرداخت پذیرنده',
            'final_settlement_amount' => 'مبلغ تسویه نهایی',
            'status'               => 'وضعیت',
            'created_at'           => 'تاریخ ثبت',
            'updated_at'           => 'تاریخ بروزرسانی',
        ];

        if (isset($map[$key])) {
            return $map[$key];
        }

        // Fallback: humanize snake_case to readable Persian-ish label (keeps English if unknown)
        $label = str_replace(['_', '-'], ' ', $key);
        $label = preg_replace('/\s+/', ' ', $label);
        $label = trim($label);

        $token_map = [
            'id' => 'شناسه',
            'front' => 'رو',
            'back' => 'پشت',
            'image' => 'تصویر',
            'file' => 'فایل',
            'doc' => 'مدرک',
            'documents' => 'مدارک',
            'address' => 'آدرس',
            'number' => 'شماره',
            'mobile' => 'موبایل',
            'phone' => 'تلفن',
            'national' => 'ملی',
            'code' => 'کد',
            'bank' => 'بانک',
            'contract' => 'قرارداد',
            'signature' => 'امضا',
            'check' => 'چک',
        ];

        $parts = explode(' ', strtolower($label));
        $out_parts = [];
        foreach ($parts as $p) {
            if ($p === '') continue;
            $out_parts[] = isset($token_map[$p]) ? $token_map[$p] : $p;
        }

        $final = trim(implode(' ', $out_parts));
        return $final !== '' ? $final : $key;
    }
}
// --- END: Human-friendly labels for keys ---

// ===================================================================
// ICS24 CREDIT VALIDATION API INTEGRATION (MOVED HERE TO FIX 400 ERROR)
// ===================================================================

if (!defined('MLR_ICS24_USERNAME')) define('MLR_ICS24_USERNAME', 'babanoellhiva');
if (!defined('MLR_ICS24_PASSWORD')) define('MLR_ICS24_PASSWORD', '16534vgdfr$58213DsJ5');
if (!defined('MLR_ICS24_BASE_URL')) define('MLR_ICS24_BASE_URL', 'https://app.ics24.ir');
if (!defined('MLR_ICS24_VERSION')) define('MLR_ICS24_VERSION', '2.0');

if (!function_exists('mlr_ics24_call_api')) {
    function mlr_ics24_call_api($endpoint, $method = 'POST', $data = [], $token_data = null) {
        $url = MLR_ICS24_BASE_URL . $endpoint;
        
        $headers = [
            'x-version: ' . MLR_ICS24_VERSION
        ];

        if ($token_data) {
            $headers[] = 'Authorization: Bearer ' . $token_data['accessToken'];
            $headers[] = 'x-apikey: ' . $token_data['apiKey'];
        }

        if ($method === 'POST') {
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        } else {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        // حذف کاراکترهای اضافی احتمالی (BOM یا whitespace)
        $response = trim($response);
        
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return new WP_Error('curl_error', 'خطای ارتباط (Curl): ' . $curl_error);
        }

        $result = json_decode($response, true);
        
        if ($http_code !== 200) {
            error_log("ICS24 API Error [$endpoint] ($http_code): " . $response);
        }

        return ['code' => $http_code, 'data' => $result, 'raw' => $response];
    }
}

if (!function_exists('mlr_ics24_get_token')) {
    function mlr_ics24_get_token() {
        $token_data = get_transient('mlr_ics24_token');
        if ($token_data && is_array($token_data)) {
            return $token_data;
        }

        $response = mlr_ics24_call_api('/Connect/Token', 'POST', [
            'Username' => MLR_ICS24_USERNAME,
            'Password' => MLR_ICS24_PASSWORD
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $data = $response['data'];
        if ($response['code'] == 200 && isset($data['hasError']) && $data['hasError'] === false && isset($data['data']['accessToken'])) {
            $token_info = ['accessToken' => $data['data']['accessToken'], 'apiKey' => $data['data']['apiKey']];
            set_transient('mlr_ics24_token', $token_info, 20 * MINUTE_IN_SECONDS);
            return $token_info;
        }
        
        $error_msg = 'خطای ناشناخته در دریافت توکن';
        if (isset($data['message'])) $error_msg = $data['message'];
        elseif (isset($data['Message'])) $error_msg = $data['Message'];
        elseif (isset($data['error_description'])) $error_msg = $data['error_description'];
        
        return new WP_Error('api_error', "خطای API ({$response['code']}): " . $error_msg);
    }
}

if (!function_exists('mlr_convert_dates_recursive')) {
    function mlr_convert_dates_recursive($data) {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = mlr_convert_dates_recursive($value);
            }
        } elseif (is_string($data)) {
            // تشخیص فرمت تاریخ میلادی (شروع با 19 یا 20)
            if (preg_match('/^(19|20)\d{2}-\d{2}-\d{2}/', $data)) {
                $format = (strpos($data, 'T') !== false || strpos($data, ':') !== false) ? 'Y/m/d H:i:s' : 'Y/m/d';
                $converted = mlr_gregorian_to_jalali($data, $format);
                if ($converted && $converted !== 'تاریخ نامعتبر') {
                    return $converted;
                }
            }
        }
        return $data;
    }
}

add_action('wp_ajax_mlr_credit_request_otp', 'mlr_credit_request_otp_callback');
add_action('wp_ajax_nopriv_mlr_credit_request_otp', 'mlr_credit_request_otp_callback');

function mlr_credit_request_otp_callback() {
    // پاکسازی بافر خروجی برای جلوگیری از خطای JSON
    if (ob_get_length()) ob_clean();
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    $national_code = sanitize_text_field($_POST['national_code'] ?? '');
    $mobile = sanitize_text_field($_POST['mobile'] ?? '');

    if (empty($national_code) || empty($mobile)) wp_send_json_error(['message' => 'کد ملی و شماره موبایل الزامی است.']);

    $token_data = mlr_ics24_get_token();
    if (is_wp_error($token_data)) {
        wp_send_json_error(['message' => $token_data->get_error_message()]);
    }
    if (!$token_data) wp_send_json_error(['message' => 'خطا در دریافت توکن اعتبارسنجی.']);

    $response = mlr_ics24_call_api('/b2b/api/request', 'POST', [
        'RealPersonNationalCode' => $national_code, 
        'MobileNumber' => $mobile
    ], $token_data);

    if (is_wp_error($response)) wp_send_json_error(['message' => 'خطا در ارسال درخواست.']);

    $result = $response['data'];
    if (isset($result['hasError']) && $result['hasError'] === false && isset($result['data'])) {
        wp_send_json_success(['hash_code' => $result['data'], 'message' => 'کد تایید پیامک شد.']);
    } else {
        $msg = isset($result['Messages'][0]['Message']) ? $result['Messages'][0]['Message'] : 'خطای ناشناخته در سرویس.';
        wp_send_json_error(['message' => $msg]);
    }
}

add_action('wp_ajax_mlr_credit_verify_otp', 'mlr_credit_verify_otp_callback');
add_action('wp_ajax_nopriv_mlr_credit_verify_otp', 'mlr_credit_verify_otp_callback');

function mlr_credit_verify_otp_callback() {
    // پاکسازی بافر خروجی
    if (ob_get_length()) ob_clean();
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    $hash_code = sanitize_text_field($_POST['hash_code'] ?? '');
    $otp = sanitize_text_field($_POST['otp'] ?? '');

    if (empty($hash_code) || empty($otp)) wp_send_json_error(['message' => 'اطلاعات ناقص است.']);

    $token_data = mlr_ics24_get_token();
    if (is_wp_error($token_data)) {
        wp_send_json_error(['message' => $token_data->get_error_message()]);
    }
    if (!$token_data) wp_send_json_error(['message' => 'خطا در دریافت توکن سرویس.']);

    $response = mlr_ics24_call_api('/b2b/api/request/' . $hash_code . '/validate', 'POST', [
        'Token' => $otp
    ], $token_data);

    if (is_wp_error($response)) wp_send_json_error(['message' => 'خطا در اعتبارسنجی کد.']);

    $result = $response['data'];
    if (isset($result['hasError']) && $result['hasError'] === false) {
        wp_send_json_success(['message' => 'کد تایید شد. در حال دریافت گزارش...']);
    } else {
        $msg = isset($result['Messages'][0]['Message']) ? $result['Messages'][0]['Message'] : 'کد اشتباه است.';
        wp_send_json_error(['message' => $msg]);
    }
}

add_action('wp_ajax_mlr_credit_check_status', 'mlr_credit_check_status_callback');
add_action('wp_ajax_nopriv_mlr_credit_check_status', 'mlr_credit_check_status_callback');

function mlr_credit_check_status_callback() {
    // پاکسازی بافر خروجی
    if (ob_get_length()) ob_clean();
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    $hash_code = sanitize_text_field($_POST['hash_code'] ?? '');
    if (empty($hash_code)) wp_send_json_error();

    $token_data = mlr_ics24_get_token();
    if (is_wp_error($token_data)) {
        wp_send_json_error(['message' => $token_data->get_error_message()]);
    }
    if (!$token_data) wp_send_json_error(['message' => 'Token Error']);

    $response = mlr_ics24_call_api('/B2B/api/request/' . $hash_code . '/status', 'GET', [], $token_data);
    if (is_wp_error($response)) wp_send_json_error(['message' => 'Connection Error']);

    $result = $response['data'];
    if (isset($result['hasError']) && $result['hasError'] === false && isset($result['data'])) {
        $status = $result['data']['status'] ?? '';
        $reportLink = $result['data']['reportLink'] ?? '';
        $statusTitle = $result['data']['statusTitle'] ?? 'در حال پردازش...';
        
        // لاگ وضعیت برای عیب‌یابی در سرور
        error_log("MLR Credit Check Status: $status - $statusTitle");

        if ($status === 'ReportGenerated') {
            if (!empty($reportLink)) {
                $reportCode = basename($reportLink);
                $reportData = mlr_ics24_get_report_json($reportCode, $token_data);
                if ($reportData) {
                    $reportData = mlr_convert_dates_recursive($reportData); // تبدیل تمام تاریخ‌ها به شمسی
                    wp_send_json_success(['status' => 'ready', 'data' => $reportData]);
                } else {
                    wp_send_json_error(['message' => 'خطا در دریافت جزئیات گزارش.']);
                }
            } else {
                // اگر گزارش تولید شده اما لینک ندارد، خطا ندهیم و منتظر بمانیم یا خطا برگردانیم
                wp_send_json_error(['message' => 'گزارش تولید شد اما لینک دانلود دریافت نشد.']);
            }
        } elseif ($status === 'ReportGenerationFailed' || $status === 'ReportGeneratedButDataLost') {
            wp_send_json_error(['message' => $statusTitle]);
        } else {
            // ارسال وضعیت خام برای دیباگ در کنسول مرورگر
            wp_send_json_success(['status' => 'pending', 'message' => $statusTitle, 'api_status' => $status]);
        }
    } else {
        wp_send_json_error(['message' => 'خطا در بررسی وضعیت.']);
    }
}

if (!function_exists('mlr_ics24_get_report_json')) {
    function mlr_ics24_get_report_json($reportCode, $token_data) {
        $response = mlr_ics24_call_api('/report/' . $reportCode . '/json', 'GET', [], $token_data);
        if (is_wp_error($response)) return false;
        
        $result = $response['data'];
        if (isset($result['hasError']) && $result['hasError'] === false && isset($result['data'])) {
            return $result['data'];
        }
        return false;
    }
}

if (!function_exists('mlr_normalize_status')) {
    function mlr_normalize_status($status) {
        if (!is_string($status)) {
            return '';
        }
        $status = trim($status);

        // Normalize Arabic characters to Persian equivalents
        $status = str_replace(['ي', 'ك'], ['ی', 'ک'], $status);

        // Normalize different Alef variants (e.g., تأیید / تایید)
        $status = str_replace(['أ', 'إ', 'آ'], 'ا', $status);

        // Collapse extra whitespace
        $status = preg_replace('/\s+/u', ' ', $status);

        return $status;
    }
}

if (!function_exists('mlr_generate_excel_export')) {
    /**
     * Generates an Excel export (HTML Table format) for a list of requests.
     * Supports RTL and UTF-8 natively without external libraries.
     */
    function mlr_generate_excel_export($requests) {
        $filename = 'loan-requests-' . date('Y-m-d-H-i') . '.xls';
        
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        echo '<head>';
        echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
        echo '<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Requests</x:Name><x:WorksheetOptions><x:DisplayRightToLeft/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->';
        echo '<style>
            body { font-family: Tahoma, Arial, sans-serif; direction: rtl; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #000; padding: 5px; text-align: center; vertical-align: middle; }
            th { background-color: #f0f0f0; font-weight: bold; }
            .text-cell { mso-number-format:"\@"; }
        </style>';
        echo '</head>';
        echo '<body>';
        echo '<table>';
        echo '<thead><tr>';
        echo '<th>شناسه</th>';
        echo '<th>پذیرنده</th>';
        echo '<th>نام متقاضی</th>';
        echo '<th>کد ملی</th>';
        echo '<th>شماره موبایل</th>';
        echo '<th>مبلغ وام (ریال)</th>';
        echo '<th>تعداد اقساط</th>';
        echo '<th>نام طرح</th>';
        echo '<th>وضعیت</th>';
        echo '<th>تاریخ ثبت</th>';
        echo '</tr></thead>';
        echo '<tbody>';

        foreach ($requests as $req) {
            $created_at = function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($req->created_at, 'Y/m/d H:i') : $req->created_at;
            $plan_name = isset($req->plan_name) ? $req->plan_name : '---';
            $display_name = isset($req->display_name) ? $req->display_name : '---';

            echo '<tr>';
            echo '<td>' . $req->id . '</td>';
            echo '<td>' . esc_html($display_name) . '</td>';
            echo '<td>' . esc_html($req->full_name) . '</td>';
            echo '<td class="text-cell">' . esc_html($req->national_code) . '</td>';
            echo '<td class="text-cell">' . esc_html($req->mobile_number) . '</td>';
            echo '<td>' . number_format($req->loan_amount) . '</td>';
            echo '<td>' . esc_html($req->installment_count) . '</td>';
            echo '<td>' . esc_html($plan_name) . '</td>';
            echo '<td>' . esc_html($req->status) . '</td>';
            echo '<td class="text-cell">' . esc_html($created_at) . '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '</body>';
        echo '</html>';
    }
}

add_action('admin_init', 'mlr_process_excel_export');

function mlr_process_excel_export() {
    if (!isset($_GET['export_excel']) || $_GET['export_excel'] != '1') {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $users_table = $wpdb->prefix . 'users';
    $plans_table = $wpdb->prefix . 'installment_plans';

    $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';

    // مدیریت خروجی برای صفحات لیست درخواست‌ها
    if (in_array($page, ['mlr-loan-requests', 'mlr-granted-requests', 'mlr-settled-requests'])) {
        
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        $status_from_url = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : '';
        $date_from_jalali = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
        $date_to_jalali = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';

        $date_from_gregorian = !empty($date_from_jalali) ? mlr_jalali_to_gregorian($date_from_jalali) : '';
        $date_to_gregorian = !empty($date_to_jalali) ? mlr_jalali_to_gregorian($date_to_jalali) : '';

        $where_clauses = ["1=1"];
        $prepare_params = [];

        if (!empty($search)) {
             $search_like = '%' . $wpdb->esc_like($search) . '%';
             $where_clauses[] = "(r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s)";
             $prepare_params[] = $search_like;
             $prepare_params[] = $search_like;
             $prepare_params[] = $search_like;
             if(is_numeric($search)){
                 $where_clauses[count($where_clauses)-1] = substr($where_clauses[count($where_clauses)-1], 0, -1);
                 $where_clauses[count($where_clauses)-1] .= " OR r.id = %d)";
                 $prepare_params[] = intval($search);
             }
        }
        
        if (!empty($status_from_url)) {
             $where_clauses[] = "r.status = %s";
             $prepare_params[] = $status_from_url;
        }
        if (!empty($date_from_gregorian)) {
            $where_clauses[] = "r.created_at >= %s";
            $prepare_params[] = $date_from_gregorian . ' 00:00:00';
        }
        if (!empty($date_to_gregorian)) {
            $where_clauses[] = "r.created_at <= %s";
            $prepare_params[] = $date_to_gregorian . ' 23:59:59';
        }

        $sql_where = "WHERE " . implode(' AND ', $where_clauses);
        
        $export_query = "SELECT r.*, u.display_name, p.name as plan_name
                       FROM $table_requests r
                       LEFT JOIN $users_table u ON r.user_id = u.ID
                       LEFT JOIN $plans_table p ON r.installment_plan_id = p.id
                       $sql_where
                       ORDER BY r.created_at DESC";
        
        $requests_export = $wpdb->get_results($wpdb->prepare($export_query, $prepare_params));
        
        if (function_exists('mlr_generate_excel_export')) {
            mlr_generate_excel_export($requests_export);
            exit;
        }

    } elseif ($page === 'mlr-unsettled-requests') {
        // مدیریت خروجی برای صفحه درخواست‌های در انتظار تسویه
        $requests_export = $wpdb->get_results("
            SELECT r.*, u.display_name, p.name as plan_name
            FROM $table_requests r
            LEFT JOIN $users_table u ON r.user_id = u.ID
            LEFT JOIN $plans_table p ON r.installment_plan_id = p.id
            WHERE r.status = 'اعطا شده' AND r.settlement_status = 'در انتظار تسویه' AND r.settlement_cycle_id IS NULL
            ORDER BY u.display_name, r.settlement_date, r.id ASC
        ");
        if (function_exists('mlr_generate_excel_export')) {
            mlr_generate_excel_export($requests_export);
            exit;
        }
    }
}