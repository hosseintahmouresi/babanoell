jQuery(document).ready(function($) {

// =========================================================
// MODAL POSITION FIX (Themes with transformed <body>)
// =========================================================
function mlrIsBodyTransformed() {
    try {
        var t = window.getComputedStyle(document.body).transform;
        return (t && t !== 'none');
    } catch (e) { return false; }
}

function mlrPositionOpenModal($modal, $overlay) {
    var needsAbsolute = mlrIsBodyTransformed();
    var update = function() {
        var scrollTop = $(window).scrollTop();
        var winH = $(window).height();
        var docH = $(document).height();

        if (needsAbsolute) {
            $overlay.css({ position: 'absolute', top: scrollTop, left: 0, width: '100%', height: docH });
            $modal.css({ position: 'absolute', top: (scrollTop + (winH / 2)), left: '50%' });
        } else {
            $overlay.css({ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%' });
            $modal.css({ position: 'fixed', top: '50%', left: '50%' });
        }
    };

    $modal.css('display', 'flex');

    $(window).off('scroll.mlrModalPos resize.mlrModalPos').on('scroll.mlrModalPos resize.mlrModalPos', function() {
        if ($overlay.is(':visible') && $modal.is(':visible')) { update(); }
    });

    update();
}

function mlrResetModalPosition($modal, $overlay) {
    $(window).off('scroll.mlrModalPos resize.mlrModalPos');
    $overlay.css({ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%' });
    $modal.css({ position: 'fixed', top: '50%', left: '50%' });
}

    // Scope to the verified-docs dashboard container to avoid conflicts
    // when multiple shortcodes exist on the same page.
    var $container = $('.mlr-user-requests[id^="mlr-verified-dashboard-"]').first();
    if ($container.length === 0) {
        return;
    }

    try {
        if (typeof $.fn.persianDatepicker === 'function') {
            $container.find('.jalali-datepicker').persianDatepicker({
                format: 'YYYY/MM/DD',
                autoClose: true
            });
        }
    } catch (e) {
        console.error("Error initializing Persian Datepicker:", e);
    }

    function loadVerifiedRequests() {
        var search = $container.find('#mlr-search').val();
        var dateFrom = $container.find('#mlr-date-from').val();
        var dateTo = $container.find('#mlr-date-to').val();
        var tableBody = $container.find('#mlr-requests-table-body');

        $.ajax({
            url: mlr_verified_ajax_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_get_verified_docs_requests', // New AJAX action
                nonce: mlr_verified_ajax_obj.nonce,
                search: search,
                date_from: dateFrom,
                date_to: dateTo,
            },
            beforeSend: function() {
                tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px;">در حال بارگذاری...</td></tr>');
            },
            success: function(response) {
                if (response.success) {
                    tableBody.html(response.data.html);
                } else {
                    tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">' + (response.data.message || 'خطا در دریافت اطلاعات.') + '</td></tr>');
                }
            },
            error: function() {
                tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">خطا در ارتباط با سرور.</td></tr>');
            }
        });
    }

    function showDetailsModal(requestId) {
        const modalOverlay = $container.find('.mlr-modal-overlay');
        const modal = $container.find('.mlr-modal');
        const modalContent = $container.find('.mlr-modal-content');

        if (!requestId) return;

        $('body').addClass('mlr-modal-open');
        modalOverlay.fadeIn(200);
        modal.css('display', 'flex');
        modal.fadeIn(200);
        mlrPositionOpenModal(modal, modalOverlay);
        modalContent.html('<p style="text-align:center; padding: 40px;">در حال بارگذاری جزئیات...</p>');

        $.ajax({
            url: mlr_verified_ajax_obj.ajax_url, 
            type: 'POST',
            data: {
                action: 'mlr_get_frontend_request_details',
                nonce: mlr_verified_ajax_obj.nonce,
                request_id: requestId
            },
            success: function(response) {
                if (response.success) {
                    modalContent.html(response.data.html);
                } else {
                    modalContent.html('<p style="color:red; text-align:center; padding: 40px;">' + (response.data.message || 'خطا در دریافت جزئیات.') + '</p>');
                }
            }
        });
    }
    
    loadVerifiedRequests();

    $container.on('click', '#mlr-filter-btn', function() {
        loadVerifiedRequests();
    });

    $container.on('keyup', '#mlr-search', function(e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            loadVerifiedRequests();
        }
    });

    $container.on('click', '.mlr-view-details-btn, #mlr-requests-table-body tr', function(e) {
        if ($(e.target).closest('form, a').length > 0) return;
        e.stopPropagation();
        const row = $(this).closest('tr');
        const requestId = row.data('id');
        showDetailsModal(requestId);
    });

    // Bank expert action form is injected into the modal with a dynamic ID.
    // Use class selector to ensure the handler always binds.
    $container.on('submit', '.mlr-bank-expert-action-form', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var button = form.find('button[type="submit"]');
        var messageDiv = form.find('.mlr-action-message');
        var formData = {
            action: 'mlr_submit_bank_expert_review',
            nonce: mlr_verified_ajax_obj.nonce,
            request_id: form.find('input[name="request_id"]').val(),
            new_status: form.find('select[name="new_status"]').val(),
            comment_text: form.find('textarea[name="comment_text"]').val()
        };

        $.ajax({
            url: mlr_verified_ajax_obj.ajax_url,
            type: 'POST',
            data: formData,
            beforeSend: function() {
                button.prop('disabled', true).text('در حال ثبت...');
                messageDiv.removeClass().addClass('mlr-action-message loading').text('لطفا صبر کنید...').slideDown();
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass().addClass('mlr-action-message success').text(response.data.message);
                    setTimeout(function() {
                        $('.mlr-modal-overlay, .mlr-modal').fadeOut(200);
                        loadVerifiedRequests();
                    }, 2000);
                } else {
                    messageDiv.removeClass().addClass('mlr-action-message error').text(response.data.message || 'خطای ناشناخته.');
                    button.prop('disabled', false).text('ثبت بررسی');
                }
            },
            error: function() {
                messageDiv.removeClass().addClass('mlr-action-message error').text('خطا در ارتباط با سرور.');
                button.prop('disabled', false).text('ثبت بررسی');
            }
        });
    });

    $container.on('click', '.mlr-modal-overlay, .mlr-modal-close', function() {
        var $ov = $container.find('.mlr-modal-overlay');
        var $md = $container.find('.mlr-modal');
        $ov.fadeOut(200);
        $md.fadeOut(200, function(){ $('body').removeClass('mlr-modal-open'); mlrResetModalPosition($md, $ov); });
    });

// --- Export Excel (CSV) ---
    $container.on('click', '#mlr-export-excel', function() {
    var search = $container.find('#mlr-search').val() || '';
    var dateFrom = $container.find('#mlr-date-from').val() || '';
    var dateTo = $container.find('#mlr-date-to').val() || '';

    var url = mlr_verified_ajax_obj.ajax_url
        + '?action=mlr_export_bank_expert_requests'
        + '&nonce=' + encodeURIComponent(mlr_verified_ajax_obj.nonce)
        + '&status=' + encodeURIComponent('تأیید مدارک')
        + '&search=' + encodeURIComponent(search)
        + '&date_from=' + encodeURIComponent(dateFrom)
        + '&date_to=' + encodeURIComponent(dateTo);

    window.location.href = url;
    });

});