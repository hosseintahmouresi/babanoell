jQuery(document).ready(function($) {

    // =========================================================
    // MODAL POSITION FIX (Admin / themes that transform <body>)
    // =========================================================
    function mlrAdminIsBodyTransformed() {
        try {
            var t = window.getComputedStyle(document.body).transform;
            return (t && t !== 'none');
        } catch (e) { return false; }
    }

    function mlrPositionAdminModal($modal, $overlay) {
        var needsAbsolute = mlrAdminIsBodyTransformed();
        var update = function() {
            var scrollTop = $(window).scrollTop();
            var winH = $(window).height();
            var docH = $(document).height();

            if (needsAbsolute) {
                $overlay.css({ position: 'absolute', top: scrollTop, left: 0, width: '100%', height: docH });
                $modal.css({ position: 'absolute', top: (scrollTop + (winH / 2)), left: '50%', transform: 'translate(-50%, -50%)', right: 'auto', bottom: 'auto', margin: 0 });
            } else {
                $overlay.css({ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%' });
                $modal.css({ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', right: 'auto', bottom: 'auto', margin: 0 });
            }
        };

        // Ensure flex layout so inner sticky header and scrolling behave correctly
        // $modal.css('display', 'flex'); // Handled in click event

        $(window).off('scroll.mlrAdminModalPos resize.mlrAdminModalPos').on('scroll.mlrAdminModalPos resize.mlrAdminModalPos', function() {
            if ($overlay.is(':visible') && $modal.is(':visible')) { update(); }
        });

        update();
    }

    function mlrResetAdminModalPosition($modal, $overlay) {
        $(window).off('scroll.mlrAdminModalPos resize.mlrAdminModalPos');
        $overlay.css({ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%' });
        $modal.css({ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', right: 'auto', bottom: 'auto', margin: 0 });
    }




    // =========================================================
    // DOCUMENTS CATEGORY TABS (Details Modal)
    // =========================================================
    function mlrAdminInitDocsCategoryTabs(context) {
        var $ctx = context ? $(context) : $(document);
        $ctx.find('.mlr-docs-card').each(function() {
            var $card = $(this);
            var $btns = $card.find('.mlr-doc-cat-btn');
            var $sections = $card.find('.mlr-doc-cat-section');
            if ($btns.length === 0 || $sections.length === 0) return;

            var defaultCat = $card.attr('data-default-cat') || $btns.first().data('cat');
            if (!defaultCat) defaultCat = $btns.first().data('cat');

            $btns.removeClass('is-active');
            $sections.hide();

            $btns.filter('[data-cat="' + defaultCat + '"]').addClass('is-active');
            $sections.filter('[data-cat="' + defaultCat + '"]').show();
        });
    }

    $(document).on('click', '.mlr-doc-cat-btn', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $card = $btn.closest('.mlr-docs-card');
        var cat = $btn.data('cat');

        $card.find('.mlr-doc-cat-btn').removeClass('is-active');
        $btn.addClass('is-active');

        $card.find('.mlr-doc-cat-section').hide();
        $card.find('.mlr-doc-cat-section[data-cat="' + cat + '"]').show();
    });

    // --- START: SHARED JALALI DATEPICKER (ADMIN VERSION) ---
    (function() {
        // If centralized datepicker is present, do not initialize the admin fallback to avoid duplicates
        if (window.MLR_JALALI_DATEPICKER_ACTIVE) { return; }

        // جلوگیری از اجرای چندباره
        if ($('#mlr-admin-datepicker').length > 0) return;

        let activeInput = null;
        let datepicker, yearSelect, monthSelect, grid;
        let currentYear, currentMonth;

        const dayNames = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
        const monthNames = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];

        // 1. ساخت HTML تقویم (فقط یکبار)
        function initDatepicker() {
            // محاسبه سال جاری
            const now = new Date();
            const todayJalali = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric' }).format(now);
            const thisYear = parseInt(todayJalali) || 1403;

            let yearOptions = '<option value="" disabled>سال</option>';
            for (let y = thisYear + 1; y >= 1350; y--) {
                yearOptions += `<option value="${y}">${y}</option>`;
            }

            let monthOptions = '<option value="" disabled>ماه</option>';
            monthNames.forEach((name, index) => {
                monthOptions += `<option value="${index + 1}">${name}</option>`;
            });

            // استایل Inline برای تضمین نمایش صحیح در ادمین
            const html = `
                <div id="mlr-admin-datepicker" style="display:none; position:absolute; z-index:9999999; background:#fff; border:1px solid #ccd0d4; border-radius:4px; padding:10px; width:220px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); font-family: Tahoma, sans-serif; direction: rtl;">
                    <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                        <select class="year-select" style="width:48%; height:30px; font-size:12px;">${yearOptions}</select>
                        <select class="month-select" style="width:48%; height:30px; font-size:12px;">${monthOptions}</select>
                    </div>
                    <div class="mlr-dp-grid" style="display:grid; grid-template-columns:repeat(7, 1fr); gap:2px; text-align:center;"></div>
                </div>`;

            $('body').append(html);

            datepicker = $('#mlr-admin-datepicker');
            yearSelect = datepicker.find('.year-select');
            monthSelect = datepicker.find('.month-select');
            grid = datepicker.find('.mlr-dp-grid');

            // رویدادهای داخلی تقویم
            yearSelect.on('change', function(e) { e.stopPropagation(); currentYear = parseInt($(this).val()); renderCalendar(); });
            monthSelect.on('change', function(e) { e.stopPropagation(); currentMonth = parseInt($(this).val()); renderCalendar(); });
            
            // انتخاب روز
            grid.on('click', '.day-cell', function(e) {
                e.stopPropagation();
                if (!activeInput) return;
                
                const day = $(this).data('day');
                const formattedDate = `${currentYear}/${String(currentMonth).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
                
                $(activeInput).val(formattedDate).trigger('change'); // تریگر change برای فرم‌ها
                datepicker.fadeOut(100);
                activeInput = null;
            });

            // کلیک روی خود تقویم باعث بسته شدن نشود
            datepicker.on('click', function(e){ e.stopPropagation(); });
        }

        // 2. محاسبات تقویم
        function isJalaliLeap(year) { return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(year % 33) > -1; }
        
        function toGregorian(jy, jm, jd) {
            var sal_a, gy, gm, gd, days; jy += 1595; days = -355668 + (365 * jy) + (~~(jy / 33) * 8) + ~~(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
            gy = 400 * ~~(days / 146097); days %= 146097; if (days > 36524) { gy += 100 * ~~(--days / 36524); days %= 36524; if (days >= 365) days++; }
            gy += 4 * ~~(days / 1461); days %= 1461; if (days > 365) { gy += ~~((days - 1) / 365); days = (days - 1) % 365; }
            gd = days + 1; sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
            return new Date(gy, gm - 1, gd);
        }

        function renderCalendar() {
            if(!currentYear || !currentMonth) return;
            grid.empty();
            // هدر روزها
            dayNames.forEach(d => grid.append(`<span style="font-size:11px; font-weight:bold; color:#777; padding:4px 0;">${d}</span>`));
            
            const daysInMonth = (currentMonth <= 6) ? 31 : (currentMonth <= 11) ? 30 : (isJalaliLeap(currentYear)) ? 30 : 29;
            const startDayIndex = (new Date(toGregorian(currentYear, currentMonth, 1)).getDay() + 1) % 7;
            
            // روزهای خالی قبل از شروع ماه
            for (let i = 0; i < startDayIndex; i++) grid.append('<span></span>');
            
            // روزهای ماه
            for (let day = 1; day <= daysInMonth; day++) {
                grid.append($(`<span class="day-cell" style="padding:5px; cursor:pointer; border-radius:3px; font-size:12px; transition:0.2s;">${day}</span>`)
                    .data('day', day)
                    .hover(
                        function(){ $(this).css('background', '#f0f0f1'); }, 
                        function(){ $(this).css('background', 'transparent'); }
                    )
                );
            }
        }

        // 3. تابع نمایش تقویم
        function openDatepicker(inputEl) {
            initDatepicker(); // اطمینان از وجود تقویم
            
            activeInput = inputEl;
            const val = $(activeInput).val();
            
            // استخراج تاریخ فعلی یا امروز
            if (val && val.match(/^\d{4}\/\d{2}\/\d{2}$/)) {
                const parts = val.split('/');
                currentYear = parseInt(parts[0]);
                currentMonth = parseInt(parts[1]);
            } else {
                const now = new Date();
                const todayParts = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: 'numeric' }).format(now).split('/');
                currentYear = parseInt(todayParts[0]);
                currentMonth = parseInt(todayParts[1]);
            }
            
            yearSelect.val(currentYear);
            monthSelect.val(currentMonth);
            renderCalendar();

            // موقعیت‌دهی دقیق زیر فیلد
            const offset = $(activeInput).offset();
            const height = $(activeInput).outerHeight();
            
            datepicker.css({
                top: (offset.top + height + 2) + 'px',
                left: 'auto',
                right: ($(window).width() - (offset.left + $(activeInput).outerWidth())) + 'px',
                display: 'block'
            });
        }

        // 4. اتصال رویدادها (Delegation)
        // کلیک روی اینپوت یا آیکون تقویم
        $(document).on('click', '.jalali-datepicker, .mlr-datepicker-trigger', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            let targetInput;
            if ($(this).hasClass('mlr-datepicker-trigger')) {
                // اگر روی آیکون کلیک شد، اینپوت قبلی‌اش را پیدا کن
                targetInput = $(this).prev('.jalali-datepicker');
            } else {
                targetInput = $(this);
            }
            
            if (targetInput.length) {
                openDatepicker(targetInput[0]);
            }
        });

        // بستن با کلیک بیرون
        $(document).on('click', function(e) {
            if (datepicker && datepicker.is(':visible')) {
                datepicker.fadeOut(100);
                activeInput = null;
            }
        });

        // اجرا در شروع کار
        initDatepicker();

    })();
    // --- END DATEPICKER ---


    // --- Other Admin Logics (Status, Cycles, Modals...) ---
    $(document).on('change', '.mlr-status-select', function() {
        var select = $(this), rid = select.data('id'), status = select.val(), spinner = select.next('.spinner');
        spinner.addClass('is-active'); select.prop('disabled', true);
        $.post(mlrAjax.ajaxurl, { action: 'mlr_update_cooperation_status', nonce: mlrAjax.nonce, request_id: rid, status: status }, function(res) {
            spinner.removeClass('is-active'); select.prop('disabled', false);
            if(res.success) select.data('original-value', status);
            else { alert(res.data.message || 'Error'); select.val(select.data('original-value')); }
        }).fail(() => { spinner.removeClass('is-active'); select.prop('disabled', false); alert('Error'); });
    });

    $(document).on('click', '.mlr-cycle-row', function(e) {
        e.stopPropagation();
        var row = $(this), id = row.data('cycle-id'), details = $('#cycle-details-' + id), container = details.find('.cycle-details-container');
        row.toggleClass('open'); details.toggle();
        if(!row.data('loaded') && details.is(':visible')) {
            container.html('<div style="text-align:center;padding:15px;"><span class="spinner is-active"></span></div>');
            $.post(mlrAjax.ajaxurl, { action: 'mlr_get_cycle_details', nonce: mlrAjax.nonce, cycle_id: id }, function(res) {
                container.html(res.success ? res.data.html : res.data.message);
                if(res.success) row.data('loaded', true);
            });
        }
    });

    $(document).on('click', '.mlr-actions-btn-icon', function(e) {
        e.stopPropagation();
        var row = $('#actions-row-' + $(this).data('id'));
        $('.mlr-actions-row').not(row).hide();
        row.toggle();
    });

    $(document).on('click', 'tr.mlr-request-row, tr.mlr-cooperation-request-row', function(e) {
        if ($(e.target).closest('a, button, input, select, .dashicons, .mlr-actions-container').length) return;
        var action = $(this).hasClass('mlr-cooperation-request-row') ? 'mlr_get_cooperation_request_details' : 'mlr_get_request_details';
        var rid = $(this).data('id');
        if(!rid) return;
        
        $('body').addClass('mlr-modal-open');
        $('#mlr-overlay').fadeIn(200);
        
        var $modal = $('#mlr-details-content');
        mlrPositionAdminModal($modal, $('#mlr-overlay'));
        $modal.css('display', 'flex').hide().fadeIn(200);
        
        $('#mlr-details-inner').html('<div style="text-align:center;padding:40px;"><span class="spinner is-active"></span></div>');
        $.post(mlrAjax.ajaxurl, { action: action, nonce: mlrAjax.nonce, request_id: rid }, function(res) {
            $('#mlr-details-inner').html(res.success ? res.data.html : 'Error');
             if(res && res.success){ mlrAdminInitDocsCategoryTabs($('#mlr-details-inner')); }
        });
    });

    // Close modal on overlay or close button click. This is a safe, targeted handler.
    $(document).on('click', '#mlr-overlay, #mlr-close-details', function() {
        $('#mlr-overlay, #mlr-details-content').fadeOut(200, function(){
            $('body').removeClass('mlr-modal-open');
            mlrResetAdminModalPosition($('#mlr-details-content'), $('#mlr-overlay'));
        });
    });

    $(document).on('click', '#mlr-add-comment-btn', function() {
        var btn = $(this), rid = btn.data('id'), txt = $('#mlr_new_comment_text').val();
        if(!txt) return alert('متن خالی است');
        btn.prop('disabled', true).next('.spinner').addClass('is-active');
        $.post(mlrAjax.ajaxurl, { action: 'mlr_add_comment', nonce: mlrAjax.nonce, request_id: rid, comment: txt }, function(res) {
            btn.prop('disabled', false).next('.spinner').removeClass('is-active');
            if(res.success) {
                if (res.data && typeof res.data.conversation_html !== 'undefined' && jQuery('#mlr-conversation-timeline-container').length) {
                    jQuery('#mlr-conversation-timeline-container').html(res.data.conversation_html);
                    jQuery('#mlr_new_comment_text').val('');
                } else {
                    jQuery('#mlr-comments-history-container').append(res.data.new_comment_html);
                    jQuery('#mlr_new_comment_text').val('');
                }
            }
            else alert(res.data.message);
        });
    });

    $('.mlr-status-select').each(function() { $(this).data('original-value', $(this).val()); });


// ============================
// Messages (Admin)
// ============================
function mlrAdminRefreshMessages(requestId) {
    var box = jQuery('#mlr-messages-history-container');
    if (box.length === 0) return;
    jQuery.post(mlrAjax.ajaxurl, {
        action: 'mlr_get_request_messages',
        nonce: mlrAjax.nonce,
        request_id: requestId
    }).done(function(res){
        if (res && res.success && res.data && typeof res.data.messages_html !== 'undefined') {
            box.html(res.data.messages_html);
            if (res.data && typeof res.data.conversation_html !== 'undefined' && jQuery('#mlr-conversation-timeline-container').length) {
                jQuery('#mlr-conversation-timeline-container').html(res.data.conversation_html);
            }
        }
    });
}

jQuery(document).on('click', '.mlr-refresh-messages-btn', function(){
    var requestId = jQuery(this).data('request-id');
    mlrAdminRefreshMessages(requestId);
});

jQuery(document).on('click', '.mlr-send-message-btn', function(){
    var btn = jQuery(this);
    var requestId = btn.data('request-id');
    var textarea = btn.closest('.mlr-add-message-form').find('.mlr-new-message-text');
    var message = textarea.val() || '';
    if (!message.trim()) { alert('متن پیام خالی است.'); return; }

    btn.prop('disabled', true).text('در حال ارسال...');
    jQuery.post(mlrAjax.ajaxurl, {
        action: 'mlr_add_request_message',
        nonce: mlrAjax.nonce,
        request_id: requestId,
        message: message
    }).done(function(res){
        btn.prop('disabled', false).text('ارسال پیام');
        if (res && res.success) {
            textarea.val('');
            if (res.data && res.data.messages_html) {
                jQuery('#mlr-messages-history-container').html(res.data.messages_html);
                if (res.data && typeof res.data.conversation_html !== 'undefined' && jQuery('#mlr-conversation-timeline-container').length) {
                    jQuery('#mlr-conversation-timeline-container').html(res.data.conversation_html);
                }
            } else {
                mlrAdminRefreshMessages(requestId);
            }
        } else {
            alert((res && res.data && res.data.message) ? res.data.message : 'خطا در ارسال پیام.');
        }
    }).fail(function(){
        btn.prop('disabled', false).text('ارسال پیام');
        alert('خطا در ارتباط با سرور.');
    });
});


// View uploaded files/documents in a new tab.
// We only intercept clicks when an href exists.
// (Some non-file buttons previously reused the same class, which broke their click handlers.)
jQuery(document).on('click', '.mlr-view-file-btn', function(e){
    var href = jQuery(this).attr('href');
    if(!href) return; // Let other click handlers (delegated) run.
    e.preventDefault();
    window.open(href, '_blank', 'noopener');
});

// Copy contract link button inside the cooperation request details modal.
jQuery(document).on('click', '.mlr-copy-link-btn', function(e){
    e.preventDefault();
    var $btn = jQuery(this);
    var link = $btn.data('link') || '';
    if (!link) return;

    var done = function(){
        var original = $btn.text();
        $btn.text('کپی شد!').prop('disabled', true);
        setTimeout(function(){ $btn.text(original).prop('disabled', false); }, 1500);
    };

    // Modern clipboard API (preferred)
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(link).then(done).catch(function(){
            // Fallback
            var $tmp = jQuery('<input>').val(link).appendTo('body').select();
            try { document.execCommand('copy'); } catch (err) {}
            $tmp.remove();
            done();
        });
    } else {
        // Fallback for non-secure contexts
        var $tmp = jQuery('<input>').val(link).appendTo('body').select();
        try { document.execCommand('copy'); } catch (err) {}
        $tmp.remove();
        done();
    }
});
});