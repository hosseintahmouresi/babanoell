<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Main callback function for all loan request admin pages.
 * It dynamically filters requests based on the 'status' GET parameter.
 */
function mlr_loan_requests_page() {
    // Determine the status filter from the URL, if present.
    $status_filter = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : ''; // Use wp_unslash

    // Define titles for specific status pages.
    $page_titles = [
        'در حال بررسی' => 'درخواست‌های در حال بررسی',
        'نقص مدارک' => 'درخواست‌های نقص مدارک',
        'رد شده' => 'درخواست‌های رد شده',
        'تأیید کارشناس' => 'درخواست‌های تأیید کارشناس',
        'تکمیل مدارک' => 'درخواست‌های تکمیل مدارک',
        'تأیید مدارک' => 'درخواست‌های تأیید مدارک',
        // Add other status titles if needed for specific views
    ];

    // Set the page title based on the filter, default to general title if no specific filter.
    $page_title = $page_titles[$status_filter] ?? 'مدیریت درخواست‌های تسهیلات';

    // Call the main display function with the determined filter and title.
    mlr_display_requests_page($status_filter, $page_title);
}


/**
 * Renders the main admin page for viewing loan requests, filtered by status.
 *
 * @param string $status_filter The status to filter by (e.g., 'در حال بررسی'). Empty string shows all.
 * @param string $page_title The title to display for the page.
 */
function mlr_display_requests_page($status_filter = '', $page_title = 'مدیریت درخواست‌ها') {
    // Check user capabilities.
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $users_table = $wpdb->prefix . 'users';
    $all_valid_statuses = mlr_get_all_valid_statuses(); // Get the list of all possible statuses.

    // --- START: Status Transition Rules ---
    // Define the allowed transitions from each status
    $status_transitions = [
        'در حال بررسی' => ['در حال بررسی', 'نقص مدارک', 'رد شده', 'تأیید کارشناس'],
        'نقص مدارک' => ['نقص مدارک', 'در حال بررسی'],
        'تأیید کارشناس' => ['تأیید کارشناس', 'نقص مدارک', 'رد شده', 'تکمیل مدارک'],
        'تکمیل مدارک' => ['تکمیل مدارک', 'تأیید مدارک'],
        'تأیید مدارک' => ['تأیید مدارک', 'اعطا شده', 'تکمیل مدارک'],
        'رد شده' => ['رد شده', 'در حال بررسی'], // Allow reopening a rejected case
        'اعطا شده' => ['اعطا شده'], // Cannot be changed from here (handled by settlement pages)
        // Default fallback: allow all valid statuses if current status is unknown
        'default' => $all_valid_statuses
    ];
    // --- END: Status Transition Rules ---

    // --- Handle Status Update Form Submission ---
    if (isset($_POST['mlr_update_status']) && check_admin_referer('mlr_update_status_action', '_wpnonce')) {
        $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
        $new_status = isset($_POST['status']) ? sanitize_text_field(wp_unslash($_POST['status'])) : '';
        $assigned_bank_user_id = isset($_POST['assigned_bank_user_id']) ? intval($_POST['assigned_bank_user_id']) : 0;

        // Validate request ID
        if ($request_id > 0) {
            $current_request = $wpdb->get_row($wpdb->prepare("SELECT status, assigned_bank_user_id FROM $table_name WHERE id = %d", $request_id));

            if ($current_request) {
                // Get the allowed transitions for the *current* status
                $current_status = $current_request->status;
                $allowed_next_statuses = $status_transitions[$current_status] ?? $status_transitions['default'];

                // *** Check if the new status is allowed ***
                if (!in_array($new_status, $allowed_next_statuses)) {
                     echo '<div id="message" class="error notice is-dismissible"><p>خطا: تغییر وضعیت از "' . esc_html($current_status) . '" به "' . esc_html($new_status) . '" مجاز نیست.</p></div>';
                }
                // Check if bank expert assignment is required
                elseif ($new_status === 'تأیید کارشناس' && empty($assigned_bank_user_id) && $assigned_bank_user_id !== $current_request->assigned_bank_user_id) {
                    echo '<div id="message" class="error notice is-dismissible"><p>خطا: برای وضعیت "تأیید کارشناس"، لطفاً یک کارشناس بانک برای ارجاع انتخاب کنید.</p></div>';
                } else {
                    // All checks passed, prepare data for update
                    $data_to_update = ['last_edited_at' => current_time('mysql')];
                    $is_status_change = $current_request->status !== $new_status;

                    $data_to_update['status'] = $new_status;
                    // Automatically set settlement status when moving to 'اعطا شده'
                    if ($new_status === 'اعطا شده' && $current_request->status !== 'اعطا شده') {
                        $data_to_update['settlement_status'] = 'منتظر تعیین تاریخ';
                    }
                    // Assign bank expert if selected
                    if ($assigned_bank_user_id > 0) {
                        $data_to_update['assigned_bank_user_id'] = $assigned_bank_user_id;
                    }

                    // Perform the update
                    $update_result = $wpdb->update($table_name, $data_to_update, ['id' => $request_id]);

                    if ($update_result !== false) {
                        echo '<div id="message" class="updated notice is-dismissible"><p>وضعیت درخواست با موفقیت به‌روزرسانی شد.</p></div>';
                        // Send SMS only if the status actually changed
                        if ($is_status_change) {
                            mlr_send_sms_on_loan_status_change($request_id, $new_status);
                        }
                    } else {
                         mlr_log("Error updating loan status for ID {$request_id}: " . $wpdb->last_error);
                         echo '<div id="message" class="error notice is-dismissible"><p>خطا در به‌روزرسانی دیتابیس.</p></div>';
                    }
                }
            } else {
                 echo '<div id="message" class="error notice is-dismissible"><p>خطا: درخواست مورد نظر یافت نشد.</p></div>';
            }
        } else {
             echo '<div id="message" class="error notice is-dismissible"><p>خطا: اطلاعات ارسال شده برای به‌روزرسانی وضعیت نامعتبر است.</p></div>';
        }
    }
    // --- End Handle Status Update ---


    // --- Filter & Search Logic ---
    $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
    // Use the $status_filter passed to the function if set, otherwise check URL
    $status_from_url = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : $status_filter;
    $date_from_jalali = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
    $date_to_jalali = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';

    // Convert Jalali dates to Gregorian for DB query
    $date_from_gregorian = !empty($date_from_jalali) ? mlr_jalali_to_gregorian($date_from_jalali) : '';
    $date_to_gregorian = !empty($date_to_jalali) ? mlr_jalali_to_gregorian($date_to_jalali) : '';

    // Build WHERE clauses
    $where_clauses = ["1=1"]; // Start with true condition
    $prepare_params = []; // Array for prepare parameters

    if (!empty($search)) {
         $search_like = '%' . $wpdb->esc_like($search) . '%';
         $where_clauses[] = "(r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s)";
         $prepare_params[] = $search_like;
         $prepare_params[] = $search_like;
         $prepare_params[] = $search_like;
         // Consider searching by ID if numeric
         if(is_numeric($search)){
             $where_clauses[count($where_clauses)-1] = substr($where_clauses[count($where_clauses)-1], 0, -1); // Remove closing parenthesis
             $where_clauses[count($where_clauses)-1] .= " OR r.id = %d)";
             $prepare_params[] = intval($search);
         }
    }
    if (!empty($status_from_url)) {
        // Ensure the status from URL is a valid one before adding to query
        if (in_array($status_from_url, $all_valid_statuses)) {
             $where_clauses[] = "r.status = %s";
             $prepare_params[] = $status_from_url;
        } else {
            // Optional: Show a notice if an invalid status was passed in URL?
            $status_from_url = ''; // Reset if invalid to avoid SQL errors
        }
    }
    if (!empty($date_from_gregorian)) {
        $where_clauses[] = "r.created_at >= %s";
        $prepare_params[] = $date_from_gregorian . ' 00:00:00';
    }
    if (!empty($date_to_gregorian)) {
        $where_clauses[] = "r.created_at <= %s";
        $prepare_params[] = $date_to_gregorian . ' 23:59:59';
    }

    $sql_where = "WHERE " . implode(' AND ', $where_clauses);

    // --- Pagination Removed: show all results without LIMIT/OFFSET ---
    // Get total items count
    $total_items_query = "SELECT COUNT(r.id) FROM $table_name r $sql_where";
    $total_items = $wpdb->get_var($wpdb->prepare($total_items_query, $prepare_params));
    if ($total_items === null) { $total_items = 0; }

    // Get all requests (no pagination)
    $requests_query = "SELECT r.*, u.display_name
                       FROM $table_name r
                       LEFT JOIN $users_table u ON r.user_id = u.ID
                       $sql_where
                       ORDER BY r.created_at DESC";
    $requests = $wpdb->get_results($wpdb->prepare($requests_query, $prepare_params));

    // Get list of users with 'bank' role for assignment dropdown
    $bank_users = get_users(['role' => 'bank', 'orderby' => 'display_name', 'order' => 'ASC']);
    // --- End Filter & Search & Pagination Logic ---

    // Determine if the actions row should be displayed (only on specific status pages)
    $show_actions_row = !empty($status_filter);

    ?>
    <div class="wrap mlr-admin-wrap">
        <div class="mlr-page-header">
            <h1><?php echo esc_html($page_title); ?></h1>
            <?php // Add New button or other header actions if applicable ?>
        </div>

        <?php // Filters Card ?>
        <div class="mlr-filters-card">
            <form method="get">
                <input type="hidden" name="page" value="<?php echo esc_attr($_REQUEST['page']); ?>">
                <div class="mlr-filters-grid">
                    <div class="mlr-filter-item" style="grid-column: 1 / -1;">
                        <label for="s">جستجو</label>
                        <input type="search" id="s" name="s" value="<?php echo esc_attr($search); ?>" placeholder="جستجو در نام متقاضی، کد ملی، شماره موبایل، شناسه...">
                    </div>
                    <div class="mlr-filter-item">
                        <label for="status">وضعیت</label>
                        <select id="status" name="status">
                            <option value="">همه وضعیت‌ها</option>
                            <?php foreach ($all_valid_statuses as $stat) : ?>
                                <option value="<?php echo esc_attr($stat); ?>" <?php selected($status_from_url, $stat); ?>><?php echo esc_html($stat); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mlr-filter-item">
                        <label for="date_from">از تاریخ</label>
                        <input type="text" id="date_from" name="date_from" class="jalali-datepicker" value="<?php echo esc_attr($date_from_jalali); ?>" placeholder="انتخاب کنید..." readonly>
                    </div>
                    <div class="mlr-filter-item">
                        <label for="date_to">تا تاریخ</label>
                        <input type="text" id="date_to" name="date_to" class="jalali-datepicker" value="<?php echo esc_attr($date_to_jalali); ?>" placeholder="انتخاب کنید..." readonly>
                    </div>
                    <div class="mlr-filter-buttons">
                        <button type="submit" class="button button-primary">فیلتر</button>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=' . esc_attr($_REQUEST['page']))); ?>" class="button">حذف فیلترها</a>
                    </div>
                </div>
            </form>
        </div>

        <?php // Results Table Wrapper ?>
        <div class="mlr-table-wrapper">
            <table class="wp-list-table widefat fixed striped mlr-modern-table loan-requests-table">
                <thead>
                    <tr>
                        <th class="manage-column column-id" scope="col">شناسه</th>
                        <th scope="col">پذیرنده</th>
                        <th scope="col">متقاضی</th>
                        <th scope="col" class="column-national-code">کد ملی</th>
                        <th scope="col" class="column-amount">مبلغ (ریال)</th>
                        <th scope="col">وضعیت</th>
                        <th scope="col" class="column-bank-expert">کارشناس بانک</th>
                        <th scope="col" class="column-date">تاریخ ثبت</th>
                        <th class="manage-column column-actions" scope="col">
                           <?php echo $show_actions_row ? 'عملیات' : 'جزئیات'; // Change header based on view ?>
                        </th>
                    </tr>
                </thead>
                <tbody id="the-list" data-wp-lists="list:loan_request">
                    <?php if (empty($requests)) : ?>
                        <tr class="no-items"><td class="colspanchange" colspan="9">هیچ درخواستی یافت نشد.</td></tr> <?php // Colspan adjusted ?>
                    <?php else: ?>
                        <?php foreach ($requests as $request) :
                            // Get assigned bank expert info if available
                            $assigned_user_info = null;
                            if (!empty($request->assigned_bank_user_id)) {
                                $assigned_user_info = get_userdata($request->assigned_bank_user_id);
                            }
                            $acceptor_display_name = $request->display_name ?: 'کاربر حذف شده'; // Handle deleted users
                            
                            // *** Get allowed next statuses for this row ***
                            $current_row_status = $request->status;
                            $allowed_transitions = $status_transitions[$current_row_status] ?? $status_transitions['default'];
                        ?>
                        <tr class="mlr-request-row" data-id="<?php echo esc_attr($request->id); ?>">
                            <td class="column-id"><?php echo esc_html($request->id); ?></td>
                            <td><?php echo esc_html($acceptor_display_name); ?></td>
                            <td><strong><?php echo esc_html($request->full_name); ?></strong></td>
                            <td class="column-national-code"><?php echo esc_html($request->national_code); ?></td>
                            <td class="column-amount"><?php echo number_format($request->loan_amount); ?></td>
                            <td><?php echo esc_html($request->status); ?></td>
                            <td class="column-bank-expert"><?php echo $assigned_user_info ? esc_html($assigned_user_info->display_name) : '---'; ?></td>
                            <td class="column-date"><?php echo mlr_gregorian_to_jalali($request->created_at, 'Y/m/d H:i'); // Show time as well ?></td>
                            <td class="mlr-actions-container column-actions">
                                <button class="mlr-actions-btn-icon" data-id="<?php echo esc_attr($request->id); ?>" title="مشاهده جزئیات کامل" aria-label="مشاهده جزئیات کامل درخواست <?php echo esc_attr($request->id); ?>">
                                    <span class="dashicons dashicons-visibility" aria-hidden="true"></span>
                                </button>
                                <?php // Display toggle only if actions row is enabled for this view ?>
                                <?php if ($show_actions_row): ?>
                                    <button class="mlr-actions-toggle-btn-icon" data-id="<?php echo esc_attr($request->id); ?>" title="تغییر وضعیت" aria-label="تغییر وضعیت درخواست <?php echo esc_attr($request->id); ?>">
                                        <span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php // Conditionally display the actions row ?>
                        <?php if ($show_actions_row): ?>
                            <tr class="mlr-actions-row" id="actions-row-<?php echo esc_attr($request->id); ?>" style="display:none;">
                                <td colspan="9"> <?php // Ensure colspan matches the number of columns ?>
                                    <div class="action-buttons">
                                        <form method="post" action="<?php echo esc_url(remove_query_arg('settings-updated')); // Prevent resubmission message ?>">
                                            <?php wp_nonce_field('mlr_update_status_action', '_wpnonce'); ?>
                                            <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">

                                            <?php // *** MODIFIED: Status Dropdown with Transition Logic *** ?>
                                            <?php if ($current_row_status !== 'اعطا شده'): ?>
                                                <label for="status_<?php echo esc_attr($request->id); ?>" class="screen-reader-text">وضعیت جدید</label>
                                                <select name="status" id="status_<?php echo esc_attr($request->id); ?>" class="mlr-status-select-action">
                                                    <?php // Loop through the *allowed* transitions for this status ?>
                                                    <?php foreach ($allowed_transitions as $stat) : ?>
                                                        <option value="<?php echo esc_attr($stat); ?>" <?php selected($current_row_status, $stat); ?>>
                                                            <?php echo esc_html($stat); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            <?php else: ?>
                                                <span class="mlr-status-message">وضعیت اصلی این درخواست نهایی شده است.</span>
                                            <?php endif; ?>
                                            <?php // *** END MODIFICATION *** ?>


                                            <?php // Bank expert assignment dropdown - Show only for relevant statuses ?>
                                            <?php if (in_array($current_row_status, ['در حال بررسی', 'نقص مدارک', 'تأیید کارشناس'])) : ?>
                                                <label for="bank_user_<?php echo esc_attr($request->id); ?>" class="screen-reader-text">ارجاع به کارشناس بانک</label>
                                                <select name="assigned_bank_user_id" id="bank_user_<?php echo esc_attr($request->id); ?>" class="mlr-bank-user-select">
                                                    <option value="">-- ارجاع به کارشناس بانک --</option>
                                                    <?php if (!empty($bank_users)): ?>
                                                        <?php foreach ($bank_users as $user): ?>
                                                            <option value="<?php echo esc_attr($user->ID); ?>" <?php selected($request->assigned_bank_user_id, $user->ID); ?>><?php echo esc_html($user->display_name); ?></option>
                                                        <?php endforeach; ?>
                                                    <?php else: ?>
                                                        <option value="" disabled>کارشناس بانکی یافت نشد</option>
                                                    <?php endif; ?>
                                                </select>
                                            <?php endif; ?>

                                            <?php // Submit button - Hide if status is 'اعطا شده' ?>
                                            <?php if ($current_row_status !== 'اعطا شده'): ?>
                                                <button type="submit" name="mlr_update_status" class="button button-primary mlr-update-button">به‌روزرسانی</button>
                                            <?php endif; ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; // End conditional display of actions row ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div> <?php // End mlr-table-wrapper ?>



        <?php // Modal structure for displaying details ?>
        <div id="mlr-overlay" style="display:none;" aria-hidden="true"></div>
        <div id="mlr-details-content" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="mlr-modal-title">
            <button id="mlr-close-details" aria-label="بستن پنجره جزئیات">&times;</button>
            <div id="mlr-details-inner">
                <?php // Content loaded via AJAX ?>
            </div>
        </div>
    </div> <?php // End wrap ?>

    <?php // Embedded CSS styles ?>
    <style>
        /* === START: Modern Loan Requests Styles (Mimicking Cooperation Style V6/V7) === */

        /* General Wrap & Header */
        .mlr-admin-wrap { padding-top: 15px; background-color: #f6f7f7; }
        .mlr-admin-wrap h1 { font-weight: 600; color: #1d2327; margin-bottom: 20px;}
        .mlr-page-header { margin-bottom: 25px;}

        /* Filter Form (Inherited styles assumed) */
        .mlr-filters-form { margin-bottom: 30px; background: #fff; border: 1px solid #dcdcde; border-radius: 6px; padding: 20px 25px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
        .mlr-filters-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px 18px; align-items: end; }
        .mlr-filter-item label { display: block; font-weight: 500; margin-bottom: 4px; font-size: 12px; color: #444; }
        .mlr-filter-item input, .mlr-filter-item select { width: 100%; box-sizing: border-box; font-size: 13px; height: 30px; vertical-align: middle; margin: 0; padding: 0 8px; border-radius: 4px; border: 1px solid #8c8f94;}
        .mlr-filter-item input[type="search"] { height: 30px; }
        .mlr-filter-buttons { display: flex; gap: 8px; align-items: center; grid-column: 1 / -1; margin-top: 10px;}
        @media (min-width: 782px) { .mlr-filter-buttons { grid-column: auto; margin-top: 0;} }
        .mlr-filter-buttons .button { height: 30px; padding: 0 10px; font-size: 13px; line-height: 28px; }

        /* Table Wrapper - Remove extra styling */
        .mlr-table-wrapper { /* No extra styles needed */ }

        /* Table Style - Separate Rows */
        .mlr-modern-table { border: none !important; box-shadow: none !important; border-collapse: separate !important; border-spacing: 0 6px !important; background: transparent !important; margin-top: 15px !important; width: 100%; }
        .mlr-modern-table thead th { background: transparent !important; border: none !important; border-bottom: none !important; font-size: 12px !important; color: #50575e !important; text-align: right !important; /* Right aligned header */ padding: 6px 15px !important; font-weight: 500; white-space: nowrap; text-transform: none; letter-spacing: normal; }
        .mlr-modern-table tbody tr.mlr-request-row { background-color: #fff !important; box-shadow: 0 1px 2px rgba(0,0,0,0.04), 0 1px 1px rgba(0,0,0,0.03) !important; border-radius: 5px !important; transition: transform 0.15s ease, box-shadow 0.15s ease !important; cursor: pointer; border: 1px solid #dcdcde !important; }
        .mlr-modern-table tbody tr.mlr-request-row:hover { transform: translateY(-2px) !important; box-shadow: 0 3px 8px rgba(0,0,0,0.07) !important; border-color: #c3c4c7 !important; }
        .mlr-modern-table tbody td { border: none !important; padding: 12px 15px !important; /* Reduced Padding */ vertical-align: middle !important; color: #444; font-size: 13px; line-height: 1.4; text-align: right !important; /* Right aligned content */ }
        .mlr-modern-table tbody td:first-child { border-top-right-radius: 5px; border-bottom-right-radius: 5px; }
        .mlr-modern-table tbody td:last-child { border-top-left-radius: 5px; border-bottom-left-radius: 5px; }
        .mlr-modern-table strong { font-weight: 600; color: #1d2327; }
        .mlr-modern-table .column-id { width: 5%; font-weight: 500; color: #646970; }
        .mlr-modern-table .column-actions { width: 90px; text-align: left !important; }
        .mlr-modern-table .column-date { width: 12%; white-space: nowrap; font-size: 12px; color: #646970;}
        .mlr-modern-table .column-national-code { width: 10%; }
        .mlr-modern-table .column-amount { width: 12%; font-weight: 500; }
        .mlr-modern-table .column-bank-expert { width: 12%; }
        .mlr-modern-table .no-items td { text-align: center !important; padding: 30px 20px !important; color: #646970; background-color: #f6f7f7 !important; border: 1px dashed #dcdcde !important; box-shadow: none !important; border-radius: 5px !important; }


        /* Action Buttons Container (in table row) */
        .mlr-actions-container { display: flex; justify-content: flex-end; /* Align buttons to the left (end in RTL) */ gap: 5px;}
        .mlr-actions-btn-icon, .mlr-actions-toggle-btn-icon { background: transparent !important; border: none !important; color: #50575e !important; cursor: pointer; width: 30px; height: 30px; border-radius: 50% !important; transition: all 0.2s ease-in-out !important; display: inline-flex !important; align-items: center; justify-content: center; padding: 0; }
        .mlr-actions-btn-icon:hover, .mlr-actions-toggle-btn-icon:hover { background-color: #e3effc !important; color: #2271b1 !important; }
        .mlr-actions-btn-icon .dashicons, .mlr-actions-toggle-btn-icon .dashicons { font-size: 18px; line-height: 1; }

        /* Action Row Styles */
        .mlr-actions-row { background-color: #f0f4ff !important; box-shadow: none !important; cursor: default; }
        /* Remove row hover effect when action row is open */
        .mlr-request-row.active:hover,
        .mlr-request-row:has(+ .mlr-actions-row:not([style*="display:none"])):hover { transform: none !important; box-shadow: 0 1px 2px rgba(0,0,0,0.04), 0 1px 1px rgba(0,0,0,0.03) !important; border-color: #dcdcde !important;}
        .mlr-actions-row td { background-color: #f8faff !important; /* Lighter blue */ padding: 15px 20px !important; border-top: 1px solid #dbeafe; border-bottom: 1px solid #dbeafe; }
        .action-buttons { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
        .action-buttons form { display: contents; }
        .action-buttons select { min-width: 150px; padding: 4px 8px; border-radius: 4px; border: 1px solid #8c8f94; background-position: left 0.5rem center; vertical-align: middle; background-color: #fff; font-size: 12px; height: 28px; line-height: 1.4; color: #3c434a; }
        .action-buttons select:focus { border-color: #2271b1; box-shadow: 0 0 0 1px #2271b1; outline: 2px solid transparent; }
        .action-buttons .button { height: 28px; padding: 0 10px; font-size: 12px; line-height: 26px; }
        .mlr-status-message { color: #50575e; font-size: 13px; font-style: italic;}


        /* Pagination */
        .mlr-pagination-nav { border-radius: 6px; background: #fff; margin-top: 25px; border: 1px solid #dcdcde; box-shadow: 0 1px 1px rgba(0,0,0,.04); padding: 8px 12px; display: flex; justify-content: space-between; align-items: center;}
        .mlr-pagination-nav .displaying-num { color: #50575e; font-size: 13px; margin: 0 !important; line-height: 26px;}
        .mlr-pagination-nav .pagination-links { float: none; display: flex; gap: 4px;}
        .mlr-pagination-nav .pagination-links a,
        .mlr-pagination-nav .pagination-links span { padding: 5px 10px; border-radius: 4px; text-decoration: none; font-size: 13px; line-height: 1.5; border: 1px solid #dcdcde; background: #f6f7f7; color: #2271b1; display: inline-flex; align-items: center; justify-content: center; min-width: 32px; height: 32px;}
        .mlr-pagination-nav .pagination-links a .dashicons,
        .mlr-pagination-nav .pagination-links span .dashicons { font-size: 18px; line-height: 1;}
        .mlr-pagination-nav .pagination-links a:hover { background-color: #f0f0f1; border-color: #c3c4c7; color: #1d2327;}
        .mlr-pagination-nav .pagination-links span.current { color: #444; background-color: #fff; border-color: #dcdcde; font-weight: 600; box-shadow: inset 0 0 0 1px #dcdcde;}
        .mlr-pagination-nav .pagination-links .prev, .mlr-pagination-nav .pagination-links .next { padding: 5px; }
        .mlr-pagination-nav .screen-reader-text { border: 0; clip: rect(1px, 1px, 1px, 1px); -webkit-clip-path: inset(50%); clip-path: inset(50%); height: 1px; margin: -1px; overflow: hidden; padding: 0; position: absolute; width: 1px; word-wrap: normal !important; }


        /* Modal Styles (Inherited from admin.css) */
        #mlr-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(10, 22, 41, 0.7); z-index: 100000; backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); }
        #mlr-details-content { display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 92%; max-width: 1100px; max-height: 88vh; overflow: auto; background: rgba(246, 247, 247, 0.98); border: 1px solid rgba(255, 255, 255, 0.2); z-index: 100001; border-radius: 12px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); padding: 18px 18px 12px; }
        #mlr-close-details { position: absolute; top: 10px; left: 10px; width: 34px; height: 34px; border-radius: 50%; border: 1px solid rgba(0,0,0,0.08); background: rgba(0,0,0,0.04); color: #374151; font-size: 22px; line-height: 30px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
        #mlr-close-details:hover { background: rgba(0,0,0,0.06); }
        .mlr-modal-header { margin-bottom: 12px; padding-bottom: 10px; border-bottom: 1px solid rgba(0,0,0,0.08); }
        .mlr-modal-title { margin: 0; font-size: 16px; font-weight: 700; color: #111827; }
        #mlr-details-inner { direction: rtl; text-align: right; }
        .mlr-modal-card { background: #fff; border: 1px solid rgba(0,0,0,0.06); border-radius: 10px; padding: 12px; margin-bottom: 12px; }
        .mlr-modal-subtitle { margin: 0 0 10px; font-weight: 700; color: #111827; font-size: 13px; }
        .mlr-details-table.modern { width: 100%; border-collapse: collapse; }
        .mlr-details-table.modern td { padding: 8px 10px; border-bottom: 1px solid rgba(0,0,0,0.06); vertical-align: top; }
        .mlr-details-table.modern tr:last-child td { border-bottom: none; }
        .mlr-details-table.modern td:first-child { width: 32%; color: #374151; font-weight: 600; }
        .mlr-details-table.modern td:last-child { color: #111827; word-break: break-word; }
        .mlr-modal-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        @media (max-width: 782px) { .mlr-modal-grid { grid-template-columns: 1fr; } #mlr-details-content { width: 96%; max-height: 90vh; } }

        /* === END: Modern Styles === */

    </style>
    <?php
}
?>