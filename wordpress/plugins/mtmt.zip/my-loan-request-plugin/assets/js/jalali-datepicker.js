/**
 * MLR Custom Jalali Datepicker - Centralized Component
 * Version: 1.1.0 (Final Fix)
 * This script provides a simple, dependency-free Jalali datepicker.
 */
jQuery(document).ready(function($) {
    // Global flag to prevent duplicate datepicker implementations
    window.MLR_JALALI_DATEPICKER_ACTIVE = true;

    // The picker must also support inputs injected later via AJAX modals.
    // Therefore, create the singleton UI even when no date field exists at page load.

    let activeInput = null;
    let datepicker, yearSelect, monthSelect, grid;
    let currentYear, currentMonth;

    const dayNames = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    const monthNames = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];

    function createDatePickerUI() {
        if ($('.mlr-custom-datepicker-popup').length > 0) return;

        let yearOptions = '<option value="" disabled selected>سال</option>';
        const currentJalaliYear = parseInt(new Date().toLocaleDateString('fa-IR-u-nu-latn').split('/')[0]);
        for (let y = currentJalaliYear; y >= 1320; y--) {
            yearOptions += `<option value="${y}">${y}</option>`;
        }

        let monthOptions = '<option value="" disabled selected>ماه</option>';
        monthNames.forEach((name, index) => {
            monthOptions += `<option value="${index + 1}">${name}</option>`;
        });

        const dp_html = `
            <div class="mlr-custom-datepicker-popup">
                <div class="mlr-dp-header">
                    <select class="mlr-dp-select month-select">${monthOptions}</select>
                    <select class="mlr-dp-select year-select">${yearOptions}</select>
                </div>
                <div class="mlr-dp-grid"></div>
            </div>`;
        $('body').append(dp_html);

        datepicker = $('.mlr-custom-datepicker-popup');
        yearSelect = datepicker.find('.year-select');
        monthSelect = datepicker.find('.month-select');
        grid = datepicker.find('.mlr-dp-grid');

        yearSelect.on('change', () => {
            currentYear = parseInt(yearSelect.val());
            if (currentMonth) renderCalendar();
        });
        monthSelect.on('change', () => {
            currentMonth = parseInt(monthSelect.val());
            if (currentYear) renderCalendar();
        });
        grid.on('click', '.mlr-dp-day:not(.disabled)', selectDate);

        // Hide on outside click
        $(document).on('click', function(e) {
            if (datepicker.is(":visible") && !$(e.target).closest('.mlr-custom-datepicker-popup').length && !$(e.target).is(activeInput)) {
                datepicker.fadeOut(200);
                activeInput = null;
            }
        });
    }

    function toGregorian(jy, jm, jd) {
        var sal_a, gy, gm, gd, days;
        jy += 1595;
        days = -355668 + (365 * jy) + (~~(jy / 33) * 8) + ~~(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
        gy = 400 * ~~(days / 146097);
        days %= 146097;
        if (days > 36524) {
            gy += 100 * ~~(--days / 36524);
            days %= 36524;
            if (days >= 365) days++;
        }
        gy += 4 * ~~(days / 1461);
        days %= 1461;
        if (days > 365) {
            gy += ~~((days - 1) / 365);
            days = (days - 1) % 365;
        }
        gd = days + 1;
        sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
        return new Date(gy, gm - 1, gd);
    }
    
    function isJalaliLeap(year) {
        const remainders = [1, 5, 9, 13, 17, 22, 26, 30];
        return remainders.indexOf(year % 33) > -1;
    }

    function renderCalendar() {
        grid.empty();
        dayNames.forEach(name => grid.append(`<span class="mlr-dp-day-name">${name}</span>`));

        const daysInMonth = (currentMonth <= 6) ? 31 : (currentMonth <= 11) ? 30 : (isJalaliLeap(currentYear)) ? 30 : 29;
        const firstDayOfMonth = toGregorian(currentYear, currentMonth, 1);
        const startDayIndex = (firstDayOfMonth.getDay() + 1) % 7;

        for (let i = 0; i < startDayIndex; i++) {
            grid.append('<span class="disabled"></span>');
        }
        for (let day = 1; day <= daysInMonth; day++) {
            grid.append(`<span class="mlr-dp-day" data-day="${day}">${day}</span>`);
        }
    }
    
    function selectDate() {
        if (!activeInput) return;
        const day = $(this).data('day');
        const finalDate = `${currentYear}/${String(currentMonth).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
        $(activeInput).val(finalDate).trigger('change'); // Trigger change for any listeners
        datepicker.fadeOut(200);
        activeInput = null;
    }

    // Use event delegation for dynamically added inputs
    $(document).off('click.mlrJalaliDp', '.jalali-datepicker, .mlr-datepicker-trigger')
        .on('click.mlrJalaliDp', '.jalali-datepicker, .mlr-datepicker-trigger', function(e) {
            if (e) { e.preventDefault(); e.stopPropagation(); }

            if ($(this).hasClass('mlr-datepicker-trigger')) {
                const input = $(this)
                    .siblings('.jalali-datepicker')
                    .add($(this).closest('.mlr-date-input-wrapper').find('.jalali-datepicker'))
                    .first();
                if (!input.length) { return; }
                activeInput = input[0];
            } else {
                activeInput = this;
            }

            grid.empty();

            const existingDate = $(activeInput).val();
if (existingDate && existingDate.match(/^\d{4}\/\d{2}\/\d{2}$/)) {
            const parts = existingDate.split('/');
            currentYear = parseInt(parts[0]);
            currentMonth = parseInt(parts[1]);
            yearSelect.val(currentYear);
            monthSelect.val(currentMonth);
            renderCalendar();
        } else {
            const now = new Date();
            const todayJalali = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: 'numeric' }).format(now).split('/');
            currentYear = parseInt(todayJalali[0]);
            currentMonth = parseInt(todayJalali[1]);
            yearSelect.val(currentYear);
            monthSelect.val(currentMonth);
            renderCalendar();
        }
        
        const inputPos = $(activeInput).offset();
        const inputHeight = $(activeInput).outerHeight();
        const datepickerWidth = datepicker.outerWidth();
        const adminMenuWidth = $('#adminmenuback').width() || 0; // handle frontend case

        let leftPosition = inputPos.left;
        
        // Adjust position to stay within viewport
        if ((leftPosition + datepickerWidth) > ($(window).width() - adminMenuWidth)) {
            leftPosition = inputPos.left - datepickerWidth + $(activeInput).outerWidth();
        }

        datepicker.css({
            top: inputPos.top + inputHeight + 5,
            left: leftPosition,
            right: 'auto'
        }).fadeIn(200);
    });

    createDatePickerUI();
});