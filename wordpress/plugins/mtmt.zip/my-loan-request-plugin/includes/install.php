<?php
if (!defined('ABSPATH')) {
    exit;
}

function mlr_install() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // 1. جدول درخواست‌های وام (Loan Requests)
    $table_requests = $wpdb->prefix . 'loan_requests';
    $sql_requests = "CREATE TABLE $table_requests (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        applicant_user_id bigint(20) UNSIGNED DEFAULT NULL,
        acceptor_user_id bigint(20) UNSIGNED DEFAULT NULL,
        request_origin varchar(30) NOT NULL DEFAULT 'acceptor_portal',
        acceptor_assignment_mode varchar(30) DEFAULT '',
        marketplace_status varchar(30) DEFAULT '',
        marketplace_claimed_by bigint(20) UNSIGNED DEFAULT NULL,
        marketplace_claimed_at datetime DEFAULT NULL,
        requested_service_scope varchar(30) DEFAULT '',
        requested_cities longtext DEFAULT NULL,
        requested_location_terms longtext DEFAULT NULL,
        requested_activity_categories longtext DEFAULT NULL,
        request_public_summary text DEFAULT NULL,
        acceptor_invitation_code varchar(100) DEFAULT NULL,
        acceptor_invited_by bigint(20) UNSIGNED DEFAULT NULL,
        acceptor_invitation_locked tinyint(1) DEFAULT 0,
        full_name varchar(255) NOT NULL,
        national_code varchar(10) NOT NULL,
        mobile_number varchar(15) NOT NULL,
        phone_number varchar(20) DEFAULT '' NOT NULL,
        birth_date date DEFAULT NULL,
        occupation varchar(100) DEFAULT '' NOT NULL,
        residential_address text,
        postal_code varchar(10) DEFAULT '' NOT NULL,
        work_address text,
        product_name text,
        installment_plan_id bigint(20) UNSIGNED NOT NULL,
        loan_amount DECIMAL(15,2) NOT NULL,
        facility_amount DECIMAL(15,2) DEFAULT NULL,
        prepayment DECIMAL(15,2) DEFAULT 0,
        wallet_charge DECIMAL(15,2) DEFAULT 0,
        acceptor_payment_amount DECIMAL(15,2) DEFAULT 0,
        final_settlement_amount DECIMAL(15,2) DEFAULT 0,
        leasing_deposit_amount DECIMAL(15,2) DEFAULT NULL,
        installment_interval int(11) NOT NULL DEFAULT 1,
        installment_count int(11) NOT NULL,
        installment_amount DECIMAL(15,2) DEFAULT 0,
        total_payment DECIMAL(15,2) DEFAULT 0,
        profit DECIMAL(15,2) DEFAULT 0,
        required_documents longtext,
        order_items longtext DEFAULT NULL,
        order_total DECIMAL(15,2) DEFAULT 0,
        form_data longtext,
        credit_report_json longtext DEFAULT NULL,
        bank_validation_file text,
        signature_image text,
        contract_file text,
        check_images longtext,
        comments longtext,
        status varchar(50) NOT NULL,
        settlement_status varchar(50) DEFAULT '',
        assigned_bank_user_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_cycle_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_date datetime DEFAULT NULL,
        created_at datetime NOT NULL,
        last_edited_at datetime DEFAULT NULL,
        PRIMARY KEY  (id),
        KEY user_id (user_id),
        KEY idx_applicant_user_id (applicant_user_id),
        KEY idx_acceptor_user_id (acceptor_user_id),
        KEY idx_request_origin (request_origin),
        KEY idx_acceptor_assignment_mode (acceptor_assignment_mode),
        KEY idx_marketplace_status (marketplace_status),
        KEY idx_marketplace_claimed_by (marketplace_claimed_by),
        KEY idx_acceptor_invitation_code (acceptor_invitation_code),
        KEY idx_acceptor_invited_by (acceptor_invited_by),
        KEY status (status),
        KEY national_code (national_code),
        KEY installment_plan_id (installment_plan_id),
        KEY idx_settlement_cycle_id (settlement_cycle_id),
        KEY idx_assigned_bank_user_id (assigned_bank_user_id)
    ) $charset_collate;";
    dbDelta($sql_requests);

    // 2. جدول طرح‌های اقساطی (Installment Plans)
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $sql_installment_plans = "CREATE TABLE $table_installment_plans (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        type varchar(50) NOT NULL,
        is_active tinyint(1) DEFAULT 1,
        settings longtext,
        display_fields longtext,
        display_fields_context longtext,
        required_documents text,
        created_at datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql_installment_plans);

    // 3. جدول درخواست‌های همکاری (Cooperation Requests)
    $table_cooperation = $wpdb->prefix . 'cooperation_requests';
    $sql_cooperation = "CREATE TABLE $table_cooperation (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_type varchar(50) NOT NULL,
        status varchar(50) NOT NULL DEFAULT 'در حال بررسی',
        contract_token varchar(64) DEFAULT NULL,
        contract_signed_status varchar(20) NOT NULL DEFAULT 'pending',
        contract_signed_at datetime DEFAULT NULL,
        contract_expires_at datetime DEFAULT NULL,
        otp_code varchar(255) DEFAULT NULL,
        otp_expiry datetime DEFAULT NULL,
        data longtext,
        files longtext,
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY idx_contract_token (contract_token),
        KEY status (status),
        KEY request_type (request_type),
        KEY idx_signed_status (contract_signed_status)
    ) $charset_collate;";
    dbDelta($sql_cooperation_requests);

    // 4. جدول سیکل‌های تسویه (Settlement Cycles)
    $table_settlement_cycles = $wpdb->prefix . 'mlr_settlement_cycles';
    $sql_settlement_cycles = "CREATE TABLE $table_settlement_cycles (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        total_amount DECIMAL(15,2) NOT NULL,
        description text,
        settlement_date datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql_settlement_cycles);

    // 5. جدول رویدادهای درخواست (Request Events)
    $table_request_events = $wpdb->prefix . 'mlr_request_events';
    $sql_request_events = "CREATE TABLE $table_request_events (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_id bigint(20) UNSIGNED NOT NULL,
        user_id bigint(20) UNSIGNED DEFAULT NULL,
        user_role varchar(50) DEFAULT '' NOT NULL,
        event_type varchar(100) DEFAULT '' NOT NULL,
        details longtext,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY request_id (request_id),
        KEY user_id (user_id),
        KEY event_type (event_type),
        KEY created_at (created_at)
    ) $charset_collate;";
    dbDelta($sql_request_events);

    // 6. جدول پیام‌های درخواست (Request Messages)
    $table_request_messages = $wpdb->prefix . 'mlr_request_messages';
    $sql_request_messages = "CREATE TABLE $table_request_messages (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_id bigint(20) UNSIGNED NOT NULL,
        user_id bigint(20) UNSIGNED DEFAULT NULL,
        user_role varchar(50) DEFAULT '' NOT NULL,
        message longtext NOT NULL,
        attachments text DEFAULT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY request_id (request_id),
        KEY user_id (user_id),
        KEY created_at (created_at)
    ) $charset_collate;";
    dbDelta($sql_request_messages);

        // 7. جدول ناتیفیکیشن‌های ادمین (Admin Notifications)
    $table_notifications = $wpdb->prefix . 'mlr_admin_notifications';
    $sql_notifications = "CREATE TABLE $table_notifications (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        type varchar(50) NOT NULL,
        message text NOT NULL,
        link text DEFAULT NULL,
        is_read tinyint(1) DEFAULT 0,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY is_read (is_read)
    ) $charset_collate;";
    dbDelta($sql_notifications);
}
?>
