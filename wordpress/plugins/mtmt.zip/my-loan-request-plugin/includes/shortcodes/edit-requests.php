<?php
add_shortcode('mlr_edit_requests', 'mlr_edit_requests_shortcode');

function mlr_edit_requests_shortcode() {
    if (!is_user_logged_in()) {
        return '<p>برای دسترسی به این بخش، لطفاً ابتدا وارد شوید.</p>';
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $user_id = get_current_user_id();

    if (!isset($_GET['mlr_edit']) || !isset($_GET['nonce'])) {
        return '<p>لینک ویرایش نامعتبر است.</p>';
    }

    $request_id = intval($_GET['mlr_edit']);
    $nonce = $_GET['nonce'];

    if (!wp_verify_nonce($nonce, 'mlr_edit_' . $request_id)) {
        return '<p>خطای امنیتی. لطفاً از طریق پنل کاربری خود اقدام کنید.</p>';
    }

    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND user_id = %d AND status = 'نقص مدارک'", $request_id, $user_id));

    if (!$request) {
        return '<p>درخواست مورد نظر یافت نشد یا در حال حاضر قابل ویرایش نیست.</p>';
    }

    if (isset($_POST['mlr_update_request']) && check_admin_referer('mlr_edit_request_action')) {
        $preserve_text_value = function($key, $fallback) {
            if (!isset($_POST[$key])) {
                return $fallback;
            }

            $value = is_string($_POST[$key]) ? wp_unslash($_POST[$key]) : $_POST[$key];
            $value = is_scalar($value) ? trim((string) $value) : '';

            return $value === '' && $fallback !== '' && $fallback !== null ? $fallback : $value;
        };
        
        $data = [
            'full_name' => sanitize_text_field($preserve_text_value('full_name', $request->full_name)),
            'national_code' => sanitize_text_field($preserve_text_value('national_code', $request->national_code)),
            'mobile_number' => sanitize_text_field($preserve_text_value('mobile_number', $request->mobile_number)),
            'phone_number' => sanitize_text_field($preserve_text_value('phone_number', $request->phone_number)),
            'birth_date' => sanitize_text_field($preserve_text_value('birth_date', $request->birth_date)),
            'occupation' => sanitize_text_field($preserve_text_value('occupation', $request->occupation)),
            'residential_address' => sanitize_textarea_field($preserve_text_value('residential_address', $request->residential_address)),
            'postal_code' => sanitize_text_field($preserve_text_value('postal_code', $request->postal_code)),
            'work_address' => sanitize_textarea_field($preserve_text_value('work_address', $request->work_address)),
            'product_name' => sanitize_textarea_field($preserve_text_value('product_name', $request->product_name)),
            'status' => 'در حال بررسی',
            'last_edited_at' => current_time('mysql')
        ];

        $form_data = [];
        $can_sync_form_data = true;
        if (!empty($request->form_data)) {
            $decoded_form_data = json_decode((string) $request->form_data, true);
            if (!is_array($decoded_form_data)) {
                $decoded_form_data = json_decode(stripslashes((string) $request->form_data), true);
            }

            if (is_array($decoded_form_data)) {
                $form_data = $decoded_form_data;
            } else {
                $can_sync_form_data = false;
            }
        }

        if ($can_sync_form_data) {
            foreach (['full_name', 'national_code', 'mobile_number', 'phone_number', 'birth_date', 'occupation', 'residential_address', 'postal_code', 'work_address', 'product_name'] as $field_key) {
                $form_data[$field_key] = $data[$field_key];
            }

            $data['form_data'] = wp_json_encode($form_data, JSON_UNESCAPED_UNICODE);
        }

        $uploaded_documents = function_exists('mlr_get_request_uploaded_documents')
            ? mlr_get_request_uploaded_documents($request->required_documents)
            : maybe_unserialize($request->required_documents);
        if (!is_array($uploaded_documents)) {
            $uploaded_documents = [];
        }
        if (!empty($_FILES)) {
            foreach ($_FILES as $file_key => $file) {
                if (!empty($file['name'])) {
                    $upload = mlr_handle_wp_upload($file);
                    if (isset($upload['url'])) {
                        $uploaded_documents[$file_key] = $upload['url'];
                    } else {
                        echo '<div class="error"><p>خطا در آپلود فایل ' . esc_html($file_key) . ': ' . esc_html($upload['error']) . '</p></div>';
                        return;
                    }
                }
            }
        }
        $data['required_documents'] = serialize($uploaded_documents);
        
        $updated = $wpdb->update($table_name, $data, ['id' => $request_id, 'user_id' => $user_id]);
        if ($updated === false) {
            echo '<div class="error"><p>خطا در ذخیره تغییرات: ' . esc_html($wpdb->last_error) . '</p></div>';
            return;
        }

        $fresh_request = $wpdb->get_row($wpdb->prepare("SELECT full_name FROM $table_name WHERE id = %d AND user_id = %d", $request_id, $user_id));
        if (!$fresh_request || trim((string) $fresh_request->full_name) !== trim((string) $data['full_name'])) {
            echo '<div class="error"><p>ذخیره انجام نشد. لطفاً دوباره تلاش کنید.</p></div>';
            return;
        }
        
        mlr_send_sms_on_loan_status_change($request_id, 'در حال بررسی');
        
        echo '<div class="updated"><p>درخواست شما با موفقیت ویرایش و برای بررسی مجدد ارسال شد.</p></div>';
        
        return;
    }

    $occupations = [
        'official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر',
        'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر',
        'employer' => 'کارفرما', 'other' => 'سایر'
    ];

    ob_start();
    ?>
    <div class="mlr-edit-request-form">
        <h2>ویرایش درخواست (شناسه: <?php echo $request_id; ?>)</h2>
        <p>لطفاً اطلاعات زیر را تکمیل یا اصلاح کرده و مدارک مورد نیاز را بارگذاری نمایید.</p>
        
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('mlr_edit_request_action'); ?>
            
            <h3>اطلاعات فردی و تماس</h3>
            <p><label>نام کامل: <input type="text" name="full_name" value="<?php echo esc_attr($request->full_name); ?>" required></label></p>
            <p><label>کد ملی: <input type="text" name="national_code" value="<?php echo esc_attr($request->national_code); ?>" required pattern="\d{10}"></label></p>
            <p><label>شماره موبایل: <input type="text" name="mobile_number" value="<?php echo esc_attr($request->mobile_number); ?>" required pattern="09\d{9}"></label></p>
            <p><label>شماره تلفن ثابت: <input type="text" name="phone_number" value="<?php echo esc_attr($request->phone_number); ?>"></label></p>
            <p><label>تاریخ تولد: <input type="date" name="birth_date" value="<?php echo esc_attr($request->birth_date); ?>"></label></p>
            <p><label>شغل: 
                <select name="occupation" required>
                    <option value="">انتخاب کنید...</option>
                    <?php foreach ($occupations as $key => $label) : ?>
                        <option value="<?php echo esc_attr($key); ?>" <?php selected($request->occupation, $key); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </label></p>

            <h3>اطلاعات آدرس و محصول</h3>
            <p><label>آدرس محل سکونت: <textarea name="residential_address" rows="3"><?php echo esc_textarea($request->residential_address); ?></textarea></label></p>
            <p><label>کد پستی: <input type="text" name="postal_code" value="<?php echo esc_attr($request->postal_code); ?>" pattern="\d{10}"></label></p>
            <p><label>آدرس محل فعالیت: <textarea name="work_address" rows="3"><?php echo esc_textarea($request->work_address); ?></textarea></label></p>
            <p><label>نام کامل محصول: <textarea name="product_name" rows="2"><?php echo esc_textarea($request->product_name); ?></textarea></label></p>

            <h3>بارگذاری مجدد مدارک (فقط در صورت نیاز)</h3>
            <?php
            $plan_docs_table = $wpdb->prefix . 'installment_plans';
            $plan = $wpdb->get_row($wpdb->prepare("SELECT required_documents FROM $plan_docs_table WHERE id = %d", $request->installment_plan_id));
            $required_docs_keys = $plan ? maybe_unserialize($plan->required_documents) : [];
            
            if (!empty($required_docs_keys)) {
                 $doc_labels = mlr_get_all_document_options();
                foreach ($required_docs_keys as $doc_key) {
                    $label = $doc_labels[$doc_key] ?? 'مدرک ' . $doc_key;
                    echo '<p><label>' . esc_html($label) . ': <input type="file" name="' . esc_attr($doc_key) . '"></label></p>';
                }
            }
            ?>
            
            <button type="submit" name="mlr_update_request" class="button button-primary">ذخیره تغییرات و ارسال مجدد</button>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
