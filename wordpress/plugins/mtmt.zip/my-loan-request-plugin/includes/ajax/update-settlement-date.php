<?php
/**
 * AJAX: بروزرسانی تاریخ تسویه — در دسترس برای نقش‌های administrator و mali (قابلیت mlr_edit_settlement_date)
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_update_settlement_date', 'mlr_update_settlement_date_callback');

function mlr_update_settlement_date_callback() {
    if (!current_user_can('mlr_edit_settlement_date')) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز.']);
        return;
    }

    check_ajax_referer('mlr_settlement_date_edit_nonce', 'nonce');

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $settlement_date_jalali = isset($_POST['settlement_date']) ? sanitize_text_field(wp_unslash($_POST['settlement_date'])) : '';

    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    if (empty($settlement_date_jalali)) {
        wp_send_json_error(['message' => 'تاریخ تسویه را وارد کنید.']);
        return;
    }

    if (!function_exists('mlr_jalali_to_gregorian')) {
        wp_send_json_error(['message' => 'تابع تبدیل تاریخ در دسترس نیست.']);
        return;
    }

    $settlement_date_gregorian = mlr_jalali_to_gregorian($settlement_date_jalali);
    if (!$settlement_date_gregorian) {
        wp_send_json_error(['message' => 'فرمت تاریخ شمسی نامعتبر است (مثال: 1403/06/15).']);
        return;
    }

    $settlement_date_gregorian .= ' ' . date('H:i:s');

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';

    $request_row = $wpdb->get_row($wpdb->prepare(
        "SELECT id, status, settlement_status, settlement_cycle_id, settlement_date FROM `{$table}` WHERE id = %d",
        $request_id
    ), ARRAY_A);

    if (!empty($request_row) && function_exists('mlr_reconcile_request_workflow_state')) {
        $request_row = array_merge($request_row, mlr_reconcile_request_workflow_state($request_row));
    }

    $current_status = function_exists('mlr_normalize_status')
        ? mlr_normalize_status($request_row['status'] ?? '')
        : trim((string) ($request_row['status'] ?? ''));

    if (empty($request_row) || $current_status !== 'اعطا شده') {
        wp_send_json_error(['message' => 'درخواست یافت نشد یا وضعیت آن اعطا شده نیست.']);
        return;
    }

    $data_to_update = ['settlement_date' => $settlement_date_gregorian];
    if (!empty($request_row) && function_exists('mlr_reconcile_request_workflow_state')) {
        foreach (mlr_reconcile_request_workflow_state(array_merge($request_row, $data_to_update)) as $field_key => $field_value) {
            if (in_array($field_key, ['status', 'settlement_status', 'settlement_cycle_id'], true)) {
                $data_to_update[$field_key] = $field_value;
            }
        }
    }

    if (function_exists('mlr_get_canonical_granted_request_settlement_state')) {
        $canonical_state = mlr_get_canonical_granted_request_settlement_state(array_merge($request_row, [
            'settlement_date' => $settlement_date_gregorian,
        ]));

        $current_settlement_status = function_exists('mlr_normalize_status')
            ? mlr_normalize_status($request_row['settlement_status'] ?? '')
            : trim((string) ($request_row['settlement_status'] ?? ''));

        if (!empty($canonical_state['settlement_status']) && $current_settlement_status !== $canonical_state['settlement_status']) {
            $data_to_update['settlement_status'] = $canonical_state['settlement_status'];
        }

        if (isset($request_row['settlement_cycle_id']) && (int) $request_row['settlement_cycle_id'] === 0) {
            $data_to_update['settlement_cycle_id'] = null;
        }
    }

    $updated = $wpdb->update(
        $table,
        $data_to_update,
        ['id' => $request_id],
        null,
        ['%d']
    );

    if ($updated === false) {
        if (function_exists('mlr_log')) {
            mlr_log('update_settlement_date failed: ' . $wpdb->last_error);
        }
        wp_send_json_error(['message' => 'خطا در بروزرسانی دیتابیس.']);
        return;
    }

    if ($updated > 0 && function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'settlement_date_edited', 'تاریخ تسویه به ' . $settlement_date_jalali . ' تغییر یافت.');
        if (isset($data_to_update['settlement_status'])) {
            mlr_add_request_event($request_id, 'settlement_status_change', 'تغییر وضعیت تسویه به: ' . $data_to_update['settlement_status']);
        }
    }

    $display_date = function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($settlement_date_gregorian, 'Y/m/d') : $settlement_date_gregorian;
    $display_settlement_status = isset($data_to_update['settlement_status'])
        ? $data_to_update['settlement_status']
        : (!empty($request_row['settlement_status']) ? $request_row['settlement_status'] : 'منتظر تعیین تاریخ');

    wp_send_json_success([
        'message' => 'تاریخ تسویه با موفقیت بروزرسانی شد.',
        'settlement_date_display' => $display_date,
        'settlement_status_display' => $display_settlement_status,
    ]);
}
