<?php
/**
 * AJAX Handler for fetching the required documents for a specific installment plan.
 * This is used by the front-end form to dynamically display file upload fields.
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_plan_documents', 'mlr_get_plan_documents_callback');
add_action('wp_ajax_nopriv_mlr_get_plan_documents', 'mlr_get_plan_documents_callback');

function mlr_get_plan_documents_callback() {
    // 1. Security Check - --- START: ویرایش و اصلاح نانس ---
    // پاکسازی بافر خروجی برای جلوگیری از خطای JSON
    if (ob_get_length()) ob_clean();
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    // --- END: ویرایش و اصلاح نانس ---

    // 2. Input Validation
    if (!isset($_POST['plan_id'])) {
        wp_send_json_error(['message' => 'خطا: شناسه طرح ارسال نشده است.']);
        return;
    }
    $plan_id = intval($_POST['plan_id']);

    if (function_exists('mlr_user_can_access_installment_plan') && !mlr_user_can_access_installment_plan(get_current_user_id(), $plan_id, true)) {
        wp_send_json_error(['message' => 'طرح انتخاب‌شده برای حساب شما در دسترس نیست.']);
        return;
    }

    // 3. Database Query
    global $wpdb;
    $table_name = $wpdb->prefix . 'installment_plans';
    $plan = $wpdb->get_row($wpdb->prepare("SELECT required_documents FROM $table_name WHERE id = %d AND is_active = 1", $plan_id));

    if (!$plan) {
        wp_send_json_error(['message' => 'طرح انتخاب شده یافت نشد یا در حال حاضر فعال نیست.']);
        return;
    }

    $required_docs_keys = maybe_unserialize($plan->required_documents);

    if (empty($required_docs_keys) || !is_array($required_docs_keys)) {
        wp_send_json_success([]); 
        return;
    }
    
    // 4. Prepare Response
    $all_doc_labels = mlr_get_all_document_options();
    // --- START: Define which fields can accept multiple files ---
    $multi_upload_fields = ['birth_certificate', 'activity_license', 'account_statement', 'additional_documents']; // Added 'additional_documents' for consistency
    // --- END: Define multi-upload fields ---
    
    $documents_to_send = [];
    foreach ($required_docs_keys as $key) {
        if (isset($all_doc_labels[$key])) {
            $is_multiple = in_array($key, $multi_upload_fields);
            $documents_to_send[] = [
                'key'      => $key,
                'label'    => $all_doc_labels[$key],
                'multiple' => $is_multiple // Add a flag for JS to use
            ];
        }
    }

    // 5. Send JSON Response
    wp_send_json_success($documents_to_send);
}
