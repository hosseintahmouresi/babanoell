<?php
// FILE: my-loan-request-plugin/includes/ajax/submit-loan-request.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_submit_loan_request', 'mlr_submit_loan_request_callback');
add_action('wp_ajax_nopriv_mlr_submit_loan_request', 'mlr_submit_loan_request_callback'); // جهت اطمینان برای کاربران لاگین نشده (اگر نیاز است)

// Helper function for normalizing uploaded files array
if (!function_exists('mlr_rearray_files')) {
    function mlr_rearray_files(&$file_post) {
        $file_ary = array();
        $file_count = count($file_post['name']);
        $file_keys = array_keys($file_post);

        for ($i = 0; $i < $file_count; $i++) {
            foreach ($file_keys as $key) {
                $file_ary[$i][$key] = $file_post[$key][$i];
            }
        }
        return $file_ary;
    }
}

function mlr_submit_loan_request_callback() {
    // 1. Security Check
    check_ajax_referer('mlr_loan_request_action', '_wpnonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای ثبت درخواست، لطفاً ابتدا وارد شوید.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $errors = [];

    // 2. Data Sanitization & Collection
    $phone_number = sanitize_text_field($_POST['phone_number'] ?? '');
    $mobile_number = sanitize_text_field($_POST['mobile_number'] ?? '');
    $national_code = sanitize_text_field($_POST['national_code'] ?? '');
    
    // Fallback for phone number
    if (empty($phone_number)) $phone_number = $mobile_number;

    // Validate National Code (Server-side)
    if (!function_exists('mlr_validate_iranian_national_code')) {
        function mlr_validate_iranian_national_code($code) {
            if (!preg_match('/^\d{10}$/', $code)) return false;
            $check = (int) $code[9];
            $sum = 0;
            for ($i = 0; $i < 9; $i++) $sum += (int) $code[$i] * (10 - $i);
            $rem = $sum % 11;
            return ($rem < 2 && $check == $rem) || ($rem >= 2 && $check == (11 - $rem));
        }
    }

    if (!mlr_validate_iranian_national_code($national_code)) {
        wp_send_json_error(['message' => 'کد ملی وارد شده معتبر نمی‌باشد.']);
        return;
    }

    // نام پدر و شماره شناسنامه اجباری
    $father_name = isset($_POST['father_name']) ? trim(sanitize_text_field(wp_unslash($_POST['father_name']))) : '';
    $certificate_number = isset($_POST['certificate_number']) ? trim(sanitize_text_field(wp_unslash($_POST['certificate_number']))) : '';
    if (empty($father_name)) {
        wp_send_json_error(['message' => 'نام پدر الزامی است.']);
        return;
    }
    if (empty($certificate_number)) {
        wp_send_json_error(['message' => 'شماره شناسنامه الزامی است.']);
        return;
    }

    // Date Handling
    $birth_date_jalali = sanitize_text_field($_POST['birth_date'] ?? '');
    $birth_date_gregorian = null;
    // Check if helper function exists, usually in functions.php
    if (!empty($birth_date_jalali) && function_exists('mlr_jalali_to_gregorian')) {
        $birth_date_gregorian = mlr_jalali_to_gregorian($birth_date_jalali);
    } else {
        // Fallback or keep as is if function missing
        $birth_date_gregorian = $birth_date_jalali; 
    }

    // Number Handling
    $persian_numbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    $loan_amount_str = str_replace([',', '٬'], '', str_replace($persian_numbers, $english_numbers, sanitize_text_field($_POST['loan_amount'] ?? '0')));
    $loan_amount = floatval($loan_amount_str);

    // 3. Product Items Parsing
    $order_items_json = isset($_POST['order_items']) ? wp_unslash($_POST['order_items']) : '[]';
    $order_items_array = json_decode($order_items_json, true);
    $cleaned_items = [];
    $product_summary = [];
    
    if (is_array($order_items_array)) {
        foreach($order_items_array as $item) {
            if (!is_array($item)) continue;

            $qty = intval($item['qty'] ?? ($item['quantity'] ?? 1));
            if ($qty <= 0) { $qty = 1; }

            $unit_price = floatval($item['price'] ?? ($item['unit_price'] ?? 0));
            $total_price = isset($item['total_price']) ? floatval($item['total_price']) : ($qty * $unit_price);

            // Preserve common invoice fields (backward compatible)
            $cleaned_items[] = [
                'id'          => sanitize_text_field($item['id'] ?? ''),
                'name'        => sanitize_text_field($item['name'] ?? ''),
                'code'        => sanitize_text_field($item['code'] ?? ($item['id'] ?? '')),
                'description' => sanitize_text_field($item['description'] ?? ($item['name'] ?? '')),
                'qty'         => $qty,
                'quantity'    => $qty,
                'unit'        => sanitize_text_field($item['unit'] ?? ''),
                'price'       => $unit_price,
                'unit_price'  => $unit_price,
                'total_price' => $total_price,
                'meta'        => is_array($item['meta'] ?? null) ? array_map('sanitize_text_field', $item['meta']) : sanitize_text_field($item['meta'] ?? ''),
            ];
            $product_summary[] = sanitize_text_field($item['name'] ?? $item['description'] ?? '');
        }
    }
    $product_name_string = implode('، ', $product_summary);

    // 4. Base Data Construction
    
    // 4. Store full submitted form data (for auditing & details popup)
    $raw_post = $_POST;
    // Remove technical keys
    unset($raw_post['action'], $raw_post['_wpnonce'], $raw_post['nonce']);
    // Avoid storing very large blobs in form_data (files are handled separately)
    if (isset($raw_post['order_items'])) {
        // keep, but ensure it's a string (original JSON)
        $raw_post['order_items'] = sanitize_textarea_field(wp_unslash($raw_post['order_items']));
    }
    $sanitized_form_data = [];
    foreach ($raw_post as $k => $v) {
        $key = sanitize_key($k);
        if (is_array($v)) {
            $sanitized_form_data[$key] = array_map(function($vv){
                return is_scalar($vv) ? sanitize_text_field($vv) : '';
            }, $v);
        } else {
            $sanitized_form_data[$key] = is_scalar($v) ? sanitize_textarea_field(wp_unslash($v)) : '';
        }
    }
    $form_data_json = wp_json_encode($sanitized_form_data, JSON_UNESCAPED_UNICODE);

    // Extract Credit Report JSON safely
    $credit_report_raw = isset($_POST['credit_report_json']) ? wp_unslash($_POST['credit_report_json']) : null;

$data = [
        'user_id' => get_current_user_id(),
        'full_name' => sanitize_text_field($_POST['full_name'] ?? ''),
        'national_code' => $national_code,
        'mobile_number' => $mobile_number,
        'phone_number' => $phone_number,
        'birth_date' => $birth_date_gregorian,
        'occupation' => sanitize_text_field($_POST['occupation'] ?? ''),
        'residential_address' => sanitize_textarea_field($_POST['residential_address'] ?? ''),
        'postal_code' => sanitize_text_field($_POST['postal_code'] ?? ''),
        'work_address' => sanitize_textarea_field($_POST['work_address'] ?? ''),
        'product_name' => $product_name_string, // Summary string
        'order_items' => wp_json_encode($cleaned_items, JSON_UNESCAPED_UNICODE), // Full JSON
        'order_total' => isset($_POST['order_total']) ? floatval(str_replace(',', '', $_POST['order_total'])) : 0,
                'form_data'  => $form_data_json,
        'credit_report_json' => $credit_report_raw, // Save raw JSON to dedicated column
        'installment_plan_id' => intval($_POST['installment_plan_id'] ?? 0),
        'loan_amount' => $loan_amount,
        'facility_amount' => $loan_amount,
        'installment_count' => intval($_POST['installment_count'] ?? 0),
        'installment_interval' => isset($_POST['installment_interval']) ? intval($_POST['installment_interval']) : 1,
        'status' => 'در حال بررسی',
        'created_at' => current_time('mysql'),
        'last_edited_at' => current_time('mysql'),
    ];

    if (!function_exists('mlr_user_can_access_installment_plan') || !mlr_user_can_access_installment_plan($data['user_id'], $data['installment_plan_id'], true)) {
        wp_send_json_error(['message' => 'طرح انتخاب‌شده برای حساب شما مجاز نیست یا در دسترس نمی‌باشد.']);
        return;
    }

    // 5. Financial Calculations
    $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $plans_table WHERE id = %d AND is_active = 1", $data['installment_plan_id']));
    if ($plan) {
        $settings = maybe_unserialize($plan->settings);
        if (!is_array($settings)) {
            $settings = [];
        }
        $user_id = get_current_user_id();
        $user_commission = get_user_meta($user_id, 'acceptor_commission_percent', true);
        
        // Ensure constant is defined, fallback to direct path if needed
        $plugin_dir = defined('MLR_PLUGIN_DIR') ? MLR_PLUGIN_DIR : WP_PLUGIN_DIR . '/my-loan-request-plugin/';
        
        if (file_exists($plugin_dir . 'includes/loan-calculations.php')) {
            require_once $plugin_dir . 'includes/loan-calculations.php';
            
            $plan_type = is_string($plan->type) ? strtolower(trim($plan->type)) : '';
            $calc_results = [];
            if ($plan_type === 'market' && function_exists('calculateMarketLoan')) {
                $calc_results = calculateMarketLoan($data['loan_amount'], $data['installment_count'], $settings, $user_commission);
            } elseif ($plan_type === 'leasing' && function_exists('calculateLeasingLoan')) {
                // فاصله اقساط نباید صفر باشد وگرنه تابع آرایه خالی برمی‌گرداند و مبلغ تسهیلات برابر مبلغ درخواستی می‌ماند
                $interval = isset($data['installment_interval']) && (int) $data['installment_interval'] > 0 ? (int) $data['installment_interval'] : 1;
                $calc_results = calculateLeasingLoan($data['loan_amount'], $data['installment_count'], $interval, $settings, $user_commission);
            }

            if (!empty($calc_results) && isset($calc_results['loanAmount'])) {
                $data['facility_amount'] = round(floatval($calc_results['loanAmount']));
                $data['prepayment'] = $calc_results['prepayment'] ?? 0;
                $data['installment_amount'] = $calc_results['installmentAmount'] ?? 0;
                $data['wallet_charge'] = $calc_results['walletCharge'] ?? 0;
                $data['leasing_deposit_amount'] = $calc_results['netLeasingPayment'] ?? null;
                $data['acceptor_payment_amount'] = $calc_results['acceptorPayment'] ?? 0;
                $data['total_payment'] = $calc_results['totalPayment'] ?? 0;
                $data['profit'] = $calc_results['profit'] ?? 0;
                $data['final_settlement_amount'] = $data['acceptor_payment_amount'];
            }
        }
    }

    // 6. Robust File Upload Handling (پذیرش آپلود از قبل انجام‌شده یا فایل مستقیم)
    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }

    $uploaded_documents = [];

    // اول: استفاده از URLهای آپلودشده از طریق آپلود تکی (فرم جدید)
    foreach ($_POST as $post_key => $post_value) {
        if (strpos($post_key, 'mlr_uploaded_doc_') !== 0) {
            continue;
        }
        $doc_key = substr($post_key, strlen('mlr_uploaded_doc_'));
        if ($doc_key === '') {
            continue;
        }
        $urls = json_decode(stripslashes($post_value), true);
        if (is_array($urls) && !empty($urls)) {
            $uploaded_documents[$doc_key] = count($urls) > 1 ? $urls : $urls[0];
        }
    }

    // دوم: اگر فایلی از طریق فرم سنتی ارسال شده (پشتیبانی بازگشتی)
    if (!empty($_FILES)) {
        foreach ($_FILES as $input_name => $file_info) {
            $clean_key = str_replace(['[', ']'], '', $input_name);
            if (strpos($input_name, 'doc_file_') === 0) {
                $clean_key = substr($input_name, strlen('doc_file_'));
            }
            if (isset($uploaded_documents[$clean_key])) {
                continue;
            }
            if (is_array($file_info['name'])) {
                $files = mlr_rearray_files($file_info);
                $file_urls = [];
                foreach ($files as $file) {
                    if ($file['error'] === UPLOAD_ERR_OK) {
                        $upload_error = '';
                        $validated_file = mlr_validate_uploaded_file($file, $upload_error);
                        if (!$validated_file) continue;
                        $file = $validated_file;
                        $upload_overrides = ['test_form' => false];
                        $movefile = wp_handle_upload($file, $upload_overrides);
                        if ($movefile && !isset($movefile['error'])) {
                            $file_urls[] = $movefile['url'];
                        }
                    }
                }
                if (!empty($file_urls)) {
                    $uploaded_documents[$clean_key] = $file_urls;
                }
            } else {
                if ($file_info['error'] === UPLOAD_ERR_OK) {
                    $upload_error = '';
                    $validated_file = mlr_validate_uploaded_file($file_info, $upload_error);
                    if ($validated_file) {
                        $upload_overrides = ['test_form' => false];
                        $movefile = wp_handle_upload($validated_file, $upload_overrides);
                        if ($movefile && !isset($movefile['error'])) {
                            $uploaded_documents[$clean_key] = $movefile['url'];
                        }
                    }
                }
            }
        }
    }
    
    // اعتبارسنجی مدارک اجباری طرح: هیچ درخواستی بدون بارگذاری تمام مدارک اجباری ثبت نشود
    $plan_id_for_docs = intval($_POST['installment_plan_id'] ?? 0);
    if ($plan_id_for_docs > 0) {
        $plan_docs_row = $wpdb->get_row($wpdb->prepare("SELECT required_documents FROM $plans_table WHERE id = %d AND is_active = 1", $plan_id_for_docs));
        if ($plan_docs_row) {
            $required_docs_keys = maybe_unserialize($plan_docs_row->required_documents);
            if (!empty($required_docs_keys) && is_array($required_docs_keys)) {
                $missing_labels = [];
                foreach ($required_docs_keys as $req_key) {
                    $req_key = is_string($req_key) ? trim($req_key) : '';
                    if ($req_key === '') continue;
                    $value = isset($uploaded_documents[$req_key]) ? $uploaded_documents[$req_key] : null;
                    $has_value = false;
                    if (is_array($value)) {
                        $has_value = count(array_filter($value, 'is_string')) > 0;
                    } elseif (is_string($value) && $value !== '') {
                        $has_value = true;
                    }
                    if (!$has_value) {
                        if (function_exists('mlr_get_all_document_options')) {
                            $labels = mlr_get_all_document_options();
                            $missing_labels[] = isset($labels[$req_key]) ? $labels[$req_key] : $req_key;
                        } else {
                            $missing_labels[] = $req_key;
                        }
                    }
                }
                if (!empty($missing_labels)) {
                    $errors[] = 'بارگذاری تمام مدارک اجباری الزامی است. مدارک بارگذاری‌نشده: ' . implode('، ', $missing_labels);
                }
            }
        }
    }
    
    // Explicitly serialize using standard serialize()
    $data['required_documents'] = serialize($uploaded_documents);

    // Map specific files to their dedicated DB columns
    $data['bank_validation_file'] = $uploaded_documents['bank_validation_file'] ?? null;
    $data['signature_image']      = $uploaded_documents['signature_image'] ?? null;
    $data['contract_file']        = $uploaded_documents['contract_file'] ?? null;
    $data['check_images']         = isset($uploaded_documents['check_images']) ? maybe_serialize($uploaded_documents['check_images']) : null;

    // 7. Insert to Database
    if (empty($errors)) {
        // Safety: Ensure we only insert columns that exist in the DB
        // This prevents "Unknown column" errors if the DB schema update failed
        $db_columns = $wpdb->get_col("DESC `{$table_name}`", 0);
        if ($db_columns) {
            $data = array_intersect_key($data, array_flip($db_columns));
        }

        $result = $wpdb->insert($table_name, $data);
        
        if ($result === false) {
            $errors[] = "خطایی در ذخیره‌سازی اطلاعات رخ داد. لطفاً با پشتیبانی تماس بگیرید.";
            error_log("MLR Database Insert Error: " . $wpdb->last_error);
        } else {
            $new_request_id = $wpdb->insert_id;
            
            // Send SMS if function exists
            if (function_exists('mlr_send_sms_on_loan_status_change')) {
                mlr_send_sms_on_loan_status_change($new_request_id, 'در حال بررسی');
            }

            // Notification
            if (function_exists('mlr_create_notification')) {
                mlr_create_notification('new_loan', 'درخواست تسهیلات جدید توسط ' . sanitize_text_field($_POST['full_name'] ?? 'کاربر') . ' ثبت شد.', admin_url('admin.php?page=mlr-loan-requests&s=' . $new_request_id));
            }
            
            // Success Response
            $user_requests_page_url = home_url('/panel/');
            if (!empty($request_id)) {
        if (function_exists('mlr_add_request_event')) {
            mlr_add_request_event($request_id, 'created', 'ثبت اولیه درخواست');
        }
    }

    wp_send_json_success([
                'message' => 'درخواست شما با موفقیت ثبت شد.', 
                'redirect_url' => esc_url($user_requests_page_url)
            ]);
        }
    }

    // 8. Error Response
    if (!empty($errors)) {
        wp_send_json_error(['message' => implode('<br>', $errors)]);
    }
}
?>
