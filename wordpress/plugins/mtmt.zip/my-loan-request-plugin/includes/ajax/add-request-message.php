<?php
// FILE: my-loan-request-plugin/includes/ajax/add-request-message.php
if (!defined('ABSPATH')) { exit; }

add_action('wp_ajax_mlr_add_request_message', 'mlr_add_request_message_callback');

function mlr_add_request_message_callback() {
    if (!function_exists('mlr_verify_any_nonce') || !mlr_verify_any_nonce('nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی.']);
        return;
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای ارسال پیام، ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $message    = isset($_POST['message']) ? wp_kses_post(wp_unslash($_POST['message'])) : '';
    $attachments_json = null;
    $uploaded_files = [];

    // Handle file uploads
    if (!empty($_FILES['attachments'])) {
        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        $files = $_FILES['attachments'];
        $upload_overrides = ['test_form' => false];

        // Normalize the $_FILES array for multiple uploads
        $file_ary = [];
        if (is_array($files['name'])) {
            foreach ($files['name'] as $key => $value) {
                if ($files['name'][$key]) {
                    $file_ary[] = ['name' => $files['name'][$key], 'type' => $files['type'][$key], 'tmp_name' => $files['tmp_name'][$key], 'error' => $files['error'][$key], 'size' => $files['size'][$key]];
                }
            }
        } else {
            $file_ary[] = $files;
        }

        foreach ($file_ary as $file) {
            $movefile = wp_handle_upload($file, $upload_overrides);
            if ($movefile && !isset($movefile['error'])) {
                $uploaded_files[] = ['url' => $movefile['url'], 'name' => basename($movefile['file'])];
            } else {
                // Log error if upload fails
                if (function_exists('mlr_log')) mlr_log("Message Attachment Upload Error: " . ($movefile['error'] ?? 'Unknown error'));
            }
        }
    }

    if (!empty($uploaded_files)) {
        $attachments_json = wp_json_encode($uploaded_files, JSON_UNESCAPED_UNICODE);
    }

    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر.']);
        return;
    }
    if (trim(wp_strip_all_tags($message)) === '' && empty($uploaded_files)) {
        wp_send_json_error(['message' => 'متن پیام یا فایل پیوست الزامی است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $req = $wpdb->get_row($wpdb->prepare("SELECT id, user_id, applicant_user_id, acceptor_user_id, request_origin, assigned_bank_user_id, status, settlement_status FROM {$table_name} WHERE id=%d", $request_id));
    if (!$req) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }
    // امکان ارسال پیام برای همه پرونده‌ها از جمله وضعیت «تسویه شده» (بر اساس دسترسی کاربر)

    $is_admin = current_user_can('manage_options');

    if (!function_exists('mlr_can_access_loan_request') || !mlr_can_access_loan_request($req)) {
        wp_send_json_error(['message' => 'دسترسی ندارید.']);
        return;
    }

    if (!function_exists('mlr_add_request_message')) {
        wp_send_json_error(['message' => 'زیرساخت پیام‌ها فعال نیست.']);
        return;
    }

    $insert_id = mlr_add_request_message($request_id, $message, $attachments_json);

    if (!$insert_id) {
        wp_send_json_error(['message' => 'ارسال پیام ناموفق بود.']);
        return;
    }

    if (function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'message', 'ارسال پیام جدید');
    }

    // Notify all admins on every new message (from user or from admin)
    if (function_exists('mlr_create_notification')) {
        $sender_label = $is_admin ? 'ادمین' : 'کاربر';
        mlr_create_notification('new_message', 'پیام جدید از ' . $sender_label . ' برای درخواست #' . $request_id, admin_url('admin.php?page=mlr-loan-requests&s=' . $request_id));
    }

    // Return latest thread
    $existing_comments_json = $wpdb->get_var($wpdb->prepare("SELECT comments FROM {$table_name} WHERE id = %d", $request_id));
    $comments = !empty($existing_comments_json) ? json_decode($existing_comments_json, true) : [];
    if (!is_array($comments)) { $comments = []; }
    if (function_exists('mlr_get_request_messages')) {
        $msgs = mlr_get_request_messages($request_id, 500);
    } else {
        $msgs = [];
    }

    wp_send_json_success([
        'message' => 'پیام ارسال شد.',
        'messages_html' => function_exists('mlr_render_request_messages_html') ? mlr_render_request_messages_html($msgs) : '',
        'conversation_html' => function_exists('mlr_render_request_conversation_html') ? mlr_render_request_conversation_html($comments, $msgs) : ''
    ]);
}
