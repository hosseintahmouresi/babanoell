<?php
/**
 * AJAX: آپلود تکی فایل برای فرم درخواست تسهیلات و فرم درخواست همکاری.
 * فایل به‌صورت جدا آپلود می‌شود تا از timeout و حجم زیاد درخواست نهایی جلوگیری شود.
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_upload_single_file', 'mlr_upload_single_file_callback');
add_action('wp_ajax_nopriv_mlr_upload_single_file', 'mlr_upload_single_file_callback');

function mlr_upload_single_file_callback() {
    while (ob_get_level()) {
        ob_end_clean();
    }

    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    $context = isset($_POST['context']) ? sanitize_text_field(wp_unslash($_POST['context'])) : '';
    $field_key = isset($_POST['field_key']) ? sanitize_key(wp_unslash($_POST['field_key'])) : '';

    $valid_nonce = wp_verify_nonce($nonce, 'mlr_loan_request_action') || wp_verify_nonce($nonce, 'mlr_applicant_loan_request_action') || wp_verify_nonce($nonce, 'mlr_cooperation_request_action') || wp_verify_nonce($nonce, 'mlr_frontend_nonce');
    if (!$valid_nonce) {
        wp_send_json_error(['message' => 'اعتبار فرم منقضی شده است. صفحه را رفرش کنید.']);
        return;
    }

    if (!in_array($context, ['loan_request', 'cooperation_request'], true)) {
        wp_send_json_error(['message' => 'پارامتر context نامعتبر است.']);
        return;
    }

    $input_name = isset($_POST['input_name']) ? sanitize_text_field(wp_unslash($_POST['input_name'])) : 'file';
    if (!isset($_FILES[$input_name]) || $_FILES[$input_name]['error'] === UPLOAD_ERR_NO_FILE) {
        wp_send_json_error(['message' => 'فایلی انتخاب نشده است.']);
        return;
    }

    $file = $_FILES[$input_name];
    $max_size_mb = 5;
    $max_bytes = $max_size_mb * 1024 * 1024;

    if ($file['size'] > $max_bytes) {
        wp_send_json_error(['message' => sprintf('حداکثر حجم هر فایل %d مگابایت است.', $max_size_mb)]);
        return;
    }

    $err = '';
    if (!function_exists('mlr_validate_uploaded_file')) {
        wp_send_json_error(['message' => 'تابع اعتبارسنجی فایل در دسترس نیست.']);
        return;
    }
    $validated = mlr_validate_uploaded_file($file, $err);
    if (!$validated) {
        wp_send_json_error(['message' => 'نوع یا فرمت فایل مجاز نیست. فقط jpg, png, pdf.']);
        return;
    }

    if (!function_exists('wp_handle_upload')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }

    $overrides = ['test_form' => false];
    $movefile = wp_handle_upload($validated, $overrides);

    if ($movefile && !isset($movefile['error'])) {
        wp_send_json_success(['url' => $movefile['url']]);
        return;
    }

    wp_send_json_error(['message' => isset($movefile['error']) ? $movefile['error'] : 'خطا در ذخیره فایل.']);
}
