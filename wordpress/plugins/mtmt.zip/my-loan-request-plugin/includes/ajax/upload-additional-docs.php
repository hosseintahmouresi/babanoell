<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

add_action('wp_ajax_mlr_upload_additional_docs', 'mlr_upload_additional_docs_callback');

function mlr_upload_additional_docs_callback() {
    // 1. Security and Permission Checks
    // Nonce is checked against 'mlr_frontend_nonce' which is localized as 'details_nonce' in mlr-user-requests.js
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای بارگذاری مدارک، لطفاً ابتدا وارد شوید.']);
        return;
    }

    // 2. Input Validation
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    // Detect the correct file input key (backward compatible)
    // Frontend may send "additional_files[]" or "additional_documents[]"
    $file_input_key = '';
    if (!empty($_FILES['additional_files'])) {
        $file_input_key = 'additional_files';
    } elseif (!empty($_FILES['additional_documents'])) {
        $file_input_key = 'additional_documents';
    }

    if (empty($file_input_key) || empty($_FILES[$file_input_key]['name']) || (is_array($_FILES[$file_input_key]['name']) && empty(array_filter($_FILES[$file_input_key]['name'])))) {
        wp_send_json_error(['message' => 'هیچ فایلی برای بارگذاری انتخاب نشده است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $user_id = get_current_user_id();

    // Verify the user owns this request and is currently in the correct status
    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT required_documents, status FROM $table_name WHERE id = %d AND user_id = %d",
        $request_id,
        $user_id
    ));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }

    if ($request->status !== 'نقص مدارک') {
        wp_send_json_error(['message' => 'درخواست مورد نظر در حال حاضر در وضعیت "نقص مدارک" نیست.']);
        return;
    }

    // 3. File Upload Handling
    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }

    $files = $_FILES[$file_input_key];
    $uploaded_urls = [];
    $errors = [];

    $upload_overrides = array('test_form' => false);

    if (is_array($files['name'])) {
        $file_count = count($files['name']);
        for ($i = 0; $i < $file_count; $i++) {
            if (empty($files['name'][$i])) {
                continue;
            }

            if ($files['error'][$i] !== UPLOAD_ERR_OK) {
                $upload_errors = [
                    UPLOAD_ERR_INI_SIZE   => 'حجم فایل از حد مجاز PHP (php.ini) بیشتر است.',
                    UPLOAD_ERR_FORM_SIZE  => 'حجم فایل از حد مجاز فرم بیشتر است.',
                    UPLOAD_ERR_PARTIAL    => 'فایل به صورت ناقص آپلود شد.',
                    UPLOAD_ERR_NO_FILE    => 'هیچ فایلی انتخاب نشد.',
                    UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت سرور وجود ندارد.',
                    UPLOAD_ERR_CANT_WRITE => 'امکان نوشتن فایل روی دیسک وجود ندارد.',
                    UPLOAD_ERR_EXTENSION  => 'یک افزونه PHP آپلود را متوقف کرد.'
                ];
                $error_msg = $upload_errors[$files['error'][$i]] ?? 'خطای نامشخص آپلود (کد: ' . $files['error'][$i] . ')';
                $errors[] = 'خطا در فایل "' . esc_html($files['name'][$i]) . '": ' . $error_msg;
                if (function_exists('mlr_log')) {
                    mlr_log("PHP Upload error for additional_docs for request {$request_id}, file {$files['name'][$i]}: {$error_msg}");
                }
                continue;
            }

            $single_file = [
                'name'     => $files['name'][$i],
                'type'     => $files['type'][$i],
                'tmp_name' => $files['tmp_name'][$i],
                'error'    => $files['error'][$i],
                'size'     => $files['size'][$i],
            ];

            $allowed_mimes = [
                'jpg|jpeg|jpe' => 'image/jpeg',
                'png'          => 'image/png',
                'pdf'          => 'application/pdf',
            ];
            $allowed_exts = ['jpg', 'jpeg', 'jpe', 'png', 'pdf'];

            $max_size = 10 * 1024 * 1024;
            if (function_exists('wp_max_upload_size')) {
                $max_size = min($max_size, wp_max_upload_size());
            }

            $filetype = wp_check_filetype_and_ext($single_file['tmp_name'], $single_file['name']);
            $detected_ext  = isset($filetype['ext']) ? strtolower($filetype['ext']) : '';
            $detected_mime = isset($filetype['type']) ? strtolower($filetype['type']) : '';

            if (empty($detected_ext) || empty($detected_mime) || !in_array($detected_ext, $allowed_exts, true) || !in_array($detected_mime, array_values($allowed_mimes), true)) {
                $errors[] = 'فایل "' . esc_html($single_file['name']) . '" دارای نوع غیرمجاز است.';
                continue;
            }

            if ($single_file['size'] > $max_size) {
                $errors[] = 'فایل "' . esc_html($single_file['name']) . '" بزرگتر از حجم مجاز است.';
                continue;
            }

$upload_result = wp_handle_upload($single_file, array_merge($upload_overrides, ['mimes' => $allowed_mimes]));

            if (isset($upload_result['error'])) {
                $errors[] = 'خطا در آپلود فایل "' . esc_html($single_file['name']) . '": ' . esc_html($upload_result['error']);
                if (function_exists('mlr_log')) {
                    mlr_log("wp_handle_upload error for request {$request_id}, file {$single_file['name']}: {$upload_result['error']}");
                }
            } else {
                $uploaded_urls[] = esc_url_raw($upload_result['url']);
            }
        }
    } else {
        if ($files['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => 'خطا در آپلود فایل.']);
            return;
        }

        $allowed_mimes = [
            'jpg|jpeg|jpe' => 'image/jpeg',
            'png'          => 'image/png',
            'pdf'          => 'application/pdf',
        ];
        $allowed_exts = ['jpg', 'jpeg', 'jpe', 'png', 'pdf'];

        $max_size = 10 * 1024 * 1024;
        if (function_exists('wp_max_upload_size')) {
            $max_size = min($max_size, wp_max_upload_size());
        }

        $filetype = wp_check_filetype_and_ext($files['tmp_name'], $files['name']);
        $detected_ext  = isset($filetype['ext']) ? strtolower($filetype['ext']) : '';
        $detected_mime = isset($filetype['type']) ? strtolower($filetype['type']) : '';

        if (empty($detected_ext) || empty($detected_mime) || !in_array($detected_ext, $allowed_exts, true) || !in_array($detected_mime, array_values($allowed_mimes), true)) {
            wp_send_json_error(['message' => 'نوع فایل غیرمجاز است.']);
            return;
        }

        if ($files['size'] > $max_size) {
            wp_send_json_error(['message' => 'حجم فایل بزرگتر از حد مجاز است.']);
            return;
        }

$upload_result = wp_handle_upload($files, array_merge($upload_overrides, ['mimes' => $allowed_mimes]));

        if (isset($upload_result['error'])) {
            wp_send_json_error(['message' => 'خطا در آپلود فایل: ' . esc_html($upload_result['error'])]);
            return;
        } else {
            $uploaded_urls[] = esc_url_raw($upload_result['url']);
        }
    }

    if (empty($uploaded_urls)) {
        if (!empty($errors)) {
            wp_send_json_error(['message' => implode('<br>', $errors)]);
        } else {
            wp_send_json_error(['message' => 'هیچ فایل معتبری برای بارگذاری وجود ندارد.']);
        }
        return;
    }

    // 4. Update Required Documents + Status
    $existing_documents = function_exists('mlr_get_request_uploaded_documents')
        ? mlr_get_request_uploaded_documents($request->required_documents)
        : maybe_unserialize($request->required_documents);
    if (!is_array($existing_documents)) {
        $existing_documents = [];
    }

    if (!isset($existing_documents['additional_documents']) || !is_array($existing_documents['additional_documents'])) {
        $existing_documents['additional_documents'] = [];
    }

    $existing_documents['additional_documents'] = array_merge($existing_documents['additional_documents'], $uploaded_urls);

    $new_status = 'در حال بررسی';

    $update_data = [
        'required_documents' => serialize($existing_documents), // Save all documents back
        'status'             => $new_status,                   // Update status
        'last_edited_at'     => current_time('mysql')          // Update modification time
    ];

    $updated = $wpdb->update(
        $table_name,
        $update_data,
        ['id' => $request_id] // Where clause
    );

    if ($updated === false && !empty($wpdb->last_error) && strpos($wpdb->last_error, "Unknown column 'last_edited_at'") !== false) {
        unset($update_data['last_edited_at']);
        $updated = $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $request_id]
        );
    }

    if ($updated === false) {
        if (function_exists('mlr_log')) {
            mlr_log("Database Error updating request ID {$request_id} after additional doc upload: " . $wpdb->last_error);
        }
        wp_send_json_error(['message' => 'خطایی در به‌روزرسانی درخواست رخ داد.']);
        return;
    }

    // 5. Send Notifications
    if (function_exists('mlr_send_sms_on_loan_status_change')) {
        mlr_send_sms_on_loan_status_change($request_id, $new_status);
    }

    // Notification
    if (function_exists('mlr_create_notification')) {
        mlr_create_notification('status_change', 'مدارک تکمیلی برای درخواست #' . $request_id . ' ارسال شد.', admin_url('admin.php?page=mlr-loan-requests&s=' . $request_id));
    }

    // 6. Send Success Response
    if (function_exists('mlr_add_request_event')) { mlr_add_request_event($request_id, 'upload_additional_docs', 'بارگذاری مدارک تکمیلی'); }
    wp_send_json_success(['message' => 'مدارک با موفقیت ارسال شد و درخواست شما مجدداً به وضعیت "در حال بررسی" منتقل گردید.']);
}
?>
