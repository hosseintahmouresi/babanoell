<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_update_document_receipt_status', 'mlr_update_document_receipt_status_callback');

function mlr_update_document_receipt_status_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!function_exists('mlr_can_manage_document_receipt_status') || !mlr_can_manage_document_receipt_status()) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای تغییر وضعیت دریافت مدارک را ندارید.']);
    }

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    if ($request_id <= 0) {
        wp_send_json_error(['message' => 'شناسه پرونده نامعتبر است.']);
    }

    $raw_status = isset($_POST['document_receipt_status']) ? wp_unslash($_POST['document_receipt_status']) : '';
    $new_status = function_exists('mlr_normalize_document_receipt_status')
        ? mlr_normalize_document_receipt_status($raw_status)
        : 'بررسی نشده';

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $request_row = $wpdb->get_row($wpdb->prepare("SELECT id, document_receipt_status FROM {$table_name} WHERE id = %d", $request_id));

    if (!$request_row) {
        wp_send_json_error(['message' => 'پرونده موردنظر یافت نشد.']);
    }

    $current_status = function_exists('mlr_get_document_receipt_status_label')
        ? mlr_get_document_receipt_status_label($request_row->document_receipt_status ?? '')
        : trim((string) ($request_row->document_receipt_status ?? ''));

    if ($current_status === $new_status) {
        wp_send_json_success([
            'message' => 'وضعیت دریافت مدارک بدون تغییر باقی ماند.',
            'document_receipt_status_display' => $new_status,
        ]);
    }

    $updated = $wpdb->update(
        $table_name,
        ['document_receipt_status' => $new_status],
        ['id' => $request_id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطا در ذخیره وضعیت دریافت مدارک.']);
    }

    if (function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'document_receipt_status_change', 'تغییر وضعیت دریافت مدارک به: ' . $new_status);
    }

    wp_send_json_success([
        'message' => 'وضعیت دریافت مدارک با موفقیت ذخیره شد.',
        'document_receipt_status_display' => $new_status,
    ]);
}
