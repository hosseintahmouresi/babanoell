<?php
// FILE: my-loan-request-plugin/includes/ajax/get-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_request_details', 'mlr_get_request_details_callback');

function mlr_get_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'عدم دسترسی.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }
    
    // Occupations Mapping
    $occupations = [
        'official_employee' => 'کارمند رسمی',
        'contract_employee' => 'کارمند قراردادی',
        'worker' => 'کارگر',
        'freelancer' => 'آزاد',
        'retired' => 'بازنشسته',
        'pensioner' => 'مستمری بگیر',
        'employer' => 'کارفرما',
        'other' => 'سایر'
    ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : esc_html($request->occupation);

    // Documents & Items Processing
    $uploaded_documents = maybe_unserialize($request->required_documents);

    // --- MLR EXTRA DETAILS SECTION (ADMIN) ---
    // فقط نمایش کامل‌تر جزئیات؛ منطق ذخیره/عملیات را تغییر نمی‌دهد.
    $extra_files = [];
    $extra_files['bank_validation_file'] = $request->bank_validation_file ?? '';
    $extra_files['signature_image']      = $request->signature_image ?? '';
    $extra_files['contract_file']        = $request->contract_file ?? '';

    $parsed_check_images = [];
    if (!empty($request->check_images)) {
        $maybe = maybe_unserialize($request->check_images);
        if (is_array($maybe)) {
            $parsed_check_images = $maybe;
        } else {
            $json = json_decode($request->check_images, true);
            if (is_array($json)) {
                $parsed_check_images = $json;
            } else {
                $parts = preg_split('/[\r\n,]+/', (string)$request->check_images);
                $parts = array_filter(array_map('trim', $parts));
                $parsed_check_images = $parts ? $parts : [(string)$request->check_images];
            }
        }
    }
    if (!empty($parsed_check_images)) {
        $extra_files['check_images'] = $parsed_check_images;
    }

    $extra_file_labels = [
        'bank_validation_file' => 'فایل اعتبارسنجی بانک',
        'signature_image'      => 'تصویر امضا',
        'contract_file'        => 'فایل قرارداد',
        'check_images'         => 'تصاویر چک',
    ];
    // --- END: MLR EXTRA DETAILS SECTION (ADMIN) ---
    $order_items = !empty($request->order_items) ? json_decode($request->order_items, true) : [];
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    $form_data = !empty($request->form_data) ? json_decode($request->form_data, true) : [];
    if (!is_array($form_data)) { $form_data = []; }
    
    // استخراج گزارش اعتبارسنجی
    $credit_report = null;
    if (!empty($request->credit_report_json)) {
        $credit_report = json_decode($request->credit_report_json, true);
    } elseif (isset($form_data['credit_report_json'])) {
        $cr_data = $form_data['credit_report_json'];
        if (is_string($cr_data)) {
            $credit_report = json_decode($cr_data, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $credit_report = json_decode(stripslashes($cr_data), true);
            }
        } else {
            $credit_report = $cr_data;
        }
    }

    // حذف از form_data
    if (isset($form_data['credit_report_json'])) {
        unset($form_data['credit_report_json']);
    }

    $form_data_labels = [
        'full_name'            => 'نام کامل',
        'father_name'          => 'نام پدر',
        'certificate_number'   => 'شماره شناسنامه',
        'certificate_city'     => 'شهر صدور شناسنامه',
        'national_code'        => 'کد ملی',
        'mobile_number'        => 'شماره موبایل',
        'phone_number'         => 'تلفن ثابت',
        'birth_date'           => 'تاریخ تولد',
        'birth_day'            => 'روز تولد',
        'birth_month'          => 'ماه تولد',
        'birth_year'           => 'سال تولد',
        'occupation'           => 'شغل',
        'postal_code'          => 'کد پستی',
        'residential_address'  => 'آدرس محل سکونت',
        'order_items'          => 'اقلام سفارش',
        'installment_plan_id'  => 'شناسه طرح اقساط',
        'plan_id'              => 'شناسه طرح',
        'loan_amount'          => 'مبلغ وام',
        'installment_count'    => 'تعداد اقساط',
        'installment_interval' => 'فاصله اقساط (ماه)',
        'guarantee_check_principal' => 'مبلغ چک ضمانت (اصل)',
        'guarantee_check_total'     => 'مبلغ چک ضمانت (اصل و فرع)',
        'prepayment'           => 'پیش پرداخت',
        'wallet_charge'        => 'اعتبار خرید',
        'comments'             => 'توضیحات',
        'address'              => 'آدرس',
    ];

    $request_events = function_exists('mlr_get_request_events') ? mlr_get_request_events($request_id, 500) : [];
    $request_messages = function_exists('mlr_get_request_messages') ? mlr_get_request_messages($request_id, 500) : [];
    
    // Get document labels from helper if exists, or use keys
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    // --- Data Preparation for Unified View ---
    $sections = [
        'identity' => [
            'title' => 'اطلاعات هویتی و تماس',
            'icon' => 'dashicons-id',
            'fields' => [
                ['label' => 'نام و نام خانوادگی', 'value' => $request->full_name],
                ['label' => 'کد ملی', 'value' => $request->national_code],
                ['label' => 'نام پدر', 'value' => $form_data['father_name'] ?? '-'],
                ['label' => 'شماره شناسنامه', 'value' => $form_data['certificate_number'] ?? '-'],
                ['label' => 'صادره از', 'value' => $form_data['certificate_city'] ?? '-'],
                ['label' => 'تاریخ تولد', 'value' => function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->birth_date) : $request->birth_date],
                ['label' => 'شماره موبایل', 'value' => $request->mobile_number],
                ['label' => 'تلفن ثابت', 'value' => $request->phone_number ?: '-'],
            ]
        ],
        'job_addr' => [
            'title' => 'اطلاعات شغلی و سکونت',
            'icon' => 'dashicons-location',
            'fields' => [
                ['label' => 'شغل', 'value' => $occupation_display],
                ['label' => 'کد پستی', 'value' => $request->postal_code ?: '-'],
                ['label' => 'آدرس سکونت', 'value' => $request->residential_address ?: '-', 'wide' => true],
                ['label' => 'آدرس محل کار', 'value' => $request->work_address ?: '-', 'wide' => true],
            ]
        ],
        'financial' => [
            'title' => 'اطلاعات مالی و طرح',
            'icon' => 'dashicons-chart-line',
            'fields' => [
                ['label' => 'نام طرح', 'value' => $request->plan_name],
                ['label' => 'مبلغ تسهیلات', 'value' => number_format($request->loan_amount) . ' ریال'],
                ['label' => 'تعداد اقساط', 'value' => $request->installment_count . ' قسط'],
                ['label' => 'مبلغ هر قسط', 'value' => number_format($request->installment_amount) . ' ریال'],
                ['label' => 'پیش‌پرداخت', 'value' => number_format($request->prepayment) . ' ریال'],
                ['label' => 'اعتبار خرید', 'value' => number_format($request->wallet_charge) . ' ریال'],
                ['label' => 'مبلغ چک ضمانت (اصل)', 'value' => isset($form_data['guarantee_check_principal']) ? number_format((float)$form_data['guarantee_check_principal']) . ' ریال' : '-'],
                ['label' => 'مبلغ چک ضمانت (کل)', 'value' => isset($form_data['guarantee_check_total']) ? number_format((float)$form_data['guarantee_check_total']) . ' ریال' : '-'],
                ['label' => 'وضعیت درخواست', 'value' => $request->status, 'is_status' => true],
            ]
        ]
    ];


    ob_start();
    ?>
    <div class="mlr-glass-wrapper">
        <div class="mlr-glass-header">
            <div class="mlr-header-title">
                <span class="dashicons dashicons-admin-generic"></span>
                <h3>مدیریت درخواست <span class="mlr-highlight">#<?php echo esc_html($request->id); ?></span></h3>
                <button type="button" class="mlr-btn mlr-btn-secondary mlr-export-single-excel-btn" data-id="<?php echo esc_attr($request->id); ?>" style="margin-right: 15px; height: 32px; padding: 0 15px; font-size: 12px; display: inline-flex; align-items: center; gap: 5px; cursor: pointer;">
                    <span class="dashicons dashicons-media-spreadsheet" style="font-size: 16px;"></span>
                    خروجی اکسل پرونده
                </button>
            </div>
            <span class="mlr-glass-badge status-<?php echo sanitize_html_class($request->status); ?>"><?php echo esc_html($request->status); ?></span>
        </div>

    <div class="mlr-glass-body">

        <div class="mlr-glass-card">
            <h4 class="mlr-card-title">
                <span class="dashicons dashicons-format-chat"></span>
                <span>گفتگو و یادداشت‌های پرونده</span>
            </h4>
                <div class="mlr-conversation-history" id="mlr-conversation-timeline-container" data-request-id="<?php echo esc_attr($request->id); ?>">
                    <?php echo function_exists('mlr_render_request_conversation_html') ? mlr_render_request_conversation_html($comments, $request_messages) : ''; ?>
                </div>

                <div class="mlr-conversation-compose">
                    <textarea id="mlr_new_comment_text" rows="3" class="mlr-glass-input" placeholder="متن پیام یا یادداشت داخلی..."></textarea>

                    <div class="mlr-attachment-controls">
                        <label for="mlr-message-attachment-input" class="mlr-attachment-btn">
                            <span class="dashicons dashicons-paperclip"></span> پیوست فایل به پیام
                        </label>
                        <input type="file" id="mlr-message-attachment-input" multiple style="display:none;">
                        <div id="mlr-attachment-previews"></div>
                    </div>

                    <div class="mlr-conversation-actions">
                        <button type="button" class="mlr-btn mlr-btn-primary mlr-send-message-btn" data-request-id="<?php echo esc_attr($request->id); ?>">
                            <span class="dashicons dashicons-send"></span>
                            ارسال پیام
                        </button>

                        <button type="button" class="mlr-btn mlr-btn-secondary" id="mlr-add-comment-btn" data-id="<?php echo esc_attr($request->id); ?>">
                            ثبت یادداشت (داخلی)
                        </button>
                        <span class="spinner" aria-hidden="true"></span>

                        <button type="button" class="mlr-btn mlr-btn-secondary mlr-refresh-messages-btn" data-request-id="<?php echo esc_attr($request->id); ?>">
                            <span class="dashicons dashicons-update"></span>
                            به‌روزرسانی
                        </button>
                    </div>
                </div>
        </div>

        <!-- Unified Info Sections -->
        <div class="mlr-data-grid">
            <?php foreach ($sections as $key => $section): ?>
                <div class="mlr-glass-card">
                    <h5 class="mlr-card-title"><span class="dashicons <?php echo esc_attr($section['icon']); ?>"></span> <?php echo esc_html($section['title']); ?></h5>
                    <?php foreach ($section['fields'] as $field): ?>
                        <div class="mlr-data-row <?php echo !empty($field['wide']) ? 'mlr-row-wide' : ''; ?>">
                            <span class="mlr-data-label"><?php echo esc_html($field['label']); ?></span>
                            <span class="mlr-data-value <?php echo !empty($field['is_status']) ? 'mlr-status-text' : ''; ?>">
                                <?php echo esc_html($field['value']); ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="mlr-glass-card">
            <h4 class="mlr-card-title"><span class="dashicons dashicons-media-text"></span> اطلاعات تکمیلی و مالی</h4>
            <div class="mlr-data-grid">
                <?php if (!empty($request->product_name)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">نام کالا</span><span class="mlr-data-value"><?php echo esc_html($request->product_name); ?></span></div>
                <?php endif; ?>
                <?php if (!empty($request->order_total)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">جمع کل سفارش</span><span class="mlr-data-value"><?php echo number_format((int)$request->order_total); ?> ریال</span></div>
                <?php endif; ?>
                <?php if (!empty($request->wallet_charge)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">اعتبار خرید</span><span class="mlr-data-value"><?php echo number_format((int)$request->wallet_charge); ?> ریال</span></div>
                <?php endif; ?>
                <?php if (!empty($request->profit)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">سود</span><span class="mlr-data-value"><?php echo number_format((int)$request->profit); ?> ریال</span></div>
                <?php endif; ?>
                <?php if (!empty($request->acceptor_payment_amount)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">پرداخت پذیرنده</span><span class="mlr-data-value"><?php echo number_format((int)$request->acceptor_payment_amount); ?> ریال</span></div>
                <?php endif; ?>
                <?php if (!empty($request->final_settlement_amount)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">تسویه نهایی</span><span class="mlr-data-value"><?php echo number_format((int)$request->final_settlement_amount); ?> ریال</span></div>
                <?php endif; ?>
                <?php if (!empty($request->settlement_status)): ?>
                    <div class="mlr-data-row"><span class="mlr-data-label">وضعیت تسویه</span><span class="mlr-data-value"><?php echo esc_html($request->settlement_status); ?></span></div>
                <?php endif; ?>
            </div>
            <?php if (!empty($request->description)): ?>
                <div style="margin-top:15px; padding-top:15px; border-top:1px dashed rgba(29,53,88,0.1);">
                    <span class="mlr-data-label" style="display:block; margin-bottom:5px;">توضیحات:</span>
                    <div class="mlr-data-value" style="font-weight:normal; line-height:1.6;"><?php echo nl2br(esc_html($request->description)); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($extra_files) && is_array($extra_files)): ?>
            <div class="mlr-glass-card">
                <h4 class="mlr-card-title"><span class="dashicons dashicons-paperclip"></span> فایل‌های تکمیلی</h4>
                <div class="mlr-file-grid">
                    <?php foreach ($extra_files as $fkey => $fval):
                        if (empty($fval)) { continue; }
                        $label = isset($extra_file_labels[$fkey]) ? $extra_file_labels[$fkey] : (function_exists('mlr_get_field_label') ? mlr_get_field_label($fkey) : ucfirst(str_replace('_',' ', $fkey)));
                    ?>
                        <div class="mlr-file-item">
                            <div class="mlr-file-label"><?php echo esc_html($label); ?></div>
                            <?php if (is_array($fval)): ?>
                                <div class="mlr-file-actions">
                                    <?php foreach ($fval as $idx => $url): if (empty($url)) { continue; } ?>
                                        <a href="<?php echo esc_url($url); ?>" target="_blank" class="mlr-btn mlr-btn-secondary mlr-view-file-btn" style="padding: 5px 10px; font-size: 12px;">
                                            مشاهده <?php echo intval($idx)+1; ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <a href="<?php echo esc_url($fval); ?>" target="_blank" class="mlr-btn mlr-btn-secondary mlr-view-file-btn" style="padding: 5px 10px; font-size: 12px;">مشاهده فایل</a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($order_items)): ?>
            <div class="mlr-glass-card">
                <h4 class="mlr-card-title"><span class="dashicons dashicons-cart"></span> ریز اقلام درخواستی</h4>
                <div class="mlr-table-wrapper">
                    <table class="mlr-report-table">
                        <thead>
                            <tr>
                                <th>نام کالا</th>
                                <th>تعداد</th>
                                <th>قیمت واحد (ریال)</th>
                                <th>قیمت کل (ریال)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($order_items as $item):
                                $price = floatval($item['price'] ?? 0);
                                $qty = intval($item['qty'] ?? 1);
                            ?>
                                <tr>
                                    <td><?php echo esc_html($item['name']); ?></td>
                                    <td><?php echo $qty; ?></td>
                                    <td><?php echo number_format($price); ?></td>
                                    <td><?php echo number_format($price * $qty); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <div class="mlr-glass-card mlr-docs-card" data-default-cat="">
            <h4 class="mlr-card-title"><span class="dashicons dashicons-paperclip"></span> مدارک و فایل‌ها</h4>
            <?php
                $grouped_docs = function_exists('mlr_group_uploaded_documents_by_category') ? mlr_group_uploaded_documents_by_category($uploaded_documents, $all_doc_labels) : [];
                $cat_labels = function_exists('mlr_get_document_category_labels') ? mlr_get_document_category_labels() : [];
                $default_cat = '';
                if (!empty($grouped_docs) && is_array($grouped_docs)) {
                    $keys = array_keys($grouped_docs);
                    $default_cat = isset($keys[0]) ? (string)$keys[0] : '';
                }
            ?>
            <?php if (!empty($grouped_docs)): ?>
                <div class="mlr-docs-categories" role="tablist" aria-label="دسته‌بندی مدارک">
                    <?php foreach ($grouped_docs as $cat => $items): 
                        $lbl = isset($cat_labels[$cat]) ? $cat_labels[$cat] : $cat;
                    ?>
                        <button type="button" class="mlr-btn mlr-btn-secondary mlr-doc-cat-btn" data-cat="<?php echo esc_attr($cat); ?>">
                            <?php echo esc_html($lbl); ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <div class="mlr-docs-sections">
                    <?php foreach ($grouped_docs as $cat => $items): ?>
                        <div class="mlr-doc-cat-section" data-cat="<?php echo esc_attr($cat); ?>" style="display:none;">
                            <div class="mlr-file-grid">
                                <?php foreach ($items as $doc): ?>
                                    <div class="mlr-file-item">
                                        <div class="mlr-file-label"><?php echo esc_html($doc['label']); ?></div>
                                        <div class="mlr-file-actions">
                                            <?php foreach ($doc['urls'] as $i => $url): ?>
                                                <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" class="mlr-btn mlr-btn-secondary mlr-view-file-btn" style="padding: 5px 10px; font-size: 12px;">
                                                    <span class="dashicons dashicons-visibility" aria-hidden="true"></span>
                                                    <?php echo (count($doc['urls']) > 1) ? ('مشاهده ' . intval($i + 1)) : 'مشاهده فایل'; ?>
                                                </a>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <style>
                    
                </style>
            <?php else: ?>
                <p class="mlr-text-muted">هیچ مدرکی بارگذاری نشده است.</p>
            <?php endif; ?>
        </div>

        <div class="mlr-glass-card">
            <h4 class="mlr-card-title"><span class="dashicons dashicons-list-view"></span> مراحل و رویدادهای پرونده</h4>
            <div class="mlr-events-container">
                <?php echo function_exists('mlr_render_request_events_html') ? mlr_render_request_events_html($request_events) : ''; ?>
            </div>
        </div>

        <?php if ($credit_report): ?>
            <div class="mlr-glass-card mlr-report-container" style="padding: 0; overflow: hidden;">
                    <?php
                        // Helper for formatting
                        $fmt = function($n) { return number_format((float)$n); };
                        
                        // Extract Data
                        $scoreObj = $credit_report['score'] ?? [];
                        $reportObj = $credit_report['report'] ?? [];
                        
                        $score = $scoreObj['score'] ?? 0;
                        $risk = $scoreObj['risk'] ?? 'نامشخص';
                        $desc = $scoreObj['description'] ?? '';
                        
                        // اصلاح محدوده امتیاز برای نمودار
                        $minScore = $scoreObj['minLimit'] ?? 0;
                        $maxScore = $scoreObj['maxLimit'] ?? 1000;
                        if ($maxScore < $score) $maxScore = 1000;
                        
                        $percent = ($maxScore > $minScore) ? (($score - $minScore) / ($maxScore - $minScore)) * 100 : 0;
                        $percent = max(0, min(100, $percent));
                        
                        // Risk Color
                        $riskClass = 'mlr-risk-unknown';
                        if (strpos($risk, 'کم') !== false || strpos($risk, 'Low') !== false || in_array($risk, ['A1','A2','A3'])) $riskClass = 'mlr-risk-low';
                        elseif (strpos($risk, 'متوسط') !== false || strpos($risk, 'Medium') !== false || in_array($risk, ['B1','B2','B3'])) $riskClass = 'mlr-risk-medium';
                        else $riskClass = 'mlr-risk-high';
                        
                        // Summary
                        $summary = ($reportObj['summaryInformationRelatedToContractsSum'][0]) ?? [];
                        $bouncedObj = $credit_report['bouncedCheque'] ?? [];
                        $bouncedCount = isset($bouncedObj['bouncedCheques']) && is_array($bouncedObj['bouncedCheques']) ? count($bouncedObj['bouncedCheques']) : 0;
                    ?>
                    
                        <!-- Header -->
                        <div class="mlr-report-header <?php echo $riskClass; ?>">
                            <div class="mlr-score-circle">
                                <svg viewBox="0 0 36 36" class="mlr-circular-chart">
                                    <path class="mlr-circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                    <path class="mlr-circle" stroke-dasharray="<?php echo $percent; ?>, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                    <text x="18" y="20.35" class="mlr-percentage"><?php echo $score; ?></text>
                                </svg>
                                <span class="mlr-score-label">امتیاز</span>
                            </div>
                            <div>
                                <div style="font-size: 18px; font-weight: 700;">ریسک: <?php echo esc_html($risk); ?></div>
                                <div style="font-size: 13px; opacity: 0.9;"><?php echo esc_html($desc); ?></div>
                            </div>
                        </div>

                        <!-- Person Info -->
                        <?php 
                        $pInfo = $scoreObj['personInformation'] ?? ($reportObj['personInformation'] ?? []);
                        if (!empty($pInfo)): ?>
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-id-alt"></span> اطلاعات هویتی</h4>
                            <div class="mlr-report-content mlr-data-grid">
                                <div class="mlr-data-row"><span class="mlr-data-label">نام و نام خانوادگی</span><span class="mlr-data-value"><?php echo esc_html(($pInfo['name'] ?? $pInfo['firstName'] ?? '') . ' ' . ($pInfo['family'] ?? $pInfo['lastName'] ?? '')); ?></span></div>
                                <div class="mlr-data-row"><span class="mlr-data-label">کد ملی</span><span class="mlr-data-value"><?php echo esc_html($pInfo['nationalCode'] ?? '-'); ?></span></div>
                                <div class="mlr-data-row"><span class="mlr-data-label">نام پدر</span><span class="mlr-data-value"><?php echo esc_html($pInfo['fatherName'] ?? '-'); ?></span></div>
                                <div class="mlr-data-row"><span class="mlr-data-label">تاریخ تولد</span><span class="mlr-data-value"><?php echo esc_html($pInfo['dateOfBirth'] ?? $pInfo['birthDate'] ?? '-'); ?></span></div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Summary Cards -->
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-chart-bar"></span> خلاصه وضعیت مالی</h4>
                            <div class="mlr-report-content mlr-summary-cards">
                                <div class="mlr-summary-card">
                                    <span class="mlr-summary-val"><?php echo $summary['inProgressContractsCount'] ?? 0; ?></span>
                                    <span class="mlr-summary-lbl">تسهیلات جاری</span>
                                </div>
                                <div class="mlr-summary-card">
                                    <span class="mlr-summary-val"><?php echo $fmt($summary['overdueAmount'] ?? 0); ?></span>
                                    <span class="mlr-summary-lbl">معوقات (ریال)</span>
                                </div>
                                <div class="mlr-summary-card">
                                    <span class="mlr-summary-val"><?php echo $bouncedCount; ?></span>
                                    <span class="mlr-summary-lbl">چک برگشتی</span>
                                </div>
                                <div class="mlr-summary-card">
                                    <span class="mlr-summary-val"><?php echo $fmt($summary['totalAmount'] ?? 0); ?></span>
                                    <span class="mlr-summary-lbl">کل تسهیلات (ریال)</span>
                                </div>
                            </div>
                        </div>

                        <!-- Loans (Direct Contracts) -->
                        <?php if (!empty($reportObj['directContracts'])): ?>
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-bank"></span> تسهیلات بانکی (وام‌ها)</h4>
                            <div class="mlr-report-content mlr-cards-container">
                                <?php foreach($reportObj['directContracts'] as $loan): 
                                    $statusText = $loan['negativeContractStatus'] ?? 'جاری';
                                    $statusClass = (strpos($statusText, 'معوق') !== false || strpos($statusText, 'مشکوک') !== false) ? 'mlr-badge-danger' : ((strpos($statusText, 'گذشته') !== false) ? 'mlr-badge-warning' : 'mlr-badge-success');
                                ?>
                                <div class="mlr-contract-card">
                                    <div class="mlr-contract-header">
                                        <span class="mlr-contract-org"><?php echo esc_html($loan['organizationName'] ?? 'بانک'); ?></span>
                                        <span class="mlr-contract-badge <?php echo $statusClass; ?>"><?php echo esc_html($statusText); ?></span>
                                    </div>
                                    <div class="mlr-contract-body">
                                        <div class="mlr-contract-row"><span>نوع:</span> <strong><?php echo esc_html($loan['typeOfFinancingTitle'] ?? '-'); ?></strong></div>
                                        <div class="mlr-contract-row"><span>مبلغ کل:</span> <strong><?php echo $fmt($loan['totalAmount'] ?? 0); ?> ریال</strong></div>
                                        <div class="mlr-contract-row"><span>مانده بدهی:</span> <strong><?php echo $fmt($loan['overdueAmount'] ?? 0); ?> ریال</strong></div>
                                        <div class="mlr-contract-row"><span>شروع:</span> <strong><?php echo esc_html($loan['startDate'] ?? '-'); ?></strong></div>
                                        <div class="mlr-contract-row"><span>پایان:</span> <strong><?php echo esc_html($loan['expectedEndDate'] ?? '-'); ?></strong></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Guarantees (Indirect Contracts) -->
                        <?php if (!empty($reportObj['indirectContracts'])): ?>
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-groups"></span> تعهدات (ضمانت‌ها)</h4>
                            <div class="mlr-report-content mlr-cards-container">
                                <?php foreach($reportObj['indirectContracts'] as $g): 
                                    $statusText = $g['negativeContractStatus'] ?? 'جاری';
                                    $statusClass = (strpos($statusText, 'معوق') !== false) ? 'mlr-badge-danger' : 'mlr-badge-success';
                                ?>
                                <div class="mlr-contract-card">
                                    <div class="mlr-contract-header">
                                        <span class="mlr-contract-org"><?php echo esc_html($g['organizationName'] ?? 'بانک'); ?> (ضامن)</span>
                                        <span class="mlr-contract-badge <?php echo $statusClass; ?>"><?php echo esc_html($statusText); ?></span>
                                    </div>
                                    <div class="mlr-contract-body">
                                        <div class="mlr-contract-row"><span>مبلغ ضمانت:</span> <strong><?php echo $fmt($g['totalAmount'] ?? 0); ?> ریال</strong></div>
                                        <div class="mlr-contract-row"><span>معوقات وام‌گیرنده:</span> <strong><?php echo $fmt($g['overdueAmount'] ?? 0); ?> ریال</strong></div>
                                        <div class="mlr-contract-row"><span>سررسید:</span> <strong><?php echo esc_html($g['expectedEndDate'] ?? '-'); ?></strong></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Pichak (Cheques) -->
                        <?php 
                        $pichakItems = $credit_report['pichak']['personChequesData']['personChequeItems'] ?? [];
                        if (!empty($pichakItems)): ?>
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-tickets-alt"></span> وضعیت چک‌های صیادی (پیچک)</h4>
                            <div class="mlr-report-content">
                                <table class="mlr-table">
                                    <thead><tr><th>وضعیت</th><th>تعداد</th><th>مبلغ کل (ریال)</th></tr></thead>
                                    <tbody>
                                        <?php foreach($pichakItems as $item): 
                                            if (($item['count'] ?? 0) == 0) continue;
                                        ?>
                                        <tr>
                                            <td><?php echo esc_html($item['checkStatusTitle'] ?? '-'); ?></td>
                                            <td><?php echo esc_html($item['count'] ?? 0); ?></td>
                                            <td><?php echo $fmt($item['totalAmount'] ?? 0); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Bounced Cheques -->
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-warning"></span> سوابق چک برگشتی</h4>
                            <div class="mlr-report-content">
                                <?php if (!empty($bouncedObj['bouncedCheques'])): ?>
                                <table class="mlr-table">
                                    <thead><tr><th>بانک</th><th>مبلغ (ریال)</th><th>تاریخ برگشت</th><th>تاریخ رفع سوءاثر</th></tr></thead>
                                    <tbody>
                                        <?php foreach($bouncedObj['bouncedCheques'] as $item): 
                                            $bouncedDate = isset($item['bouncedDate']) ? preg_split('/[ T]/', $item['bouncedDate'])[0] : '-';
                                            $clearedDate = isset($item['clearedDate']) ? preg_split('/[ T]/', $item['clearedDate'])[0] : '---';
                                        ?>
                                        <tr>
                                            <td><?php echo esc_html($item['organizationName'] ?? '-'); ?></td>
                                            <td><?php echo $fmt($item['amount'] ?? 0); ?></td>
                                            <td><?php echo esc_html($bouncedDate); ?></td>
                                            <td><?php echo esc_html($clearedDate); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                    <div class="mlr-badge mlr-badge-success" style="display:inline-block; font-size:13px; padding:5px 10px;">✅ فاقد چک برگشتی</div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Tax -->
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-money"></span> وضعیت مالیاتی</h4>
                            <div class="mlr-report-content">
                                <?php 
                                $taxItems = $credit_report['tax']['taxResult'] ?? [];
                                $hasTax = false;
                                foreach($taxItems as $t) { if(!empty($t['year'])) $hasTax = true; }
                                
                                if ($hasTax): ?>
                                <table class="mlr-table">
                                    <thead><tr><th>سال</th><th>درآمد ابرازی</th><th>مالیات قطعی</th><th>بدهی</th></tr></thead>
                                    <tbody>
                                        <?php foreach($taxItems as $item): if(empty($item['year'])) continue; ?>
                                        <tr>
                                            <td><?php echo esc_html($item['year']); ?></td>
                                            <td><?php echo $fmt($item['daramadEbrazi'] ?? 0); ?></td>
                                            <td><?php echo $fmt($item['maliatGhati'] ?? 0); ?></td>
                                            <td><?php echo $fmt($item['bedehiMaliatAmalkard'] ?? 0); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                    <div class="mlr-badge mlr-badge-success" style="display:inline-block; font-size:13px; padding:5px 10px;">✅ فاقد بدهی مالیاتی</div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Judiciary -->
                        <?php 
                        $jud = $credit_report['judiciary']['judiciaryData'] ?? [];
                        if (($jud['sumExecuteCount'] ?? 0) > 0 || ($jud['sumNotExecuteCount'] ?? 0) > 0): 
                        ?>
                        <div class="mlr-report-section">
                            <h4><span class="dashicons dashicons-gavel"></span> پرونده‌های قضایی</h4>
                            <div class="mlr-report-content mlr-grid-view">
                                <div class="mlr-info-item">پرونده‌های اجرا شده: <strong><?php echo esc_html($jud['sumExecuteCount']); ?></strong></div>
                                <div class="mlr-info-item">پرونده‌های اجرا نشده: <strong><?php echo esc_html($jud['sumNotExecuteCount']); ?></strong></div>
                                <div class="mlr-info-item">محکومیت اجرا نشده: <strong><?php echo $fmt($jud['sumNotExecuteSumPenaltyAmount'] ?? 0); ?> ریال</strong></div>
                            </div>
                        </div>
                        <?php endif; ?>

                    <style>
                        .mlr-report-container { font-family: 'Vazirmatn', Tahoma, sans-serif; direction: rtl; background: #fff; margin-top: 20px; }
                        .mlr-report-header { display: flex; align-items: center; padding: 20px; color: #fff; border-radius: 12px; margin-bottom: 20px; }
                        .mlr-risk-low { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
                        .mlr-risk-medium { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
                        .mlr-risk-high { background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); }
                        .mlr-risk-unknown { background: linear-gradient(135deg, #64748b 0%, #475569 100%); }
                        
                        .mlr-score-circle { width: 80px; height: 80px; margin-left: 20px; position: relative; flex-shrink: 0; text-align: center; }
                        .mlr-circular-chart { display: block; margin: 0 auto; max-width: 100%; max-height: 100%; }
                        .mlr-circle-bg { fill: none; stroke: rgba(255,255,255,0.3); stroke-width: 3.8; }
                        .mlr-circle { fill: none; stroke: #fff; stroke-width: 2.8; stroke-linecap: round; transition: stroke-dasharray 1s ease-out; }
                        .mlr-percentage { fill: #fff; font-family: sans-serif; font-weight: bold; font-size: 0.5em; text-anchor: middle; }
                        
                        .mlr-score-label { font-size: 10px; font-weight: normal; margin-top: 2px; opacity: 0.9; }
                        
                        .mlr-report-section { border: 1px solid rgba(29, 53, 88, 0.1); border-radius: 12px; margin-bottom: 20px; overflow: hidden; }
                        .mlr-report-section h4 { background: rgba(208, 226, 242, 0.3); padding: 12px 15px; margin: 0; border-bottom: 1px solid rgba(29, 53, 88, 0.1); font-size: 14px; font-weight: 700; color: var(--mlr-blue-dark); display: flex; align-items: center; gap: 8px; }
                        .mlr-report-content { padding: 15px; }
                        
                        .mlr-summary-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px; }
                        .mlr-summary-card { background: rgba(208, 226, 242, 0.4); padding: 15px; border-radius: 10px; text-align: center; border: 1px solid rgba(255,255,255,0.6); }
                        .mlr-summary-val { font-size: 16px; font-weight: 800; color: var(--mlr-blue-dark); display: block; margin-bottom: 4px; }
                        .mlr-summary-lbl { font-size: 11px; color: rgba(29, 53, 88, 0.7); }
                        
                        .mlr-table { width: 100%; border-collapse: collapse; font-size: 12px; }
                        .mlr-table th { background: #f8fafc; padding: 10px; text-align: right; color: #64748b; border-bottom: 1px solid #e2e8f0; white-space: nowrap; }
                        .mlr-table td { padding: 10px; border-bottom: 1px solid #f1f5f9; color: #334155; }
                        .mlr-table tr:last-child td { border-bottom: none; }

                        .mlr-cards-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px; }
                        .mlr-contract-card { border: 1px solid rgba(29, 53, 88, 0.15); border-radius: 12px; overflow: hidden; background: #fff; }
                        .mlr-contract-header { background: rgba(208, 226, 242, 0.6); padding: 10px 15px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(29, 53, 88, 0.1); }
                        .mlr-contract-org { font-weight: 700; font-size: 13px; color: var(--mlr-blue-dark); }
                        .mlr-contract-badge { font-size: 11px; padding: 3px 8px; border-radius: 12px; color: #fff; font-weight: 600; }
                        .mlr-contract-body { padding: 15px; font-size: 13px; }
                        .mlr-contract-row { display: flex; justify-content: space-between; margin-bottom: 8px; border-bottom: 1px dashed #f1f5f9; padding-bottom: 4px; }
                        .mlr-contract-row:last-child { margin-bottom: 0; border-bottom: none; }
                        
                        .mlr-badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; color: #fff; display: inline-block; }
                        .mlr-badge-success { background: #10b981; }
                        .mlr-badge-warning { background: #f59e0b; }
                        .mlr-badge-danger { background: #ef4444; }
                    </style>
            </div>
        <?php endif; ?>

    </div>
    
    <style>
        :root {
            --mlr-blue-dark: #1D3558;
            --mlr-blue-light: #D0E2F2;
            --mlr-gold: #eda900;
            --mlr-white-glass: rgba(255, 255, 255, 0.75);
            --mlr-white-glass-strong: rgba(255, 255, 255, 0.9);
            --mlr-border-glass: 1px solid rgba(255, 255, 255, 0.6);
            --mlr-shadow-soft: 0 10px 40px -10px rgba(29, 53, 88, 0.15);
            --mlr-radius-lg: 24px;
            --mlr-radius-md: 14px;
            --mlr-font-family: 'Vazirmatn', Tahoma, sans-serif;
        }

        .mlr-glass-wrapper {
            font-family: var(--mlr-font-family);
            direction: rtl;
            background: linear-gradient(135deg, #f0f5f9 0%, var(--mlr-blue-light) 100%);
            padding: 30px;
            border-radius: var(--mlr-radius-lg);
            box-shadow: var(--mlr-shadow-soft);
            color: var(--mlr-blue-dark);
            max-width: 1000px;
            margin: 0 auto;
        }

        .mlr-glass-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(29, 53, 88, 0.1);
        }

        .mlr-header-title h3 {
            margin: 0;
            font-size: 24px;
            font-weight: 800;
            color: var(--mlr-blue-dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .mlr-header-title .dashicons { font-size: 28px; width: 28px; height: 28px; color: var(--mlr-gold); }
        .mlr-highlight { color: var(--mlr-blue-dark); opacity: 0.7; }

        .mlr-glass-badge {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
            background: var(--mlr-white-glass-strong);
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            color: var(--mlr-blue-dark);
        }

        .mlr-glass-card {
            background: var(--mlr-white-glass);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: var(--mlr-border-glass);
            border-radius: var(--mlr-radius-md);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.05);
            padding: 25px;
            margin-bottom: 25px;
            transition: transform 0.3s ease;
        }
        .mlr-glass-card:hover { transform: translateY(-3px); background: var(--mlr-white-glass-strong); }

        .mlr-card-title {
            margin: 0 0 20px 0;
            font-size: 16px;
            font-weight: 700;
            color: var(--mlr-blue-dark);
            display: flex;
            align-items: center;
            gap: 8px;
            border-bottom: 1px solid rgba(29, 53, 88, 0.08);
            padding-bottom: 10px;
        }
        .mlr-card-title .dashicons { color: var(--mlr-gold); }

        .mlr-data-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        
        .mlr-data-row { display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 14px; border-bottom: 1px dashed rgba(29, 53, 88, 0.1); padding-bottom: 8px; }
        .mlr-data-row:last-child { border-bottom: none; margin-bottom: 0; }
        .mlr-data-label { color: rgba(29, 53, 88, 0.7); }
        .mlr-data-value { font-weight: 600; color: var(--mlr-blue-dark); text-align: left; }
        .mlr-row-wide { flex-direction: column; gap: 5px; align-items: flex-start; }

        /* Inputs & Buttons */
        .mlr-glass-input { width: 100%; padding: 10px; border: 1px solid rgba(29, 53, 88, 0.2); border-radius: 8px; background: rgba(255,255,255,0.8); transition: all 0.3s; }
        .mlr-glass-input:focus { background: #fff; border-color: var(--mlr-blue-dark); outline: none; box-shadow: 0 0 0 3px rgba(29, 53, 88, 0.1); }
        
        .mlr-btn { padding: 10px 20px; border-radius: 8px; border: none; cursor: pointer; font-weight: 700; transition: all 0.3s; display: inline-flex; align-items: center; justify-content: center; gap: 5px; }
        .mlr-btn-primary { background: var(--mlr-blue-dark); color: #fff; }
        .mlr-btn-primary:hover { background: var(--mlr-gold); color: var(--mlr-blue-dark); }
        .mlr-btn-secondary { background: rgba(255,255,255,0.6); color: var(--mlr-blue-dark); border: 1px solid rgba(29, 53, 88, 0.1); }
        .mlr-btn-secondary:hover { background: #fff; }

        /* Files */
        .mlr-file-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; }
        .mlr-file-item { background: #fff; padding: 10px; border-radius: 8px; border: 1px solid rgba(29, 53, 88, 0.1); text-align: center; }
        .mlr-file-label { font-size: 12px; margin-bottom: 5px; color: rgba(29, 53, 88, 0.7); }

        /* Comments */
        .mlr-comment { background: rgba(255,255,255,0.6); padding: 12px; border-radius: 8px; margin-bottom: 10px; border: 1px solid rgba(29, 53, 88, 0.05); }
        .mlr-conversation-history { max-height: 300px; overflow-y: auto; margin-bottom: 15px; padding-right: 5px; }
        .mlr-conversation-compose { border-top: 1px solid rgba(29, 53, 88, 0.1); padding-top: 15px; }
        .mlr-conversation-actions { display: flex; gap: 10px; margin-top: 10px; align-items: center; }

        @media (max-width: 768px) {
            .mlr-glass-wrapper { padding: 15px; }
            .mlr-data-grid { grid-template-columns: 1fr; }
        }
    </style>
    <?php

    $html_output = ob_get_clean();
    wp_send_json_success(['html' => $html_output]);
}
?>