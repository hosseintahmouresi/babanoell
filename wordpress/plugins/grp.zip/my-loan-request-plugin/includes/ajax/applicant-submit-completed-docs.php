<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_applicant_submit_completed_docs', 'mlr_applicant_submit_completed_docs_callback');

function mlr_applicant_submit_completed_docs_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای بارگذاری مدارک، لطفاً ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $user_id = get_current_user_id();

    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT id, required_documents, status FROM {$table_name} WHERE id = %d AND applicant_user_id = %d AND request_origin = %s LIMIT 1",
        $request_id,
        $user_id,
        'applicant_portal'
    ));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }

    $document_stage = function_exists('mlr_get_document_flow_stage')
        ? mlr_get_document_flow_stage($request->status)
        : (in_array($request->status, ['تکمیل مدارک', 'در انتظار مدارک', 'در انتظار تکمیل', 'در انتظار تکمیل مدارک'], true) ? 'completion_documents' : '');

    if (!in_array($document_stage, ['completion_documents', 'pending_documents'], true)) {
        wp_send_json_error(['message' => 'درخواست مورد نظر در حال حاضر در وضعیت مناسب برای تکمیل مدارک نیست.']);
        return;
    }

    // بررسی اولیه وجود قرارداد و فاکتور امضا شده (اجباری)
    if (empty($_FILES['signed_contract']) || $_FILES['signed_contract']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(['message' => 'فایل قرارداد امضا‌شده الزامی است.']);
        return;
    }
    if (empty($_FILES['signed_invoice']) || $_FILES['signed_invoice']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(['message' => 'فایل فاکتور امضا/مهر‌شده الزامی است.']);
        return;
    }


    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }
    
    $existing_documents = function_exists('mlr_get_request_uploaded_documents')
        ? mlr_get_request_uploaded_documents($request->required_documents)
        : maybe_unserialize($request->required_documents);
    if (!is_array($existing_documents)) {
        $existing_documents = [];
    }
    
    $errors = [];
    $allowed_mimes = ['jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf'];
    $upload_overrides = ['test_form' => false, 'mimes' => $allowed_mimes];

    // Helper function to process multiple files
    $process_multiple_files = function($files_key) use ($upload_overrides, &$errors) {
        if (empty($_FILES[$files_key]) || empty($_FILES[$files_key]['name'][0])) return [];
        
        $urls = [];
        $files = $_FILES[$files_key];
        foreach ($files['name'] as $key => $value) {
            if ($files['error'][$key] === UPLOAD_ERR_OK) {
                $file = ['name' => $files['name'][$key], 'type' => $files['type'][$key], 'tmp_name' => $files['tmp_name'][$key], 'error' => $files['error'][$key], 'size' => $files['size'][$key]];
                $movefile = wp_handle_upload($file, $upload_overrides);
                if ($movefile && !isset($movefile['error'])) {
                    $urls[] = $movefile['url'];
                } else {
                    $errors[] = "($files_key): " . ($movefile['error'] ?? 'خطای نامشخص');
                }
            }
        }
        return $urls;
    };

    // 1. پردازش چک‌های تکمیل شده (چندتایی)
    $check_urls = $process_multiple_files('completed_check_files');
    if (!empty($check_urls)) {
        $existing_documents['completed_check_files'] = $check_urls;
    }

    // 2. پردازش قرارداد امضا شده (تکی)
    if (!empty($_FILES['signed_contract']) && $_FILES['signed_contract']['error'] === UPLOAD_ERR_OK) {
        $movefile = wp_handle_upload($_FILES['signed_contract'], $upload_overrides);
        if ($movefile && !isset($movefile['error'])) {
            // Note: The key is 'signed_contract_files' to match admin view expectations
            $existing_documents['signed_contract_files'] = [$movefile['url']];
        } else {
            $errors[] = 'قرارداد امضا شده: ' . ($movefile['error'] ?? 'خطای نامشخص');
        }
    }

    // 3. پردازش فاکتور امضا شده (تکی)
    if (!empty($_FILES['signed_invoice']) && $_FILES['signed_invoice']['error'] === UPLOAD_ERR_OK) {
        $movefile = wp_handle_upload($_FILES['signed_invoice'], $upload_overrides);
        if ($movefile && !isset($movefile['error'])) {
            // Note: The key is 'signed_invoice_files' to match admin view expectations
            $existing_documents['signed_invoice_files'] = [$movefile['url']];
        } else {
            $errors[] = 'فاکتور امضا شده: ' . ($movefile['error'] ?? 'خطای نامشخص');
        }
    }

    // 4. پردازش سایر مدارک (چندتایی)
    $other_urls = $process_multiple_files('other_completed_files');
    if (!empty($other_urls)) {
        $existing_documents['other_completed_files'] = $other_urls;
    }

    if (!empty($errors)) {
        wp_send_json_error(['message' => 'خطا در آپلود فایل‌ها: ' . implode(', ', $errors)]);
        return;
    }

    // Prepare data for update
    $update_data = [
        'required_documents' => serialize($existing_documents),
        'status'             => 'تأیید مدارک',
        'last_edited_at'     => current_time('mysql')
    ];

    // Update specific columns if files were uploaded
    if (isset($existing_documents['signed_contract_files'][0])) {
        $update_data['contract_file'] = $existing_documents['signed_contract_files'][0];
    }
    // Note: signed_invoice_files doesn't have a dedicated column in standard schema, stays in required_documents

    // Safety: Filter update data against existing columns
    $db_columns = $wpdb->get_col("DESC `{$table_name}`", 0);
    if ($db_columns) {
        $update_data = array_intersect_key($update_data, array_flip($db_columns));
    }

    // به‌روزرسانی دیتابیس
    // وضعیت به 'تأیید مدارک' تغییر می‌کند که مرحله بعد از تکمیل مدارک است.
    $updated = $wpdb->update(
        $table_name,
        $update_data,
        ['id' => $request_id]
    );

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطایی در به‌روزرسانی درخواست رخ داد.']);
        return;
    }

    mlr_send_sms_on_loan_status_change($request_id, 'تأیید مدارک');

    // Notification
    if (function_exists('mlr_create_notification')) {
        mlr_create_notification('status_change', 'مدارک نهایی (چک/قرارداد) برای درخواست #' . $request_id . ' ارسال شد.', admin_url('admin.php?page=mlr-loan-requests&s=' . $request_id));
    }

    if (function_exists('mlr_add_request_event')) { mlr_add_request_event($request_id, 'upload_completed_docs', 'بارگذاری مدارک تکمیل‌شده'); }
    wp_send_json_success(['message' => 'مدارک شما با موفقیت ارسال شد و درخواست به مرحله بررسی کارشناس رفت.']);
}
