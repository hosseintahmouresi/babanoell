<?php
/**
 * AJAX: آپلود تکه‌ای فایل برای فایل‌های بزرگ (جلوگیری از timeout).
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_upload_chunk', 'mlr_upload_chunk_callback');
add_action('wp_ajax_nopriv_mlr_upload_chunk', 'mlr_upload_chunk_callback');

function mlr_upload_chunk_callback() {
    while (ob_get_level()) {
        ob_end_clean();
    }

    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    $valid_nonce =
        wp_verify_nonce($nonce, 'mlr_loan_request_action') ||
        wp_verify_nonce($nonce, 'mlr_applicant_loan_request_action') ||
        wp_verify_nonce($nonce, 'mlr_cooperation_request_action') ||
        wp_verify_nonce($nonce, 'mlr_frontend_nonce');
    if (!$valid_nonce) {
        wp_send_json_error(['message' => 'اعتبار فرم منقضی شده است.']);
        return;
    }

    $upload_id = isset($_POST['upload_id']) ? sanitize_file_name(wp_unslash($_POST['upload_id'])) : '';
    $chunk_index = isset($_POST['chunk_index']) ? intval($_POST['chunk_index']) : -1;
    $total_chunks = isset($_POST['total_chunks']) ? intval($_POST['total_chunks']) : 0;
    $original_name = isset($_POST['original_name']) ? sanitize_file_name(wp_unslash($_POST['original_name'])) : 'upload';
    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $document_flow_state = isset($_POST['document_flow_state']) ? sanitize_text_field(wp_unslash($_POST['document_flow_state'])) : '';

    if (empty($upload_id) || $chunk_index < 0 || $total_chunks <= 0 || $chunk_index >= $total_chunks) {
        wp_send_json_error(['message' => 'پارامترهای آپلود تکه‌ای نامعتبر است.']);
        return;
    }

    if ($request_id > 0 && function_exists('mlr_validate_document_upload_request_state')) {
        $state_check = mlr_validate_document_upload_request_state($request_id);
        if (is_wp_error($state_check)) {
            wp_send_json_error(['message' => $state_check->get_error_message()]);
            return;
        }
    } elseif ($document_flow_state !== '' && function_exists('mlr_get_document_flow_stage')) {
        $state = mlr_get_document_flow_stage($document_flow_state);
        $allowed_stages = function_exists('mlr_get_allowed_document_upload_stages') ? mlr_get_allowed_document_upload_stages() : ['defect_documents', 'completion_documents', 'pending_documents'];
        if ($state !== '' && !in_array($state, $allowed_stages, true)) {
            wp_send_json_error(['message' => 'وضعیت بارگذاری مدارک نامعتبر است.']);
            return;
        }
    }

    if (!isset($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) {
        wp_send_json_error(['message' => 'تکه فایل دریافت نشد.']);
        return;
    }

    $upload_dir = wp_upload_dir();
    if ($upload_dir['error']) {
        wp_send_json_error(['message' => 'پوشه آپلود در دسترس نیست.']);
        return;
    }

    $base_dir = $upload_dir['basedir'] . '/mlr_chunks';
    if (!wp_mkdir_p($base_dir)) {
        wp_send_json_error(['message' => 'خطا در ایجاد پوشه موقت.']);
        return;
    }

    $part_path = $base_dir . '/' . $upload_id . '.part.' . $chunk_index;
    $tmp = $_FILES['chunk']['tmp_name'];

    if (!move_uploaded_file($tmp, $part_path)) {
        wp_send_json_error(['message' => 'خطا در ذخیره تکه فایل.']);
        return;
    }

    if ($chunk_index !== $total_chunks - 1) {
        wp_send_json_success(['chunk_index' => $chunk_index, 'upload_id' => $upload_id]);
        return;
    }

    $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'pdf'], true)) {
        $ext = 'bin';
    }
    $final_name = $upload_id . '_' . wp_generate_password(8, false) . '.' . $ext;
    $subdir = date('Y/m');
    $dest_dir = $upload_dir['basedir'] . '/' . $subdir;
    if (!wp_mkdir_p($dest_dir)) {
        wp_send_json_error(['message' => 'خطا در ایجاد پوشه مقصد.']);
        return;
    }
    $dest_path = $dest_dir . '/' . $final_name;

    $out = fopen($dest_path, 'wb');
    if (!$out) {
        wp_send_json_error(['message' => 'خطا در ایجاد فایل نهایی.']);
        return;
    }

    for ($i = 0; $i < $total_chunks; $i++) {
        $p = $base_dir . '/' . $upload_id . '.part.' . $i;
        if (!is_file($p)) {
            fclose($out);
            @unlink($dest_path);
            wp_send_json_error(['message' => 'تکه‌ای از فایل یافت نشد.']);
            return;
        }
        $data = file_get_contents($p);
        fwrite($out, $data);
        @unlink($p);
    }
    fclose($out);

    $url = $upload_dir['baseurl'] . '/' . $subdir . '/' . $final_name;
    $url = set_url_scheme($url, is_ssl() ? 'https' : 'http');

    wp_send_json_success(['url' => $url]);
}
