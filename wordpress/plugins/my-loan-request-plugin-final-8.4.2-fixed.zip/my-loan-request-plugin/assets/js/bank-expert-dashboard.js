jQuery(document).ready(function($) {
    // Exit if the main container for this dashboard doesn't exist.
    if ($('.mlr-user-requests[id^="mlr-bank-dashboard-"]').length === 0) {
        return;
    }

    // --- Initialize Jalali Datepicker Safely ---
    try {
        if (typeof $.fn.persianDatepicker === 'function') {
            $('.jalali-datepicker').persianDatepicker({
                format: 'YYYY/MM/DD',
                autoClose: true
            });
        } else {
            console.warn("Persian Datepicker library not found.");
        }
    } catch (e) {
        console.error("Error initializing Persian Datepicker:", e);
    }

    // --- Main function to load requests via AJAX ---
    function loadBankRequests() {
        var container = $('.mlr-user-requests'); 
        var search = container.find('#mlr-search').val();
        var dateFrom = container.find('#mlr-date-from').val();
        var dateTo = container.find('#mlr-date-to').val();
        var tableBody = container.find('#mlr-requests-table-body');

        $.ajax({
            url: mlr_bank_ajax_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_get_bank_expert_requests',
                nonce: mlr_bank_ajax_obj.nonce,
                search: search,
                date_from: dateFrom,
                date_to: dateTo
            },
            beforeSend: function() {
                tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px;">در حال بارگذاری...</td></tr>');
            },
            success: function(response) {
                if (response.success) {
                    tableBody.html(response.data.html);
                } else {
                    tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">' + (response.data.message || 'خطا در دریافت اطلاعات.') + '</td></tr>');
                }
            },
            error: function() {
                tableBody.html('<tr><td colspan="9" style="text-align:center; padding: 20px; color: red;">خطا در ارتباط با سرور.</td></tr>');
            }
        });
    }

    // --- Function to show the details modal (re-uses the same AJAX endpoint as regular users) ---
    function showDetailsModal(requestId, container) {
        const modalOverlay = container.find('.mlr-modal-overlay');
        const modal = container.find('.mlr-modal');
        const modalContent = container.find('.mlr-modal-content');

        if (!requestId) return;

        modalOverlay.fadeIn(200);
        modal.fadeIn(200);
        modalContent.html('<p style="text-align:center; padding: 40px;">در حال بارگذاری جزئیات...</p>');

        $.ajax({
            url: mlr_bank_ajax_obj.ajax_url, 
            type: 'POST',
            data: {
                action: 'mlr_get_frontend_request_details', // The backend will handle permissions
                nonce: mlr_bank_ajax_obj.nonce,
                request_id: requestId
            },
            success: function(response) {
                if (response.success) {
                    modalContent.html(response.data.html);
                } else {
                    modalContent.html('<p style="color:red; text-align:center; padding: 40px;">' + (response.data.message || 'خطا در دریافت جزئیات.') + '</p>');
                }
            },
            error: function() {
                modalContent.html('<p class="mlr-error">خطا در ارتباط با سرور.</p>');
            }
        });
    }

    // --- Initial Load ---
    loadBankRequests();

    // --- Event Handlers ---
    $(document).on('click', '#mlr-filter-btn', function() {
        loadBankRequests();
    });

    $(document).on('keyup', '#mlr-search', function(e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            loadBankRequests();
        }
    });

    $(document).on('click', '.mlr-view-details-btn, #mlr-requests-table-body tr', function(e) {
        if ($(e.target).closest('form, a').length > 0) return;
        e.stopPropagation();
        const row = $(this).closest('tr');
        const container = row.closest('.mlr-user-requests');
        const requestId = row.data('id');
        showDetailsModal(requestId, container);
    });

    // --- Bank Expert Action Form Submission ---
    $(document).on('submit', '#mlr-bank-expert-action-form', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var button = form.find('button[type="submit"]');
        var messageDiv = form.find('.mlr-action-message');
        var formData = {
            action: 'mlr_submit_bank_expert_review',
            nonce: mlr_bank_ajax_obj.nonce,
            request_id: form.find('input[name="request_id"]').val(),
            new_status: form.find('select[name="new_status"]').val(),
            comment_text: form.find('textarea[name="comment_text"]').val()
        };

        $.ajax({
            url: mlr_bank_ajax_obj.ajax_url,
            type: 'POST',
            data: formData,
            beforeSend: function() {
                button.prop('disabled', true).text('در حال ثبت...');
                messageDiv.removeClass().addClass('mlr-action-message loading').text('لطفا صبر کنید...').slideDown();
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass().addClass('mlr-action-message success').text(response.data.message);
                    setTimeout(function() {
                        $('.mlr-modal-overlay, .mlr-modal').fadeOut(200);
                        loadBankRequests();
                    }, 2000);
                } else {
                    messageDiv.removeClass().addClass('mlr-action-message error').text(response.data.message || 'خطای ناشناخته.');
                    button.prop('disabled', false).text('ثبت بررسی');
                }
            },
            error: function() {
                messageDiv.removeClass().addClass('mlr-action-message error').text('خطا در ارتباط با سرور.');
                button.prop('disabled', false).text('ثبت بررسی');
            }
        });
    });

    // Close Modal
    $(document).on('click', '.mlr-modal-overlay, .mlr-modal-close', function() {
        $(this).closest('.mlr-user-requests').find('.mlr-modal-overlay, .mlr-modal').fadeOut(200);
    });

// --- Export Excel (CSV) ---
$(document).on('click', '#mlr-export-excel', function() {
    var container = $('.mlr-user-requests');
    var search = container.find('#mlr-search').val() || '';
    var dateFrom = container.find('#mlr-date-from').val() || '';
    var dateTo = container.find('#mlr-date-to').val() || '';

    var url = mlr_bank_ajax_obj.ajax_url
        + '?action=mlr_export_bank_expert_requests'
        + '&nonce=' + encodeURIComponent(mlr_bank_ajax_obj.nonce)
        + '&status=' + encodeURIComponent('تأیید کارشناس')
        + '&search=' + encodeURIComponent(search)
        + '&date_from=' + encodeURIComponent(dateFrom)
        + '&date_to=' + encodeURIComponent(dateTo);

    window.location.href = url;
});

});