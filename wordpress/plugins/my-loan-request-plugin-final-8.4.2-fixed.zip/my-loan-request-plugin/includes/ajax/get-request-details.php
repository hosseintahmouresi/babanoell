<?php
// FILE: my-loan-request-plugin/includes/ajax/get-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_request_details', 'mlr_get_request_details_callback');

function mlr_get_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'عدم دسترسی.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }
    
    // Occupations Mapping
    $occupations = [
        'official_employee' => 'کارمند رسمی',
        'contract_employee' => 'کارمند قراردادی',
        'worker' => 'کارگر',
        'freelancer' => 'آزاد',
        'retired' => 'بازنشسته',
        'pensioner' => 'مستمری بگیر',
        'employer' => 'کارفرما',
        'other' => 'سایر'
    ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : esc_html($request->occupation);

    // Documents & Items Processing
    $uploaded_documents = maybe_unserialize($request->required_documents);

    // --- MLR EXTRA DETAILS SECTION (ADMIN) ---
    // فقط نمایش کامل‌تر جزئیات؛ منطق ذخیره/عملیات را تغییر نمی‌دهد.
    $extra_files = [];
    $extra_files['bank_validation_file'] = $request->bank_validation_file ?? '';
    $extra_files['signature_image']      = $request->signature_image ?? '';
    $extra_files['contract_file']        = $request->contract_file ?? '';

    $parsed_check_images = [];
    if (!empty($request->check_images)) {
        $maybe = maybe_unserialize($request->check_images);
        if (is_array($maybe)) {
            $parsed_check_images = $maybe;
        } else {
            $json = json_decode($request->check_images, true);
            if (is_array($json)) {
                $parsed_check_images = $json;
            } else {
                $parts = preg_split('/[\r\n,]+/', (string)$request->check_images);
                $parts = array_filter(array_map('trim', $parts));
                $parsed_check_images = $parts ? $parts : [(string)$request->check_images];
            }
        }
    }
    if (!empty($parsed_check_images)) {
        $extra_files['check_images'] = $parsed_check_images;
    }

    $extra_file_labels = [
        'bank_validation_file' => 'فایل اعتبارسنجی بانک',
        'signature_image'      => 'تصویر امضا',
        'contract_file'        => 'فایل قرارداد',
        'check_images'         => 'تصاویر چک',
    ];
    // --- END: MLR EXTRA DETAILS SECTION (ADMIN) ---
    $order_items = !empty($request->order_items) ? json_decode($request->order_items, true) : [];
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    $form_data = !empty($request->form_data) ? json_decode($request->form_data, true) : [];
    if (!is_array($form_data)) { $form_data = []; }
    $request_events = function_exists('mlr_get_request_events') ? mlr_get_request_events($request_id, 500) : [];
    $request_messages = function_exists('mlr_get_request_messages') ? mlr_get_request_messages($request_id, 500) : [];
    
    // Get document labels from helper if exists, or use keys
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست #<?php echo esc_html($request->id); ?></h3>
    </div>
    
    <div class="mlr-modal-body">
        
        <div class="mlr-modal-card mlr-modal-comments-section">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-format-chat"></span>یادداشت‌های پرونده</h4>
            <div class="mlr-comments-history" id="mlr-comments-history-container">
                <?php if (!empty($comments) && is_array($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                        <div class="mlr-comment-bubble">
                            <div class="mlr-comment-header">
                                <strong class="mlr-comment-author"><?php echo esc_html($comment['display_name'] ?? 'کاربر'); ?></strong>
                                <span class="mlr-comment-date"><?php echo function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i') : ($comment['timestamp'] ?? ''); ?></span>
                            </div>
                            <div class="mlr-comment-body"><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="text-align:center;color:#999;padding:10px;">یادداشتی وجود ندارد.</p>
                <?php endif; ?>
            </div>
            <div class="mlr-add-comment-form">
                <textarea id="mlr_new_comment_text" rows="3" class="widefat" placeholder="یادداشت محرمانه کارشناس..."></textarea>
                <button type="button" class="button button-primary" id="mlr-add-comment-btn" data-id="<?php echo esc_attr($request->id); ?>" style="margin-top:10px;">ثبت یادداشت</button>
            </div>
        </div>

        <div class="mlr-modal-grid">
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-id"></span> مشخصات متقاضی</h4>
                <table class="mlr-details-table">
                    <tr><td>نام کامل:</td><td><strong><?php echo esc_html($request->full_name); ?></strong></td></tr>
                    <tr><td>کد ملی:</td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td>موبایل:</td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td>تلفن ثابت:</td><td><?php echo esc_html($request->phone_number ?: '-'); ?></td></tr>
                    <tr><td>شغل:</td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td>تاریخ تولد:</td><td><?php echo function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->birth_date) : $request->birth_date; ?></td></tr>
                    <tr><td>کد پستی:</td><td><?php echo esc_html($request->postal_code ?: '-'); ?></td></tr>
                </table>
                <div style="margin-top:10px; border-top:1px solid #eee; padding-top:5px;">
                    <strong>آدرس سکونت:</strong>
                    <p style="margin:5px 0; color:#555;"><?php echo nl2br(esc_html($request->residential_address ?: '-')); ?></p>
                </div>
                <div style="margin-top:10px; border-top:1px solid #eee; padding-top:5px;">
                    <strong>آدرس محل کار:</strong>
                    <p style="margin:5px 0; color:#555;"><?php echo nl2br(esc_html($request->work_address ?: '-')); ?></p>
                </div>
            </div>

            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-chart-line"></span> محاسبات مالی</h4>
                <table class="mlr-details-table">
                    <tr><td>طرح:</td><td><?php echo esc_html($request->plan_name); ?></td></tr>
                    <tr><td>مبلغ تسهیلات:</td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td>تعداد اقساط:</td><td><?php echo esc_html($request->installment_count); ?> ماه</td></tr>
                    <tr><td>مبلغ هر قسط:</td><td><?php echo number_format($request->installment_amount); ?> ریال</td></tr>
                    <tr><td>پیش پرداخت:</td><td><?php echo number_format($request->prepayment); ?> ریال</td></tr>
                    <tr><td>کل بازپرداخت:</td><td><?php echo number_format($request->total_payment); ?> ریال</td></tr>
                    <tr style="background:#f0f6fc;"><td><strong>وضعیت:</strong></td><td><strong><?php echo esc_html($request->status); ?></strong></td></tr>
                </table>
            </div>
        </div>

        
        <!-- MLR EXTRA DETAILS HTML (ADMIN) -->
        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-media-text"></span> اطلاعات تکمیلی</h4>
            <table class="mlr-details-table">
                <?php if (!empty($request->product_name)): ?>
                    <tr><td>نام/شرح کالا:</td><td><strong><?php echo esc_html($request->product_name); ?></strong></td></tr>
                <?php endif; ?>
                <?php if (!empty($request->order_total)): ?>
                    <tr><td>جمع کل سفارش:</td><td><?php echo number_format((int)$request->order_total); ?> ریال</td></tr>
                <?php endif; ?>
                <?php if (!empty($request->wallet_charge)): ?>
                    <tr><td>شارژ کیف پول:</td><td><?php echo number_format((int)$request->wallet_charge); ?> ریال</td></tr>
                <?php endif; ?>
                <?php if (!empty($request->profit)): ?>
                    <tr><td>سود:</td><td><?php echo number_format((int)$request->profit); ?> ریال</td></tr>
                <?php endif; ?>
                <?php if (!empty($request->acceptor_payment_amount)): ?>
                    <tr><td>پرداخت پذیرنده:</td><td><?php echo number_format((int)$request->acceptor_payment_amount); ?> ریال</td></tr>
                <?php endif; ?>
                <?php if (!empty($request->final_settlement_amount)): ?>
                    <tr><td>تسویه نهایی:</td><td><?php echo number_format((int)$request->final_settlement_amount); ?> ریال</td></tr>
                <?php endif; ?>
                <?php if (!empty($request->settlement_status)): ?>
                    <tr><td>وضعیت تسویه:</td><td><?php echo esc_html($request->settlement_status); ?></td></tr>
                <?php endif; ?>
                <?php if (!empty($request->description)): ?>
                    <tr><td>توضیحات:</td><td><?php echo nl2br(esc_html($request->description)); ?></td></tr>
                <?php endif; ?>
            </table>
        </div>

        <?php if (!empty($extra_files) && is_array($extra_files)): ?>
        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-paperclip"></span> فایل‌های تکمیلی</h4>
            <div class="mlr-file-grid">
                <?php foreach ($extra_files as $fkey => $fval):
                    if (empty($fval)) continue;
                    $label = isset($extra_file_labels[$fkey]) ? $extra_file_labels[$fkey] : ucfirst(str_replace('_',' ', $fkey));
                ?>
                    <div class="mlr-file-item" style="border:1px solid #ddd; padding:10px; border-radius:6px; background:#fff;">
                        <div style="font-weight:800; margin-bottom:8px;"><?php echo esc_html($label); ?>:</div>
                        <?php if (is_array($fval)): ?>
                            <div style="display:flex; flex-wrap:wrap; gap:6px;">
                                <?php foreach ($fval as $idx => $url): if (empty($url)) continue; ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank" class="button button-small">
                                        مشاهده <?php echo intval($idx)+1; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo esc_url($fval); ?>" target="_blank" class="button button-small">مشاهده فایل</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        <!-- END: MLR EXTRA DETAILS HTML (ADMIN) -->

<?php if (!empty($order_items)): ?>
        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-cart"></span> ریز اقلام درخواستی</h4>
            <table class="widefat striped" style="border:1px solid #ddd;">
                <thead>
                    <tr>
                        <th>نام کالا</th>
                        <th>تعداد</th>
                        <th>قیمت واحد (ریال)</th>
                        <th>قیمت کل (ریال)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($order_items as $item): 
                        $price = floatval($item['price'] ?? 0);
                        $qty = intval($item['qty'] ?? 1);
                    ?>
                    <tr>
                        <td><?php echo esc_html($item['name']); ?></td>
                        <td><?php echo $qty; ?></td>
                        <td><?php echo number_format($price); ?></td>
                        <td><?php echo number_format($price * $qty); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-paperclip"></span> مدارک و فایل‌ها</h4>
            <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                <div class="mlr-file-grid">
                <?php foreach($uploaded_documents as $doc_key => $doc_value): 
                    $label = isset($all_doc_labels[$doc_key]) ? $all_doc_labels[$doc_key] : ucfirst(str_replace('_', ' ', $doc_key));
                ?>
                    <div class="mlr-file-item" style="border:1px solid #ddd; padding:10px; border-radius:4px; margin-bottom:5px; background:#fff;">
                        <div style="font-weight:bold; margin-bottom:5px;"><?php echo esc_html($label); ?>:</div>
                        
                        <?php if (is_array($doc_value)): // Multiple files for this key ?>
                            <div style="display:flex; flex-wrap:wrap; gap:5px;">
                                <?php foreach ($doc_value as $idx => $url): ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank" class="button button-small" style="text-decoration:none;">
                                        <span class="dashicons dashicons-download" style="vertical-align:middle;"></span> فایل <?php echo $idx + 1; ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php elseif (is_string($doc_value) && !empty($doc_value)): // Single file ?>
                             <a href="<?php echo esc_url($doc_value); ?>" target="_blank" class="button button-small">
                                <span class="dashicons dashicons-visibility" style="vertical-align:middle;"></span> مشاهده فایل
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>هیچ مدرکی بارگذاری نشده است.</p>
            <?php endif; ?>
        </div>


<div class="mlr-modal-card">
    <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-clipboard"></span>اطلاعات ثبت‌شده (فرم)</h4>
    <div class="mlr-form-data-table" style="overflow:auto;">
        <?php if (!empty($form_data)): ?>
            <table class="widefat striped">
                <tbody>
                <?php foreach ($form_data as $k => $v): ?>
                    <tr>
                        <th style="width:35%;text-align:right"><?php echo esc_html($k); ?></th>
                        <td style="text-align:right">
                            <?php
                            if (is_array($v)) {
                                echo esc_html(implode(' ، ', array_map('strval', $v)));
                            } else {
                                echo esc_html((string)$v);
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align:center;color:#999;padding:10px;">اطلاعات فرم ذخیره نشده یا خالی است.</p>
        <?php endif; ?>
    </div>
</div>

<div class="mlr-modal-card">
    <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-list-view"></span>مراحل و رویدادهای پرونده</h4>
    <div class="mlr-events-container">
        <?php echo function_exists('mlr_render_request_events_html') ? mlr_render_request_events_html($request_events) : ''; ?>
    </div>
</div>

<div class="mlr-modal-card mlr-modal-messages-section">
    <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-email"></span>مکالمات پرونده</h4>
    <div class="mlr-messages-history" id="mlr-messages-history-container" data-request-id="<?php echo esc_attr($request->id); ?>">
        <?php echo function_exists('mlr_render_request_messages_html') ? mlr_render_request_messages_html($request_messages) : ''; ?>
    </div>
    <div class="mlr-add-message-form" style="margin-top:10px;">
        <textarea class="widefat mlr-new-message-text" rows="3" placeholder="پیام..."></textarea>
        <div style="display:flex;gap:8px;margin-top:8px;">
            <button type="button" class="button button-primary mlr-send-message-btn" data-request-id="<?php echo esc_attr($request->id); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('mlr_frontend_nonce')); ?>">ارسال پیام</button>
            <button type="button" class="button mlr-refresh-messages-btn" data-request-id="<?php echo esc_attr($request->id); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('mlr_frontend_nonce')); ?>">به‌روزرسانی</button>
        </div>
    </div>
</div>



    </div>
    <?php
    $html_output = ob_get_clean();
    wp_send_json_success(['html' => $html_output]);
}
?>