<?php
add_shortcode('mlr_complete_request', 'mlr_complete_request_shortcode');
function mlr_complete_request_shortcode() {
    if (!is_user_logged_in()) {
        return '<p>لطفاً ابتدا وارد شوید.</p>';
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $user_id = get_current_user_id();

    if (!isset($_GET['mlr_complete']) || !isset($_GET['nonce'])) {
        return '<p>درخواست نامعتبر است.</p>';
    }

    $request_id = intval($_GET['mlr_complete']);
    $nonce = $_GET['nonce'];

    if (!wp_verify_nonce($nonce, 'mlr_complete_' . $request_id)) {
        return '<p>توکن امنیتی نامعتبر است.</p>';
    }

    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND user_id = %d AND status IN ('در انتظار مدارک', 'تأیید نهایی')", $request_id, $user_id));

    if (!$request) {
        return '<p>درخواست یافت نشد یا قابل تکمیل نیست.</p>';
    }

    $plan = $wpdb->get_row($wpdb->prepare("SELECT issue_check, requires_national_card_front, requires_national_card_back FROM $plans_table WHERE id = %d", $request->installment_plan_id));

    if (isset($_POST['mlr_complete_request']) && wp_verify_nonce($_POST['_wpnonce'], 'mlr_complete_request_action')) {
        $order_items = sanitize_textarea_field($_POST['order_items']);
        $order_total = intval($_POST['order_total']);
        $description = sanitize_textarea_field($_POST['description']);
        $check_images = $request->check_images;
        $national_card_front = $request->national_card_front;
        $national_card_back = $request->national_card_back;

        $has_errors = false;
        $error_messages = [];

        if (empty($description)) {
            $has_errors = true;
            $error_messages[] = 'توضیحات الزامی است.';
        }

        // contract_file is required (either existing on request or newly uploaded)
        if (empty($request->contract_file) && (empty($_FILES['contract_file']) || empty($_FILES['contract_file']['name']))) {
            $has_errors = true;
            $error_messages[] = 'فایل فاکتور/قرارداد الزامی است.';
        }

        if ($plan->requires_national_card_front && empty($request->national_card_front) && (empty($_FILES['national_card_front']) || empty($_FILES['national_card_front']['name']))) {
            $has_errors = true;
            $error_messages[] = 'عکس کارت ملی (رو) الزامی است.';
        }
        if ($plan->requires_national_card_back && empty($request->national_card_back) && (empty($_FILES['national_card_back']) || empty($_FILES['national_card_back']['name']))) {
            $has_errors = true;
            $error_messages[] = 'عکس کارت ملی (پشت) الزامی است.';
        }
        if ($plan->issue_check && empty($request->check_images) && (empty($_FILES['check_images']) || empty($_FILES['check_images']['name']))) {
            $has_errors = true;
            $error_messages[] = 'تصاویر چک الزامی است.';
        }

        if ($has_errors) {
            echo '<div class="error"><p>' . esc_html(implode(' | ', $error_messages)) . '</p></div>';
        } else {


        // Handle signature image upload
        $signature_image = $request->signature_image;
        if (!empty($_FILES['signature_image']['name'])) {
            $upload = wp_upload_bits($_FILES['signature_image']['name'], null, file_get_contents($_FILES['signature_image']['tmp_name']));
            if (!$upload['error']) {
                $signature_image = $upload['url'];
            } else {
                echo '<div class="error"><p>خطا در آپلود تصویر امضا: ' . esc_html($upload['error']) . '</p></div>';
                return;
            }
        } elseif (!$request->signature_image) {
            echo '<div class="error"><p>تصویر امضا الزامی است.</p></div>';
            return;
        }

        // Handle contract file upload (optional)
        $contract_file = $request->contract_file;
        if (!empty($_FILES['contract_file']['name'])) {
            $upload = wp_upload_bits($_FILES['contract_file']['name'], null, file_get_contents($_FILES['contract_file']['tmp_name']));
            if (!$upload['error']) {
                $contract_file = $upload['url'];
            } else {
                echo '<div class="error"><p>خطا در آپلود فایل قرارداد: ' . esc_html($upload['error']) . '</p></div>';
            }
        }

        // Handle national card front upload if enabled
        if ($plan->requires_national_card_front && !empty($_FILES['national_card_front']['name'])) {
            $upload = wp_upload_bits($_FILES['national_card_front']['name'], null, file_get_contents($_FILES['national_card_front']['tmp_name']));
            if (!$upload['error']) {
                $national_card_front = $upload['url'];
            } else {
                echo '<div class="error"><p>خطا در آپلود عکس کارت ملی (رو): ' . esc_html($upload['error']) . '</p></div>';
            }
        }

        // Handle national card back upload if enabled
        if ($plan->requires_national_card_back && !empty($_FILES['national_card_back']['name'])) {
            $upload = wp_upload_bits($_FILES['national_card_back']['name'], null, file_get_contents($_FILES['national_card_back']['tmp_name']));
            if (!$upload['error']) {
                $national_card_back = $upload['url'];
            } else {
                echo '<div class="error"><p>خطا در آپلود عکس کارت ملی (پشت): ' . esc_html($upload['error']) . '</p></div>';
            }
        }

        // Handle check images upload if issue_check is enabled
        if ($plan->issue_check && !empty($_FILES['check_images']['name'][0])) {
            $check_urls = [];
            foreach ($_FILES['check_images']['name'] as $key => $value) {
                if ($_FILES['check_images']['name'][$key]) {
                    $upload = wp_upload_bits($_FILES['check_images']['name'][$key], null, file_get_contents($_FILES['check_images']['tmp_name'][$key]));
                    if (!$upload['error']) {
                        $check_urls[] = $upload['url'];
                    } else {
                        echo '<div class="error"><p>خطا در آپلود تصویر چک: ' . esc_html($upload['error']) . '</p></div>';
                    }
                }
            }
            $check_images = implode(',', $check_urls);
        }

        $wpdb->update(
            $table_name,
            [
                'order_items' => $order_items,
                'order_total' => $order_total,
                'description' => $description,
                'signature_image' => $signature_image,
                'contract_file' => $contract_file,
                'national_card_front' => $national_card_front,
                'national_card_back' => $national_card_back,
                'check_images' => $check_images,
                'status' => 'تأیید نهایی',
                'last_edited_at' => current_time('mysql')
            ],
            ['id' => $request_id, 'user_id' => $user_id]
        );
        echo '<div class="updated"><p>درخواست با موفقیت تکمیل شد و به حالت "تأیید نهایی" تغییر یافت.</p></div>';
        $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND user_id = %d", $request_id, $user_id));
        }
    }

    ob_start();
    ?>
    <div class="mlr-complete-request">
        <h2>تکمیل درخواست (شناسه: <?php echo $request_id; ?>)</h2>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('mlr_complete_request_action'); ?>
            <p><label>اقلام سفارش: <textarea name="order_items" required><?php echo esc_textarea($request->order_items); ?></textarea></label></p>
            <p><label>مبلغ کل سفارش (تومان): <input type="number" name="order_total" value="<?php echo esc_attr($request->order_total); ?>" required></label></p>
            <p><label>توضیحات: <textarea name="description" required><?php echo esc_textarea($request->description); ?></textarea></label></p>
            <p><label>تصویر امضا: <input type="file" name="signature_image" <?php echo $request->signature_image ? '' : 'required'; ?>></label></p>
            <p><label>فایل فاکتور/قرارداد: <input type="file" name="contract_file" required></label></p>
            <?php if ($plan->requires_national_card_front) : ?>
            <p><label>عکس کارت ملی (رو): <input type="file" name="national_card_front" required></label></p>
            <?php endif; ?>
            <?php if ($plan->requires_national_card_back) : ?>
            <p><label>عکس کارت ملی (پشت): <input type="file" name="national_card_back" required></label></p>
            <?php endif; ?>
            <?php if ($plan->issue_check) : ?>
            <p><label>تصاویر چک: <input type="file" name="check_images[]" multiple required></label></p>
            <?php endif; ?>
            <button type="submit" name="mlr_complete_request" class="button">ذخیره و تأیید نهایی</button>
        </form>
    </div>
    <?php
    return ob_get_clean();
}
?>