<?php
if (!defined('ABSPATH')) {
    exit;
}

// The form processing logic has been moved to includes/ajax/submit-loan-request.php

add_shortcode('mlr_loan_request_form', 'mlr_loan_request_form_shortcode');

function mlr_loan_request_form_shortcode() {
    wp_enqueue_style('mlr-loan-form-style', MLR_PLUGIN_URL . 'assets/css/loan-request-form.css', [], '6.5.1');

    if (!is_user_logged_in()) {
        return '<div class="mlr-form-container"><p style="padding: 30px; text-align:center;">برای ثبت درخواست، لطفاً ابتدا <a href="' . wp_login_url(get_permalink()) . '">وارد شوید</a>.</p></div>';
    }

    global $wpdb;
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $plans = $wpdb->get_results("SELECT id, name, type, settings FROM $table_installment_plans WHERE is_active = 1 ORDER BY id DESC");
    
    $js_plans = array_map(function($plan) {
        $settings = maybe_unserialize($plan->settings);
        $plan->view_settings = ['requires_bank_validation' => $settings['requires_bank_validation'] ?? 0, 'min_amount' => $settings['min_amount'] ?? 0, 'max_amount' => $settings['max_amount'] ?? 0, 'active_installments' => $settings['active_installments'] ?? '', 'min_interval' => $settings['min_interval'] ?? 1, 'max_interval' => $settings['max_interval'] ?? 12];
        unset($plan->settings); 
        return $plan;
    }, $plans);

    $user_id = get_current_user_id();
    $user_commission = get_user_meta($user_id, 'acceptor_commission_percent', true);

    wp_enqueue_script('mlr-front-form-js', MLR_PLUGIN_URL . 'assets/js/loan-request-form.js', ['jquery'], '6.5.2');
    wp_localize_script('mlr-front-form-js', 'mlr_form_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('mlr_frontend_nonce'),
        'calc_nonce' => wp_create_nonce('mlr_frontend_calc_nonce'),
        'submit_nonce' => wp_create_nonce('mlr_loan_request_action'),
        'plans' => $js_plans, 
        'user_commission' => $user_commission
    ]);
    
    ob_start();

    try {
        $jalali_year = (int)date_i18n('Y', time(), new DateTimeZone('Asia/Tehran')) - 621;
    } catch (Exception $e) {
        $jalali_year = 1403;
    }

    $end_year = $jalali_year - 18;
    $start_year = $jalali_year - 75;
    ?>
    <div class="mlr-form-container">
        <div class="mlr-form-wrapper">
            <div class="mlr-stepper-sidebar">
                <div class="mlr-steps-container">
                    <div class="mlr-step-item" data-step-id="1">
                        <div class="mlr-step-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        </div>
                        <div class="mlr-step-text">
                            <span class="mlr-step-label">احراز هویت</span>
                            <span class="mlr-step-sublabel">تایید شماره موبایل</span>
                        </div>
                    </div>
                    <div class="mlr-step-item" data-step-id="2">
                        <div class="mlr-step-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                        </div>
                        <div class="mlr-step-text">
                            <span class="mlr-step-label">انتخاب طرح</span>
                            <span class="mlr-step-sublabel">محاسبه اقساط</span>
                        </div>
                    </div>
                    <div class="mlr-step-item" data-step-id="3" id="step-indicator-3" style="display:none;">
                        <div class="mlr-step-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 17l4 4L14 7l4 4L22 3"></path><path d="M12 7h4a2 2 0 0 1 2 2v4"></path></svg>
                        </div>
                        <div class="mlr-step-text">
                            <span class="mlr-step-label">اعتبارسنجی</span>
                            <span class="mlr-step-sublabel">بررسی بانکی</span>
                        </div>
                    </div>
                    <div class="mlr-step-item" data-step-id="4">
                        <div class="mlr-step-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        </div>
                        <div class="mlr-step-text">
                            <span class="mlr-step-label">اطلاعات فردی</span>
                            <span class="mlr-step-sublabel">مشخصات و آدرس</span>
                        </div>
                    </div>
                    <div class="mlr-step-item" data-step-id="5">
                        <div class="mlr-step-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>
                        </div>
                        <div class="mlr-step-text">
                            <span class="mlr-step-label">مدارک</span>
                            <span class="mlr-step-sublabel">بارگذاری فایل‌ها</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mlr-form-content">
                <form id="mlr-loan-request-form-main" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="national_code" id="national_code">
                    <input type="hidden" name="mobile_number" id="mobile_number">
                    <input type="hidden" name="birth_date" id="birth_date">
                    <input type="hidden" name="order_items" id="order_items_json">

                    <div class="mlr-step-content" id="step1">
                        <p class="mlr-step-description">لطفا کد ملی و شماره موبایل خود را جهت استعلام تطابق وارد نمایید.</p>
                        <div id="mlr-message"></div>
                        <div class="mlr-form-group">
                            <label for="national_code_verify">کد ملی</label>
                            <input type="text" id="national_code_verify" class="mlr-input" placeholder="کد ملی ۱۰ رقمی" style="text-align:center; direction: ltr;">
                            <span class="mlr-error-message">کد ملی باید ۱۰ رقم باشد.</span>
                        </div>
                        <div class="mlr-form-group">
                            <label for="mobile_number_verify">شماره موبایل</label>
                            <input type="text" id="mobile_number_verify" class="mlr-input" placeholder="مثال: 09123456789" style="text-align:center; direction: ltr;">
                            <span class="mlr-error-message">شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.</span>
                        </div>
                        <button type="button" id="verify_shahkar_btn" class="mlr-btn mlr-btn-primary" style="width: 100%;" disabled>بررسی تطابق و ادامه</button>
                    </div>

                    <div class="mlr-step-content" id="step2">
                        <div class="mlr-form-group">
                            <label for="calc_plan_select">طرح اقساطی:</label>
                            <select id="calc_plan_select" name="installment_plan_id" class="mlr-select" required>
                                <option value="">-- یک طرح را انتخاب کنید --</option>
                                <?php foreach($plans as $plan): ?>
                                    <option value="<?php echo esc_attr($plan->id); ?>" data-type="<?php echo esc_attr($plan->type); ?>"><?php echo esc_html($plan->name); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="mlr-error-message">انتخاب طرح الزامی است.</span>
                        </div>
                        <div class="mlr-grid-2-col">
                            <div class="mlr-form-group"><label id="calc_amount_label" for="calc_amount">مبلغ (ریال):</label><input type="text" id="calc_amount" name="loan_amount" class="mlr-input" required><span class="mlr-error-message">مبلغ وارد شده خارج از محدوده مجاز طرح است.</span></div>
                            <div class="mlr-form-group"><label for="calc_installments">تعداد اقساط:</label><select id="calc_installments" name="installment_count" class="mlr-select" required></select></div>
                        </div>
                        <div class="mlr-form-group" id="calc_interval_wrapper" style="display:none;">
                            <label for="calc_interval">فاصله اقساط (ماه):</label>
                            <input type="number" id="calc_interval" name="installment_interval" value="1" class="mlr-input">
                            <span class="mlr-error-message">فاصله اقساط خارج از محدوده مجاز طرح است.</span>
                        </div>
                        <button type="button" id="run_calculator" class="mlr-btn mlr-btn-primary" style="width:100%; margin-bottom: 20px;" disabled>محاسبه</button>
                        <div id="calculation-result"></div>
                        <div class="mlr-step-buttons">
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-prev-btn" data-target-step="1">مرحله قبل</button>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-next-btn" id="next_step_2" disabled>مرحله بعد</button>
                        </div>
                    </div>
                    
                    <div class="mlr-step-content" id="step3">
                        <p class="mlr-step-description">این قابلیت در حال حاضر در مرحله توسعه است. برای ادامه، روی دکمه "مرحله بعد" کلیک کنید.</p>
                        <div class="mlr-step-buttons">
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-prev-btn" data-target-step="2">مرحله قبل</button>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-next-btn" data-target-step="4">مرحله بعد</button>
                        </div>
                    </div>

                    <div class="mlr-step-content" id="step4">
                        <div class="mlr-grid-2-col">
                            <div class="mlr-form-group"><label for="full_name">نام و نام خانوادگی:</label><input type="text" name="full_name" id="full_name" class="mlr-input" required><span class="mlr-error-message">این فیلد الزامی است.</span></div>
                            <div class="mlr-form-group"><label for="phone_number">شماره تلفن ثابت (اختیاری):</label><input type="text" name="phone_number" id="phone_number" class="mlr-input"></div>
                        </div>
                        <div class="mlr-form-group">
                            <label>تاریخ تولد:</label>
                            <div class="mlr-birthdate-group">
                                <select name="birth_day" id="birth_day" class="mlr-select" required><option value="">روز</option><?php for ($i = 1; $i <= 31; $i++): ?><option value="<?php echo $i; ?>"><?php echo $i; ?></option><?php endfor; ?></select>
                                <select name="birth_month" id="birth_month" class="mlr-select" required><option value="">ماه</option><option value="1">فروردین</option><option value="2">اردیبهشت</option><option value="3">خرداد</option><option value="4">تیر</option><option value="5">مرداد</option><option value="6">شهریور</option><option value="7">مهر</option><option value="8">آبان</option><option value="9">آذر</option><option value="10">دی</option><option value="11">بهمن</option><option value="12">اسفند</option></select>
                                <select name="birth_year" id="birth_year" class="mlr-select" required><option value="">سال</option><?php for ($year = $end_year; $year >= $start_year; $year--): ?><option value="<?php echo esc_attr($year); ?>"><?php echo esc_html($year); ?></option><?php endfor; ?></select>
                            </div>
                             <span class="mlr-error-message" id="birthdate-error">تاریخ تولد کامل الزامی است.</span>
                        </div>
                        <div class="mlr-grid-2-col">
                            <div class="mlr-form-group"><label for="occupation">شغل:</label><select name="occupation" id="occupation" class="mlr-select" required><option value="">انتخاب کنید...</option><option value="official_employee">کارمند رسمی</option><option value="contract_employee">کارمند قراردادی</option><option value="worker">کارگر</option><option value="freelancer">آزاد</option><option value="retired">بازنشسته</option><option value="pensioner">مستمری بگیر</option><option value="employer">کارفرما</option><option value="other">سایر</option></select><span class="mlr-error-message">انتخاب شغل الزامی است.</span></div>
                            <div class="mlr-form-group"><label for="postal_code">کد پستی:</label><input type="text" name="postal_code" id="postal_code" class="mlr-input" required><span class="mlr-error-message">کد پستی ۱۰ رقمی الزامی است.</span></div>
                        </div>
                        <div class="mlr-form-group"><label for="residential_address">آدرس محل سکونت:</label><textarea name="residential_address" id="residential_address" rows="3" class="mlr-textarea" required></textarea><span class="mlr-error-message">آدرس محل سکونت الزامی است.</span></div>
                        <div class="mlr-form-group"><label for="work_address">آدرس محل فعالیت:</label><textarea name="work_address" id="work_address" rows="3" class="mlr-textarea" required></textarea><span class="mlr-error-message">آدرس محل فعالیت الزامی است.</span></div>
                        
                        <div class="mlr-form-group">
                            <label>محصولات درخواستی</label>
                            <div class="mlr-loan-amount-notice">مبلغ تسهیلات درخواستی شما: <span id="display_loan_amount">0</span> ریال</div>
                            <div id="mlr-product-repeater">
                                <div class="mlr-product-repeater-header">
                                    <div>شناسه محصول</div>
                                    <div>نام کامل محصول</div>
                                    <div>قیمت (ریال)</div>
                                    <div>تعداد</div>
                                    <div>مبلغ کل ردیف</div>
                                    <div></div>
                                </div>
                                <div class="mlr-product-row">
                                    <input type="text" class="mlr-input product-id" placeholder="اختیاری">
                                    <input type="text" class="mlr-input product-name" required>
                                    <input type="text" class="mlr-input product-price" required>
                                    <input type="number" class="mlr-input product-qty" min="1" value="1" required>
                                    <div class="product-row-total">0 ریال</div>
                                    <button type="button" class="mlr-remove-product-btn" style="display: none;">&times;</button>
                                </div>
                            </div>
                            <button type="button" id="mlr-add-product-btn" class="mlr-btn-add-row">+ افزودن محصول دیگر</button>
                            <div class="mlr-product-total-summary">
                                جمع کل مبلغ محصولات: <span id="display_product_total">0</span> ریال
                            </div>
                             <span class="mlr-error-message" id="product-error">لطفاً اطلاعات تمام محصولات را کامل کرده و مجموع مبلغ آن‌ها را با مبلغ تسهیلات برابر کنید.</span>
                        </div>

                        <div class="mlr-step-buttons">
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-prev-btn" data-target-step="2" id="prev_step_4">مرحله قبل</button>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-next-btn" id="next_step_4" data-target-step="5" disabled>مرحله بعد</button>
                        </div>
                    </div>

                    <div class="mlr-step-content" id="step5">
                        <p class="mlr-step-description">لطفا مدارک مورد نیاز طرح انتخابی را بارگذاری نمایید.</p>
                        <div id="dynamic-documents"></div>
                         <div id="mlr-submission-feedback"></div>
                        <div class="mlr-step-buttons">
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-prev-btn" data-target-step="4">مرحله قبل</button>
                            <button type="button" class="mlr-btn mlr-btn-primary" id="final-submit-btn" disabled>ارسال نهایی درخواست</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}