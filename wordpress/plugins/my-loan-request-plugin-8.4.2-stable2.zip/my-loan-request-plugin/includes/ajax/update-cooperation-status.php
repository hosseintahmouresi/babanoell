<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_update_cooperation_status', 'mlr_update_cooperation_status_callback');

function mlr_update_cooperation_status_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $new_status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

    if (!$request_id || empty($new_status)) {
        wp_send_json_error(['message' => 'اطلاعات نامعتبر است.']);
        return;
    }

    $allowed_statuses = mlr_get_cooperation_statuses();
    if (!in_array($new_status, $allowed_statuses)) {
        wp_send_json_error(['message' => 'وضعیت انتخاب شده مجاز نیست.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'cooperation_requests';
    $current_request = $wpdb->get_row($wpdb->prepare("SELECT status, contract_token FROM $table_name WHERE id = %d", $request_id));

    if (!$current_request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    $data_to_update = ['status' => $new_status];
    $token = $current_request->contract_token; // Keep existing token by default
    $new_token_generated = false;

    // *** MODIFIED: Generate Token on 'تایید مدارک' status ***
    if ($new_status === 'تایید مدارک' && empty($current_request->contract_token)) {
        // Generate a 12-character hex token
        $token = bin2hex(random_bytes(6)); // 6 bytes = 12 hex characters
        // Ensure token uniqueness
        while ($wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE contract_token = %s", $token))) {
            $token = bin2hex(random_bytes(6));
        }
        $data_to_update['contract_token'] = $token;
        $new_token_generated = true; // Flag that a new token was made
        mlr_log("Generated contract token for cooperation request ID {$request_id} upon reaching 'تایید مدارک': {$token}");
    }
    // *** END Modification ***

    $updated = $wpdb->update(
        $table_name,
        $data_to_update,
        ['id' => $request_id]
    );

    if ($updated === false) {
        // Check for duplicate token error specifically if a new one was generated
        if ($new_token_generated && $wpdb->last_error && strpos($wpdb->last_error, 'Duplicate entry') !== false && strpos($wpdb->last_error, 'idx_contract_token') !== false) {
             mlr_log("Token collision detected for cooperation request ID {$request_id}. Token: {$token}. Retrying generation might be needed.");
             wp_send_json_error(['message' => 'خطا در ایجاد لینک یکتا (تداخل). لطفاً دوباره تلاش کنید.']);
             return;
        } else {
            mlr_log("Error updating cooperation status for ID {$request_id}: " . $wpdb->last_error);
            wp_send_json_error(['message' => 'خطا در به‌روزرسانی وضعیت در دیتابیس: ' . $wpdb->last_error]);
        }
        return;
    }

    // Attempt to send SMS if status actually changed
    if ($current_request->status !== $new_status) {
        // Pass the request object with the potentially new token for SMS placeholder replacement
        $updated_request_for_sms = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}cooperation_requests WHERE id = %d", $request_id));
        if ($updated_request_for_sms) {
            mlr_send_sms_on_cooperation_status_change($request_id, $new_status, $updated_request_for_sms); // Pass the updated request object
        }
    }

    $response_data = ['message' => 'وضعیت با موفقیت به‌روزرسانی شد.'];
    // Include the generated link in the success response if token was generated or already exists and status allows it
    $link_relevant_statuses = ['تایید مدارک', 'عقد قرارداد']; // Statuses where the link is relevant
    if (in_array($new_status, $link_relevant_statuses) && !empty($token)) {
         $contract_page = get_page_by_path('cooperation-contract'); // Get page object
         if ($contract_page) {
             $contract_page_url = get_permalink($contract_page->ID);
             if ($contract_page_url) {
                $response_data['contract_link'] = esc_url(add_query_arg('token', $token, $contract_page_url));
             } else {
                 mlr_log("Could not get permalink for cooperation-contract page to generate contract link for request ID {$request_id}.");
             }
         } else {
              mlr_log("Could not find page with slug 'cooperation-contract' to generate contract link for request ID {$request_id}.");
         }
    }

    wp_send_json_success($response_data);
}
?>