<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_submit_cooperation_request', 'mlr_submit_cooperation_request_callback');
add_action('wp_ajax_nopriv_mlr_submit_cooperation_request', 'mlr_submit_cooperation_request_callback');

function mlr_submit_cooperation_request_callback() {
    check_ajax_referer('mlr_cooperation_request_action', '_wpnonce');

    global $wpdb;
    $errors = [];
    $data = [];
    $files = [];

    $request_type = isset($_POST['request_type']) ? sanitize_text_field($_POST['request_type']) : '';
    if (empty($request_type) || !in_array($request_type, ['individual', 'legal'])) {
        wp_send_json_error(['message' => 'نوع درخواست نامعتبر است.']);
        return;
    }

    $all_fields = mlr_get_all_cooperation_fields();
    $default_config = [];
    foreach ($all_fields as $key => $info) {
        $default_config[$key] = ['visible' => $info['default_visible'] ?? true, 'required' => $info['default_required'] ?? false];
    }
    $form_config = wp_parse_args(get_option('mlr_cooperation_form_config', []), $default_config);


    foreach ($all_fields as $field_key => $field_info) {
        if ($field_info['form'] !== 'both' && $field_info['form'] !== $request_type) {
            continue;
        }

        $config = $form_config[$field_key];
        $is_visible = (bool)$config['visible'];
        $is_required = (bool)$config['required'];

        if ($field_info['type'] === 'file') {
            if (!$is_visible) continue;

            if (isset($_FILES[$field_key])) {
                if (!function_exists('wp_handle_upload')) {
                    require_once ABSPATH . 'wp-admin/includes/file.php';
                    require_once ABSPATH . 'wp-admin/includes/image.php';
                    require_once ABSPATH . 'wp-admin/includes/media.php';
                }
                
                $allowed_mimes = ['jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf'];
                $uploaded_files_for_field = [];
                $file_data_arr = $_FILES[$field_key];

                $rearranged_files = [];
                if(isset($file_data_arr['name']) && is_array($file_data_arr['name'])) {
                    foreach ($file_data_arr['name'] as $key => $name) {
                        if ($file_data_arr['error'][$key] !== UPLOAD_ERR_NO_FILE) {
                            $rearranged_files[] = [
                                'name'     => $file_data_arr['name'][$key],
                                'type'     => $file_data_arr['type'][$key],
                                'tmp_name' => $file_data_arr['tmp_name'][$key],
                                'error'    => $file_data_arr['error'][$key],
                                'size'     => $file_data_arr['size'][$key]
                            ];
                        }
                    }
                } elseif (isset($file_data_arr['name']) && $file_data_arr['error'] !== UPLOAD_ERR_NO_FILE) {
                     $rearranged_files[] = $file_data_arr;
                }

                foreach ($rearranged_files as $single_file) {
                    if ($single_file['error'] === UPLOAD_ERR_OK) {
                        $file_type = wp_check_filetype(basename($single_file['name']), $allowed_mimes);
                        if (empty($file_type['ext']) || empty($file_type['type']) || !in_array($file_type['type'], array_values($allowed_mimes))) {
                            $errors[] = 'خطا: نوع فایل "' . esc_html($single_file['name']) . '" مجاز نیست.';
                            continue;
                        }

                        if ($single_file['size'] > 5 * 1024 * 1024) {
                             $errors[] = 'خطا: حجم فایل "' . esc_html($single_file['name']) . '" بیشتر از 5 مگابایت است.';
                             continue;
                        }

                        $clean_name = sanitize_file_name($single_file['name']);
                        $single_file['name'] = $clean_name;

                        // Use media_handle_sideload (or custom upload + attachment insert) to register in Media Library
                        // Since we have the $_FILES array, we can simulate the upload
                        $upload_overrides = ['test_form' => false, 'mimes' => $allowed_mimes];
                        $movefile = wp_handle_upload($single_file, $upload_overrides);

                        if ($movefile && !isset($movefile['error'])) {
                            // Register in Media Library
                            $wp_filetype = wp_check_filetype(basename($movefile['file']), null);
                            $attachment = [
                                'guid'           => $movefile['url'], 
                                'post_mime_type' => $wp_filetype['type'],
                                'post_title'     => preg_replace('/\.[^.]+$/', '', basename($movefile['file'])),
                                'post_content'   => '',
                                'post_status'    => 'inherit'
                            ];
                            
                            $attach_id = wp_insert_attachment($attachment, $movefile['file']);
                            if (!is_wp_error($attach_id)) {
                                require_once(ABSPATH . 'wp-admin/includes/image.php');
                                $attach_data = wp_generate_attachment_metadata($attach_id, $movefile['file']);
                                wp_update_attachment_metadata($attach_id, $attach_data);
                            }

                            $uploaded_files_for_field[] = $movefile['url'];
                        } else {
                            $errors[] = 'خطا در آپلود فایل: ' . ($movefile['error'] ?? '');
                        }
                    }
                }

                if (!empty($uploaded_files_for_field)) {
                    $files[$field_key] = $uploaded_files_for_field;
                } elseif ($is_required) {
                    $errors[] = 'فیلد "' . esc_html($field_info['label']) . '" اجباری است.';
                }

            } elseif ($is_required) {
                $errors[] = 'فیلد "' . esc_html($field_info['label']) . '" اجباری است.';
            }

        } else {
            $value = isset($_POST[$field_key]) ? stripslashes($_POST[$field_key]) : '';
            switch ($field_info['type']) {
                case 'email':
                    $sanitized_value = sanitize_email($value);
                    if (!empty($value) && !is_email($sanitized_value)) {
                         $errors[] = 'فرمت ایمیل نامعتبر است.';
                         $sanitized_value = '';
                    }
                    break;
                case 'textarea':
                    $sanitized_value = sanitize_textarea_field($value);
                    break;
                case 'text':
                case 'select':
                default:
                    $sanitized_value = sanitize_text_field($value);
                    break;
            }

            if ($is_required && empty(trim($sanitized_value))) {
                $errors[] = 'فیلد "' . esc_html($field_info['label']) . '" اجباری است.';
            }
            $data[$field_key] = $sanitized_value;
        }
    }

    if (empty($errors)) {
        $table_requests = $wpdb->prefix . 'cooperation_requests';
        
        // --- Unique Token Generation with Retry ---
        $max_retries = 5;
        $retry_count = 0;
        $inserted = false;
        $last_db_error = '';

        do {
            // Generate a random 64-char token (32 bytes hex)
            $token_candidate = bin2hex(random_bytes(32));
            
            // Explicitly check for existence first to avoid relying solely on DB error which is messier
            $existing_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_requests WHERE contract_token = %s", $token_candidate));
            
            if (!$existing_id) {
                $insert_data = [
                    'request_type' => $request_type,
                    'status' => 'در حال بررسی',
                    'contract_token' => $token_candidate,
                    'data' => wp_json_encode($data, JSON_UNESCAPED_UNICODE),
                    'files' => wp_json_encode($files, JSON_UNESCAPED_UNICODE),
                    'created_at' => current_time('mysql')
                ];

                $result = $wpdb->insert($table_requests, $insert_data);
                
                if ($result !== false) {
                    $inserted = true;
                    $new_request_id = $wpdb->insert_id;
                } else {
                    $last_db_error = $wpdb->last_error;
                }
            }
            
            $retry_count++;
        } while (!$inserted && $retry_count < $max_retries);


        if ($inserted) {
            mlr_send_sms_on_cooperation_status_change($new_request_id, 'در حال بررسی');
            wp_send_json_success(['message' => 'درخواست همکاری شما با موفقیت ثبت گردید.']);
            return;
        } else {
            mlr_log("Cooperation Submission Failed after {$retry_count} retries. DB Error: " . $last_db_error);
            wp_send_json_error(['message' => 'خطا در ثبت اطلاعات. لطفاً مجدداً تلاش کنید.']);
        }

    } else {
        wp_send_json_error(['message' => implode('<br>', $errors)]);
    }
}
?>