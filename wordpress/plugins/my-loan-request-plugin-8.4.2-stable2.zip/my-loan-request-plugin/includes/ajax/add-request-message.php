<?php
// FILE: my-loan-request-plugin/includes/ajax/add-request-message.php
if (!defined('ABSPATH')) { exit; }

add_action('wp_ajax_mlr_add_request_message', 'mlr_add_request_message_callback');

function mlr_add_request_message_callback() {
    if (!function_exists('mlr_verify_any_nonce') || !mlr_verify_any_nonce('nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی.']);
        return;
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای ارسال پیام، ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $message    = isset($_POST['message']) ? wp_unslash($_POST['message']) : '';

    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر.']);
        return;
    }
    if (trim(wp_strip_all_tags($message)) === '') {
        wp_send_json_error(['message' => 'متن پیام خالی است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $req = $wpdb->get_row($wpdb->prepare("SELECT id,user_id,assigned_bank_user_id FROM {$table_name} WHERE id=%d", $request_id));
    if (!$req) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    $current_user = wp_get_current_user();
    $uid = get_current_user_id();
    $is_admin = current_user_can('manage_options');
    $is_bank  = in_array('bank', (array)$current_user->roles, true);

    // دسترسی: ادمین/بک‌اند، بانکِ ارجاع شده، یا خود متقاضی
    if (!$is_admin) {
        if ($is_bank) {
            if (intval($req->assigned_bank_user_id) !== $uid) {
                wp_send_json_error(['message' => 'دسترسی ندارید.']);
                return;
            }
        } else {
            if (intval($req->user_id) !== $uid) {
                wp_send_json_error(['message' => 'دسترسی ندارید.']);
                return;
            }
        }
    }

    if (!function_exists('mlr_add_request_message')) {
        wp_send_json_error(['message' => 'زیرساخت پیام‌ها فعال نیست.']);
        return;
    }

    $insert_id = mlr_add_request_message($request_id, $message);

    if (!$insert_id) {
        wp_send_json_error(['message' => 'ارسال پیام ناموفق بود.']);
        return;
    }

    if (function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'message', 'ارسال پیام جدید');
    }

    // Return latest thread
    if (function_exists('mlr_get_request_messages')) {
        $msgs = mlr_get_request_messages($request_id, 500);
    } else {
        $msgs = [];
    }

    wp_send_json_success([
    return;
        'message' => 'پیام ارسال شد.',
        'messages_html' => function_exists('mlr_render_request_messages_html') ? mlr_render_request_messages_html($msgs) : ''
    ]);
}
