<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');
add_action('wp_ajax_nopriv_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');

function mlr_frontend_calculate_loan_callback() {
    try {
        check_ajax_referer('mlr_frontend_calc_nonce', 'nonce');

        $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
        if (!$plan_id) {
            wp_send_json_error(['message' => 'لطفاً یک طرح را انتخاب کنید.']);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'installment_plans';
        $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND is_active = 1", $plan_id));

        if (!$plan) {
            wp_send_json_error(['message' => 'طرح انتخاب شده یافت نشد یا غیرفعال است.']);
        }

        $settings = maybe_unserialize($plan->settings);
        $display_fields = maybe_unserialize($plan->display_fields);
        $amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
        $installments = isset($_POST['installments']) ? intval($_POST['installments']) : 0;
        
        // --- START: Get user commission from AJAX POST ---
        $user_commission = isset($_POST['user_commission']) && is_numeric($_POST['user_commission']) ? floatval($_POST['user_commission']) : null;
        // --- END: Get user commission ---

        if ($amount <= 0 || $installments <= 0) {
            wp_send_json_error(['message' => 'مبلغ و تعداد اقساط باید معتبر باشند.']);
        }
        
        if ($amount < ($settings['min_amount'] ?? 0) || $amount > ($settings['max_amount'] ?? 0)) {
            wp_send_json_error(['message' => 'مبلغ وارد شده در محدوده مجاز این طرح نیست.']);
        }

        $results = [];
        if ($plan->type === 'market') {
            // Pass user commission as the 4th argument
            $results = calculateMarketLoan($amount, $installments, $settings, $user_commission);
        } elseif ($plan->type === 'leasing') {
            $installment_interval = isset($_POST['installment_interval']) ? intval($_POST['installment_interval']) : 1;
            // Pass user commission as the 5th argument
            $results = calculateLeasingLoan($amount, $installments, $installment_interval, $settings, $user_commission);
        }

        if (empty($results)) {
            wp_send_json_error(['message' => 'نوع طرح نامعتبر است یا محاسبات انجام نشد.']);
        }

        $labels_with_units = mlr_get_calculation_labels();
        ob_start();
        echo '<table>';
        foreach ($results as $key => $value) {
            if (!empty($display_fields) && is_array($display_fields) && in_array($key, $display_fields)) {
                $label_info = $labels_with_units[$key] ?? ['label' => ucwords(str_replace('_', ' ', $key)), 'unit' => ''];
                $label = $label_info['label'];
                $unit = $label_info['unit'];
                $formatted_value = '';

                if ($unit === 'درصد') {
                    $formatted_value = number_format($value * 100, 3) . ' ' . $unit;
                } else {
                    $formatted_value = number_format(round($value)) . ' ' . $unit;
                }
                
                echo '<tr>';
                echo '<td><strong>' . esc_html($label) . '</strong></td>';
                echo '<td>' . esc_html($formatted_value) . '</td>';
                echo '</tr>';
            }
        }
        echo '</table>';
        $html = ob_get_clean();

        if (empty(trim(strip_tags($html)))) {
            $html = '<p>هیچ فیلدی برای نمایش در این طرح تنظیم نشده است. لطفاً با مدیر سایت تماس بگیرید.</p>';
        }

        wp_send_json_success(['html' => $html]);
        return;

    } catch (Exception $e) {
        error_log('Frontend Calculator Error: ' . $e->getMessage());
        wp_send_json_error(['message' => 'خطای داخلی سرور.']);
    }
}