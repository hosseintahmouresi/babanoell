<?php
/*
Plugin Name: درخواست تسهیلات بابانوئل
Description: افزونه‌ای برای مدیریت درخواست‌های تسهیلات با قابلیت محاسبه اقساط و ثبت-نام پذیرندگان
Version: 8.4.2.5
Author: شرکت پدیده تجارت
*/

if (!defined('ABSPATH')) {
    exit;
}

define('MLR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MLR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MLR_VERSION', '8.4.3.0');


// --- START: MLR Log Path Helpers ---
if (!function_exists('mlr_get_log_file_path')) {
    function mlr_get_log_file_path() {
        $upload_dir = wp_upload_dir(null, false);
        $base_dir = isset($upload_dir['basedir']) ? $upload_dir['basedir'] : WP_CONTENT_DIR;
        $log_dir  = trailingslashit($base_dir) . 'mlr-logs';
        return trailingslashit($log_dir) . 'mlr_debug.log';
    }
}

if (!function_exists('mlr_ensure_log_dir')) {
    function mlr_ensure_log_dir() {
        $log_file = mlr_get_log_file_path();
        $log_dir  = dirname($log_file);

        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }

        // Create protection files (best-effort)
        $index_file = trailingslashit($log_dir) . 'index.html';
        if (!file_exists($index_file)) {
            @file_put_contents($index_file, '');
        }

        $htaccess_file = trailingslashit($log_dir) . '.htaccess';
        if (!file_exists($htaccess_file)) {
            @file_put_contents($htaccess_file, "Deny from all\n");
        }
    }
}
// --- END: MLR Log Path Helpers ---



// --- START: MLR Logging Function ---
if (!function_exists('mlr_log')) {
    function mlr_log($message) {
        $log_file = mlr_get_log_file_path();
        mlr_ensure_log_dir();
        $timestamp = date('Y-m-d H:i:s');
        
        // Prepare message
        if (is_array($message) || is_object($message)) {
            $log_content = print_r($message, true);
        } else {
            $log_content = $message;
        }

        // Mask sensitive data (Basic Protection)
        $log_content = preg_replace('/(password|client_secret|Authorization)(\'|")?\s*(=>|:)\s*(\'|")?([^\'"\s]+)(\'|")?/i', '$1$2$3$4*****$6', $log_content);

        $formatted_message = sprintf("[%s] %s\n", $timestamp, $log_content);
        
        // Add file locking for safer concurrent writes
        $file_handle = @fopen($log_file, 'a');
        if ($file_handle) {
            if (flock($file_handle, LOCK_EX)) {
                fwrite($file_handle, $formatted_message);
                fflush($file_handle);
                flock($file_handle, LOCK_UN);
            }
            fclose($file_handle);
        } else {
             error_log("MLR_Log Error: Could not open log file for writing: " . $log_file);
        }
    }
}
// --- END: MLR Logging Function ---


// --- START: افزودن فیلدهای سفارشی به پروفایل کاربر ---
add_action('show_user_profile', 'mlr_add_custom_user_profile_fields');
add_action('edit_user_profile', 'mlr_add_custom_user_profile_fields');
function mlr_add_custom_user_profile_fields($user) {
    ?>
    <h3>اطلاعات تکمیلی پذیرنده</h3>
    <table class="form-table">
        <tr>
            <th><label for="shebaaa">شماره شبا</label></th>
            <td>
                <input type="text" name="shebaaa" id="shebaaa" value="<?php echo esc_attr(get_the_author_meta('shebaaa', $user->ID)); ?>" class="regular-text ltr" pattern="[0-9]{24}" title="شماره شبا 24 رقمی" />
                <p class="description">شماره شبا ۲۴ رقمی بدون IR</p>
            </td>
        </tr>
        <?php if (current_user_can('manage_options') || current_user_can('edit_user', $user->ID)): ?>
        <?php if (current_user_can('manage_options')): ?>
        <tr>
            <th><label for="acceptor_commission_percent">کمیسیون پذیرنده (%)</label></th>
            <td>
                <input type="number" name="acceptor_commission_percent" id="acceptor_commission_percent" value="<?php echo esc_attr(get_the_author_meta('acceptor_commission_percent', $user->ID)); ?>" class="small-text ltr" step="0.01" min="0" max="100" />
                <p class="description">این مقدار در محاسبه‌گر فرم ثبت‌نام استفاده خواهد شد (پیش‌فرض تنظیمات طرح اعمال می‌شود).</p>
            </td>
        </tr>
        <?php endif; ?>
         <tr>
             <th><label for="acceptor_mobile_number">شماره موبایل پذیرنده (برای پیامک)</label></th>
             <td>
                 <input type="text" name="acceptor_mobile_number" id="acceptor_mobile_number" value="<?php echo esc_attr(get_the_author_meta('acceptor_mobile_number', $user->ID)); ?>" class="regular-text ltr" pattern="09[0-9]{9}" title="شماره موبایل 11 رقمی با شروع 09" />
                 <p class="description">این شماره موبایل برای دریافت پیامک‌های مربوط به وضعیت درخواست‌های تسهیلات استفاده خواهد شد. (جایگزین شماره موبایل پیش‌فرض حساب کاربری یا ووکامرس)</p>
             </td>
         </tr>
        <?php endif; ?>
    </table>
    <?php
}

add_action('personal_options_update', 'mlr_save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'mlr_save_custom_user_profile_fields');
function mlr_save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    if (isset($_POST['shebaaa'])) {
        $sheba = preg_replace('/[^0-9]/', '', $_POST['shebaaa']);
        if (strlen($sheba) === 24) {
            update_user_meta($user_id, 'shebaaa', $sheba);
        } else {
             delete_user_meta($user_id, 'shebaaa');
        }
    }

    if (current_user_can('manage_options') && isset($_POST['acceptor_commission_percent'])) {
        $commission_value = sanitize_text_field($_POST['acceptor_commission_percent']);
        if (is_numeric($commission_value) && $commission_value >= 0 && $commission_value <= 100) {
             update_user_meta($user_id, 'acceptor_commission_percent', $commission_value);
        } else {
             delete_user_meta($user_id, 'acceptor_commission_percent');
        }
    }
    
    if (isset($_POST['acceptor_mobile_number'])) {
        $mobile = preg_replace('/[^0-9]/', '', $_POST['acceptor_mobile_number']);
         if (preg_match('/^09\d{9}$/', $mobile)) {
            update_user_meta($user_id, 'acceptor_mobile_number', $mobile);
        } else {
             delete_user_meta($user_id, 'acceptor_mobile_number');
        }
    }
}
// --- END: افزودن فیلدهای سفارشی ---


add_action('admin_init', 'mlr_check_and_update_database_schema');
function mlr_check_and_update_database_schema() {
    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $table_cooperation = $wpdb->prefix . 'cooperation_requests';
    $table_messages = $wpdb->prefix . 'mlr_request_messages';
    $version_option_name = 'mlr_db_version';
    $current_db_version = '1.8'; // Incremented version for safety

    $installed_ver = get_option($version_option_name);

    if ($installed_ver != $current_db_version) {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // --- Loan Requests Table Updates ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_requests)) == $table_requests) {
             $existing_columns_requests = $wpdb->get_col("DESC `{$table_requests}`", 0);            // expert_note column retained for backward compatibility            // bank_note column retained for backward compatibility

             $required_columns_requests = [
                 'phone_number' => "varchar(20) DEFAULT '' NOT NULL AFTER `mobile_number`",
                 'birth_date' => "date DEFAULT NULL AFTER `phone_number`",
                 'occupation' => "varchar(100) DEFAULT '' NOT NULL AFTER `birth_date`",
                 'residential_address' => "text AFTER `occupation`",
                 'postal_code' => "varchar(10) DEFAULT '' NOT NULL AFTER `residential_address`",
                 'work_address' => "text AFTER `postal_code`",
                 'product_name' => "text AFTER `work_address`",
                 'comments' => "TEXT DEFAULT NULL",
                 'prepayment' => "DECIMAL(15,2) DEFAULT 0 AFTER `loan_amount`",
                 'installment_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `installment_count`",
                 'total_payment' => "DECIMAL(15,2) DEFAULT 0 AFTER `installment_amount`",
                 'profit' => "DECIMAL(15,2) DEFAULT 0 AFTER `total_payment`",
                 'wallet_charge' => "DECIMAL(15,2) DEFAULT 0 AFTER `prepayment`",
                 'acceptor_payment_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `wallet_charge`",
                 'final_settlement_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `acceptor_payment_amount`",
                 'assigned_bank_user_id' => "bigint(20) UNSIGNED DEFAULT NULL AFTER `settlement_status`",
                 'settlement_cycle_id' => "bigint(20) UNSIGNED DEFAULT NULL AFTER `assigned_bank_user_id`",
                 'settlement_date' => "datetime DEFAULT NULL AFTER `settlement_cycle_id`",
                 'order_total' => "DECIMAL(15,2) DEFAULT 0 AFTER `order_items`",
                 'form_data' => "LONGTEXT DEFAULT NULL AFTER `order_total`",
                 'bank_validation_file' => "TEXT DEFAULT NULL AFTER `form_data`",
                 'signature_image' => "TEXT DEFAULT NULL AFTER `bank_validation_file`",
                 'contract_file' => "TEXT DEFAULT NULL AFTER `signature_image`",
                 'check_images' => "LONGTEXT DEFAULT NULL AFTER `contract_file`"];
             
             $current_columns_requests = $wpdb->get_col("DESC `{$table_requests}`", 0);
             foreach ($required_columns_requests as $column_name => $column_definition) {
                 if (!in_array($column_name, $current_columns_requests)) {
                     if ($wpdb->query("ALTER TABLE `{$table_requests}` ADD COLUMN `{$column_name}` {$column_definition};") === false) {
                          mlr_log("Error adding column {$column_name} to {$table_requests}: " . $wpdb->last_error);
                     } else {
                          mlr_log("Successfully added column {$column_name} to {$table_requests}");
                          $current_columns_requests[] = $column_name;
                     }
                 }
             }

             // Add Indexes
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_requests}` WHERE Key_name = %s", 'idx_settlement_cycle_id'))) {
                 $wpdb->query("ALTER TABLE `{$table_requests}` ADD INDEX `idx_settlement_cycle_id` (`settlement_cycle_id`);");
             }
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_requests}` WHERE Key_name = %s", 'idx_assigned_bank_user_id'))) {
                 $wpdb->query("ALTER TABLE `{$table_requests}` ADD INDEX `idx_assigned_bank_user_id` (`assigned_bank_user_id`);");
             }
        }
        
        // --- Add guarantor_info column ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_requests)) == $table_requests) {
            if (!$wpdb->get_results("SHOW COLUMNS FROM `{$table_requests}` LIKE 'guarantor_info'")) {
                $wpdb->query("ALTER TABLE `{$table_requests}` ADD COLUMN `guarantor_info` LONGTEXT DEFAULT NULL AFTER `comments`;");
            }
        }
        
        
        // --- Admin Notifications Table Updates (Add read_by column) ---
        $table_notifications = $wpdb->prefix . 'mlr_admin_notifications';
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_notifications)) == $table_notifications) {
            $existing_columns_notif = $wpdb->get_col("DESC `{$table_notifications}`", 0);
            if (!in_array('read_by', $existing_columns_notif)) {
                $wpdb->query("ALTER TABLE `{$table_notifications}` ADD COLUMN `read_by` longtext DEFAULT NULL AFTER `is_read`;");
            }
        }

        // --- Request Messages Table Updates (FIX for Attachments) ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_messages)) == $table_messages) {
            $existing_columns_msgs = $wpdb->get_col("DESC `{$table_messages}`", 0);
            if (!in_array('attachments', $existing_columns_msgs)) {
                $wpdb->query("ALTER TABLE `{$table_messages}` ADD COLUMN `attachments` text DEFAULT NULL AFTER `message`;");
                if (function_exists('mlr_log')) mlr_log("Added attachments column to {$table_messages}");
            }
        }

        // --- Cooperation Requests Table Updates ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_cooperation)) == $table_cooperation) {
             $existing_columns_coop = $wpdb->get_col("DESC `{$table_cooperation}`", 0);
             $required_columns_coop = [
                 'contract_token' => "VARCHAR(64) DEFAULT NULL AFTER `status`",
                 'contract_signed_status' => "VARCHAR(20) DEFAULT 'pending' NOT NULL AFTER `contract_token`",
                 'contract_signed_at' => "DATETIME DEFAULT NULL AFTER `contract_signed_status`",
                 'contract_expires_at' => "DATETIME DEFAULT NULL AFTER `contract_signed_at`",
                 'otp_code' => "VARCHAR(255) DEFAULT NULL AFTER `contract_expires_at`",
                 'otp_expires_at' => "DATETIME DEFAULT NULL AFTER `otp_code`"
             ];
             foreach ($required_columns_coop as $column_name => $column_definition) {
                if (!in_array($column_name, $existing_columns_coop)) {
                    $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD COLUMN `{$column_name}` {$column_definition};");
                    $existing_columns_coop[] = $column_name;
                }
             }
             
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_cooperation}` WHERE Key_name = %s", 'idx_contract_token'))) {
                 if (in_array('contract_token', $existing_columns_coop)) {
                    $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD UNIQUE INDEX `idx_contract_token` (`contract_token`);");
                 }
             }
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_cooperation}` WHERE Key_name = %s", 'idx_signed_status'))) {
                  if (in_array('contract_signed_status', $existing_columns_coop)) { 
                      $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD INDEX `idx_signed_status` (`contract_signed_status`);"); 
                  }
             }
        }

        update_option($version_option_name, $current_db_version);
        mlr_log("Database schema checked/updated to version {$current_db_version}");
    }
}


// Helper & Core Functions
require_once MLR_PLUGIN_DIR . 'includes/sms-functions.php';
require_once MLR_PLUGIN_DIR . 'includes/loan-calculations.php';
require_once MLR_PLUGIN_DIR . 'includes/functions.php';

// AJAX Handlers (Consolidated)
require_once MLR_PLUGIN_DIR . 'includes/ajax-handlers.php';


// Admin Pages
if (is_admin()) {
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/loan-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/installment-plans.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/granted-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/unsettled-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/settled-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/cooperation-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/form-editor.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/sms-settings.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/log-viewer.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/cooperation-contract-settings.php';
}

// Shortcodes
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/loan-request-form.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-loan-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/needs-review-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/processing-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/granted-user-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-settlement-cycles.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/bank-expert-dashboard.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/granted-expert-dashboard.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/verified-docs-dashboard.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/cooperation-request-form.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/loan-calculator.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-stats.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/invoice.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/edit-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/complete-request.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/cooperation-contract-viewer.php';



// Ensure required DB tables exist even if plugin was updated without re-activation
add_action('plugins_loaded', 'mlr_maybe_create_required_tables');
function mlr_maybe_create_required_tables() {
    global $wpdb;
    if (!function_exists('dbDelta')) {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    }

    $table_request_messages = $wpdb->prefix . 'mlr_request_messages';
    $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_request_messages));
    if ($exists !== $table_request_messages) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql_request_messages = "CREATE TABLE $table_request_messages (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            request_id bigint(20) UNSIGNED NOT NULL,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            user_role varchar(50) DEFAULT '' NOT NULL,
            message longtext NOT NULL,
        attachments text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY request_id (request_id),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        dbDelta($sql_request_messages);
    }

    // Ensure installment_plans has display_fields_context column (for per-shortcode calculator fields)
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $col_exists = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table_installment_plans` LIKE %s", 'display_fields_context'));
    if (empty($col_exists)) {
        $wpdb->query("ALTER TABLE `$table_installment_plans` ADD COLUMN display_fields_context longtext");
    }

}


register_activation_hook(__FILE__, 'mlr_install_and_update');
register_deactivation_hook(__FILE__, 'mlr_deactivate');

function mlr_install_and_update() {
    // Ensure log directory exists
    if (function_exists('mlr_ensure_log_dir')) { mlr_ensure_log_dir(); }

    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // Unified bigInt definition
    $table_requests = $wpdb->prefix . 'loan_requests';
    $sql_requests = "CREATE TABLE $table_requests (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        full_name varchar(255) NOT NULL,
        national_code varchar(10) NOT NULL,
        mobile_number varchar(15) NOT NULL,
        phone_number varchar(20) DEFAULT '' NOT NULL,
        birth_date date DEFAULT NULL,
        occupation varchar(100) DEFAULT '' NOT NULL,
        residential_address text,
        postal_code varchar(10) DEFAULT '' NOT NULL,
        work_address text,
        product_name text,
        installment_plan_id bigint(20) UNSIGNED NOT NULL,
        loan_amount DECIMAL(15,2) NOT NULL,
        prepayment DECIMAL(15,2) DEFAULT 0,
        wallet_charge DECIMAL(15,2) DEFAULT 0,
        acceptor_payment_amount DECIMAL(15,2) DEFAULT 0,
        final_settlement_amount DECIMAL(15,2) DEFAULT 0,
        installment_interval int(11) NOT NULL DEFAULT 1,
        installment_count int(11) NOT NULL,
        installment_amount DECIMAL(15,2) DEFAULT 0,
        total_payment DECIMAL(15,2) DEFAULT 0,
        profit DECIMAL(15,2) DEFAULT 0,
        required_documents longtext,
        order_items longtext,
        order_total DECIMAL(15,2) DEFAULT 0,
        form_data longtext,
        bank_validation_file text,
        signature_image text,
        contract_file text,
        check_images longtext,
        comments longtext,
        guarantor_info longtext,
        status varchar(50) NOT NULL,
        settlement_status varchar(50) DEFAULT '',
        assigned_bank_user_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_cycle_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_date datetime DEFAULT NULL,
        created_at datetime NOT NULL,
        last_edited_at datetime DEFAULT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status),
        KEY national_code (national_code),
        KEY installment_plan_id (installment_plan_id),
        KEY idx_settlement_cycle_id (settlement_cycle_id),
        KEY idx_assigned_bank_user_id (assigned_bank_user_id)
    ) $charset_collate;";
    dbDelta($sql_requests);

    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $sql_installment_plans = "CREATE TABLE $table_installment_plans (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        type varchar(50) NOT NULL,
        is_active tinyint(1) DEFAULT 1,
        settings longtext,
        display_fields longtext,
                display_fields_context longtext,
required_documents text,
        created_at datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql_installment_plans);

    $table_cooperation_requests = $wpdb->prefix . 'cooperation_requests';
    $sql_cooperation_requests = "CREATE TABLE $table_cooperation_requests (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_type varchar(50) NOT NULL,
        status varchar(50) NOT NULL DEFAULT 'در حال بررسی',
        contract_token varchar(64) DEFAULT NULL,
        contract_signed_status varchar(20) NOT NULL DEFAULT 'pending',
        contract_signed_at datetime DEFAULT NULL,
        contract_expires_at datetime DEFAULT NULL,
        otp_code varchar(255) DEFAULT NULL,
        otp_expires_at datetime DEFAULT NULL,
        data longtext,
        files longtext,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY idx_contract_token (contract_token),
        KEY status (status),
        KEY request_type (request_type),
        KEY idx_signed_status (contract_signed_status)
    ) $charset_collate;";
    dbDelta($sql_cooperation_requests);

    $table_settlement_cycles = $wpdb->prefix . 'mlr_settlement_cycles';
    $sql_settlement_cycles = "CREATE TABLE $table_settlement_cycles (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        total_amount DECIMAL(15,2) NOT NULL,
        description text,
        settlement_date datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql_settlement_cycles);

    // --- Request Events & Messages Tables ---
    $table_request_events = $wpdb->prefix . 'mlr_request_events';
    $sql_request_events = "CREATE TABLE $table_request_events (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_id bigint(20) UNSIGNED NOT NULL,
        user_id bigint(20) UNSIGNED DEFAULT NULL,
        user_role varchar(50) DEFAULT '' NOT NULL,
        event_type varchar(100) DEFAULT '' NOT NULL,
        details longtext,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY request_id (request_id),
        KEY user_id (user_id),
        KEY event_type (event_type),
        KEY created_at (created_at)
    ) $charset_collate;";
    dbDelta($sql_request_events);

    $table_request_messages = $wpdb->prefix . 'mlr_request_messages';
    $sql_request_messages = "CREATE TABLE $table_request_messages (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_id bigint(20) UNSIGNED NOT NULL,
        user_id bigint(20) UNSIGNED DEFAULT NULL,
        user_role varchar(50) DEFAULT '' NOT NULL,
        message longtext NOT NULL,
        attachments text DEFAULT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY request_id (request_id),
        KEY user_id (user_id),
        KEY created_at (created_at)
    ) $charset_collate;";
    dbDelta($sql_request_messages);

    // 7. جدول ناتیفیکیشن‌های ادمین (Admin Notifications)
    $table_notifications = $wpdb->prefix . 'mlr_admin_notifications';
    $sql_notifications = "CREATE TABLE $table_notifications (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        type varchar(50) NOT NULL,
        message text NOT NULL,
        link text DEFAULT NULL,
        is_read tinyint(1) DEFAULT 0,
        read_by longtext DEFAULT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY is_read (is_read)
    ) $charset_collate;";
    dbDelta($sql_notifications);

    mlr_check_and_update_database_schema();

    // Create contract viewer page
    $contract_page_slug = 'cooperation-contract';
    if ( null == get_page_by_path( $contract_page_slug ) ) {
      wp_insert_post(
        array(
          'comment_status' => 'closed',
          'ping_status'    => 'closed',
          'post_author'    => (get_current_user_id() ? get_current_user_id() : 1),
          'post_name'      => $contract_page_slug,
          'post_title'     => 'قرارداد همکاری',
          'post_status'    => 'publish',
          'post_type'      => 'page',
          'post_content'   => '[mlr_cooperation_contract_viewer]'
        )
      );
    }
}

function mlr_deactivate() { }


add_action('admin_menu', 'mlr_admin_menu');
function mlr_admin_menu() {
    add_menu_page('عملیات تسهیلات', 'عملیات تسهیلات', 'manage_options', 'mlr-loan-requests', 'mlr_loan_requests_page', 'dashicons-money-alt', 6);
    add_submenu_page('mlr-loan-requests', 'همه‌درخواست‌ها', 'همه‌درخواست‌ها', 'manage_options', 'mlr-loan-requests', 'mlr_loan_requests_page');
    add_submenu_page('mlr-loan-requests', 'در حال بررسی', 'در حال بررسی', 'manage_options', 'admin.php?page=mlr-loan-requests&status=در حال بررسی');
    add_submenu_page('mlr-loan-requests', 'نقص مدارک', 'نقص مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=نقص مدارک');
    add_submenu_page('mlr-loan-requests', 'رد شده', 'رد شده', 'manage_options', 'admin.php?page=mlr-loan-requests&status=رد شده');
    add_submenu_page('mlr-loan-requests', 'تأیید کارشناس', 'تأیید کارشناس', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تأیید کارشناس');
    add_submenu_page('mlr-loan-requests', 'تکمیل مدارک', 'تکمیل مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تکمیل مدارک');
    add_submenu_page('mlr-loan-requests', 'تأیید مدارک', 'تأیید مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تأیید مدارک');
    
    add_submenu_page('mlr-loan-requests', 'اعطا شده', 'اعطا شده', 'manage_options', 'mlr-granted-requests', 'mlr_granted_requests_page');
    add_submenu_page('mlr-loan-requests', 'در انتظار تسویه', 'در انتظار تسویه', 'manage_options', 'mlr-unsettled-requests', 'mlr_unsettled_requests_page');
    add_submenu_page('mlr-loan-requests', 'تسویه شده', 'تسویه شده', 'manage_options', 'mlr-settled-requests', 'mlr_settled_requests_page');
    add_submenu_page('mlr-loan-requests', 'طرح‌های اقساطی', 'طرح‌های اقساطی', 'manage_options', 'mlr-installment-plans', 'mlr_installment_plans_page');
    add_submenu_page('mlr-loan-requests', 'تنظیمات API', 'تنظیمات API', 'manage_options', 'mlr-api-settings', 'mlr_api_settings_page_callback');

    add_menu_page('مدیریت همکاری', 'مدیریت همکاری', 'manage_options', 'mlr-cooperation-main', 'mlr_cooperation_requests_page', 'dashicons-groups', 7);
    add_submenu_page('mlr-cooperation-main', 'درخواست‌های همکاری', 'درخواست‌های همکاری', 'manage_options', 'mlr-cooperation-main', 'mlr_cooperation_requests_page');
    add_submenu_page('mlr-cooperation-main', 'ویرایشگر فرم همکاری', 'ویرایشگر فرم', 'manage_options', 'mlr-form-editor', 'mlr_form_editor_page');
    add_submenu_page('mlr-cooperation-main', 'تنظیمات قرارداد', 'تنظیمات قرارداد', 'manage_options', 'mlr-cooperation-contract-settings', 'mlr_cooperation_contract_settings_page');

    add_menu_page('تنظیمات پیامک', 'تنظیمات پیامک', 'manage_options', 'mlr-sms-settings', 'mlr_sms_settings_page', 'dashicons-email-alt', 8);
    add_submenu_page('mlr-sms-settings', 'مشاهده لاگ', 'مشاهده لاگ', 'manage_options', 'mlr-log-viewer', 'mlr_log_viewer_page');
}


add_action('admin_init', 'mlr_register_plugin_settings');
function mlr_register_plugin_settings() {
    register_setting('mlr_api_settings_group', 'mlr_shahkar_client_id', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_api_settings_group', 'mlr_shahkar_client_secret', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_api_settings_group', 'mlr_shahkar_owner_nid', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_sms_settings_group', 'mlr_sms_settings', ['sanitize_callback' => 'mlr_sanitize_sms_settings']);
    register_setting('mlr_cooperation_contract_settings_group', 'mlr_cooperation_contract_settings', ['sanitize_callback' => 'mlr_sanitize_cooperation_contract_settings']);
    register_setting('mlr_cooperation_form_editor_group', 'mlr_cooperation_form_options', ['sanitize_callback' => 'mlr_sanitize_cooperation_form_options']);
    register_setting('mlr_cooperation_form_editor_group', 'mlr_cooperation_form_config', ['sanitize_callback' => 'mlr_sanitize_cooperation_form_config']);
}

function mlr_sanitize_cooperation_form_options($input) {
    $sanitized_input = [];
    $option_keys = ['activity_field_options', 'how_heard_options'];
    foreach ($option_keys as $key) {
        if (isset($input[$key])) {
            $lines = explode("\n", $input[$key]);
            $options = [];
            foreach ($lines as $line) {
                $trimmed = trim($line);
                if (!empty($trimmed)) $options[] = sanitize_text_field($trimmed);
            }
            $sanitized_input[$key] = $options;
        } else {
            $sanitized_input[$key] = [];
        }
    }
    return $sanitized_input;
}

function mlr_sanitize_cooperation_form_config($input) {
    $sanitized_input = [];
    $all_fields = mlr_get_all_cooperation_fields();
    if (!is_array($input)) $input = [];

    foreach ($all_fields as $field_key => $field_info) {
        if ($field_info['type'] === 'file') {
             $sanitized_input[$field_key]['visible'] = isset($input[$field_key]['visible']) ? 1 : 0;
        } else {
             $sanitized_input[$field_key]['visible'] = 1;
        }
        $is_visible = $sanitized_input[$field_key]['visible'];
        $sanitized_input[$field_key]['required'] = (isset($input[$field_key]['required']) && $is_visible) ? 1 : 0;
    }
    return $sanitized_input;
}

function mlr_sanitize_cooperation_contract_settings($input) {
    $sanitized_input = [];
    if (!is_array($input)) $input = [];
    $sanitized_input['header_image_url'] = isset($input['header_image_url']) ? esc_url_raw(trim($input['header_image_url'])) : '';
    $sanitized_input['footer_image_url'] = isset($input['footer_image_url']) ? esc_url_raw(trim($input['footer_image_url'])) : '';
    $sanitized_input['contract_text'] = isset($input['contract_text']) ? wp_kses_post($input['contract_text']) : '';
    return $sanitized_input;
}

function mlr_sanitize_sms_settings($input) {
    $sanitized_input = [];
    if (!is_array($input)) $input = [];

    $sanitized_input['username'] = isset($input['username']) ? sanitize_text_field(trim($input['username'])) : '';
    $current = get_option('mlr_sms_settings', []);
    if (!empty($input['password'])) {
        $sanitized_input['password'] = sanitize_text_field(trim($input['password']));
    } elseif (isset($current['password'])) {
        $sanitized_input['password'] = $current['password'];
    } else {
        $sanitized_input['password'] = '';
    }

    foreach (['cooperation_statuses', 'loan_statuses', 'otp_settings'] as $group_key) {
        if (isset($input[$group_key]) && is_array($input[$group_key])) {
            foreach ($input[$group_key] as $key => $settings) {
                if (!is_array($settings)) continue;
                $sanitized_key = sanitize_text_field($key);
                $sanitized_input[$group_key][$sanitized_key]['enabled'] = isset($settings['enabled']) ? 1 : 0;
                $sanitized_input[$group_key][$sanitized_key]['bodyId'] = isset($settings['bodyId']) ? sanitize_text_field(trim($settings['bodyId'])) : '';

                for ($i = 0; $i < 3; $i++) {
                    $var = "var_{$i}";
                    $sanitized_input[$group_key][$sanitized_key][$var] = isset($settings[$var]) ? sanitize_text_field(trim($settings[$var])) : '';
                }

                if ($group_key === 'loan_statuses') {
                    $sanitized_input[$group_key][$sanitized_key]['send_to_applicant'] = isset($settings['send_to_applicant']) ? 1 : 0;
                    $sanitized_input[$group_key][$sanitized_key]['send_to_acceptor'] = isset($settings['send_to_acceptor']) ? 1 : 0;
                }
            }
        }
    }
    return $sanitized_input;
}

function mlr_get_all_cooperation_fields() {
    return [
        'store_name' => ['type' => 'text', 'form' => 'individual', 'label' => 'نام فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_owner_name' => ['type' => 'text', 'form' => 'individual', 'label' => 'نام مالک فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_address' => ['type' => 'textarea', 'form' => 'individual', 'label' => 'آدرس فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_images' => ['type' => 'file', 'form' => 'individual', 'label' => 'تصاویر فروشگاه', 'default_required' => true, 'default_visible' => true],

        'company_name' => ['type' => 'text', 'form' => 'legal', 'label' => 'نام شرکت', 'default_required' => true, 'default_visible' => true],
        'contact_person' => ['type' => 'text', 'form' => 'legal', 'label' => 'نام رابط', 'default_required' => true, 'default_visible' => true],
        'company_address' => ['type' => 'textarea', 'form' => 'legal', 'label' => 'آدرس شرکت', 'default_required' => true, 'default_visible' => true],
        'email' => ['type' => 'email', 'form' => 'legal', 'label' => 'ایمیل', 'default_required' => true, 'default_visible' => true],
        'company_images' => ['type' => 'file', 'form' => 'legal', 'label' => 'تصاویر شرکت', 'default_required' => true, 'default_visible' => true],
        'company_docs' => ['type' => 'file', 'form' => 'legal', 'label' => 'اساسنامه و روزنامه رسمی', 'default_required' => true, 'default_visible' => true],

        'activity_field' => ['type' => 'select', 'form' => 'both', 'label' => 'زمینه فعالیت', 'options_key' => 'activity_field_options', 'default_required' => true, 'default_visible' => true],
        'how_heard' => ['type' => 'select', 'form' => 'both', 'label' => 'نحوه آشنایی با ما', 'options_key' => 'how_heard_options', 'default_required' => false, 'default_visible' => true],
        'activity_description' => ['type' => 'text', 'form' => 'both', 'label' => 'شرح فعالیت', 'default_required' => false, 'default_visible' => true],
        'postal_code' => ['type' => 'text', 'form' => 'both', 'label' => 'کد پستی', 'default_required' => true, 'default_visible' => true],
        'applicant_id_number' => ['type' => 'text', 'form' => 'both', 'label' => 'کد ملی / شناسه ملی', 'default_required' => true, 'default_visible' => true],
        'mobile_number' => ['type' => 'text', 'form' => 'both', 'label' => 'شماره همراه', 'default_required' => true, 'default_visible' => true],
        'phone_number' => ['type' => 'text', 'form' => 'both', 'label' => 'تلفن ثابت', 'default_required' => false, 'default_visible' => true],
        'website' => ['type' => 'text', 'form' => 'both', 'label' => 'آدرس سایت', 'default_required' => false, 'default_visible' => true],
        'branches' => ['type' => 'textarea', 'form' => 'both', 'label' => 'آدرس شعب', 'default_required' => false, 'default_visible' => true],
        'description' => ['type' => 'textarea', 'form' => 'both', 'label' => 'توضیحات تکمیلی', 'default_required' => false, 'default_visible' => true],

        'national_card' => ['type' => 'file', 'form' => 'both', 'label' => 'کارت ملی (رو و پشت)', 'default_required' => true, 'default_visible' => true],
        'id_card' => ['type' => 'file', 'form' => 'both', 'label' => 'شناسنامه (تمام صفحات)', 'default_required' => true, 'default_visible' => true],
        'business_license' => ['type' => 'file', 'form' => 'both', 'label' => 'جواز کسب', 'default_required' => true, 'default_visible' => true],
        'ownership_or_lease' => ['type' => 'file', 'form' => 'both', 'label' => 'سند مالکیت یا اجاره‌نامه', 'default_required' => true, 'default_visible' => true],
        'thana_certificate' => ['type' => 'file', 'form' => 'both', 'label' => 'گواهی ثبت ثنا', 'default_required' => true, 'default_visible' => true],
        'logo' => ['type' => 'file', 'form' => 'both', 'label' => 'لوگو', 'default_required' => false, 'default_visible' => true],
        'check_image' => ['type' => 'file', 'form' => 'both', 'label' => 'تصویر چک صیادی', 'default_required' => false, 'default_visible' => true],
        'signature_certificate' => ['type' => 'file', 'form' => 'both', 'label' => 'گواهی امضا', 'default_required' => false, 'default_visible' => true],
        'tax_info' => ['type' => 'file', 'form' => 'both', 'label' => 'اطلاعات سامانه مالیاتی', 'default_required' => false, 'default_visible' => true],
        'enamad' => ['type' => 'file', 'form' => 'both', 'label' => 'تصویر اینماد', 'default_required' => false, 'default_visible' => true],
    ];
}


function mlr_api_settings_page_callback() {
    ?>
    <div class="wrap mlr-admin-wrap">
        <h1>تنظیمات اتصال به API فینوتک (شاهکار)</h1>
        <p>این اطلاعات برای تأیید تطابق کد ملی و شماره موبایل کاربران در فرم ثبت درخواست تسهیلات استفاده می‌شود.</p>
        <form method="post" action="options.php">
            <?php settings_fields('mlr_api_settings_group'); ?>
            <?php do_settings_sections('mlr_api_settings_group'); ?>
             <div class="mlr-settings-card">
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_client_id">Client ID</label></th>
                        <td><input type="text" id="mlr_shahkar_client_id" name="mlr_shahkar_client_id" value="<?php echo esc_attr(get_option('mlr_shahkar_client_id')); ?>" class="regular-text ltr" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_client_secret">Client Secret</label></th>
                        <td><input type="password" id="mlr_shahkar_client_secret" name="mlr_shahkar_client_secret" value="" placeholder="<?php echo esc_attr(get_option('mlr_shahkar_client_secret')) ? '•••••••• (برای تغییر، مقدار جدید را وارد کنید)' : ''; ?>" class="regular-text ltr" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_owner_nid">Owner NID <br>(کد ملی مالک سرویس)</label></th>
                        <td><input type="text" id="mlr_shahkar_owner_nid" name="mlr_shahkar_owner_nid" value="<?php echo esc_attr(get_option('mlr_shahkar_owner_nid')); ?>" class="regular-text ltr" pattern="[0-9]{10}" title="کد ملی 10 رقمی" />
                        <p class="description">کد ملی شخصی که سرویس فینوتک به نام ایشان ثبت شده است.</p></td>
                    </tr>
                </table>
            </div>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action('admin_enqueue_scripts', 'mlr_enqueue_admin_scripts');
function mlr_enqueue_admin_scripts($hook) {
    // --- 1. Enqueue Admin Notifications (Global for all admin pages) ---
    wp_enqueue_style('mlr-admin-notifications-css', MLR_PLUGIN_URL . 'assets/css/admin-notifications.css', [], MLR_VERSION);
    wp_enqueue_script('mlr-admin-notifications-js', MLR_PLUGIN_URL . 'assets/js/admin-notifications.js', ['jquery'], MLR_VERSION, true);
    wp_localize_script('mlr-admin-notifications-js', 'mlrNotificationAjax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('mlr_ajax_nonce_action'),
        'sound_url' => MLR_PLUGIN_URL . 'assets/sounds/notification.mp3'
    ]);

    // --- 2. Check if we are on a plugin specific page ---
     $plugin_pages = [
        'toplevel_page_mlr-loan-requests',
        'mlr-loan-requests_page_mlr-granted-requests',
        'mlr-loan-requests_page_mlr-unsettled-requests',
        'mlr-loan-requests_page_mlr-settled-requests',
        'mlr-loan-requests_page_mlr-installment-plans',
        'mlr-loan-requests_page_mlr-api-settings',
        'عملیات-تسهیلات_page_mlr-granted-requests',
        'عملیات-تسهیلات_page_mlr-unsettled-requests',
        'عملیات-تسهیلات_page_mlr-settled-requests',
        'عملیات-تسهیلات_page_mlr-installment-plans',
        'عملیات-تسهیلات_page_mlr-api-settings',
        'toplevel_page_mlr-cooperation-main',
        'مدیریت-همکاری_page_mlr-form-editor',
        'مدیریت-همکاری_page_mlr-cooperation-contract-settings',
        'toplevel_page_mlr-sms-settings',
        'تنظیمات-پیامک_page_mlr-log-viewer',
    ];

    $is_plugin_page = in_array($hook, $plugin_pages);

    // Fallback: some environments may produce different hook suffixes for submenu pages.
    if (!$is_plugin_page && isset($_GET['page'])) {
        $page = sanitize_key(wp_unslash($_GET['page']));
        if (in_array($page, ['mlr-granted-requests', 'mlr-unsettled-requests', 'mlr-settled-requests', 'mlr-installment-plans', 'mlr-api-settings', 'mlr-loan-requests'], true)) {
            $is_plugin_page = true;
        }
    }
    if (!$is_plugin_page && isset($_GET['page']) && $_GET['page'] === 'mlr-loan-requests' && isset($_GET['status'])) {
        $is_plugin_page = true;
    }
    if (!$is_plugin_page && ($hook === 'profile.php' || $hook === 'user-edit.php')) {
         $is_plugin_page = true;
    }

    if (!$is_plugin_page) return;

    wp_enqueue_style('mlr-admin-css', MLR_PLUGIN_URL . 'assets/css/admin.css', [], MLR_VERSION);
    // Unified popup/modal styles (admin + frontend) - must load after admin.css to override
    wp_enqueue_style('mlr-modal-unified-css', MLR_PLUGIN_URL . 'assets/css/mlr-modal-unified.css', ['mlr-admin-css'], MLR_VERSION);

    if ($hook === 'مدیریت-همکاری_page_mlr-cooperation-contract-settings' || $hook === 'عملیات-تسهیلات_page_mlr-installment-plans') {
  // Add for enqueuing admin notification
        wp_enqueue_style('mlr-admin-notifications', MLR_PLUGIN_URL . 'assets/css/admin-notifications.css', array(), MLR_VERSION);
        wp_enqueue_media();
    }

    wp_enqueue_script('mlr-jalali-datepicker', MLR_PLUGIN_URL . 'assets/js/jalali-datepicker.js', ['jquery'], MLR_VERSION, true);
    wp_enqueue_script('mlr-admin-js', MLR_PLUGIN_URL . 'assets/js/admin.js', ['jquery', 'mlr-jalali-datepicker'], MLR_VERSION, true);

    wp_localize_script('mlr-admin-js', 'mlrAjax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('mlr_ajax_nonce_action')

    ]);

    if ($hook === 'مدیریت-همکاری_page_mlr-form-editor') {
        wp_add_inline_script('mlr-admin-js', '
            jQuery(document).ready(function($){
                function updateRequiredState(visibilityToggle) {
                    var isChecked = $(visibilityToggle).is(":checked");
                    var controlsDiv = $(visibilityToggle).closest(".mlr-field-controls");
                    var requiredSwitch = controlsDiv.find(".mlr-required-switch");
                    var requiredLabel = controlsDiv.find(".mlr-required-label");
                    var requiredInput = requiredSwitch.find("input[type=checkbox]");

                    if (isChecked) {
                        requiredSwitch.removeClass("mlr-disabled");
                        requiredLabel.removeClass("mlr-disabled");
                        requiredInput.prop("disabled", false);
                    } else {
                        requiredSwitch.addClass("mlr-disabled");
                        requiredLabel.addClass("mlr-disabled");
                        requiredInput.prop("disabled", true).prop("checked", false);
                    }
                }
                $(".mlr-visibility-toggle").on("change", function(){ updateRequiredState(this); });
                $(".mlr-visibility-toggle").each(function(){ updateRequiredState(this); });
            });
        ');
    }
}

add_action('admin_init', 'mlr_process_pdf_export');

function mlr_process_pdf_export() {
    if ((!isset($_GET['export_pdf_credit']) && !isset($_GET['export_pdf_dossier'])) || !current_user_can('manage_options')) {
        return;
    }

    $type = isset($_GET['export_pdf_credit']) ? 'credit' : 'dossier';
    
    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $users_table = $wpdb->prefix . 'users';
    $plans_table = $wpdb->prefix . 'installment_plans';

    // --- Re-use Filter Logic ---
    $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
    $status_from_url = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : '';
    $date_from_jalali = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
    $date_to_jalali = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';

    $date_from_gregorian = !empty($date_from_jalali) && function_exists('mlr_jalali_to_gregorian') ? mlr_jalali_to_gregorian($date_from_jalali) : '';
    $date_to_gregorian = !empty($date_to_jalali) && function_exists('mlr_jalali_to_gregorian') ? mlr_jalali_to_gregorian($date_to_jalali) : '';

    $where_clauses = ["1=1"];
    $prepare_params = [];

    if (!empty($search)) {
         $search_like = '%' . $wpdb->esc_like($search) . '%';
         $where_clauses[] = "(r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s)";
         $prepare_params[] = $search_like;
         $prepare_params[] = $search_like;
         $prepare_params[] = $search_like;
         if(is_numeric($search)){
             $where_clauses[count($where_clauses)-1] = substr($where_clauses[count($where_clauses)-1], 0, -1);
             $where_clauses[count($where_clauses)-1] .= " OR r.id = %d)";
             $prepare_params[] = intval($search);
         }
    }
    
    if (!empty($status_from_url)) {
         $where_clauses[] = "r.status = %s";
         $prepare_params[] = $status_from_url;
    }
    if (!empty($date_from_gregorian)) {
        $where_clauses[] = "r.created_at >= %s";
        $prepare_params[] = $date_from_gregorian . ' 00:00:00';
    }
    if (!empty($date_to_gregorian)) {
        $where_clauses[] = "r.created_at <= %s";
        $prepare_params[] = $date_to_gregorian . ' 23:59:59';
    }

    $sql_where = "WHERE " . implode(' AND ', $where_clauses);
    
    $query = "SELECT r.*, u.display_name, p.name as plan_name
                   FROM $table_requests r
                   LEFT JOIN $users_table u ON r.user_id = u.ID
                   LEFT JOIN $plans_table p ON r.installment_plan_id = p.id
                   $sql_where
                   ORDER BY r.created_at DESC";
    
    $requests = $wpdb->get_results($wpdb->prepare($query, $prepare_params));

    // --- Generate HTML ---
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>چاپ گزارش - <?php echo $type === 'credit' ? 'نتایج اعتبارسنجی' : 'پرونده کامل'; ?></title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap');
            body { font-family: 'Vazirmatn', Tahoma, sans-serif; direction: rtl; background: #eee; margin: 0; padding: 20px; color: #333; }
            .page-container { max-width: 210mm; margin: 0 auto; background: #fff; padding: 10mm; box-shadow: 0 0 10px rgba(0,0,0,0.1); margin-bottom: 20px; position: relative; min-height: 297mm; box-sizing: border-box; }
            .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
            .header h1 { margin: 0; font-size: 20px; }
            .header .meta { font-size: 12px; margin-top: 5px; display: flex; justify-content: space-between; }
            .section { margin-bottom: 15px; border: 1px solid #ddd; border-radius: 5px; overflow: hidden; }
            .section-title { background: #f0f0f0; padding: 8px 10px; font-weight: bold; font-size: 14px; border-bottom: 1px solid #ddd; }
            .section-content { padding: 10px; font-size: 13px; }
            .row { display: flex; flex-wrap: wrap; margin-bottom: 5px; }
            .col { flex: 1; min-width: 45%; margin-bottom: 5px; }
            .label { color: #666; font-size: 12px; }
            .value { font-weight: bold; }
            .credit-score-box { text-align: center; padding: 15px; background: #f9f9f9; border-radius: 8px; margin-bottom: 15px; border: 1px solid #eee; }
            .score-val { font-size: 24px; font-weight: bold; color: #2c3e50; }
            .risk-val { font-size: 16px; margin-top: 5px; }
            table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 10px; }
            th, td { border: 1px solid #ddd; padding: 6px; text-align: center; }
            th { background: #f5f5f5; }
            .badge { padding: 2px 6px; border-radius: 4px; color: #fff; font-size: 10px; }
            .badge-success { background: #10b981; }
            .badge-warning { background: #f59e0b; }
            .badge-danger { background: #ef4444; }
            .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 10px; }
            .summary-card { background: #f9f9f9; border: 1px solid #eee; padding: 10px; border-radius: 5px; text-align: center; }
            
            @media print {
                body { background: #fff; padding: 0; }
                .page-container { box-shadow: none; margin: 0; page-break-after: always; width: 100%; max-width: none; min-height: auto; height: auto; }
                .no-print { display: none; }
            }
        </style>
    </head>
    <body>
        <div class="no-print" style="text-align:center; margin-bottom:20px;">
            <button onclick="window.print();" style="padding:10px 20px; font-size:16px; cursor:pointer; background:#0073aa; color:#fff; border:none; border-radius:5px;">چاپ / ذخیره به عنوان PDF</button>
        </div>

        <?php foreach ($requests as $req): 
            $form_data = !empty($req->form_data) ? json_decode($req->form_data, true) : [];
            $credit_report = null;
            if (!empty($req->credit_report_json)) {
                $credit_report = json_decode($req->credit_report_json, true);
            } elseif (isset($form_data['credit_report_json'])) {
                $cr_data = $form_data['credit_report_json'];
                if (is_string($cr_data)) {
                    $credit_report = json_decode($cr_data, true);
                    if (json_last_error() !== JSON_ERROR_NONE) $credit_report = json_decode(stripslashes($cr_data), true);
                } else {
                    $credit_report = $cr_data;
                }
            }
            
            $created_at = function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($req->created_at, 'Y/m/d H:i') : $req->created_at;
        ?>
        <div class="page-container">
            <div class="header">
                <h1>گزارش <?php echo $type === 'credit' ? 'اعتبارسنجی' : 'پرونده'; ?> درخواست تسهیلات</h1>
                <div class="meta">
                    <span>شماره درخواست: <strong><?php echo $req->id; ?></strong></span>
                    <span>تاریخ ثبت: <?php echo $created_at; ?></span>
                    <span>وضعیت: <?php echo $req->status; ?></span>
                </div>
            </div>

            <div class="section">
                <div class="section-title">اطلاعات متقاضی</div>
                <div class="section-content">
                    <div class="row">
                        <div class="col"><span class="label">نام و نام خانوادگی:</span> <span class="value"><?php echo esc_html($req->full_name); ?></span></div>
                        <div class="col"><span class="label">کد ملی:</span> <span class="value"><?php echo esc_html($req->national_code); ?></span></div>
                    </div>
                    <div class="row">
                        <div class="col"><span class="label">شماره موبایل:</span> <span class="value"><?php echo esc_html($req->mobile_number); ?></span></div>
                        <div class="col"><span class="label">طرح:</span> <span class="value"><?php echo esc_html($req->plan_name); ?></span></div>
                    </div>
                    <div class="row">
                        <div class="col"><span class="label">مبلغ وام:</span> <span class="value"><?php echo number_format($req->loan_amount); ?> ریال</span></div>
                        <div class="col"><span class="label">پذیرنده:</span> <span class="value"><?php echo esc_html($req->display_name); ?></span></div>
                    </div>
                </div>
            </div>

            <?php if ($credit_report): 
                $scoreObj = $credit_report['score'] ?? [];
                $reportObj = $credit_report['report'] ?? [];
                $score = $scoreObj['score'] ?? 0;
                $risk = $scoreObj['risk'] ?? 'نامشخص';
                $summary = ($reportObj['summaryInformationRelatedToContractsSum'][0]) ?? [];
                $bouncedObj = $credit_report['bouncedCheque'] ?? [];
                $bouncedCount = isset($bouncedObj['bouncedCheques']) && is_array($bouncedObj['bouncedCheques']) ? count($bouncedObj['bouncedCheques']) : 0;
            ?>
            <div class="section">
                <div class="section-title">نتیجه اعتبارسنجی</div>
                <div class="section-content">
                    <div class="credit-score-box">
                        <div class="score-val">امتیاز: <?php echo $score; ?></div>
                        <div class="risk-val">ریسک: <?php echo $risk; ?></div>
                    </div>
                    
                    <?php // Personal Info from Credit Report ?>
                    <?php 
                    $pInfo = $scoreObj['personInformation'] ?? ($reportObj['personInformation'] ?? []);
                    if (!empty($pInfo)): ?>
                        <div style="margin-top:15px; font-weight:bold;">اطلاعات هویتی (تأیید شده بانکی):</div>
                        <div class="row">
                            <div class="col"><span class="label">نام و نام خانوادگی:</span> <span class="value"><?php echo esc_html(($pInfo['name'] ?? $pInfo['firstName'] ?? '') . ' ' . ($pInfo['family'] ?? $pInfo['lastName'] ?? '')); ?></span></div>
                            <div class="col"><span class="label">نام پدر:</span> <span class="value"><?php echo esc_html($pInfo['fatherName'] ?? '-'); ?></span></div>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col"><span class="label">تسهیلات جاری:</span> <span class="value"><?php echo $summary['inProgressContractsCount'] ?? 0; ?></span></div>
                        <div class="col"><span class="label">معوقات:</span> <span class="value"><?php echo number_format($summary['overdueAmount'] ?? 0); ?> ریال</span></div>
                    </div>
                    <div class="row">
                        <div class="col"><span class="label">چک برگشتی:</span> <span class="value"><?php echo $bouncedCount; ?> عدد</span></div>
                        <div class="col"><span class="label">کل تسهیلات:</span> <span class="value"><?php echo number_format($summary['totalAmount'] ?? 0); ?> ریال</span></div>
                    </div>

                    <?php // Direct Contracts (Loans) ?>
                    <?php if (!empty($reportObj['directContracts'])): ?>
                        <div style="margin-top:15px; font-weight:bold;">تسهیلات بانکی (وام‌ها):</div>
                        <table>
                            <thead><tr><th>بانک</th><th>نوع</th><th>مبلغ کل</th><th>مانده بدهی</th><th>وضعیت</th></tr></thead>
                            <tbody>
                                <?php foreach($reportObj['directContracts'] as $loan): 
                                    $statusText = $loan['negativeContractStatus'] ?? 'جاری';
                                    $statusClass = (strpos($statusText, 'معوق') !== false || strpos($statusText, 'مشکوک') !== false) ? 'badge-danger' : ((strpos($statusText, 'گذشته') !== false) ? 'badge-warning' : 'badge-success');
                                ?>
                                <tr>
                                    <td><?php echo esc_html($loan['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo esc_html($loan['typeOfFinancingTitle'] ?? '-'); ?></td>
                                    <td><?php echo number_format($loan['totalAmount'] ?? 0); ?></td>
                                    <td><?php echo number_format($loan['overdueAmount'] ?? 0); ?></td>
                                    <td><span class="badge <?php echo $statusClass; ?>"><?php echo esc_html($statusText); ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                    <?php // Indirect Contracts (Guarantees) ?>
                    <?php if (!empty($reportObj['indirectContracts'])): ?>
                        <div style="margin-top:15px; font-weight:bold;">تعهدات (ضمانت‌ها):</div>
                        <table>
                            <thead><tr><th>بانک</th><th>مبلغ ضمانت</th><th>معوقات وام‌گیرنده</th><th>وضعیت</th></tr></thead>
                            <tbody>
                                <?php foreach($reportObj['indirectContracts'] as $g): 
                                    $statusText = $g['negativeContractStatus'] ?? 'جاری';
                                    $statusClass = (strpos($statusText, 'معوق') !== false) ? 'badge-danger' : 'badge-success';
                                ?>
                                <tr>
                                    <td><?php echo esc_html($g['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo number_format($g['totalAmount'] ?? 0); ?></td>
                                    <td><?php echo number_format($g['overdueAmount'] ?? 0); ?></td>
                                    <td><span class="badge <?php echo $statusClass; ?>"><?php echo esc_html($statusText); ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                    <?php // Pichak (Cheques) ?>
                    <?php 
                    $pichakItems = $credit_report['pichak']['personChequesData']['personChequeItems'] ?? [];
                    if (!empty($pichakItems)): ?>
                        <div style="margin-top:15px; font-weight:bold;">وضعیت چک‌های صیادی (پیچک):</div>
                        <table>
                            <thead><tr><th>وضعیت</th><th>تعداد</th><th>مبلغ کل (ریال)</th></tr></thead>
                            <tbody>
                                <?php foreach($pichakItems as $item): if (($item['count'] ?? 0) == 0) continue; ?>
                                <tr>
                                    <td><?php echo esc_html($item['checkStatusTitle'] ?? '-'); ?></td>
                                    <td><?php echo esc_html($item['count'] ?? 0); ?></td>
                                    <td><?php echo number_format($item['totalAmount'] ?? 0); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                    <?php if (!empty($bouncedObj['bouncedCheques'])): ?>
                        <div style="margin-top:10px; font-weight:bold;">جزئیات چک‌های برگشتی:</div>
                        <table>
                            <thead><tr><th>بانک</th><th>مبلغ</th><th>تاریخ برگشت</th><th>تاریخ رفع سوءاثر</th></tr></thead>
                            <tbody>
                                <?php foreach($bouncedObj['bouncedCheques'] as $chk): ?>
                                <tr>
                                    <td><?php echo esc_html($chk['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo number_format($chk['amount'] ?? 0); ?></td>
                                    <td><?php echo esc_html(!empty($chk['bouncedDate']) ? substr($chk['bouncedDate'], 0, 10) : '-'); ?></td>
                                    <td><?php echo esc_html(!empty($chk['clearedDate']) ? substr($chk['clearedDate'], 0, 10) : '---'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                    <?php // Tax ?>
                    <?php 
                    $taxItems = $credit_report['tax']['taxResult'] ?? [];
                    $hasTax = false; foreach($taxItems as $t) { if(!empty($t['year'])) $hasTax = true; }
                    if ($hasTax): ?>
                        <div style="margin-top:15px; font-weight:bold;">وضعیت مالیاتی:</div>
                        <table>
                            <thead><tr><th>سال</th><th>درآمد ابرازی</th><th>مالیات قطعی</th><th>بدهی</th></tr></thead>
                            <tbody>
                                <?php foreach($taxItems as $item): if(empty($item['year'])) continue; ?>
                                <tr>
                                    <td><?php echo esc_html($item['year']); ?></td>
                                    <td><?php echo number_format($item['daramadEbrazi'] ?? 0); ?></td>
                                    <td><?php echo number_format($item['maliatGhati'] ?? 0); ?></td>
                                    <td><?php echo number_format($item['bedehiMaliatAmalkard'] ?? 0); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>

                    <?php // Judiciary ?>
                    <?php 
                    $jud = $credit_report['judiciary']['judiciaryData'] ?? [];
                    if (($jud['sumExecuteCount'] ?? 0) > 0 || ($jud['sumNotExecuteCount'] ?? 0) > 0): 
                    ?>
                        <div style="margin-top:15px; font-weight:bold;">پرونده‌های قضایی:</div>
                        <div class="row">
                            <div class="col"><span class="label">پرونده‌های اجرا شده:</span> <span class="value"><?php echo esc_html($jud['sumExecuteCount']); ?></span></div>
                            <div class="col"><span class="label">پرونده‌های اجرا نشده:</span> <span class="value"><?php echo esc_html($jud['sumNotExecuteCount']); ?></span></div>
                            <div class="col" style="flex:100%"><span class="label">محکومیت اجرا نشده:</span> <span class="value"><?php echo number_format($jud['sumNotExecuteSumPenaltyAmount'] ?? 0); ?> ریال</span></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php else: ?>
                <div class="section">
                    <div class="section-content" style="text-align:center; color:#999;">گزارش اعتبارسنجی موجود نیست.</div>
                </div>
            <?php endif; ?>

            <?php if ($type === 'dossier'): ?>
                <?php 
                $occupations_map = [
                    'official_employee' => 'کارمند رسمی', 
                    'contract_employee' => 'کارمند قراردادی', 
                    'worker'            => 'کارگر', 
                    'freelancer'        => 'آزاد', 
                    'retired'           => 'بازنشسته', 
                    'pensioner'         => 'مستمری بگیر', 
                    'employer'          => 'کارفرما', 
                    'other'             => 'سایر'
                ];
                $occupation_display = isset($occupations_map[$req->occupation]) ? $occupations_map[$req->occupation] : $req->occupation;
                ?>
                <div class="section">
                    <div class="section-title">جزئیات تکمیلی پرونده</div>
                    <div class="section-content">
                        <div class="row">
                            <div class="col"><span class="label">شغل:</span> <span class="value"><?php echo esc_html($occupation_display); ?></span></div>
                            <div class="col"><span class="label">کد پستی:</span> <span class="value"><?php echo esc_html($req->postal_code); ?></span></div>
                        </div>
                        <div class="row">
                            <div class="col" style="flex:100%;"><span class="label">آدرس:</span> <span class="value"><?php echo esc_html($req->residential_address); ?></span></div>
                        </div>
                        <div class="row" style="margin-top:10px;">
                            <div class="col"><span class="label">تعداد اقساط:</span> <span class="value"><?php echo $req->installment_count; ?></span></div>
                            <div class="col"><span class="label">مبلغ قسط:</span> <span class="value"><?php echo number_format($req->installment_amount); ?> ریال</span></div>
                        </div>
                        
                        <?php if (!empty($req->description)): ?>
                            <div style="margin-top:10px; border-top:1px dashed #eee; padding-top:5px;">
                                <span class="label">توضیحات متقاضی:</span>
                                <p style="margin:5px 0;"><?php echo nl2br(esc_html($req->description)); ?></p>
                            </div>
                        <?php endif; ?>

                        <?php 
                        // --- Documents Section ---
                        $uploaded_docs = maybe_unserialize($req->required_documents);
                        if (!is_array($uploaded_docs)) $uploaded_docs = [];
                        
                        $all_files_to_show = [];
                        $doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

                        foreach ($uploaded_docs as $key => $val) {
                            if (empty($val)) continue;
                            $label = isset($doc_labels[$key]) ? $doc_labels[$key] : $key;
                            $urls = is_array($val) ? $val : [$val];
                            foreach ($urls as $url) {
                                if (!empty($url)) $all_files_to_show[] = ['label' => $label, 'url' => $url];
                            }
                        }

                        if (!empty($req->bank_validation_file)) $all_files_to_show[] = ['label' => 'فایل اعتبارسنجی بانک', 'url' => $req->bank_validation_file];
                        if (!empty($req->signature_image)) $all_files_to_show[] = ['label' => 'تصویر امضا', 'url' => $req->signature_image];
                        if (!empty($req->contract_file)) $all_files_to_show[] = ['label' => 'فایل قرارداد', 'url' => $req->contract_file];
                        
                        if (!empty($req->check_images)) {
                            $checks = maybe_unserialize($req->check_images);
                            if (!is_array($checks)) {
                                $checks = json_decode($req->check_images, true);
                                if (!is_array($checks)) $checks = array_filter(array_map('trim', preg_split('/[\r\n,]+/', (string)$req->check_images)));
                            }
                            if (!empty($checks)) {
                                foreach ($checks as $chk_url) {
                                    if (!empty($chk_url)) $all_files_to_show[] = ['label' => 'تصویر چک', 'url' => $chk_url];
                                }
                            }
                        }

                        if (!empty($all_files_to_show)): ?>
                        <div style="margin-top:15px; border-top:1px dashed #eee; padding-top:10px;">
                            <span class="label" style="display:block; margin-bottom:5px; font-weight:bold;">مدارک و فایل‌های پیوست:</span>
                            <div class="mlr-pdf-docs-container" style="display: flex; flex-direction: column; gap: 20px;">
                                <?php foreach($all_files_to_show as $file): ?>
                                <div style="border: 1px solid #eee; padding: 15px; border-radius: 8px; page-break-inside: avoid;">
                                    <div class="label" style="margin-bottom: 10px; font-weight: bold; font-size: 14px; color: #444;"><?php echo esc_html($file['label']); ?>:</div>
                                    <?php 
                                    $file_url = $file['url'];
                                    $ext = strtolower(pathinfo(parse_url($file_url, PHP_URL_PATH), PATHINFO_EXTENSION));
                                    $image_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                                    
                                    if (in_array($ext, $image_exts)): ?>
                                        <div style="text-align: center;">
                                            <img src="<?php echo esc_url($file_url); ?>" style="max-width: 100%; max-height: 500px; height: auto; border: 1px solid #ddd; display: block; margin: 0 auto; border-radius: 4px;">
                                        </div>
                                    <?php else: ?>
                                        <a href="<?php echo esc_url($file_url); ?>" target="_blank" style="text-decoration:none; color:#0073aa; font-size: 13px;">[مشاهده/دانلود فایل غیر تصویری (<?php echo strtoupper($ext); ?>)]</a>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

        </div>
        <?php endforeach; ?>
        
        <script>window.print();</script>
    </body>
    </html>
    <?php
    exit;
}

add_action('admin_init', 'mlr_process_dossier_excel_export');
/**
 * Handles the export of a single loan request dossier to Excel with specific columns.
 */
function mlr_process_dossier_excel_export() {
    if (!isset($_GET['action']) || $_GET['action'] !== 'mlr_export_dossier_excel') return;
    if (!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    
    $nonce = isset($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'mlr_ajax_nonce_action')) wp_die('خطای امنیتی');

    $rid = isset($_GET['request_id']) ? intval($_GET['request_id']) : 0;
    if (!$rid) wp_die('شناسه نامعتبر');

    global $wpdb;
    $req = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}loan_requests WHERE id = %d", $rid));
    if (!$req) wp_die('درخواست یافت نشد');

    $form_data = !empty($req->form_data) ? json_decode($req->form_data, true) : [];
    
    // Split full name into first and last name (best effort)
    $names = explode(' ', trim($req->full_name), 2);
    $first_name = $names[0] ?? '';
    $last_name = $names[1] ?? '';
    
    $columns = [
        'شناسه' => $req->id,
        'تاریخ ثبت' => function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($req->created_at, 'Y/m/d H:i') : $req->created_at,
        'نام' => $first_name,
        'نام خانوادگی' => $last_name,
        'جنسیت' => '', // Not available in current schema
        'کدملی' => $req->national_code,
        'نام پدر' => $form_data['father_name'] ?? '',
        'شماره شناسنامه' => $form_data['certificate_number'] ?? '',
        'تاریخ تولد' => function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($req->birth_date, 'Y/m/d') : $req->birth_date,
        'محل تولد (شهر)' => '', // Not available
        'تاریخ صدور' => '', // Not available
        'محل صدور (شهر)' => $form_data['certificate_city'] ?? '',
        'استان محل سکونت' => '', // Not available
        'شهر محل سکونت' => '', // Not available
        'آدرس محل سکونت' => $req->residential_address,
        'تلفن ثابت محل سکونت' => $req->phone_number,
        'کدپستی' => $req->postal_code,
        'محل سکونت' => '', // Not available
        'تلفن همراه' => $req->mobile_number,
    ];

    $filename = 'dossier-' . $rid . '.xls';
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
    echo '<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Dossier</x:Name><x:WorksheetOptions><x:DisplayRightToLeft/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head>';
    echo '<body style="direction:rtl;"><table border="1"><tr>';
    foreach (array_keys($columns) as $header) echo '<th style="background:#f2f2f2; padding:5px;">' . esc_html($header) . '</th>';
    echo '</tr><tr>';
    foreach ($columns as $val) echo '<td style="padding:5px; mso-number-format:\'\@\';">' . esc_html($val) . '</td>';
    echo '</tr></table></body></html>';
    exit;
}



add_action('wp_enqueue_scripts', 'mlr_enqueue_frontend_scripts');
function mlr_enqueue_frontend_scripts() {
    global $post;

    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], MLR_VERSION);
    // Unified popup/modal styles (admin + frontend) - must load after frontend.css to override
    wp_enqueue_style('mlr-modal-unified-css', MLR_PLUGIN_URL . 'assets/css/mlr-modal-unified.css', ['mlr-frontend-css'], MLR_VERSION);
    wp_enqueue_script('mlr-jalali-datepicker', MLR_PLUGIN_URL . 'assets/js/jalali-datepicker.js', ['jquery'], MLR_VERSION, true);

    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_cooperation_contract_viewer')) {
        wp_enqueue_style('mlr-contract-viewer-css', MLR_PLUGIN_URL . 'assets/css/contract-viewer.css', [], MLR_VERSION);
        wp_enqueue_script('mlr-contract-viewer-js', MLR_PLUGIN_URL . 'assets/js/contract-viewer.js', ['jquery'], MLR_VERSION, true);
        wp_localize_script('mlr-contract-viewer-js', 'mlr_contract_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'send_otp_nonce' => wp_create_nonce('mlr_send_cooperation_otp_nonce'),
            'verify_otp_nonce' => wp_create_nonce('mlr_verify_cooperation_otp_nonce'),
            'resend_cooldown' => 60
        ]);
    }

    if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'mlr_individual_request_form') || has_shortcode($post->post_content, 'mlr_legal_request_form'))) {
         wp_enqueue_script('mlr-cooperation-form-js', MLR_PLUGIN_URL . 'assets/js/cooperation-form.js', ['jquery'], MLR_VERSION, true);
         wp_localize_script('mlr-cooperation-form-js', 'mlr_coop_ajax', [
             'ajax_url' => admin_url('admin-ajax.php'),
             'nonce'    => wp_create_nonce('mlr_cooperation_request_action'),
         ]);
    }

     if (is_a($post, 'WP_Post') && (
         has_shortcode($post->post_content, 'mlr_user_loan_requests') ||
         has_shortcode($post->post_content, 'mlr_needs_review_requests') ||
         has_shortcode($post->post_content, 'mlr_processing_requests') ||
         has_shortcode($post->post_content, 'mlr_granted_user_requests') ||
         has_shortcode($post->post_content, 'mlr_user_settlement_cycles') ||
         has_shortcode($post->post_content, 'mlr_bank_expert_dashboard') ||
         has_shortcode($post->post_content, 'mlr_verified_docs_dashboard')
         )) {
        wp_enqueue_script('mlr-user-requests-js', MLR_PLUGIN_URL . 'assets/js/mlr-user-requests.js', ['jquery', 'mlr-jalali-datepicker'], MLR_VERSION, true);
        wp_localize_script('mlr-user-requests-js', 'mlr_ajax_obj', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'filter_nonce'    => wp_create_nonce('mlr_user_requests_nonce'),
            'details_nonce'   => wp_create_nonce('mlr_frontend_nonce'),
            'cycle_nonce'     => wp_create_nonce('mlr_user_cycle_nonce'),
            'allowed_statuses' => []
        ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_bank_expert_dashboard')) {
          wp_enqueue_style('mlr-bank-expert-dashboard-css', MLR_PLUGIN_URL . 'assets/css/bank-expert-dashboard.css', [], MLR_VERSION);
          wp_enqueue_script('mlr-bank-expert-dashboard-js', MLR_PLUGIN_URL . 'assets/js/bank-expert-dashboard.js', ['jquery', 'mlr-jalali-datepicker'], MLR_VERSION, true);
          wp_localize_script('mlr-bank-expert-dashboard-js', 'mlr_bank_ajax_obj', [
              'ajax_url' => admin_url('admin-ajax.php'),
              'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
          ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_verified_docs_dashboard')) {
          wp_enqueue_script('mlr-verified-docs-dashboard-js', MLR_PLUGIN_URL . 'assets/js/verified-docs-dashboard.js', ['jquery', 'mlr-jalali-datepicker'], MLR_VERSION, true);
          wp_localize_script('mlr-verified-docs-dashboard-js', 'mlr_verified_ajax_obj', [
              'ajax_url' => admin_url('admin-ajax.php'),
              'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
          ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_loan_request_form')) {
         wp_enqueue_style('mlr-loan-form-style', MLR_PLUGIN_URL . 'assets/css/loan-request-form.css', [], MLR_VERSION);
         wp_enqueue_script('mlr-front-form-js', MLR_PLUGIN_URL . 'assets/js/loan-request-form.js', ['jquery'], MLR_VERSION, true);

         $user_commission = null;
         if (is_user_logged_in()) {
             $user_commission = get_user_meta(get_current_user_id(), 'acceptor_commission_percent', true);
         }

         wp_localize_script('mlr-front-form-js', 'mlr_form_ajax', [
             'ajax_url' => admin_url('admin-ajax.php'),
             'nonce' => wp_create_nonce('mlr_frontend_nonce'),
             'calc_nonce' => wp_create_nonce('mlr_frontend_calc_nonce'),
             'submit_nonce' => wp_create_nonce('mlr_loan_request_action'),
             'plans' => mlr_get_js_plans(),
             'user_commission' => $user_commission
         ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_loan_calculator')) {
        wp_enqueue_script('mlr-calculator-js', MLR_PLUGIN_URL . 'assets/js/loan-calculator.js', ['jquery'], MLR_VERSION, true);
        $user_commission = null;
         if (is_user_logged_in()) {
             $user_commission = get_user_meta(get_current_user_id(), 'acceptor_commission_percent', true);
         }
        wp_localize_script('mlr-calculator-js', 'mlrCalculatorAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('mlr_frontend_calc_nonce'),
            'plans'   => mlr_get_js_plans(),
            'user_commission' => $user_commission
        ]);
     }
}

function mlr_get_js_plans() {
    global $wpdb;
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $plans = $wpdb->get_results("SELECT id, name, type, settings FROM `$table_installment_plans` WHERE is_active = 1 ORDER BY id DESC");

    if (!is_array($plans)) {
        return [];
    }

    return array_map(function($plan) {
        $settings = maybe_unserialize($plan->settings);
        if (!is_array($settings)) {
            $settings = [];
        }
        $plan->view_settings = [
            'requires_bank_validation' => $settings['requires_bank_validation'] ?? 0,
            'min_amount' => $settings['min_amount'] ?? 0,
            'max_amount' => $settings['max_amount'] ?? 0,
            'active_installments' => $settings['active_installments'] ?? '',
            'min_interval' => $settings['min_interval'] ?? 1,
            'max_interval' => $settings['max_interval'] ?? 12,
            'prepayment_percent' => $settings['prepayment_percent'] ?? null,
        ];
        unset($plan->settings);
        return $plan;
    }, $plans);
}

add_action('wp_ajax_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');
add_action('wp_ajax_nopriv_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');
function mlr_verify_shahkar_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    $user_national_code = isset($_POST['national_code']) ? sanitize_text_field($_POST['national_code']) : '';
    $user_mobile = isset($_POST['mobile_number']) ? sanitize_text_field($_POST['mobile_number']) : '';

    if (!preg_match('/^\d{10}$/', $user_national_code) || !preg_match('/^09\d{9}$/', $user_mobile)) {
        wp_send_json_error(['message' => 'کد ملی یا شماره موبایل وارد شده نامعتبر است.']);
        return;
    }

    $client_id = get_option('mlr_shahkar_client_id');
    $client_secret = get_option('mlr_shahkar_client_secret');
    $owner_nid = get_option('mlr_shahkar_owner_nid');

    if (empty($client_id) || empty($client_secret) || empty($owner_nid)) {
        mlr_log("Shahkar API Error: Settings not configured.");
        wp_send_json_error(['message' => 'سرویس احراز هویت در دسترس نیست.']);
        return;
    }

    $token_url = 'https://api.finnotech.ir/dev/v2/oauth2/token';
    $auth_string = base64_encode("{$client_id}:{$client_secret}");
    $scope_for_token = 'card:shahkar:get';

    $token_args = [
        'method' => 'POST',
        'timeout' => 20,
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Basic ' . $auth_string,
        ],
        'body' => json_encode([
            'grant_type' => 'client_credentials',
            'nid' => $owner_nid,
            'scopes' => $scope_for_token,
        ]),
    ];

    $token_response = wp_remote_post($token_url, $token_args);

    if (is_wp_error($token_response)) {
        mlr_log("Shahkar API Token Error: " . $token_response->get_error_message());
        wp_send_json_error(['message' => 'خطا در ارتباط با سرویس احراز هویت (مرحله ۱).']);
        return;
    }

    $token_body_raw = wp_remote_retrieve_body($token_response);
    $token_body = json_decode($token_body_raw, true);
    $access_token = isset($token_body['result']['value']) ? $token_body['result']['value'] : null;
    $response_code = wp_remote_retrieve_response_code($token_response);

    if ($response_code !== 200 || !$access_token) {
        // Robust Error Handling for non-JSON or HTML error pages
        $err_msg = 'خطای سرویس توکن';
        if(is_array($token_body) && isset($token_body['error'])) {
            $err_msg = $token_body['error']['message'] ?? $err_msg;
        } else {
             $err_msg = "Status: $response_code. Body: " . substr($token_body_raw, 0, 100);
        }
        mlr_log("Shahkar Token Failed: " . $err_msg);
        wp_send_json_error(['message' => 'دریافت مجوز احراز هویت ناموفق بود.']);
        return;
    }

    $verify_base_url = "https://api.finnotech.ir/mpg/v2/clients/{$client_id}/shahkar/verify";
    $track_id = 'MLR' . time() . rand(100, 999);

    $verify_url_with_params = add_query_arg([
        'trackId' => $track_id,
        'mobile' => $user_mobile,
        'nationalCode' => $user_national_code,
    ], $verify_base_url);


    $verify_args = [
        'method' => 'GET',
        'timeout' => 25,
        'headers' => [
            'Authorization' => 'Bearer ' . $access_token,
        ],
    ];

    $verify_response = wp_remote_get($verify_url_with_params, $verify_args);

    if (is_wp_error($verify_response)) {
        mlr_log("Shahkar API Verify Error: " . $verify_response->get_error_message());
        wp_send_json_error(['message' => 'خطا در ارتباط با سرویس احراز هویت (مرحله ۲).']);
        return;
    }

    $verify_body_raw = wp_remote_retrieve_body($verify_response);
    $verify_body = json_decode($verify_body_raw, true);
    $verify_response_code = wp_remote_retrieve_response_code($verify_response);

    // Robust Handling for Verify Response
    if ($verify_response_code === 200 && isset($verify_body['result']['isValid']) && $verify_body['result']['isValid'] === true && isset($verify_body['status']) && $verify_body['status'] === 'DONE') {
        wp_send_json_success(['message' => 'تطابق شماره موبایل و کد ملی تأیید شد.']);
    } else {
        $error_detail = 'عدم تطابق یا خطای نامشخص.';
        if (isset($verify_body['result']['isValid']) && $verify_body['result']['isValid'] === false) {
             $error_detail = 'شماره موبایل وارد شده متعلق به این کد ملی نمی‌باشد.';
        } elseif (is_array($verify_body) && isset($verify_body['error']['message'])) {
             $error_detail = $verify_body['error']['message'];
        } elseif ($verify_response_code !== 200) {
            $error_detail = "خطای سرویس (کد: {$verify_response_code}).";
        }
        
        mlr_log("Shahkar Verify Failed: " . $error_detail);
        wp_send_json_error(['message' => $error_detail]);
    }
}
?>