<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_save_guarantor_info', 'mlr_save_guarantor_info_callback');

function mlr_save_guarantor_info_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';
    $uid = get_current_user_id();
    
    // Check access
    $req = $wpdb->get_row($wpdb->prepare("SELECT user_id, guarantor_info FROM $table WHERE id=%d", $request_id));
    if (!$req) wp_send_json_error(['message' => 'درخواست یافت نشد.']);
    
    if (!current_user_can('manage_options') && $req->user_id != $uid) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز.']);
        return;
    }

    $info = !empty($req->guarantor_info) ? json_decode($req->guarantor_info, true) : [];
    if (!is_array($info)) $info = [];

    // Text fields
    $text_fields = ['full_name', 'national_code', 'father_name', 'id_number', 'issued_from', 'birth_date', 'mobile', 'phone', 'job', 'postal_code', 'address'];
    foreach ($text_fields as $f) {
        if (isset($_POST[$f])) $info[$f] = sanitize_text_field($_POST[$f]);
    }

    // File fields
    $file_fields = ['national_card', 'id_card', 'payslip', 'sana', 'check', 'residence_deed', 'work_deed', 'account_statement', 'extra_docs'];
    foreach ($file_fields as $f) {
        if (!empty($_FILES[$f]['name'])) {
            $upload = mlr_handle_wp_upload($_FILES[$f]);
            if (!is_wp_error($upload)) {
                $info[$f] = $upload;
            }
        }
    }

    $updated = $wpdb->update($table, ['guarantor_info' => json_encode($info, JSON_UNESCAPED_UNICODE)], ['id' => $request_id]);

    if ($updated === false) wp_send_json_error(['message' => 'خطا در ذخیره اطلاعات.']);
    
    wp_send_json_success(['message' => 'اطلاعات ضامن با موفقیت ذخیره شد.']);
}