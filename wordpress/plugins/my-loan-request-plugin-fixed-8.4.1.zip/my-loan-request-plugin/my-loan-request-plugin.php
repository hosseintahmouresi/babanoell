<?php
/*
Plugin Name: درخواست تسهیلات بابانوئل
Description: افزونه‌ای برای مدیریت درخواست‌های تسهیلات با قابلیت محاسبه اقساط و ثبت-نام پذیرندگان
Version: 8.4.1
Author: شرکت پدیده تجارت
*/

if (!defined('ABSPATH')) {
    exit;
}

define('MLR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MLR_PLUGIN_URL', plugin_dir_url(__FILE__));


// --- START: MLR Log Path Helpers ---
if (!function_exists('mlr_get_log_file_path')) {
    function mlr_get_log_file_path() {
        $upload_dir = wp_upload_dir(null, false);
        $base_dir = isset($upload_dir['basedir']) ? $upload_dir['basedir'] : WP_CONTENT_DIR;
        $log_dir  = trailingslashit($base_dir) . 'mlr-logs';
        return trailingslashit($log_dir) . 'mlr_debug.log';
    }
}

if (!function_exists('mlr_ensure_log_dir')) {
    function mlr_ensure_log_dir() {
        $log_file = mlr_get_log_file_path();
        $log_dir  = dirname($log_file);

        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }

        // Create protection files (best-effort)
        $index_file = trailingslashit($log_dir) . 'index.html';
        if (!file_exists($index_file)) {
            @file_put_contents($index_file, '');
        }

        $htaccess_file = trailingslashit($log_dir) . '.htaccess';
        if (!file_exists($htaccess_file)) {
            @file_put_contents($htaccess_file, "Deny from all\n");
        }
    }
}
// --- END: MLR Log Path Helpers ---



// --- START: MLR Logging Function ---
if (!function_exists('mlr_log')) {
    function mlr_log($message) {
        $log_file = mlr_get_log_file_path();
        mlr_ensure_log_dir();
        $timestamp = date('Y-m-d H:i:s');
        
        // Prepare message
        if (is_array($message) || is_object($message)) {
            $log_content = print_r($message, true);
        } else {
            $log_content = $message;
        }

        // Mask sensitive data (Basic Protection)
        $log_content = preg_replace('/(password|client_secret|Authorization)(\'|")?\s*(=>|:)\s*(\'|")?([^\'"\s]+)(\'|")?/i', '$1$2$3$4*****$6', $log_content);

        $formatted_message = sprintf("[%s] %s\n", $timestamp, $log_content);
        
        // Add file locking for safer concurrent writes
        $file_handle = @fopen($log_file, 'a');
        if ($file_handle) {
            if (flock($file_handle, LOCK_EX)) {
                fwrite($file_handle, $formatted_message);
                fflush($file_handle);
                flock($file_handle, LOCK_UN);
            }
            fclose($file_handle);
        } else {
             error_log("MLR_Log Error: Could not open log file for writing: " . $log_file);
        }
    }
}
// --- END: MLR Logging Function ---


// --- START: افزودن فیلدهای سفارشی به پروفایل کاربر ---
add_action('show_user_profile', 'mlr_add_custom_user_profile_fields');
add_action('edit_user_profile', 'mlr_add_custom_user_profile_fields');
function mlr_add_custom_user_profile_fields($user) {
    ?>
    <h3>اطلاعات تکمیلی پذیرنده</h3>
    <table class="form-table">
        <tr>
            <th><label for="shebaaa">شماره شبا</label></th>
            <td>
                <input type="text" name="shebaaa" id="shebaaa" value="<?php echo esc_attr(get_the_author_meta('shebaaa', $user->ID)); ?>" class="regular-text ltr" pattern="[0-9]{24}" title="شماره شبا 24 رقمی" />
                <p class="description">شماره شبا ۲۴ رقمی بدون IR</p>
            </td>
        </tr>
        <?php if (current_user_can('manage_options') || current_user_can('edit_user', $user->ID)): ?>
        <?php if (current_user_can('manage_options')): ?>
        <tr>
            <th><label for="acceptor_commission_percent">کمیسیون پذیرنده (%)</label></th>
            <td>
                <input type="number" name="acceptor_commission_percent" id="acceptor_commission_percent" value="<?php echo esc_attr(get_the_author_meta('acceptor_commission_percent', $user->ID)); ?>" class="small-text ltr" step="0.01" min="0" max="100" />
                <p class="description">این مقدار در محاسبه‌گر فرم ثبت‌نام استفاده خواهد شد (پیش‌فرض تنظیمات طرح اعمال می‌شود).</p>
            </td>
        </tr>
        <?php endif; ?>
         <tr>
             <th><label for="acceptor_mobile_number">شماره موبایل پذیرنده (برای پیامک)</label></th>
             <td>
                 <input type="text" name="acceptor_mobile_number" id="acceptor_mobile_number" value="<?php echo esc_attr(get_the_author_meta('acceptor_mobile_number', $user->ID)); ?>" class="regular-text ltr" pattern="09[0-9]{9}" title="شماره موبایل 11 رقمی با شروع 09" />
                 <p class="description">این شماره موبایل برای دریافت پیامک‌های مربوط به وضعیت درخواست‌های تسهیلات استفاده خواهد شد. (جایگزین شماره موبایل پیش‌فرض حساب کاربری یا ووکامرس)</p>
             </td>
         </tr>
        <?php endif; ?>
    </table>
    <?php
}

add_action('personal_options_update', 'mlr_save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'mlr_save_custom_user_profile_fields');
function mlr_save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    if (isset($_POST['shebaaa'])) {
        $sheba = preg_replace('/[^0-9]/', '', $_POST['shebaaa']);
        if (strlen($sheba) === 24) {
            update_user_meta($user_id, 'shebaaa', $sheba);
        } else {
             delete_user_meta($user_id, 'shebaaa');
        }
    }

    if (current_user_can('manage_options') && isset($_POST['acceptor_commission_percent'])) {
        $commission_value = sanitize_text_field($_POST['acceptor_commission_percent']);
        if (is_numeric($commission_value) && $commission_value >= 0 && $commission_value <= 100) {
             update_user_meta($user_id, 'acceptor_commission_percent', $commission_value);
        } else {
             delete_user_meta($user_id, 'acceptor_commission_percent');
        }
    }
    
    if (isset($_POST['acceptor_mobile_number'])) {
        $mobile = preg_replace('/[^0-9]/', '', $_POST['acceptor_mobile_number']);
         if (preg_match('/^09\d{9}$/', $mobile)) {
            update_user_meta($user_id, 'acceptor_mobile_number', $mobile);
        } else {
             delete_user_meta($user_id, 'acceptor_mobile_number');
        }
    }
}
// --- END: افزودن فیلدهای سفارشی ---


add_action('admin_init', 'mlr_check_and_update_database_schema');
function mlr_check_and_update_database_schema() {
    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $table_cooperation = $wpdb->prefix . 'cooperation_requests';
    $version_option_name = 'mlr_db_version';
    $current_db_version = '1.4'; // Incremented version for safety

    $installed_ver = get_option($version_option_name);

    if ($installed_ver != $current_db_version) {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // --- Loan Requests Table Updates ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_requests)) == $table_requests) {
             $existing_columns_requests = $wpdb->get_col("DESC `{$table_requests}`", 0);            // expert_note column retained for backward compatibility            // bank_note column retained for backward compatibility

             $required_columns_requests = [
                 'phone_number' => "varchar(20) DEFAULT '' NOT NULL AFTER `mobile_number`",
                 'birth_date' => "date DEFAULT NULL AFTER `phone_number`",
                 'occupation' => "varchar(100) DEFAULT '' NOT NULL AFTER `birth_date`",
                 'residential_address' => "text AFTER `occupation`",
                 'postal_code' => "varchar(10) DEFAULT '' NOT NULL AFTER `residential_address`",
                 'work_address' => "text AFTER `postal_code`",
                 'product_name' => "text AFTER `work_address`",
                 'comments' => "TEXT DEFAULT NULL",
                 'prepayment' => "DECIMAL(15,2) DEFAULT 0 AFTER `loan_amount`",
                 'installment_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `installment_count`",
                 'total_payment' => "DECIMAL(15,2) DEFAULT 0 AFTER `installment_amount`",
                 'profit' => "DECIMAL(15,2) DEFAULT 0 AFTER `total_payment`",
                 'wallet_charge' => "DECIMAL(15,2) DEFAULT 0 AFTER `prepayment`",
                 'acceptor_payment_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `wallet_charge`",
                 'final_settlement_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `acceptor_payment_amount`",
                 'assigned_bank_user_id' => "bigint(20) UNSIGNED DEFAULT NULL AFTER `settlement_status`",
                 'settlement_cycle_id' => "bigint(20) UNSIGNED DEFAULT NULL AFTER `assigned_bank_user_id`",
                 'settlement_date' => "datetime DEFAULT NULL AFTER `settlement_cycle_id`"
             ];
             
             $current_columns_requests = $wpdb->get_col("DESC `{$table_requests}`", 0);
             foreach ($required_columns_requests as $column_name => $column_definition) {
                 if (!in_array($column_name, $current_columns_requests)) {
                     if ($wpdb->query("ALTER TABLE `{$table_requests}` ADD COLUMN `{$column_name}` {$column_definition};") === false) {
                          mlr_log("Error adding column {$column_name} to {$table_requests}: " . $wpdb->last_error);
                     } else {
                          mlr_log("Successfully added column {$column_name} to {$table_requests}");
                          $current_columns_requests[] = $column_name;
                     }
                 }
             }

             // Add Indexes
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_requests}` WHERE Key_name = %s", 'idx_settlement_cycle_id'))) {
                 $wpdb->query("ALTER TABLE `{$table_requests}` ADD INDEX `idx_settlement_cycle_id` (`settlement_cycle_id`);");
             }
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_requests}` WHERE Key_name = %s", 'idx_assigned_bank_user_id'))) {
                 $wpdb->query("ALTER TABLE `{$table_requests}` ADD INDEX `idx_assigned_bank_user_id` (`assigned_bank_user_id`);");
             }
        }

        // --- Cooperation Requests Table Updates ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_cooperation)) == $table_cooperation) {
             $existing_columns_coop = $wpdb->get_col("DESC `{$table_cooperation}`", 0);
             $required_columns_coop = [
                 'contract_token' => "VARCHAR(64) DEFAULT NULL AFTER `status`",
                 'contract_signed_status' => "VARCHAR(20) DEFAULT 'pending' NOT NULL AFTER `contract_token`",
                 'contract_signed_at' => "DATETIME DEFAULT NULL AFTER `contract_signed_status`",
                 'contract_expires_at' => "DATETIME DEFAULT NULL AFTER `contract_signed_at`",
                 'otp_code' => "VARCHAR(255) DEFAULT NULL AFTER `contract_expires_at`",
                 'otp_expires_at' => "DATETIME DEFAULT NULL AFTER `otp_code`"
             ];
             foreach ($required_columns_coop as $column_name => $column_definition) {
                if (!in_array($column_name, $existing_columns_coop)) {
                    $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD COLUMN `{$column_name}` {$column_definition};");
                    $existing_columns_coop[] = $column_name;
                }
             }
             
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_cooperation}` WHERE Key_name = %s", 'idx_contract_token'))) {
                 if (in_array('contract_token', $existing_columns_coop)) {
                    $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD UNIQUE INDEX `idx_contract_token` (`contract_token`);");
                 }
             }
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_cooperation}` WHERE Key_name = %s", 'idx_signed_status'))) {
                  if (in_array('contract_signed_status', $existing_columns_coop)) { 
                      $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD INDEX `idx_signed_status` (`contract_signed_status`);"); 
                  }
             }
        }

        update_option($version_option_name, $current_db_version);
        mlr_log("Database schema checked/updated to version {$current_db_version}");
    }
}


// Helper & Core Functions
require_once MLR_PLUGIN_DIR . 'includes/sms-functions.php';
require_once MLR_PLUGIN_DIR . 'includes/loan-calculations.php';
require_once MLR_PLUGIN_DIR . 'includes/functions.php';

// AJAX Handlers
foreach (glob(MLR_PLUGIN_DIR . 'includes/ajax/*.php') as $filename) {
    require_once $filename;
}
require_once MLR_PLUGIN_DIR . 'includes/ajax/cooperation-otp-actions.php';


// Admin Pages
if (is_admin()) {
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/loan-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/installment-plans.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/granted-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/unsettled-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/settled-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/cooperation-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/form-editor.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/sms-settings.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/log-viewer.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/cooperation-contract-settings.php';
}

// Shortcodes
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/loan-request-form.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-loan-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/needs-review-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/processing-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/granted-user-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-settlement-cycles.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/bank-expert-dashboard.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/verified-docs-dashboard.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/cooperation-request-form.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/loan-calculator.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-stats.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/invoice.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/edit-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/complete-request.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/cooperation-contract-viewer.php';


register_activation_hook(__FILE__, 'mlr_install_and_update');
register_deactivation_hook(__FILE__, 'mlr_deactivate');

function mlr_install_and_update() {
    // Ensure log directory exists
    if (function_exists('mlr_ensure_log_dir')) { mlr_ensure_log_dir(); }

    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // Unified bigInt definition
    $table_requests = $wpdb->prefix . 'loan_requests';
    $sql_requests = "CREATE TABLE $table_requests (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        full_name varchar(255) NOT NULL,
        national_code varchar(10) NOT NULL,
        mobile_number varchar(15) NOT NULL,
        phone_number varchar(20) DEFAULT '' NOT NULL,
        birth_date date DEFAULT NULL,
        occupation varchar(100) DEFAULT '' NOT NULL,
        residential_address text,
        postal_code varchar(10) DEFAULT '' NOT NULL,
        work_address text,
        product_name text,
        installment_plan_id bigint(20) UNSIGNED NOT NULL,
        loan_amount DECIMAL(15,2) NOT NULL,
        prepayment DECIMAL(15,2) DEFAULT 0,
        wallet_charge DECIMAL(15,2) DEFAULT 0,
        acceptor_payment_amount DECIMAL(15,2) DEFAULT 0,
        final_settlement_amount DECIMAL(15,2) DEFAULT 0,
        installment_interval int(11) NOT NULL DEFAULT 1,
        installment_count int(11) NOT NULL,
        installment_amount DECIMAL(15,2) DEFAULT 0,
        total_payment DECIMAL(15,2) DEFAULT 0,
        profit DECIMAL(15,2) DEFAULT 0,
        required_documents longtext,
        order_items longtext,
        comments longtext,
        status varchar(50) NOT NULL,
        settlement_status varchar(50) DEFAULT '',
        assigned_bank_user_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_cycle_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_date datetime DEFAULT NULL,
        created_at datetime NOT NULL,
        last_edited_at datetime DEFAULT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status),
        KEY national_code (national_code),
        KEY installment_plan_id (installment_plan_id),
        KEY idx_settlement_cycle_id (settlement_cycle_id),
        KEY idx_assigned_bank_user_id (assigned_bank_user_id)
    ) $charset_collate;";
    dbDelta($sql_requests);

    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $sql_installment_plans = "CREATE TABLE $table_installment_plans (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        type varchar(50) NOT NULL,
        is_active tinyint(1) DEFAULT 1,
        settings longtext,
        display_fields longtext,
        required_documents text,
        created_at datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql_installment_plans);

    $table_cooperation_requests = $wpdb->prefix . 'cooperation_requests';
    $sql_cooperation_requests = "CREATE TABLE $table_cooperation_requests (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_type varchar(50) NOT NULL,
        status varchar(50) NOT NULL DEFAULT 'در حال بررسی',
        contract_token varchar(64) DEFAULT NULL,
        contract_signed_status varchar(20) NOT NULL DEFAULT 'pending',
        contract_signed_at datetime DEFAULT NULL,
        contract_expires_at datetime DEFAULT NULL,
        otp_code varchar(255) DEFAULT NULL,
        otp_expires_at datetime DEFAULT NULL,
        data longtext,
        files longtext,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY idx_contract_token (contract_token),
        KEY status (status),
        KEY request_type (request_type),
        KEY idx_signed_status (contract_signed_status)
    ) $charset_collate;";
    dbDelta($sql_cooperation_requests);

    $table_settlement_cycles = $wpdb->prefix . 'mlr_settlement_cycles';
    $sql_settlement_cycles = "CREATE TABLE $table_settlement_cycles (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        total_amount DECIMAL(15,2) NOT NULL,
        description text,
        settlement_date datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql_settlement_cycles);

    mlr_check_and_update_database_schema();

    // Create contract viewer page
    $contract_page_slug = 'cooperation-contract';
    if ( null == get_page_by_path( $contract_page_slug ) ) {
      wp_insert_post(
        array(
          'comment_status' => 'closed',
          'ping_status'    => 'closed',
          'post_author'    => (get_current_user_id() ? get_current_user_id() : 1),
          'post_name'      => $contract_page_slug,
          'post_title'     => 'قرارداد همکاری',
          'post_status'    => 'publish',
          'post_type'      => 'page',
          'post_content'   => '[mlr_cooperation_contract_viewer]'
        )
      );
    }
}

function mlr_deactivate() { }


add_action('admin_menu', 'mlr_admin_menu');
function mlr_admin_menu() {
    add_menu_page('عملیات تسهیلات', 'عملیات تسهیلات', 'manage_options', 'mlr-loan-requests', 'mlr_loan_requests_page', 'dashicons-money-alt', 6);
    add_submenu_page('mlr-loan-requests', 'همه‌درخواست‌ها', 'همه‌درخواست‌ها', 'manage_options', 'mlr-loan-requests', 'mlr_loan_requests_page');
    add_submenu_page('mlr-loan-requests', 'در حال بررسی', 'در حال بررسی', 'manage_options', 'admin.php?page=mlr-loan-requests&status=در حال بررسی');
    add_submenu_page('mlr-loan-requests', 'نقص مدارک', 'نقص مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=نقص مدارک');
    add_submenu_page('mlr-loan-requests', 'رد شده', 'رد شده', 'manage_options', 'admin.php?page=mlr-loan-requests&status=رد شده');
    add_submenu_page('mlr-loan-requests', 'تأیید کارشناس', 'تأیید کارشناس', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تأیید کارشناس');
    add_submenu_page('mlr-loan-requests', 'تکمیل مدارک', 'تکمیل مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تکمیل مدارک');
    add_submenu_page('mlr-loan-requests', 'تأیید مدارک', 'تأیید مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تأیید مدارک');
    
    add_submenu_page('mlr-loan-requests', 'اعطا شده', 'اعطا شده', 'manage_options', 'mlr-granted-requests', 'mlr_granted_requests_page');
    add_submenu_page('mlr-loan-requests', 'در انتظار تسویه', 'در انتظار تسویه', 'manage_options', 'mlr-unsettled-requests', 'mlr_unsettled_requests_page');
    add_submenu_page('mlr-loan-requests', 'تسویه شده', 'تسویه شده', 'manage_options', 'mlr-settled-requests', 'mlr_settled_requests_page');
    add_submenu_page('mlr-loan-requests', 'طرح‌های اقساطی', 'طرح‌های اقساطی', 'manage_options', 'mlr-installment-plans', 'mlr_installment_plans_page');
    add_submenu_page('mlr-loan-requests', 'تنظیمات API', 'تنظیمات API', 'manage_options', 'mlr-api-settings', 'mlr_api_settings_page_callback');

    add_menu_page('مدیریت همکاری', 'مدیریت همکاری', 'manage_options', 'mlr-cooperation-main', 'mlr_cooperation_requests_page', 'dashicons-groups', 7);
    add_submenu_page('mlr-cooperation-main', 'درخواست‌های همکاری', 'درخواست‌های همکاری', 'manage_options', 'mlr-cooperation-main', 'mlr_cooperation_requests_page');
    add_submenu_page('mlr-cooperation-main', 'ویرایشگر فرم همکاری', 'ویرایشگر فرم', 'manage_options', 'mlr-form-editor', 'mlr_form_editor_page');
    add_submenu_page('mlr-cooperation-main', 'تنظیمات قرارداد', 'تنظیمات قرارداد', 'manage_options', 'mlr-cooperation-contract-settings', 'mlr_cooperation_contract_settings_page');

    add_menu_page('تنظیمات پیامک', 'تنظیمات پیامک', 'manage_options', 'mlr-sms-settings', 'mlr_sms_settings_page', 'dashicons-email-alt', 8);
    add_submenu_page('mlr-sms-settings', 'مشاهده لاگ', 'مشاهده لاگ', 'manage_options', 'mlr-log-viewer', 'mlr_log_viewer_page');
}


add_action('admin_init', 'mlr_register_plugin_settings');
function mlr_register_plugin_settings() {
    register_setting('mlr_api_settings_group', 'mlr_shahkar_client_id', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_api_settings_group', 'mlr_shahkar_client_secret', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_api_settings_group', 'mlr_shahkar_owner_nid', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_sms_settings_group', 'mlr_sms_settings', ['sanitize_callback' => 'mlr_sanitize_sms_settings']);
    register_setting('mlr_cooperation_contract_settings_group', 'mlr_cooperation_contract_settings', ['sanitize_callback' => 'mlr_sanitize_cooperation_contract_settings']);
    register_setting('mlr_cooperation_form_editor_group', 'mlr_cooperation_form_options', ['sanitize_callback' => 'mlr_sanitize_cooperation_form_options']);
    register_setting('mlr_cooperation_form_editor_group', 'mlr_cooperation_form_config', ['sanitize_callback' => 'mlr_sanitize_cooperation_form_config']);
}

function mlr_sanitize_cooperation_form_options($input) {
    $sanitized_input = [];
    $option_keys = ['activity_field_options', 'how_heard_options'];
    foreach ($option_keys as $key) {
        if (isset($input[$key])) {
            $lines = explode("\n", $input[$key]);
            $options = [];
            foreach ($lines as $line) {
                $trimmed = trim($line);
                if (!empty($trimmed)) $options[] = sanitize_text_field($trimmed);
            }
            $sanitized_input[$key] = $options;
        } else {
            $sanitized_input[$key] = [];
        }
    }
    return $sanitized_input;
}

function mlr_sanitize_cooperation_form_config($input) {
    $sanitized_input = [];
    $all_fields = mlr_get_all_cooperation_fields();
    if (!is_array($input)) $input = [];

    foreach ($all_fields as $field_key => $field_info) {
        if ($field_info['type'] === 'file') {
             $sanitized_input[$field_key]['visible'] = isset($input[$field_key]['visible']) ? 1 : 0;
        } else {
             $sanitized_input[$field_key]['visible'] = 1;
        }
        $is_visible = $sanitized_input[$field_key]['visible'];
        $sanitized_input[$field_key]['required'] = (isset($input[$field_key]['required']) && $is_visible) ? 1 : 0;
    }
    return $sanitized_input;
}

function mlr_sanitize_cooperation_contract_settings($input) {
    $sanitized_input = [];
    if (!is_array($input)) $input = [];
    $sanitized_input['header_image_url'] = isset($input['header_image_url']) ? esc_url_raw(trim($input['header_image_url'])) : '';
    $sanitized_input['footer_image_url'] = isset($input['footer_image_url']) ? esc_url_raw(trim($input['footer_image_url'])) : '';
    $sanitized_input['contract_text'] = isset($input['contract_text']) ? wp_kses_post($input['contract_text']) : '';
    return $sanitized_input;
}

function mlr_sanitize_sms_settings($input) {
    $sanitized_input = [];
    if (!is_array($input)) $input = [];

    $sanitized_input['username'] = isset($input['username']) ? sanitize_text_field(trim($input['username'])) : '';
    $current = get_option('mlr_sms_settings', []);
    if (!empty($input['password'])) {
        $sanitized_input['password'] = sanitize_text_field(trim($input['password']));
    } elseif (isset($current['password'])) {
        $sanitized_input['password'] = $current['password'];
    } else {
        $sanitized_input['password'] = '';
    }

    foreach (['cooperation_statuses', 'loan_statuses', 'otp_settings'] as $group_key) {
        if (isset($input[$group_key]) && is_array($input[$group_key])) {
            foreach ($input[$group_key] as $key => $settings) {
                if (!is_array($settings)) continue;
                $sanitized_key = sanitize_text_field($key);
                $sanitized_input[$group_key][$sanitized_key]['enabled'] = isset($settings['enabled']) ? 1 : 0;
                $sanitized_input[$group_key][$sanitized_key]['bodyId'] = isset($settings['bodyId']) ? sanitize_text_field(trim($settings['bodyId'])) : '';

                for ($i = 0; $i < 3; $i++) {
                    $var = "var_{$i}";
                    $sanitized_input[$group_key][$sanitized_key][$var] = isset($settings[$var]) ? sanitize_text_field(trim($settings[$var])) : '';
                }

                if ($group_key === 'loan_statuses') {
                    $sanitized_input[$group_key][$sanitized_key]['send_to_applicant'] = isset($settings['send_to_applicant']) ? 1 : 0;
                    $sanitized_input[$group_key][$sanitized_key]['send_to_acceptor'] = isset($settings['send_to_acceptor']) ? 1 : 0;
                }
            }
        }
    }
    return $sanitized_input;
}

function mlr_get_all_cooperation_fields() {
    return [
        'store_name' => ['type' => 'text', 'form' => 'individual', 'label' => 'نام فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_owner_name' => ['type' => 'text', 'form' => 'individual', 'label' => 'نام مالک فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_address' => ['type' => 'textarea', 'form' => 'individual', 'label' => 'آدرس فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_images' => ['type' => 'file', 'form' => 'individual', 'label' => 'تصاویر فروشگاه', 'default_required' => true, 'default_visible' => true],

        'company_name' => ['type' => 'text', 'form' => 'legal', 'label' => 'نام شرکت', 'default_required' => true, 'default_visible' => true],
        'contact_person' => ['type' => 'text', 'form' => 'legal', 'label' => 'نام رابط', 'default_required' => true, 'default_visible' => true],
        'company_address' => ['type' => 'textarea', 'form' => 'legal', 'label' => 'آدرس شرکت', 'default_required' => true, 'default_visible' => true],
        'email' => ['type' => 'email', 'form' => 'legal', 'label' => 'ایمیل', 'default_required' => true, 'default_visible' => true],
        'company_images' => ['type' => 'file', 'form' => 'legal', 'label' => 'تصاویر شرکت', 'default_required' => true, 'default_visible' => true],
        'company_docs' => ['type' => 'file', 'form' => 'legal', 'label' => 'اساسنامه و روزنامه رسمی', 'default_required' => true, 'default_visible' => true],

        'activity_field' => ['type' => 'select', 'form' => 'both', 'label' => 'زمینه فعالیت', 'options_key' => 'activity_field_options', 'default_required' => true, 'default_visible' => true],
        'how_heard' => ['type' => 'select', 'form' => 'both', 'label' => 'نحوه آشنایی با ما', 'options_key' => 'how_heard_options', 'default_required' => false, 'default_visible' => true],
        'activity_description' => ['type' => 'text', 'form' => 'both', 'label' => 'شرح فعالیت', 'default_required' => false, 'default_visible' => true],
        'postal_code' => ['type' => 'text', 'form' => 'both', 'label' => 'کد پستی', 'default_required' => true, 'default_visible' => true],
        'applicant_id_number' => ['type' => 'text', 'form' => 'both', 'label' => 'کد ملی / شناسه ملی', 'default_required' => true, 'default_visible' => true],
        'mobile_number' => ['type' => 'text', 'form' => 'both', 'label' => 'شماره همراه', 'default_required' => true, 'default_visible' => true],
        'phone_number' => ['type' => 'text', 'form' => 'both', 'label' => 'تلفن ثابت', 'default_required' => false, 'default_visible' => true],
        'website' => ['type' => 'text', 'form' => 'both', 'label' => 'آدرس سایت', 'default_required' => false, 'default_visible' => true],
        'branches' => ['type' => 'textarea', 'form' => 'both', 'label' => 'آدرس شعب', 'default_required' => false, 'default_visible' => true],
        'description' => ['type' => 'textarea', 'form' => 'both', 'label' => 'توضیحات تکمیلی', 'default_required' => false, 'default_visible' => true],

        'national_card' => ['type' => 'file', 'form' => 'both', 'label' => 'کارت ملی (رو و پشت)', 'default_required' => true, 'default_visible' => true],
        'id_card' => ['type' => 'file', 'form' => 'both', 'label' => 'شناسنامه (تمام صفحات)', 'default_required' => true, 'default_visible' => true],
        'business_license' => ['type' => 'file', 'form' => 'both', 'label' => 'جواز کسب', 'default_required' => true, 'default_visible' => true],
        'ownership_or_lease' => ['type' => 'file', 'form' => 'both', 'label' => 'سند مالکیت یا اجاره‌نامه', 'default_required' => true, 'default_visible' => true],
        'thana_certificate' => ['type' => 'file', 'form' => 'both', 'label' => 'گواهی ثبت ثنا', 'default_required' => true, 'default_visible' => true],
        'logo' => ['type' => 'file', 'form' => 'both', 'label' => 'لوگو', 'default_required' => false, 'default_visible' => true],
        'check_image' => ['type' => 'file', 'form' => 'both', 'label' => 'تصویر چک صیادی', 'default_required' => false, 'default_visible' => true],
        'signature_certificate' => ['type' => 'file', 'form' => 'both', 'label' => 'گواهی امضا', 'default_required' => false, 'default_visible' => true],
        'tax_info' => ['type' => 'file', 'form' => 'both', 'label' => 'اطلاعات سامانه مالیاتی', 'default_required' => false, 'default_visible' => true],
        'enamad' => ['type' => 'file', 'form' => 'both', 'label' => 'تصویر اینماد', 'default_required' => false, 'default_visible' => true],
    ];
}


function mlr_api_settings_page_callback() {
    ?>
    <div class="wrap mlr-admin-wrap">
        <h1>تنظیمات اتصال به API فینوتک (شاهکار)</h1>
        <p>این اطلاعات برای تأیید تطابق کد ملی و شماره موبایل کاربران در فرم ثبت درخواست تسهیلات استفاده می‌شود.</p>
        <form method="post" action="options.php">
            <?php settings_fields('mlr_api_settings_group'); ?>
            <?php do_settings_sections('mlr_api_settings_group'); ?>
             <div class="mlr-settings-card">
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_client_id">Client ID</label></th>
                        <td><input type="text" id="mlr_shahkar_client_id" name="mlr_shahkar_client_id" value="<?php echo esc_attr(get_option('mlr_shahkar_client_id')); ?>" class="regular-text ltr" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_client_secret">Client Secret</label></th>
                        <td><input type="password" id="mlr_shahkar_client_secret" name="mlr_shahkar_client_secret" value="" placeholder="<?php echo esc_attr(get_option('mlr_shahkar_client_secret')) ? '•••••••• (برای تغییر، مقدار جدید را وارد کنید)' : ''; ?>" class="regular-text ltr" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_owner_nid">Owner NID <br>(کد ملی مالک سرویس)</label></th>
                        <td><input type="text" id="mlr_shahkar_owner_nid" name="mlr_shahkar_owner_nid" value="<?php echo esc_attr(get_option('mlr_shahkar_owner_nid')); ?>" class="regular-text ltr" pattern="[0-9]{10}" title="کد ملی 10 رقمی" />
                        <p class="description">کد ملی شخصی که سرویس فینوتک به نام ایشان ثبت شده است.</p></td>
                    </tr>
                </table>
            </div>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action('admin_enqueue_scripts', 'mlr_enqueue_admin_scripts');
function mlr_enqueue_admin_scripts($hook) {
     $plugin_pages = [
        'toplevel_page_mlr-loan-requests',
        'mlr-loan-requests_page_mlr-granted-requests',
        'mlr-loan-requests_page_mlr-unsettled-requests',
        'mlr-loan-requests_page_mlr-settled-requests',
        'mlr-loan-requests_page_mlr-installment-plans',
        'mlr-loan-requests_page_mlr-api-settings',
        'عملیات-تسهیلات_page_mlr-granted-requests',
        'عملیات-تسهیلات_page_mlr-unsettled-requests',
        'عملیات-تسهیلات_page_mlr-settled-requests',
        'عملیات-تسهیلات_page_mlr-installment-plans',
        'عملیات-تسهیلات_page_mlr-api-settings',
        'toplevel_page_mlr-cooperation-main',
        'مدیریت-همکاری_page_mlr-form-editor',
        'مدیریت-همکاری_page_mlr-cooperation-contract-settings',
        'toplevel_page_mlr-sms-settings',
        'تنظیمات-پیامک_page_mlr-log-viewer',
    ];

    $is_plugin_page = in_array($hook, $plugin_pages);

    // Fallback: some environments may produce different hook suffixes for submenu pages.
    if (!$is_plugin_page && isset($_GET['page'])) {
        $page = sanitize_key(wp_unslash($_GET['page']));
        if (in_array($page, ['mlr-granted-requests', 'mlr-unsettled-requests', 'mlr-settled-requests', 'mlr-installment-plans', 'mlr-api-settings', 'mlr-loan-requests'], true)) {
            $is_plugin_page = true;
        }
    }
    if (!$is_plugin_page && isset($_GET['page']) && $_GET['page'] === 'mlr-loan-requests' && isset($_GET['status'])) {
        $is_plugin_page = true;
    }
    if (!$is_plugin_page && ($hook === 'profile.php' || $hook === 'user-edit.php')) {
         $is_plugin_page = true;
    }

    if (!$is_plugin_page) return;

    $version = '8.4.1';
    wp_enqueue_style('mlr-admin-css', MLR_PLUGIN_URL . 'assets/css/admin.css', [], $version);

    if ($hook === 'مدیریت-همکاری_page_mlr-cooperation-contract-settings' || $hook === 'عملیات-تسهیلات_page_mlr-installment-plans') {
        wp_enqueue_media();
    }

    wp_enqueue_script('mlr-jalali-datepicker', MLR_PLUGIN_URL . 'assets/js/jalali-datepicker.js', ['jquery'], $version, true);
    wp_enqueue_script('mlr-admin-js', MLR_PLUGIN_URL . 'assets/js/admin.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);

    wp_localize_script('mlr-admin-js', 'mlrAjax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('mlr_ajax_nonce_action')
    ]);

    if ($hook === 'مدیریت-همکاری_page_mlr-form-editor') {
        wp_add_inline_script('mlr-admin-js', '
            jQuery(document).ready(function($){
                function updateRequiredState(visibilityToggle) {
                    var isChecked = $(visibilityToggle).is(":checked");
                    var controlsDiv = $(visibilityToggle).closest(".mlr-field-controls");
                    var requiredSwitch = controlsDiv.find(".mlr-required-switch");
                    var requiredLabel = controlsDiv.find(".mlr-required-label");
                    var requiredInput = requiredSwitch.find("input[type=checkbox]");

                    if (isChecked) {
                        requiredSwitch.removeClass("mlr-disabled");
                        requiredLabel.removeClass("mlr-disabled");
                        requiredInput.prop("disabled", false);
                    } else {
                        requiredSwitch.addClass("mlr-disabled");
                        requiredLabel.addClass("mlr-disabled");
                        requiredInput.prop("disabled", true).prop("checked", false);
                    }
                }
                $(".mlr-visibility-toggle").on("change", function(){ updateRequiredState(this); });
                $(".mlr-visibility-toggle").each(function(){ updateRequiredState(this); });
            });
        ');
    }
}

add_action('wp_enqueue_scripts', 'mlr_enqueue_frontend_scripts');
function mlr_enqueue_frontend_scripts() {
    global $post;
    $version = '8.4.1';

    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], $version);
    wp_enqueue_script('mlr-jalali-datepicker', MLR_PLUGIN_URL . 'assets/js/jalali-datepicker.js', ['jquery'], $version, true);

    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_cooperation_contract_viewer')) {
        wp_enqueue_style('mlr-contract-viewer-css', MLR_PLUGIN_URL . 'assets/css/contract-viewer.css', [], $version);
        wp_enqueue_script('mlr-contract-viewer-js', MLR_PLUGIN_URL . 'assets/js/contract-viewer.js', ['jquery'], $version, true);
        wp_localize_script('mlr-contract-viewer-js', 'mlr_contract_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'send_otp_nonce' => wp_create_nonce('mlr_send_cooperation_otp_nonce'),
            'verify_otp_nonce' => wp_create_nonce('mlr_verify_cooperation_otp_nonce'),
            'resend_cooldown' => 60
        ]);
    }

    if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'mlr_individual_request_form') || has_shortcode($post->post_content, 'mlr_legal_request_form'))) {
         wp_enqueue_script('mlr-cooperation-form-js', MLR_PLUGIN_URL . 'assets/js/cooperation-form.js', ['jquery'], '1.0.3', true);
         wp_localize_script('mlr-cooperation-form-js', 'mlr_coop_ajax', [
             'ajax_url' => admin_url('admin-ajax.php'),
             'nonce'    => wp_create_nonce('mlr_cooperation_request_action'),
         ]);
    }

     if (is_a($post, 'WP_Post') && (
         has_shortcode($post->post_content, 'mlr_user_loan_requests') ||
         has_shortcode($post->post_content, 'mlr_needs_review_requests') ||
         has_shortcode($post->post_content, 'mlr_processing_requests') ||
         has_shortcode($post->post_content, 'mlr_granted_user_requests') ||
         has_shortcode($post->post_content, 'mlr_user_settlement_cycles') ||
         has_shortcode($post->post_content, 'mlr_bank_expert_dashboard') ||
         has_shortcode($post->post_content, 'mlr_verified_docs_dashboard')
         )) {
        wp_enqueue_script('mlr-user-requests-js', MLR_PLUGIN_URL . 'assets/js/mlr-user-requests.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
        wp_localize_script('mlr-user-requests-js', 'mlr_ajax_obj', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'filter_nonce'    => wp_create_nonce('mlr_user_requests_nonce'),
            'details_nonce'   => wp_create_nonce('mlr_frontend_nonce'),
            'cycle_nonce'     => wp_create_nonce('mlr_user_cycle_nonce'),
            'allowed_statuses' => []
        ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_bank_expert_dashboard')) {
          wp_enqueue_style('mlr-bank-expert-dashboard-css', MLR_PLUGIN_URL . 'assets/css/bank-expert-dashboard.css', [], $version);
          wp_enqueue_script('mlr-bank-expert-dashboard-js', MLR_PLUGIN_URL . 'assets/js/bank-expert-dashboard.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
          wp_localize_script('mlr-bank-expert-dashboard-js', 'mlr_bank_ajax_obj', [
              'ajax_url' => admin_url('admin-ajax.php'),
              'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
          ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_verified_docs_dashboard')) {
          wp_enqueue_script('mlr-verified-docs-dashboard-js', MLR_PLUGIN_URL . 'assets/js/verified-docs-dashboard.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
          wp_localize_script('mlr-verified-docs-dashboard-js', 'mlr_verified_ajax_obj', [
              'ajax_url' => admin_url('admin-ajax.php'),
              'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
          ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_loan_request_form')) {
         wp_enqueue_style('mlr-loan-form-style', MLR_PLUGIN_URL . 'assets/css/loan-request-form.css', [], $version);
         wp_enqueue_script('mlr-front-form-js', MLR_PLUGIN_URL . 'assets/js/loan-request-form.js', ['jquery'], $version, true);

         $user_commission = null;
         if (is_user_logged_in()) {
             $user_commission = get_user_meta(get_current_user_id(), 'acceptor_commission_percent', true);
         }

         wp_localize_script('mlr-front-form-js', 'mlr_form_ajax', [
             'ajax_url' => admin_url('admin-ajax.php'),
             'nonce' => wp_create_nonce('mlr_frontend_nonce'),
             'calc_nonce' => wp_create_nonce('mlr_frontend_calc_nonce'),
             'submit_nonce' => wp_create_nonce('mlr_loan_request_action'),
             'plans' => mlr_get_js_plans(),
             'user_commission' => $user_commission
         ]);
     }

     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_loan_calculator')) {
        wp_enqueue_script('mlr-calculator-js', MLR_PLUGIN_URL . 'assets/js/loan-calculator.js', ['jquery'], $version, true);
        $user_commission = null;
         if (is_user_logged_in()) {
             $user_commission = get_user_meta(get_current_user_id(), 'acceptor_commission_percent', true);
         }
        wp_localize_script('mlr-calculator-js', 'mlrCalculatorAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('mlr_frontend_calc_nonce'),
            'plans'   => mlr_get_js_plans(),
            'user_commission' => $user_commission
        ]);
     }
}

function mlr_get_js_plans() {
    global $wpdb;
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $plans = $wpdb->get_results("SELECT id, name, type, settings FROM `$table_installment_plans` WHERE is_active = 1 ORDER BY id DESC");

    if (!is_array($plans)) {
        return [];
    }

    return array_map(function($plan) {
        $settings = maybe_unserialize($plan->settings);
        if (!is_array($settings)) {
            $settings = [];
        }
        $plan->view_settings = [
            'requires_bank_validation' => $settings['requires_bank_validation'] ?? 0,
            'min_amount' => $settings['min_amount'] ?? 0,
            'max_amount' => $settings['max_amount'] ?? 0,
            'active_installments' => $settings['active_installments'] ?? '',
            'min_interval' => $settings['min_interval'] ?? 1,
            'max_interval' => $settings['max_interval'] ?? 12,
            'prepayment_percent' => $settings['prepayment_percent'] ?? null,
        ];
        unset($plan->settings);
        return $plan;
    }, $plans);
}

add_action('wp_ajax_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');
add_action('wp_ajax_nopriv_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');
function mlr_verify_shahkar_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    $user_national_code = isset($_POST['national_code']) ? sanitize_text_field($_POST['national_code']) : '';
    $user_mobile = isset($_POST['mobile_number']) ? sanitize_text_field($_POST['mobile_number']) : '';

    if (!preg_match('/^\d{10}$/', $user_national_code) || !preg_match('/^09\d{9}$/', $user_mobile)) {
        wp_send_json_error(['message' => 'کد ملی یا شماره موبایل وارد شده نامعتبر است.']);
        return;
    }

    $client_id = get_option('mlr_shahkar_client_id');
    $client_secret = get_option('mlr_shahkar_client_secret');
    $owner_nid = get_option('mlr_shahkar_owner_nid');

    if (empty($client_id) || empty($client_secret) || empty($owner_nid)) {
        mlr_log("Shahkar API Error: Settings not configured.");
        wp_send_json_error(['message' => 'سرویس احراز هویت در دسترس نیست.']);
        return;
    }

    $token_url = 'https://api.finnotech.ir/dev/v2/oauth2/token';
    $auth_string = base64_encode("{$client_id}:{$client_secret}");
    $scope_for_token = 'card:shahkar:get';

    $token_args = [
        'method' => 'POST',
        'timeout' => 20,
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Basic ' . $auth_string,
        ],
        'body' => json_encode([
            'grant_type' => 'client_credentials',
            'nid' => $owner_nid,
            'scopes' => $scope_for_token,
        ]),
    ];

    $token_response = wp_remote_post($token_url, $token_args);

    if (is_wp_error($token_response)) {
        mlr_log("Shahkar API Token Error: " . $token_response->get_error_message());
        wp_send_json_error(['message' => 'خطا در ارتباط با سرویس احراز هویت (مرحله ۱).']);
        return;
    }

    $token_body_raw = wp_remote_retrieve_body($token_response);
    $token_body = json_decode($token_body_raw, true);
    $access_token = isset($token_body['result']['value']) ? $token_body['result']['value'] : null;
    $response_code = wp_remote_retrieve_response_code($token_response);

    if ($response_code !== 200 || !$access_token) {
        // Robust Error Handling for non-JSON or HTML error pages
        $err_msg = 'خطای سرویس توکن';
        if(is_array($token_body) && isset($token_body['error'])) {
            $err_msg = $token_body['error']['message'] ?? $err_msg;
        } else {
             $err_msg = "Status: $response_code. Body: " . substr($token_body_raw, 0, 100);
        }
        mlr_log("Shahkar Token Failed: " . $err_msg);
        wp_send_json_error(['message' => 'دریافت مجوز احراز هویت ناموفق بود.']);
        return;
    }

    $verify_base_url = "https://api.finnotech.ir/mpg/v2/clients/{$client_id}/shahkar/verify";
    $track_id = 'MLR' . time() . rand(100, 999);

    $verify_url_with_params = add_query_arg([
        'trackId' => $track_id,
        'mobile' => $user_mobile,
        'nationalCode' => $user_national_code,
    ], $verify_base_url);


    $verify_args = [
        'method' => 'GET',
        'timeout' => 25,
        'headers' => [
            'Authorization' => 'Bearer ' . $access_token,
        ],
    ];

    $verify_response = wp_remote_get($verify_url_with_params, $verify_args);

    if (is_wp_error($verify_response)) {
        mlr_log("Shahkar API Verify Error: " . $verify_response->get_error_message());
        wp_send_json_error(['message' => 'خطا در ارتباط با سرویس احراز هویت (مرحله ۲).']);
        return;
    }

    $verify_body_raw = wp_remote_retrieve_body($verify_response);
    $verify_body = json_decode($verify_body_raw, true);
    $verify_response_code = wp_remote_retrieve_response_code($verify_response);

    // Robust Handling for Verify Response
    if ($verify_response_code === 200 && isset($verify_body['result']['isValid']) && $verify_body['result']['isValid'] === true && isset($verify_body['status']) && $verify_body['status'] === 'DONE') {
        wp_send_json_success(['message' => 'تطابق شماره موبایل و کد ملی تأیید شد.']);
    } else {
        $error_detail = 'عدم تطابق یا خطای نامشخص.';
        if (isset($verify_body['result']['isValid']) && $verify_body['result']['isValid'] === false) {
             $error_detail = 'شماره موبایل وارد شده متعلق به این کد ملی نمی‌باشد.';
        } elseif (is_array($verify_body) && isset($verify_body['error']['message'])) {
             $error_detail = $verify_body['error']['message'];
        } elseif ($verify_response_code !== 200) {
            $error_detail = "خطای سرویس (کد: {$verify_response_code}).";
        }
        
        mlr_log("Shahkar Verify Failed: " . $error_detail);
        wp_send_json_error(['message' => $error_detail]);
    }
}
?>