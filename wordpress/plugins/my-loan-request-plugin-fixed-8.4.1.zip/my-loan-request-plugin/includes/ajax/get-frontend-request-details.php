<?php
// FILE: my-loan-request-plugin/includes/ajax/get-frontend-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');

function mlr_get_frontend_request_details_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً ابتدا وارد سایت شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $is_admin = current_user_can('manage_options');
    $is_bank_expert = in_array('bank', (array) $current_user->roles);

    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';

    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }

    // بررسی سطح دسترسی
    if (!$is_admin) {
        if ($is_bank_expert) {
            if ($request->assigned_bank_user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این پرونده ندارید.']);
                return;
            }
        } else {
            if ($request->user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این درخواست ندارید.']);
                return;
            }
        }
    }

    $uploaded_documents = maybe_unserialize($request->required_documents);
    if (!is_array($uploaded_documents)) {
        $uploaded_documents = [];
    }
    
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];

    // فایل‌های تکمیلی
    $extra_files = [];
    $extra_files['bank_validation_file'] = $request->bank_validation_file ?? '';
    $extra_files['signature_image'] = $request->signature_image ?? '';
    $extra_files['contract_file'] = $request->contract_file ?? '';

    $parsed_check_images = [];
    if (!empty($request->check_images)) {
        $maybe = maybe_unserialize($request->check_images);
        if (is_array($maybe)) {
            $parsed_check_images = $maybe;
        } else {
            $json = json_decode($request->check_images, true);
            if (is_array($json)) {
                $parsed_check_images = $json;
            } else {
                $parts = preg_split('/[\r\n,]+/', (string)$request->check_images);
                $parts = array_filter(array_map('trim', $parts));
                $parsed_check_images = $parts ? $parts : [(string)$request->check_images];
            }
        }
    }
    if (!empty($parsed_check_images)) {
        $extra_files['check_images'] = $parsed_check_images;
    }

    $extra_file_labels = [
        'bank_validation_file' => 'فایل اعتبارسنجی بانک',
        'signature_image'      => 'تصویر امضا',
        'contract_file'        => 'فایل قرارداد',
        'check_images'         => 'تصاویر چک',
    ];
    
    $occupations = [
        'official_employee' => 'کارمند رسمی', 
        'contract_employee' => 'کارمند قراردادی', 
        'worker' => 'کارگر', 
        'freelancer' => 'آزاد', 
        'retired' => 'بازنشسته', 
        'pensioner' => 'مستمری بگیر', 
        'employer' => 'کارفرما', 
        'other' => 'سایر'
    ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : $request->occupation;
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    // تولید شناسه‌های کاملاً یکتا برای جلوگیری از تداخل DOM
    $uniq = uniqid('req_');
    $form_id = 'mlr_upload_form_' . $uniq;
    $input_file_id = 'mlr_file_' . $uniq;
    $input_note_id = 'mlr_note_' . $uniq;
    $input_req_id = 'mlr_req_' . $uniq;

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست #<?php echo esc_html($request->id); ?></h3>
        <span class="mlr-status-badge status-<?php echo sanitize_html_class($request->status); ?>"><?php echo esc_html($request->status); ?></span>
    </div>
    
    <div class="mlr-modal-body">
        
        <?php if ($request->status === 'نقص مدارک' && !$is_bank_expert && !$is_admin): ?>
            <div class="mlr-reupload-section" style="margin-bottom: 25px; padding: 20px; border: 2px dashed #f39c12; background: #fffdf6; border-radius: 8px;">
                <h4 style="color: #d35400; margin-top: 0; margin-bottom: 10px; display: flex; align-items: center;">
                    <span class="dashicons dashicons-warning" style="margin-left: 5px;"></span> رفع نقص مدارک
                </h4>
                <p style="margin-bottom: 15px; font-size: 0.95em; line-height: 1.6; color: #444;">
                    پرونده شما به دلیل نقص در مدارک بازگردانده شده است. لطفاً بخش "سوابق و پیام‌ها" را مطالعه کنید تا از علت نقص مطلع شوید، سپس مدارک صحیح را بارگذاری کنید.
                    <br><strong>پس از ارسال، وضعیت پرونده به "در حال بررسی" تغییر خواهد کرد.</strong>
                </p>
                
                <form id="<?php echo esc_attr($form_id); ?>" class="mlr-universal-upload-form" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" id="<?php echo esc_attr($input_req_id); ?>" value="<?php echo esc_attr($request->id); ?>">
                    
                    <div class="mlr-form-group">
                        <label for="<?php echo esc_attr($input_file_id); ?>" style="font-weight: bold; display: block; margin-bottom: 8px; color: #333;">انتخاب مدارک جدید (تصویر یا PDF):</label>
                        <input type="file" id="<?php echo esc_attr($input_file_id); ?>" name="additional_files[]" multiple accept=".jpg,.jpeg,.png,.pdf" required style="width: 100%; padding: 10px; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
                        <p class="description" style="font-size: 0.85em; color: #666; margin-top: 5px;">می‌توانید چند فایل را همزمان انتخاب کنید.</p>
                    </div>

                    <div class="mlr-form-group" style="margin-top: 15px;">
                        <label for="<?php echo esc_attr($input_note_id); ?>" style="font-weight: bold; display: block; margin-bottom: 8px; color: #333;">توضیحات شما (اختیاری):</label>
                        <textarea id="<?php echo esc_attr($input_note_id); ?>" name="user_note" rows="3" style="width: 100%; border: 1px solid #ddd; border-radius: 4px; padding: 8px; min-height: 80px;" placeholder="توضیحات رفع نقص..."></textarea>
                    </div>

                    <button type="submit" class="button button-primary mlr-submit-docs-btn" style="margin-top: 15px; width: 100%; height: 40px; display:flex; justify-content:center; align-items:center; font-size: 14px;">ارسال مدارک و بررسی مجدد</button>
                    <div class="mlr-upload-status" style="display:none; margin-top: 15px; padding: 10px; border-radius: 4px; text-align: center;"></div>
                </form>
            </div>
        <?php endif; ?>


        <?php if (in_array($request->status, ['تکمیل مدارک', 'در انتظار مدارک', 'در انتظار تکمیل', 'در انتظار تکمیل مدارک'], true) && !$is_bank_expert && !$is_admin): ?>
            <?php
                // Load installment plan contract settings
                $plan_settings = [];
                if (!empty($request->installment_plan_id)) {
                    $plan_row = $wpdb->get_row($wpdb->prepare("SELECT settings FROM {$plans_table} WHERE id = %d", $request->installment_plan_id));
                    if ($plan_row && !empty($plan_row->settings)) {
                        $plan_settings = maybe_unserialize($plan_row->settings);
                        if (!is_array($plan_settings)) {
                            $decoded = json_decode($plan_row->settings, true);
                            if (is_array($decoded)) {
                                $plan_settings = $decoded;
                            } else {
                                $plan_settings = [];
                            }
                        }
                    }
                }

                $contract_letterhead_url = isset($plan_settings['plan_letterhead_url']) ? $plan_settings['plan_letterhead_url'] : '';
                $contract_footer_url     = isset($plan_settings['plan_footer_url']) ? $plan_settings['plan_footer_url'] : '';
                $contract_text_raw       = isset($plan_settings['plan_contract_text']) ? $plan_settings['plan_contract_text'] : '';

                $placeholder_map = [
                    '[request_id]'          => $request->id ?? '',
                    '[full_name]'           => $request->full_name ?? '',
                    '[national_code]'       => $request->national_code ?? '',
                    '[mobile_number]'       => $request->mobile_number ?? '',
                    '[loan_amount]'         => isset($request->loan_amount) ? number_format(floatval($request->loan_amount)) : '0',
                    '[installment_count]'   => isset($request->installment_count) ? intval($request->installment_count) : '',
                    '[installment_amount]'  => isset($request->installment_amount) ? number_format(floatval($request->installment_amount)) : '0',
                    '[total_payment]'       => isset($request->total_payment) ? number_format(floatval($request->total_payment)) : '0',
                    '[plan_name]'           => $request->plan_name ?? '',
                    '[created_at]'          => !empty($request->created_at) ? mlr_gregorian_to_jalali($request->created_at, 'Y/m/d') : '',
                ];

                $contract_text_rendered = $contract_text_raw;
                if (!empty($contract_text_rendered)) {
                    $contract_text_rendered = strtr($contract_text_rendered, $placeholder_map);
                    $contract_text_rendered = wpautop($contract_text_rendered);
                }

                $contract_acc_id = 'mlr_contract_acc_' . $uniq;
                $invoice_acc_id  = 'mlr_invoice_acc_' . $uniq;
                $contract_print_id = 'mlr_contract_print_' . $uniq;
                $invoice_print_id  = 'mlr_invoice_print_' . $uniq;
            ?>
            <style>
                .mlr-accordion{border:1px solid #e5e5e5;border-radius:8px;overflow:hidden;background:#fff;margin:0 0 15px 0}
                .mlr-acc-btn{width:100%;text-align:right;background:#f7f7f7;border:0;padding:12px 14px;cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-weight:700}
                .mlr-acc-btn:focus{outline:none}
                .mlr-acc-content{display:none;padding:14px}
                .mlr-acc-content.is-open{display:block}
                .mlr-print-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:10px 0 0 0}
                .mlr-print-area{background:#fff}
                @media print{
                    body{background:#fff!important}
                    .mlr-no-print{display:none!important}
                    .mlr-print-area{box-shadow:none!important;border:0!important}
                }
            </style>

            <div class="mlr-reupload-section" style="margin-bottom: 25px; padding: 20px; border: 2px dashed #3498db; background: #f7fbff; border-radius: 8px;">
                <h4 style="color: #1f6fb2; margin-top: 0; margin-bottom: 10px; display: flex; align-items: center;">
                    <span class="dashicons dashicons-yes-alt" style="margin-left: 5px;"></span> تکمیل مدارک
                </h4>
                <p style="margin-bottom: 15px; font-size: 0.95em; line-height: 1.8; color: #444;">
                    لطفاً قرارداد و فاکتور را مشاهده و در صورت نیاز چاپ کنید، سپس مدارک تکمیلی را بارگذاری نمایید.
                </p>

                <div class="mlr-accordion">
                    <button type="button" class="mlr-acc-btn mlr-no-print" data-target="<?php echo esc_attr($contract_acc_id); ?>">
                        <span>مشاهده و پرینت قرارداد</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div id="<?php echo esc_attr($contract_acc_id); ?>" class="mlr-acc-content">
                        <div id="<?php echo esc_attr($contract_print_id); ?>" class="mlr-print-area">
                            <?php if (!empty($contract_letterhead_url)): ?>
                                <div style="text-align:center; margin-bottom: 10px;">
                                    <img src="<?php echo esc_url($contract_letterhead_url); ?>" alt="سربرگ قرارداد" style="max-width:100%; height:auto;">
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($contract_text_rendered)): ?>
                                <div class="mlr-contract-body" style="font-size: 12.5px; line-height: 2; color:#111;">
                                    <?php echo wp_kses_post($contract_text_rendered); ?>
                                </div>
                            <?php else: ?>
                                <p>برای این طرح، متن قرارداد تنظیم نشده است.</p>
                            <?php endif; ?>

                            <?php if (!empty($contract_footer_url)): ?>
                                <div style="text-align:center; margin-top: 10px;">
                                    <img src="<?php echo esc_url($contract_footer_url); ?>" alt="پابرگ قرارداد" style="max-width:100%; height:auto;">
                                </div>
                            <?php endif; ?>

                            <?php
                                $plan_files = [];
                                if (isset($plan_settings['plan_downloadable_files']) && is_array($plan_settings['plan_downloadable_files'])) {
                                    $plan_files = array_values(array_filter($plan_settings['plan_downloadable_files']));
                                }
                            ?>
                            <?php if (!empty($plan_files)): ?>
                                <div class="mlr-no-print" style="margin-top: 12px;">
                                    <div style="font-weight:600; margin-bottom:8px;">فایل‌های پیوست قابل دانلود</div>
                                    <div style="display:flex; flex-wrap:wrap; gap:8px;">
                                        <?php foreach ($plan_files as $file_url): ?>
                                            <a class="button button-secondary" href="<?php echo esc_url($file_url); ?>" target="_blank" rel="noopener noreferrer">دانلود فایل</a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>

                        <div class="mlr-print-actions mlr-no-print">
                            <button type="button" class="button button-secondary" data-print="<?php echo esc_attr($contract_print_id); ?>">چاپ قرارداد</button>
                        </div>
                    </div>
                </div>

                <div class="mlr-accordion">
                    <button type="button" class="mlr-acc-btn mlr-no-print" data-target="<?php echo esc_attr($invoice_acc_id); ?>">
                        <span>مشاهده و پرینت فاکتور</span>
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div id="<?php echo esc_attr($invoice_acc_id); ?>" class="mlr-acc-content">
                        <div id="<?php echo esc_attr($invoice_print_id); ?>" class="mlr-print-area">
                            <?php echo do_shortcode('[mlr_invoice id="' . intval($request->id) . '"]'); ?>
                        </div>
                        <div class="mlr-print-actions mlr-no-print">
                            <button type="button" class="button button-secondary" data-print="<?php echo esc_attr($invoice_print_id); ?>">چاپ فاکتور</button>
                        </div>
                    </div>
                </div>

                <?php
                    $completed_docs_form_id = 'mlr_completed_docs_form_' . $uniq;
                ?>
                <form id="mlr-complete-docs-form" class="mlr-completed-docs-form" enctype="multipart/form-data" style="margin-top: 15px;">
                    <input type="hidden" name="action" value="mlr_submit_completed_docs">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
<div style="display:grid; grid-template-columns: 1fr; gap: 10px;">
                        <label style="display:block;">
                            <strong>تصاویر چک (ضروری)</strong>
                            <input type="file" name="completed_check_files[]" multiple accept=".jpg,.jpeg,.png,.pdf" style="width:100%;" required>
                        </label>

                        <label style="display:block;">
                            <strong>قرارداد امضا‌شده</strong>
                            <input type="file" name="signed_contract" accept=".jpg,.jpeg,.png,.pdf" style="width:100%;" required>
                        </label>
                        <label style="display:block;">
                            <strong>فاکتور امضا/مهر‌شده</strong>
                            <input type="file" name="signed_invoice" accept=".jpg,.jpeg,.png,.pdf" style="width:100%;" required>
                        </label>
                        <label style="display:block;">
                            <strong>سایر مدارک (اختیاری)</strong>
                            <input type="file" name="other_completed_files[]" multiple accept=".jpg,.jpeg,.png,.pdf" style="width:100%;">
                        </label>
                    </div>

                    <div style="margin-top: 15px; display:flex; gap:10px; align-items:center;">
                        <button type="submit" class="button button-primary">ارسال مدارک</button>
                        <span class="mlr-doc-upload-msg" style="font-size:0.9em; color:#555;"></span>
                    </div>
                </form>

                <script>
                    (function(){
                        function qsa(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
                        qsa('.mlr-acc-btn', document).forEach(function(btn){
                            btn.addEventListener('click', function(){
                                var id = btn.getAttribute('data-target');
                                var el = document.getElementById(id);
                                if(!el) return;
                                if(el.classList.contains('is-open')){ el.classList.remove('is-open'); }
                                else{ el.classList.add('is-open'); }
                            });
                        });
                        qsa('[data-print]', document).forEach(function(btn){
                            btn.addEventListener('click', function(){
                                var targetId = btn.getAttribute('data-print');
                                var target = document.getElementById(targetId);
                                if(!target) return;

                                var w = window.open('', '_blank');
                                if(!w) return;

                                var css = '<style>@media print{body{direction:rtl;font-family:tahoma,arial,sans-serif} .mlr-no-print{display:none!important}}</style>';
                                w.document.open();
                                w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Print</title>' + css + '</head><body dir="rtl">' + target.innerHTML + '</body></html>');
                                w.document.close();
                                w.focus();
                                w.print();
                                w.close();
                            });
                        });
                    })();
                </script>
            </div>
        <?php endif; ?>
        <div class="mlr-info-box">
            <h4>مشخصات فردی</h4>
            <div class="mlr-info-grid">
                <div><span>نام:</span> <strong><?php echo esc_html($request->full_name); ?></strong></div>
                <div><span>کد ملی:</span> <?php echo esc_html($request->national_code); ?></div>
                <div><span>موبایل:</span> <?php echo esc_html($request->mobile_number); ?></div>
                <div><span>شغل:</span> <?php echo esc_html($occupation_display); ?></div>
                <div style="grid-column: 1 / -1;"><span>آدرس:</span> <?php echo esc_html($request->residential_address); ?></div>
            </div>
        </div>

        <div class="mlr-info-box">
            <h4>اطلاعات تسهیلات</h4>
            <div class="mlr-info-grid">
                <div><span>طرح:</span> <?php echo esc_html($request->plan_name); ?></div>
                <div><span>مبلغ وام:</span> <?php echo number_format($request->loan_amount); ?> ریال</div>
                <div><span>اقساط:</span> <?php echo esc_html($request->installment_count); ?> ماهه</div>
                <div><span>مبلغ قسط:</span> <?php echo number_format($request->installment_amount); ?> ریال</div>
            </div>
        </div>

        <div class="mlr-info-box">
            <h4>اطلاعات تکمیلی</h4>
            <div class="mlr-info-grid">
                <?php if (!empty($request->product_name)): ?>
                    <div><span>نام کالا:</span> <strong><?php echo esc_html($request->product_name); ?></strong></div>
                <?php endif; ?>
                <?php if (!empty($request->created_at)): ?>
                    <div><span>تاریخ ثبت نام:</span> <strong><?php echo esc_html(function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($request->created_at) : $request->created_at); ?></strong></div>
                <?php endif; ?>
            </div>
            <?php if (!empty($request->description)): ?>
                <div style="margin-top:12px;">
                    <div style="font-weight:800; color: var(--mlr-text-dark); margin-bottom: 5px;">توضیحات متقاضی:</div>
                    <div class="mlr-long-text" style="background: #f9f9f9; padding: 10px; border-radius: 4px; border: 1px solid #eee;"><?php echo nl2br(esc_html($request->description)); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!empty($extra_files) && is_array($extra_files)): ?>
        <div class="mlr-info-box">
            <h4>فایل‌های سیستمی و قرارداد</h4>
            <div class="mlr-file-grid">
                <?php foreach ($extra_files as $fkey => $fval): 
                    if (empty($fval)) continue;
                    $label = isset($extra_file_labels[$fkey]) ? $extra_file_labels[$fkey] : ucfirst(str_replace('_',' ', $fkey));
                ?>
                    <div class="mlr-file-item">
                        <div class="mlr-file-label"><?php echo esc_html($label); ?></div>
                        <div class="mlr-file-actions">
                            <?php if (is_array($fval)): ?>
                                <?php foreach ($fval as $idx => $url): if (empty($url)) continue; ?>
                                    <a class="mlr-view-file-btn" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">مشاهده <?php echo intval($idx)+1; ?></a>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <a class="mlr-view-file-btn" href="<?php echo esc_url($fval); ?>" target="_blank" rel="noopener noreferrer">مشاهده فایل</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($uploaded_documents)): ?>
        <div class="mlr-info-box">
            <h4>مدارک بارگذاری شده</h4>
            <div class="mlr-docs-list">
                <?php foreach($uploaded_documents as $key => $val): 
                     $label = $all_doc_labels[$key] ?? $key;
                ?>
                    <div class="mlr-doc-item">
                        <strong><?php echo esc_html($label); ?>:</strong>
                        <?php if(is_array($val)): ?>
                            <?php foreach($val as $i => $url): ?>
                                <a href="<?php echo esc_url($url); ?>" target="_blank" class="mlr-btn-small">فایل <?php echo $i+1; ?></a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <a href="<?php echo esc_url($val); ?>" target="_blank" class="mlr-btn-small">مشاهده</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($comments)): ?>
        <div class="mlr-info-box">
            <h4>سوابق و پیام‌ها (یادداشت‌های کارشناس)</h4>
            <div class="mlr-comments-list">
                <?php foreach($comments as $cm): ?>
                    <div class="mlr-comment" style="background: #f1f1f1; padding: 10px; margin-bottom: 10px; border-radius: 5px;">
                        <div style="font-size: 0.85em; color: #777; margin-bottom: 5px;">
                            <span style="font-weight: bold; color: #333;"><?php echo esc_html($cm['display_name']); ?></span> - 
                            <?php echo (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($cm['timestamp'], 'Y/m/d H:i') : $cm['timestamp']); ?>
                        </div>
                        <p style="margin: 0; line-height: 1.5;"><?php echo nl2br(esc_html($cm['text'])); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($is_bank_expert && $request->assigned_bank_user_id == $user_id): ?>
             <div class="mlr-action-box" style="background: #e8f0fe; padding: 20px; border-radius: 8px; margin-top: 25px; border: 1px solid #b3d7ff;">
                 <h4 style="margin-top:0; color:#0056b3;">بررسی و تغییر وضعیت پرونده</h4>
                 <?php 
                 $action_form_id = 'mlr_expert_action_' . $uniq;
                 $status_id = 'status_' . $uniq;
                 $expert_comment_id = 'expert_comment_' . $uniq;
                 ?>
                 <form id="<?php echo esc_attr($action_form_id); ?>" class="mlr-bank-expert-action-form">
                     <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                     <div class="mlr-form-group">
                         <label for="<?php echo esc_attr($status_id); ?>" style="font-weight:bold;">تغییر وضعیت به:</label>
                         <select name="new_status" id="<?php echo esc_attr($status_id); ?>" class="mlr-select" style="width:100%; margin-bottom:15px; padding: 8px;">
                            <?php 
                            $opts = ($request->status == 'تأیید کارشناس') 
                                ? ['تکمیل مدارک'=>'ارسال برای تکمیل مدارک','نقص مدارک'=>'اعلام نقص مدارک','رد شده'=>'رد درخواست'] 
                                : ['اعطا شده'=>'تأیید نهایی و اعطا شده','رد شده'=>'رد درخواست','تکمیل مدارک'=>'بازگشت به تکمیل مدارک'];
                            foreach($opts as $v => $l): echo "<option value='$v'>$l</option>"; endforeach; 
                            ?>
                         </select>
                     </div>
                     <div class="mlr-form-group">
                         <label for="<?php echo esc_attr($expert_comment_id); ?>" style="font-weight:bold;">توضیحات (اختیاری):</label>
                         <textarea name="comment_text" id="<?php echo esc_attr($expert_comment_id); ?>" rows="3" class="mlr-textarea" style="width:100%; padding: 8px;" placeholder="توضیحاتی برای کاربر یا سیستم..."></textarea>
                     </div>
                     <div class="mlr-action-message" style="display:none; margin-bottom:10px;"></div>
                     <button type="submit" class="mlr-btn mlr-btn-primary" style="width:100%; height: 40px;">ثبت بررسی</button>
                 </form>
             </div>
        <?php endif; ?>

    </div>
    <?php
    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}
?>