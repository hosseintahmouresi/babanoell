<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');

function mlr_get_frontend_request_details_callback() {
    if (!check_ajax_referer('mlr_frontend_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => 'خطای امنیتی. لطفاً صفحه را رفرش کنید.']);
        return;
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای مشاهده جزئیات، لطفاً ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $current_user = wp_get_current_user();
    
    $is_bank_expert = in_array('bank', (array) $current_user->roles);

    $query = $wpdb->prepare("
        SELECT r.*, p.name as plan_name, p.settings as plan_settings
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d", $request_id);

    if (!$is_bank_expert) {
        $query .= $wpdb->prepare(" AND r.user_id = %d", $current_user->ID);
    } else {
        $query .= $wpdb->prepare(" AND (r.user_id = %d OR r.assigned_bank_user_id = %d)", $current_user->ID, $current_user->ID);
    }

    $request = $wpdb->get_row($query);

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد یا شما به آن دسترسی ندارید.']);
        return;
    }

    $occupations = [ 'official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر' ];
    $occupation_display = $occupations[$request->occupation] ?? esc_html($request->occupation);
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $order_items = !empty($request->order_items) ? json_decode($request->order_items, true) : [];
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    $plan_settings = maybe_unserialize($request->plan_settings);
    
    $acceptor_user_data = get_userdata($request->user_id);
    $seller_shop_name = get_user_meta($request->user_id, 'shoppp', true);
    if (empty($seller_shop_name)) {
        $seller_shop_name = $acceptor_user_data ? $acceptor_user_data->display_name : '-';
    }

    $seller_address = get_user_meta($request->user_id, 'addresss', true) ?: '-';
    $seller_postal_code = get_user_meta($request->user_id, 'postiii', true) ?: '-';
    $seller_economic_number = get_user_meta($request->user_id, 'eghtesadiii', true) ?: '-';
    $seller_national_id = get_user_meta($request->user_id, 'meliii', true) ?: '-';
    $seller_registration_number = get_user_meta($request->user_id, 'sabttt', true) ?: '-';

    ob_start();
    ?>
    <h3 class="mlr-modal-title">
        جزئیات کامل درخواست (شناسه: <?php echo esc_html($request->id); ?>)
        <button class="mlr-print-btn" onclick="window.print();" title="چاپ"><span class="dashicons dashicons-printer"></span></button>
    </h3>
    <div class="mlr-modal-content-inner">
        
        <?php if (!empty($comments) && is_array($comments)): ?>
            <div class="mlr-frontend-chat-container">
                <h4 class="mlr-modal-subtitle">گفتگو با کارشناسان</h4>
                <?php foreach($comments as $comment): ?>
                    <div class="mlr-chat-bubble">
                        <div class="mlr-chat-header">
                            <span class="mlr-chat-author"><?php echo esc_html($comment['display_name'] ?? 'پشتیبانی'); ?></span>
                            <span class="mlr-chat-timestamp"><?php echo mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i'); ?></span>
                        </div>
                        <div class="mlr-chat-body"><p><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></p></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($request->status === 'تکمیل مدارک' && (int)$request->user_id === $current_user->ID): ?>
            <div class="mlr-complete-docs-section">
                <div class="mlr-stepper">
                    <div class="mlr-step active" data-step="1"><div class="mlr-step-icon">1</div><div class="mlr-step-label">آپلود چک</div></div>
                    <div class="mlr-step-connector"></div>
                    <div class="mlr-step" data-step="2"><div class="mlr-step-icon">2</div><div class="mlr-step-label">قرارداد</div></div>
                    <div class="mlr-step-connector"></div>
                    <div class="mlr-step" data-step="3"><div class="mlr-step-icon">3</div><div class="mlr-step-label">فاکتور</div></div>
                    <div class="mlr-step-connector"></div>
                    <div class="mlr-step" data-step="4"><div class="mlr-step-icon">4</div><div class="mlr-step-label">تکمیل نهایی</div></div>
                </div>

                <form id="mlr-complete-docs-form" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request_id); ?>">

                    <div class="mlr-stepper-content">
                        <div class="mlr-step-pane active" data-step-pane="1">
                            <h4 class="mlr-modal-subtitle">مرحله ۱: آپلود تصویر چک</h4>
                            <div class="mlr-form-group">
                                <label for="completed_check_upload">تصویر چک تکمیل شده‌ی صیادی</label>
                                <input type="file" id="completed_check_upload" name="completed_check_files[]" class="mlr-file-input" multiple required>
                            </div>
                        </div>

                        <div class="mlr-step-pane" data-step-pane="2">
                            <h4 class="mlr-modal-subtitle">مرحله ۲: دریافت و آپلود قرارداد</h4>
                            <p>لطفاً فایل قرارداد را دریافت و چاپ کرده، پس از امضا، فایل اسکن شده آن را بارگذاری نمایید.</p>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-print-contract-step-btn">دریافت و چاپ قرارداد</button>

                             <div class="printable-contract-area" style="display: none;">
                                <?php if (!empty($plan_settings['plan_letterhead_url'])): ?>
                                    <div class="mlr-contract-letterhead"><img src="<?php echo esc_url($plan_settings['plan_letterhead_url']); ?>"></div>
                                <?php endif; ?>
                                <div class="mlr-contract-datetime">تاریخ: <?php echo mlr_gregorian_to_jalali(current_time('mysql'), 'Y/m/d'); ?></div>
                                <?php 
                                    if (!empty($plan_settings['plan_contract_text'])) {
                                        $contract_text = $plan_settings['plan_contract_text'];
                                        $variables = [
                                            '[full_name]' => esc_html($request->full_name),
                                            '[national_code]' => esc_html($request->national_code),
                                            '[mobile_number]' => esc_html($request->mobile_number),
                                            '[loan_amount]' => number_format($request->loan_amount),
                                            '[installment_count]' => esc_html($request->installment_count),
                                            '[installment_amount]' => number_format($request->installment_amount),
                                            '[total_payment]' => number_format($request->total_payment),
                                        ];
                                        echo '<div class="mlr-contract-box">' . wpautop(str_replace(array_keys($variables), array_values($variables), $contract_text)) . '</div>';
                                    } else {
                                         echo '<div class="mlr-contract-box"><p>متن قرارداد تنظیم نشده است.</p></div>';
                                    }
                                ?>
                                <?php if (!empty($plan_settings['plan_footer_url'])): ?>
                                    <div class="mlr-contract-footer"><img src="<?php echo esc_url($plan_settings['plan_footer_url']); ?>"></div>
                                <?php endif; ?>
                            </div>
                            <div class="mlr-form-group" style="margin-top: 20px;">
                                <label for="signed_contract_upload">آپلود قرارداد امضا شده</label>
                                <input type="file" id="signed_contract_upload" name="signed_contract_files[]" class="mlr-file-input" multiple accept="image/*,.pdf">
                            </div>
                        </div>

                        <div class="mlr-step-pane" data-step-pane="3">
                            <h4 class="mlr-modal-subtitle">مرحله ۳: فاکتور</h4>
                            <div class="printable-invoice-area" style="display:none;">
                                <div style="direction:rtl; text-align:right; font-family:Tahoma;">
                                    <h3>فاکتور فروش</h3>
                                    <p>فروشنده: <?php echo esc_html($seller_shop_name); ?></p>
                                    <p>خریدار: <?php echo esc_html($request->full_name); ?></p>
                                    <table border="1" style="width:100%; border-collapse:collapse;">
                                        <thead><tr><th>کالا</th><th>تعداد</th><th>قیمت</th></tr></thead>
                                        <tbody>
                                            <?php if(!empty($order_items) && is_array($order_items)): foreach($order_items as $item): ?>
                                                <tr><td><?php echo esc_html($item['name'] ?? '-'); ?></td><td><?php echo esc_html($item['qty'] ?? 1); ?></td><td><?php echo number_format($item['price'] ?? 0); ?></td></tr>
                                            <?php endforeach; endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-print-invoice-step-btn">دریافت و چاپ فاکتور</button>
                            <div class="mlr-form-group" style="margin-top: 20px;">
                                <label for="signed_invoice_upload">آپلود فاکتور امضا شده</label>
                                <input type="file" id="signed_invoice_upload" name="signed_invoice_files[]" class="mlr-file-input" multiple accept="image/*,.pdf">
                            </div>
                        </div>
                        
                        <div class="mlr-step-pane" data-step-pane="4">
                             <h4 class="mlr-modal-subtitle">مرحله ۴: فایل‌های نهایی</h4>
                            <?php 
                            if (!empty($plan_settings['plan_downloadable_files']) && is_array($plan_settings['plan_downloadable_files'])) {
                                echo '<h5>دانلود فایل‌های ضمیمه:</h5><ul class="mlr-downloadable-files-list">';
                                foreach ($plan_settings['plan_downloadable_files'] as $file_url) {
                                    $filename = basename($file_url);
                                    if(!empty($file_url)) {
                                        echo '<li><a href="' . esc_url($file_url) . '" class="mlr-view-file-btn">' . esc_html($filename) . ' <span class="dashicons dashicons-download"></span></a></li>';
                                    }
                                }
                                echo '</ul>';
                            }
                            ?>
                             <div class="mlr-form-group">
                                <label for="other_completed_files_upload">آپلود سایر مدارک (اختیاری)</label>
                                <input type="file" id="other_completed_files_upload" name="other_completed_files[]" class="mlr-file-input" multiple accept=".jpg,.jpeg,.png,.pdf">
                            </div>
                        </div>
                    </div>

                    <div class="mlr-stepper-buttons">
                        <button type="button" class="mlr-btn-secondary mlr-prev-step-btn" style="display: none;">قبلی</button>
                        <button type="button" class="mlr-btn-primary mlr-next-step-btn">بعدی</button>
                        <button type="submit" class="mlr-btn-success mlr-submit-btn" style="display: none;">ارسال مدارک و تأیید نهایی</button>
                    </div>
                    <div id="mlr-complete-upload-message" class="mlr-upload-status"></div>
                </form>
            </div>
        <?php endif; ?>

        <?php if ($request->status === 'نقص مدارک' && (int)$request->user_id === $current_user->ID): ?>
            <div class="mlr-additional-docs-section">
                <h4 class="mlr-modal-subtitle">بارگذاری مدارک تکمیلی (رفع نقص)</h4>
                <form id="mlr-additional-docs-form" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request_id); ?>">
                    <div class="mlr-form-group">
                        <label for="additional_documents_upload">فایل‌های خود را انتخاب کنید</label>
                        <input type="file" id="additional_documents_upload" name="additional_documents[]" class="mlr-file-input" multiple required>
                    </div>
                    <div id="mlr-upload-message" class="mlr-upload-status"></div>
                    <button type="submit" class="mlr-btn">ارسال مدارک</button>
                </form>
            </div>
        <?php endif; ?>

        <div class="mlr-modal-grid">
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle">اطلاعات متقاضی</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام متقاضی:</strong></td><td><?php echo esc_html($request->full_name); ?></td></tr>
                    <tr><td><strong>کدملی:</strong></td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td><strong>موبایل:</strong></td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td><strong>شغل:</strong></td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td><strong>آدرس:</strong></td><td><?php echo nl2br(esc_html($request->residential_address)); ?></td></tr>
                </table>
            </div>
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle">اطلاعات تسهیلات</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام طرح:</strong></td><td><?php echo esc_html($request->plan_name); ?></td></tr>
                    <tr><td><strong>مبلغ وام:</strong></td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td><strong>اقساط:</strong></td><td><?php echo esc_html($request->installment_count); ?> ماهه</td></tr>
                    <tr><td><strong>مبلغ هر قسط:</strong></td><td><?php echo number_format($request->installment_amount); ?> ریال</td></tr>
                    <tr><td><strong>بازپرداخت کل:</strong></td><td><?php echo number_format($request->total_payment); ?> ریال</td></tr>
                    <tr><td><strong>وضعیت:</strong></td><td><span class="mlr-status-badge" data-status="<?php echo esc_attr($request->status); ?>"><?php echo esc_html($request->status); ?></span></td></tr>
                </table>
            </div>
        </div>
        
        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle">مدارک بارگذاری شده</h4>
            <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                <ul class="mlr-file-list">
                    <?php $doc_labels = mlr_get_all_document_options(); ?>
                    <?php foreach($uploaded_documents as $doc_key => $doc_value): ?>
                        <li>
                            <strong><?php echo esc_html($doc_labels[$doc_key] ?? ucfirst(str_replace('_', ' ', $doc_key))); ?>:</strong>
                            <?php if (is_array($doc_value)): ?>
                                <ul>
                                    <?php foreach ($doc_value as $index => $url): 
                                        if(empty($url)) continue; ?>
                                        <li>
                                            <a href="<?php echo esc_url($url); ?>" class="mlr-view-file-btn">
                                                <span class="dashicons dashicons-visibility"></span> مشاهده فایل <?php echo $index + 1; ?>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php elseif (is_string($doc_value) && !empty($doc_value)): ?>
                                <a href="<?php echo esc_url($doc_value); ?>" class="mlr-view-file-btn">
                                    <span class="dashicons dashicons-visibility"></span> مشاهده فایل
                                </a>
                            <?php else: ?>
                                <span><em>فایلی بارگذاری نشده است.</em></span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="text-align:center;">هیچ مدرکی بارگذاری نشده است.</p>
            <?php endif; ?>
        </div>
        
    </div>
    <?php
    $html_output = ob_get_clean();
    wp_send_json_success(['html' => $html_output]);
}