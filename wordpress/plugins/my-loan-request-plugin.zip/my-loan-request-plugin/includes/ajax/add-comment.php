<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_add_comment', 'mlr_add_comment_callback');

function mlr_add_comment_callback() {
    // 1. Security Checks
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
        return;
    }

    // 2. Input Validation & Sanitization
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $comment_text = isset($_POST['comment']) ? sanitize_textarea_field(stripslashes($_POST['comment'])) : '';
    $uploaded_files = [];

    // Handle file uploads
    if (!empty($_FILES['attachments'])) {
        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        $files = $_FILES['attachments'];
        $upload_overrides = ['test_form' => false];

        // Normalize the $_FILES array for multiple uploads
        $file_ary = [];
        if (is_array($files['name'])) {
            foreach ($files['name'] as $key => $value) {
                if ($files['name'][$key]) {
                    $file_ary[] = ['name' => $files['name'][$key], 'type' => $files['type'][$key], 'tmp_name' => $files['tmp_name'][$key], 'error' => $files['error'][$key], 'size' => $files['size'][$key]];
                }
            }
        } else {
            $file_ary[] = $files;
        }

        foreach ($file_ary as $file) {
            $movefile = wp_handle_upload($file, $upload_overrides);
            if ($movefile && !isset($movefile['error'])) {
                // We only need the URL and name for the comments JSON
                $uploaded_files[] = ['url' => $movefile['url'], 'name' => basename($movefile['file'])];
            } else {
                if (function_exists('mlr_log')) mlr_log("Admin Note Attachment Upload Error: " . ($movefile['error'] ?? 'Unknown error'));
            }
        }
    }

    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }
    
    if (empty(trim($comment_text)) && empty($uploaded_files)) {
        wp_send_json_error(['message' => 'متن یادداشت یا فایل پیوست الزامی است.']);
        return;
    }

    // 3. Database Interaction
    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';

    // Fetch existing comments
    $existing_comments_json = $wpdb->get_var($wpdb->prepare("SELECT comments FROM $table_name WHERE id = %d", $request_id));
    $comments = !empty($existing_comments_json) ? json_decode($existing_comments_json, true) : [];
    
    if (!is_array($comments)) {
        $comments = [];
    }

    // Prepare new comment
    $current_user = wp_get_current_user();
    $new_comment = [
        'user_id'      => $current_user->ID,
        'display_name' => $current_user->display_name,
        'text'         => $comment_text,
        'timestamp'    => current_time('mysql'),
        'attachments'  => $uploaded_files, // Add attachments array
    ];

    // Add new comment to the array
    $comments[] = $new_comment;

    // Update the database
    $updated = $wpdb->update(
        $table_name,
        ['comments' => json_encode($comments, JSON_UNESCAPED_UNICODE)],
        ['id' => $request_id]
    );

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطایی در هنگام ذخیره یادداشت رخ داد.']);
        return;
    }

    // Notify all admins when a new internal note is added
    if (function_exists('mlr_create_notification')) {
        mlr_create_notification('new_message', 'یادداشت جدید برای درخواست #' . $request_id, admin_url('admin.php?page=mlr-loan-requests&s=' . $request_id));
    }

    // 4. Send Success Response with the new comment HTML for live update
    ob_start();
    ?>
    <div class="mlr-comment-bubble">
        <div class="mlr-comment-header">
            <strong class="mlr-comment-author"><?php echo esc_html($new_comment['display_name']); ?></strong>
            <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($new_comment['timestamp'], 'Y/m/d H:i'); ?></span>
        </div>
        <div class="mlr-comment-body">
            <?php echo nl2br(esc_html($new_comment['text'])); ?>
        </div>
        <?php if (!empty($new_comment['attachments'])): ?>
            <div class="mlr-conv-attachments">
                <strong class="mlr-attachments-title">پیوست‌ها:</strong>
                <div class="mlr-attachments-list">
                    <?php foreach ($new_comment['attachments'] as $file): ?>
                        <a href="<?php echo esc_url($file['url']); ?>" target="_blank" class="mlr-view-file-btn">
                            <span class="dashicons dashicons-download"></span> <?php echo esc_html($file['name']); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php
    $new_comment_html = ob_get_clean();

    // Regenerate the whole conversation timeline to ensure correct order
    $request_messages = function_exists('mlr_get_request_messages') ? mlr_get_request_messages($request_id, 1000) : [];
    $conversation_html = function_exists('mlr_render_request_conversation_html') ? mlr_render_request_conversation_html($comments, $request_messages) : '';
    wp_send_json_success([
        'message' => 'یادداشت با موفقیت اضافه شد.',
        'new_comment_html' => $new_comment_html, // Fallback
        'conversation_html' => $conversation_html // Primary response
    ]);
}