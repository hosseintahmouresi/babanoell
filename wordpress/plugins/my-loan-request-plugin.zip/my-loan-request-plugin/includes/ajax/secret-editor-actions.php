<?php
/**
 * AJAX actions for Secret Editor – فقط با تأیید نشست پنل مخفی
 */

if (!defined('ABSPATH')) {
    exit;
}

function mlr_secret_editor_verify() {
    if (empty($_COOKIE['mlr_secret_editor_token'])) {
        wp_send_json_error(['message' => 'لطفاً دوباره وارد شوید.']);
    }
    $stored = get_option('mlr_secret_editor_session');
    if (!$stored || !hash_equals($stored, $_COOKIE['mlr_secret_editor_token'])) {
        wp_send_json_error(['message' => 'نشست منقضی شده. دوباره وارد شوید.']);
    }
}

add_action('wp_ajax_mlr_secret_editor_list', 'mlr_secret_editor_list_callback');
add_action('wp_ajax_nopriv_mlr_secret_editor_list', 'mlr_secret_editor_list_callback');
function mlr_secret_editor_list_callback() {
    mlr_secret_editor_verify();
    check_ajax_referer('mlr_secret_editor_nonce', 'nonce');

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

    $where = '1=1';
    $params = [];
    if ($search !== '') {
        $like = '%' . $wpdb->esc_like($search) . '%';
        $where .= ' AND (id = %d OR full_name LIKE %s OR national_code LIKE %s OR mobile_number LIKE %s)';
        $id = is_numeric($search) ? intval($search) : 0;
        $params = $id ? [$id, $like, $like, $like] : [$like, $like, $like];
    }
    if ($status !== '') {
        $where .= ' AND status = %s';
        $params[] = $status;
    }
    $sql = "SELECT id, full_name, national_code, mobile_number, loan_amount, status, created_at FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT 500";
    if (!empty($params)) {
        $sql = $wpdb->prepare($sql, $params);
    }
    $rows = $wpdb->get_results($sql);

    $html = '';
    if (empty($rows)) {
        $html = '<tr><td colspan="7" class="mlr-secret-empty">هیچ درخواستی یافت نشد.</td></tr>';
    } else {
        foreach ($rows as $r) {
            $created = function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($r->created_at, 'Y/m/d H:i') : $r->created_at;
            $html .= '<tr data-id="' . esc_attr($r->id) . '">';
            $html .= '<td>' . esc_html($r->id) . '</td>';
            $html .= '<td>' . esc_html($r->full_name) . '</td>';
            $html .= '<td>' . esc_html($r->national_code) . '</td>';
            $html .= '<td><span class="mlr-secret-badge">' . esc_html($r->status) . '</span></td>';
            $html .= '<td>' . number_format($r->loan_amount) . '</td>';
            $html .= '<td>' . esc_html($created) . '</td>';
            $html .= '<td><button type="button" class="mlr-secret-btn mlr-secret-btn-sm mlr-secret-edit-btn" data-id="' . esc_attr($r->id) . '">ویرایش</button> <button type="button" class="mlr-secret-btn mlr-secret-btn-sm mlr-secret-btn-danger mlr-secret-delete-btn" data-id="' . esc_attr($r->id) . '">حذف</button></td>';
            $html .= '</tr>';
        }
    }
    wp_send_json_success(['html' => $html]);
}

add_action('wp_ajax_mlr_secret_editor_get', 'mlr_secret_editor_get_callback');
add_action('wp_ajax_nopriv_mlr_secret_editor_get', 'mlr_secret_editor_get_callback');
function mlr_secret_editor_get_callback() {
    mlr_secret_editor_verify();
    check_ajax_referer('mlr_secret_editor_nonce', 'nonce');

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر است.']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
    if (!$row) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
    }
    wp_send_json_success(['request' => $row]);
}

add_action('wp_ajax_mlr_secret_editor_save', 'mlr_secret_editor_save_callback');
add_action('wp_ajax_nopriv_mlr_secret_editor_save', 'mlr_secret_editor_save_callback');
function mlr_secret_editor_save_callback() {
    mlr_secret_editor_verify();
    check_ajax_referer('mlr_secret_editor_nonce', 'nonce');

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر است.']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';
    $existing = $wpdb->get_row($wpdb->prepare("SELECT id, status, settlement_status, settlement_cycle_id, settlement_date FROM {$table} WHERE id = %d", $id), ARRAY_A);
    if (!$existing) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
    }

    $cols = $wpdb->get_col("DESC {$table}", 0);
    $allowed = array_flip(array_diff($cols, ['id']));
    $data = [];
    foreach ($_POST as $key => $value) {
        if ($key === 'action' || $key === 'nonce' || $key === 'id') continue;
        if (!isset($allowed[$key])) continue;
        if (is_array($value) || is_object($value)) {
            $data[$key] = maybe_serialize($value);
        } else {
            $data[$key] = $value;
        }
    }

    // جلوگیری از پاک شدن تصادفی وضعیت تسویه هنگام ویرایش فقط مبالغ/تاریخ: اگر پرونده اعطا شده است و وضعیت تسویه معنی‌دار دارد، مقدار خالی از فرم را اعمال نکن.
    if (isset($existing['status']) && $existing['status'] === 'اعطا شده') {
        if (!empty($existing['settlement_status']) && (string) ($data['settlement_status'] ?? '') === '') {
            unset($data['settlement_status']);
        }
        if (isset($existing['settlement_cycle_id']) && (int) $existing['settlement_cycle_id'] > 0) {
            $incoming_cycle = isset($data['settlement_cycle_id']) ? trim((string) $data['settlement_cycle_id']) : '';
            if ($incoming_cycle === '' || (int) $incoming_cycle === 0) {
                unset($data['settlement_cycle_id']);
            }
        }
        if (!empty($existing['settlement_date']) && (string) ($data['settlement_date'] ?? '') === '') {
            unset($data['settlement_date']);
        }
    }

    $data['last_edited_at'] = current_time('mysql');

    $r = $wpdb->update($table, $data, ['id' => $id]);
    if ($r === false) {
        wp_send_json_error(['message' => 'خطا در ذخیره: ' . $wpdb->last_error]);
    }
    wp_send_json_success(['message' => 'ذخیره شد.']);
}

add_action('wp_ajax_mlr_secret_editor_delete', 'mlr_secret_editor_delete_callback');
add_action('wp_ajax_nopriv_mlr_secret_editor_delete', 'mlr_secret_editor_delete_callback');
function mlr_secret_editor_delete_callback() {
    mlr_secret_editor_verify();
    check_ajax_referer('mlr_secret_editor_nonce', 'nonce');

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر است.']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';
    $r = $wpdb->delete($table, ['id' => $id]);
    if ($r === false) {
        wp_send_json_error(['message' => 'خطا در حذف.']);
    }
    wp_send_json_success(['message' => 'درخواست حذف شد.']);
}

add_action('wp_ajax_mlr_secret_editor_form', 'mlr_secret_editor_form_callback');
add_action('wp_ajax_nopriv_mlr_secret_editor_form', 'mlr_secret_editor_form_callback');
function mlr_secret_editor_form_callback() {
    mlr_secret_editor_verify();
    check_ajax_referer('mlr_secret_editor_nonce', 'nonce');

    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    if (!$id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر است.']);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';
    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), ARRAY_A);
    if (!$row) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
    }

    $plans = $wpdb->get_results("SELECT id, name FROM " . $wpdb->prefix . "installment_plans ORDER BY name");
    ob_start();
    include MLR_PLUGIN_DIR . 'includes/secret-editor/edit-form.php';
    $html = ob_get_clean();
    wp_send_json_success(['html' => $html, 'id' => $id]);
}
