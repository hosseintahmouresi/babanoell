<?php
/**
 * AJAX: بروزرسانی تاریخ تسویه — در دسترس برای نقش‌های administrator و mali (قابلیت mlr_edit_settlement_date)
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_update_settlement_date', 'mlr_update_settlement_date_callback');

function mlr_update_settlement_date_callback() {
    if (!current_user_can('mlr_edit_settlement_date')) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز.']);
        return;
    }

    check_ajax_referer('mlr_settlement_date_edit_nonce', 'nonce');

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $settlement_date_jalali = isset($_POST['settlement_date']) ? sanitize_text_field(wp_unslash($_POST['settlement_date'])) : '';

    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    if (empty($settlement_date_jalali)) {
        wp_send_json_error(['message' => 'تاریخ تسویه را وارد کنید.']);
        return;
    }

    if (!function_exists('mlr_jalali_to_gregorian')) {
        wp_send_json_error(['message' => 'تابع تبدیل تاریخ در دسترس نیست.']);
        return;
    }

    $settlement_date_gregorian = mlr_jalali_to_gregorian($settlement_date_jalali);
    if (!$settlement_date_gregorian) {
        wp_send_json_error(['message' => 'فرمت تاریخ شمسی نامعتبر است (مثال: 1403/06/15).']);
        return;
    }

    $settlement_date_gregorian .= ' ' . date('H:i:s');

    global $wpdb;
    $table = $wpdb->prefix . 'loan_requests';

    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM `{$table}` WHERE id = %d AND status = 'اعطا شده'",
        $request_id
    ));

    if (!$exists) {
        wp_send_json_error(['message' => 'درخواست یافت نشد یا وضعیت آن اعطا شده نیست.']);
        return;
    }

    $updated = $wpdb->update(
        $table,
        ['settlement_date' => $settlement_date_gregorian],
        ['id' => $request_id],
        ['%s'],
        ['%d']
    );

    if ($updated === false) {
        if (function_exists('mlr_log')) {
            mlr_log('update_settlement_date failed: ' . $wpdb->last_error);
        }
        wp_send_json_error(['message' => 'خطا در بروزرسانی دیتابیس.']);
        return;
    }

    if ($updated > 0 && function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'settlement_date_edited', 'تاریخ تسویه به ' . $settlement_date_jalali . ' تغییر یافت.');
    }

    $display_date = function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($settlement_date_gregorian, 'Y/m/d') : $settlement_date_gregorian;
    wp_send_json_success([
        'message' => 'تاریخ تسویه با موفقیت بروزرسانی شد.',
        'settlement_date_display' => $display_date,
    ]);
}
