jQuery(document).ready(function($) {
    if ($('#mlr-loan-request-form-main').length === 0) return;

    let currentStep = 1;
    let selectedPlan = null;
    let documentsSectionPlanId = null;
    let requiresBankValidation = false;
    let loanAmountForProducts = 0;
    let creditCheckHashCode = '';
    let creditCheckInterval = null;
    const form = $('#mlr-loan-request-form-main');
    
    // --- Helper Functions ---

    function parseFormattedNumber(str) {
        if (!str) return 0;
        const persianNumbersMap = { '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9' };
        let englishStr = String(str);
        englishStr = englishStr.replace(/[۰-۹]/g, (match) => persianNumbersMap[match]);
        englishStr = englishStr.replace(/[٬,.]|\s/g, '');
        return parseInt(englishStr, 10) || 0;
    }

    function formatNumber(num) {
        if (!num || isNaN(num)) return '';
        return new Intl.NumberFormat('fa-IR').format(num);
    }

    // New Algorithm for Iranian National Code Validation
    function isValidIranianNationalCode(input) {
        if (!/^\d{10}$/.test(input)) return false;
        const check = parseInt(input[9]);
        const sum = input.split('').slice(0, 9).reduce((acc, x, i) => acc + parseInt(x) * (10 - i), 0) % 11;
        return (sum < 2 && check === sum) || (sum >= 2 && check === 11 - sum);
    }

    function showError(element, message) {
        element.addClass('is-invalid');
        element.closest('.mlr-form-group').find('.mlr-error-message').text(message).show();
    }

    function hideError(element) {
        element.removeClass('is-invalid');
        element.closest('.mlr-form-group').find('.mlr-error-message').hide();
    }

    // --- Dynamic Year Population (18 to 70 years old) ---
    function populateBirthYears() {
        const yearSelect = $('#birth_year');
        if (yearSelect.length === 0) return;

        // Get current Jalali Year
        const today = new Date();
        const formatter = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric' });
        const currentYearString = formatter.format(today).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)); // Ensure English digits
        const currentJalaliYear = parseInt(currentYearString);

        // Calculate range: 18 to 70 years ago
        const minAge = 18;
        const maxAge = 70;
        const startYear = currentJalaliYear - minAge; // e.g., 1403 - 18 = 1385
        const endYear = currentJalaliYear - maxAge;   // e.g., 1403 - 70 = 1333

        let optionsHtml = '<option value="">سال</option>';
        for (let y = startYear; y >= endYear; y--) {
            optionsHtml += `<option value="${y}">${y}</option>`;
        }
        yearSelect.html(optionsHtml);
    }

    // Initial population of years
    populateBirthYears();

    // --- Validation Logic ---

    function validateStep1() {
        let isStepValid = true;
        const nationalCode = $('#national_code_verify');
        const mobileNumber = $('#mobile_number_verify');
        const ncValue = nationalCode.val();

        if (!isValidIranianNationalCode(ncValue)) {
            showError(nationalCode, 'کد ملی وارد شده نامعتبر است.');
            isStepValid = false;
        } else {
            hideError(nationalCode);
        }

        if (!/^09\d{9}$/.test(mobileNumber.val())) {
            showError(mobileNumber, 'شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.');
            isStepValid = false;
        } else {
            hideError(mobileNumber);
        }

        $('#verify_shahkar_btn').prop('disabled', !isStepValid);
    }

    function validateStep2() {
        const planSelect = $('#calc_plan_select');
        const amountInput = $('#calc_amount');
        const intervalInput = $('#calc_interval');
        
        const amount = parseFormattedNumber(amountInput.val());
        const interval = parseInt(intervalInput.val());

        const minAmount = selectedPlan ? parseInt(selectedPlan.view_settings.min_amount) : 0;
        const maxAmount = selectedPlan ? parseInt(selectedPlan.view_settings.max_amount) : Infinity;
        const minInterval = selectedPlan ? parseInt(selectedPlan.view_settings.min_interval) : 1;
        const maxInterval = selectedPlan ? parseInt(selectedPlan.view_settings.max_interval) : 12;
        
        let isStepValid = true;

        if (!planSelect.val()) {
            showError(planSelect, 'انتخاب طرح الزامی است.');
            isStepValid = false;
        } else {
            hideError(planSelect);
        }

        if (!selectedPlan || amount < minAmount || amount > maxAmount) {
            const minText = selectedPlan ? formatNumber(minAmount) : '...';
            const maxText = selectedPlan ? formatNumber(maxAmount) : '...';
            showError(amountInput, `مبلغ باید بین ${minText} و ${maxText} باشد.`);
            isStepValid = false;
        } else {
            hideError(amountInput);
        }

        if (selectedPlan && selectedPlan.type === 'leasing') {
            if (isNaN(interval) || interval < minInterval || interval > maxInterval) {
                showError(intervalInput, `فاصله اقساط باید بین ${minInterval} و ${maxInterval} ماه باشد.`);
                isStepValid = false;
            } else {
                hideError(intervalInput);
            }
        } else {
            hideError(intervalInput);
        }

        $('#run_calculator').prop('disabled', !isStepValid);
        
        if ($('#calculation-result').is(':empty') || $('#calculation-result').hasClass('mlr-error')) {
             $('#next_step_2').prop('disabled', true);
        }
    }

    function validateStep4() {
        let isStepValid = true;
        
        const fullName = $('#full_name');
        if (fullName.val().trim() === '') {
            showError(fullName, 'نام و نام خانوادگی الزامی است.'); isStepValid = false;
        } else {
            hideError(fullName);
        }

        const fatherName = $('#father_name');
        if (fatherName.length > 0 && fatherName.val().trim() === '') {
            showError(fatherName, 'نام پدر الزامی است.'); isStepValid = false;
        } else {
            hideError(fatherName);
        }

        const certNum = $('#certificate_number');
        if (certNum.length > 0 && certNum.val().trim() === '') {
            showError(certNum, 'شماره شناسنامه الزامی است.'); isStepValid = false;
        } else {
            hideError(certNum);
        }

        const certCity = $('#certificate_city');
        if (certCity.length > 0 && certCity.val().trim() === '') {
            showError(certCity, 'شهر صدور شناسنامه الزامی است.'); isStepValid = false;
        } else {
            hideError(certCity);
        }

        const birthDateError = $('#birthdate-error');
        if ($('#birth_year').val() === '' || $('#birth_month').val() === '' || $('#birth_day').val() === '') {
            birthDateError.show(); isStepValid = false;
        } else {
            birthDateError.hide();
        }

        const occupation = $('#occupation');
        if (occupation.val() === '') {
            showError(occupation, 'انتخاب شغل الزامی است.'); isStepValid = false;
        } else {
            hideError(occupation);
        }

        const resAddress = $('#residential_address');
        if (resAddress.val().trim() === '') {
            showError(resAddress, 'آدرس محل سکونت الزامی است.'); isStepValid = false;
        } else {
            hideError(resAddress);
        }

        const workAddress = $('#work_address');
        if (workAddress.val().trim() === '') {
            showError(workAddress, 'آدرس محل فعالیت الزامی است.'); isStepValid = false;
        } else {
            hideError(workAddress);
        }
        
        const postalCode = $('#postal_code');
        if (!/^\d{10}$/.test(postalCode.val())) {
            showError(postalCode, 'کد پستی ۱۰ رقمی الزامی است.'); isStepValid = false;
        } else {
            hideError(postalCode);
        }

        let productTotal = 0;
        let productsValid = true;
        const productError = $('#product-error');
        if ($('.mlr-product-row').length === 0) {
            productsValid = false;
        }
        $('.mlr-product-row').each(function() {
            const name = $(this).find('.product-name').val().trim();
            const price = parseFormattedNumber($(this).find('.product-price').val());
            const qty = parseInt($(this).find('.product-qty').val());
            if (!name || isNaN(price) || price <= 0 || isNaN(qty) || qty <= 0) {
                productsValid = false;
            }
            productTotal += price * qty;
        });

        if (!productsValid || productTotal !== loanAmountForProducts) {
            productError.show(); isStepValid = false;
        } else {
            productError.hide();
        }
        
        $('#next_step_4').prop('disabled', !isStepValid);
    }

    function validateStep5() {
        var allUploaded = true;
        var anyInProgress = false;
        $('#dynamic-documents .mlr-doc-upload-group').each(function() {
            var $group = $(this);
            var urls = $group.find('input.mlr-uploaded-urls').val();
            var arr = [];
            try { arr = urls ? JSON.parse(urls) : []; } catch (e) {}
            if (arr.length === 0) allUploaded = false;
            if ($group.hasClass('mlr-upload-in-progress')) anyInProgress = true;
        });
        $('#final-submit-btn').prop('disabled', !allUploaded || anyInProgress);
    }

    function goToStep(stepNumber) {
        $('.mlr-step-content').removeClass('is-active');
        $('#step' + stepNumber).addClass('is-active');

        $('.mlr-step-item').each(function() {
            const stepId = $(this).data('step-id');
            $(this).removeClass('is-active is-completed');
            if (stepId < stepNumber) { $(this).addClass('is-completed'); } 
            else if (stepId === stepNumber) { $(this).addClass('is-active'); }
        });
        currentStep = stepNumber;
        if (stepNumber === 1) validateStep1();
        if (stepNumber === 2) validateStep2();
        if (stepNumber === 4) validateStep4();
        if (stepNumber === 5) validateStep5();
    }

    function updateDynamicDocuments(onDone) {
        if (!selectedPlan) { if (onDone) onDone(); return; }
        $('#dynamic-documents').html('<p class="mlr-loading">در حال بارگذاری مدارک مورد نیاز...</p>');
        $.post(mlr_form_ajax.ajax_url, {
            action: 'mlr_get_plan_documents', nonce: mlr_form_ajax.nonce, plan_id: selectedPlan.id
        }, function(response) {
            if (response.success && Array.isArray(response.data) && response.data.length > 0) {
                var documentsHtml = '';
                response.data.forEach(function(doc) {
                    var inputName = doc.multiple ? (doc.key + '[]') : doc.key;
                    var requiredAttr = 'required';
                    documentsHtml += '<div class="mlr-doc-upload-group mlr-form-group" data-key="' + doc.key + '" data-required="true">';
                    documentsHtml += '<label for="doc_' + doc.key + '">' + doc.label + ':</label>';
                    documentsHtml += '<input type="file" id="doc_' + doc.key + '" class="mlr-input mlr-doc-file-input" name="doc_file_' + doc.key + '" ' + (doc.multiple ? 'multiple' : '') + ' ' + requiredAttr + ' accept=".jpg,.jpeg,.png,.pdf">';
                    documentsHtml += '<p class="mlr-upload-hint description">حداکثر حجم هر فایل ۵ مگابایت. پس از انتخاب، فایل‌ها به‌صورت خودکار آپلود می‌شوند. می‌توانید فایل‌های بیشتری اضافه یا حذف کنید.</p>';
                    documentsHtml += '<div class="mlr-uploaded-files-list" aria-live="polite"></div>';
                    documentsHtml += '<div class="mlr-upload-progress-wrap" style="display:none;"><div class="mlr-upload-progress-bar"><span class="mlr-upload-progress-fill"></span></div><span class="mlr-upload-progress-pct">0%</span></div>';
                    documentsHtml += '<div class="mlr-upload-error" role="alert" style="display:none;"></div>';
                    documentsHtml += '<input type="hidden" class="mlr-uploaded-urls" name="mlr_uploaded_doc_' + doc.key + '" value="[]">';
                    documentsHtml += '</div>';
                });
                $('#dynamic-documents').html(documentsHtml);
                bindDocFileUploads();
            } else {
                $('#dynamic-documents').html('<p>برای این طرح، مدرکی جهت بارگذاری مورد نیاز نیست.</p>');
            }
            validateStep5();
            if (typeof onDone === 'function') onDone();
        }).fail(function() { $('#dynamic-documents').html('<p class="mlr-error">خطا در بارگذاری لیست مدارک.</p>'); validateStep5(); if (typeof onDone === 'function') onDone(); });
    }

    function bindDocFileUploads() {
        if (typeof MLRFileUpload === 'undefined') {
            $('#dynamic-documents .mlr-doc-file-input').on('change', function() { validateStep5(); });
            return;
        }
        $('#dynamic-documents .mlr-doc-file-input').off('change.mlrUpload').on('change.mlrUpload', function() {
            var $input = $(this);
            var $group = $input.closest('.mlr-doc-upload-group');
            var $progressWrap = $group.find('.mlr-upload-progress-wrap');
            var $progressFill = $group.find('.mlr-upload-progress-fill');
            var $pct = $group.find('.mlr-upload-progress-pct');
            var $urlsInput = $group.find('.mlr-uploaded-urls');
            var $list = $group.find('.mlr-uploaded-files-list');
            var $errorEl = $group.find('.mlr-upload-error');
            var key = $group.data('key');
            var files = $input[0].files;
            if (!files || files.length === 0) { validateStep5(); return; }

            $errorEl.hide().empty();
            $group.addClass('mlr-upload-in-progress');
            $progressWrap.show();
            var urls = [];
            try { urls = JSON.parse($urlsInput.val() || '[]'); } catch (e) {}
            var total = files.length;

            function escapeHtml(s) { if (!s) return ''; var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
            function escapeAttr(s) { if (!s) return ''; return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#39;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
            function fileItemHtml(name, url) { return '<div class="mlr-uploaded-file-item" data-url="' + escapeAttr(url) + '"><span class="mlr-uploaded-file-name">' + escapeHtml(name) + '</span> <a href="#" class="mlr-view-file" title="مشاهده فایل">مشاهده</a> <button type="button" class="mlr-remove-file" title="حذف فایل">حذف</button></div>'; }

            function nextFile(index) {
                if (index >= total) {
                    $group.removeClass('mlr-upload-in-progress');
                    $progressWrap.hide();
                    $progressFill.css('width', '0%');
                    $pct.text('0%');
                    $input.val('');
                    $urlsInput.val(JSON.stringify(urls));
                    validateStep5();
                    return;
                }
                var file = files[index];
                $pct.text('0%');
                $progressFill.css('width', '0%');
                MLRFileUpload.processAndUploadFile(file, {
                    nonce: mlr_form_ajax.submit_nonce,
                    context: 'loan_request',
                    field_key: key,
                    ajax_url: mlr_form_ajax.ajax_url
                }, function(pct) {
                    $progressFill.css('width', pct + '%');
                    $pct.text(pct + '%');
                }).then(function(res) {
                    if (res && res.url) {
                        urls.push(res.url);
                        $list.append(fileItemHtml(file.name, res.url));
                    }
                    nextFile(index + 1);
                }).catch(function(err) {
                    var errMsg = (err && err.message) ? err.message : 'خطای ناشناخته. نوع و حجم فایل را بررسی کنید.';
                    $errorEl.text('خطا در آپلود «' + escapeHtml(file.name) + '»: ' + errMsg).show();
                    nextFile(index + 1);
                });
            }
            nextFile(0);
        });
    }

    // --- Event Listeners ---

    $('#national_code_verify, #mobile_number_verify').on('keyup input', validateStep1);
    $('#calc_plan_select, #calc_amount, #calc_interval').on('change keyup input', validateStep2);
    $('#step4').on('keyup input change', 'input, select, textarea', validateStep4);
    $('#dynamic-documents').on('change', 'input[type="file"]', validateStep5);

    $('#mlr-loan-request-form-main').on('click', '.mlr-view-file', function(e) {
        e.preventDefault();
        var url = $(this).closest('.mlr-uploaded-file-item').data('url');
        if (url) window.open(url, '_blank', 'noopener,noreferrer');
    });
    $('#mlr-loan-request-form-main').on('click', '.mlr-remove-file', function(e) {
        e.preventDefault();
        var $item = $(this).closest('.mlr-uploaded-file-item');
        var urlToRemove = $item.data('url');
        var $group = $item.closest('.mlr-doc-upload-group');
        var $hidden = $group.find('input.mlr-uploaded-urls');
        var urls = [];
        try { urls = JSON.parse($hidden.val() || '[]'); } catch (err) { urls = []; }
        urls = urls.filter(function(u) { return u !== urlToRemove; });
        $hidden.val(JSON.stringify(urls));
        $item.remove();
        validateStep5();
    });

    $('#verify_shahkar_btn').on('click', function() {
        const btn = $(this), msgDiv = $('#mlr-message');
        
        const nc = $('#national_code_verify').val();
        if(!isValidIranianNationalCode(nc)) {
             showError($('#national_code_verify'), 'کد ملی نامعتبر است.');
             return;
        }

        btn.prop('disabled', true).text('در حال بررسی...');
        msgDiv.html('درحال ارسال اطلاعات...').removeClass().addClass('mlr-loading').fadeIn();
        $.post(mlr_form_ajax.ajax_url, {
            action: 'mlr_verify_shahkar', nonce: mlr_form_ajax.nonce, national_code: nc, mobile_number: $('#mobile_number_verify').val()
        }).done(function(res) {
            if (res.success) {
                msgDiv.html('✅ ' + res.data.message).removeClass().addClass('mlr-success');
                $('#national_code').val($('#national_code_verify').val());
                $('#mobile_number').val($('#mobile_number_verify').val());
                setTimeout(() => { goToStep(2); msgDiv.fadeOut().empty(); }, 1500);
            } else {
                msgDiv.html('❌ ' + (res.data.message || 'خطا')).removeClass().addClass('mlr-error');
                btn.prop('disabled', false).text('بررسی تطابق و ادامه');
            }
        }).fail(() => { msgDiv.html('خطای سرور.').removeClass().addClass('mlr-error'); btn.prop('disabled', false).text('بررسی تطابق و ادامه'); });
    });
    
    $('#calc_plan_select').on('change', function() {
        const selectedPlanId = $(this).val();
        documentsSectionPlanId = null;
        $('#calculation-result').empty().hide();
        $('#next_step_2').prop('disabled', true);
        const amountInput = $('#calc_amount');
        const intervalInput = $('#calc_interval');
        if (!selectedPlanId) {
            $('#calc_installments').html(''); selectedPlan = null; validateStep2(); return;
        }
        selectedPlan = mlr_form_ajax.plans.find(p => p.id == selectedPlanId);
        if (!selectedPlan) return;
        const viewSettings = selectedPlan.view_settings;
        requiresBankValidation = viewSettings.requires_bank_validation == 1;
        $('#step-indicator-3').toggle(requiresBankValidation);
        if (viewSettings.active_installments) {
            const installmentsOptions = viewSettings.active_installments.split(',');
            let optionsHtml = '';
            installmentsOptions.forEach(function(inst) { optionsHtml += `<option value="${inst.trim()}">${inst.trim()} ماه</option>`; });
            $('#calc_installments').html(optionsHtml);
        }
        if (viewSettings.min_amount && viewSettings.max_amount) {
            amountInput.attr({'min': viewSettings.min_amount, 'max': viewSettings.max_amount, 'placeholder': `بین ${formatNumber(viewSettings.min_amount)} تا ${formatNumber(viewSettings.max_amount)} ریال`});
        }
        amountInput.off('keyup.formatter').on('keyup.formatter', function(e) {
            if (['ArrowLeft', 'ArrowRight', 'Backspace', 'Delete', 'Tab'].includes(e.key)) return;
            let rawValue = parseFormattedNumber($(this).val());
            $(this).val(formatNumber(rawValue));
        });
        if (selectedPlan.type === 'leasing') {
            $('#calc_interval_wrapper').slideDown(); 
            $('#calc_amount_label').text('مبلغ خرید (ریال):');
            if (viewSettings.min_interval && viewSettings.max_interval) {
                intervalInput.attr({ 'min': viewSettings.min_interval, 'max': viewSettings.max_interval });
                intervalInput.val(viewSettings.min_interval);
            }
        } else {
            $('#calc_interval_wrapper').slideUp(); 
            $('#calc_amount_label').text('مبلغ تسهیلات (ریال):');
        }
        validateStep2();
    });

    $('#run_calculator').on('click', function() {
        const resultDiv = $('#calculation-result');
        const data = { action: 'mlr_frontend_calculate_loan', nonce: mlr_form_ajax.calc_nonce, plan_id: selectedPlan.id, amount: parseFormattedNumber($('#calc_amount').val()), installments: $('#calc_installments').val(), installment_interval: $('#calc_interval').val(), user_commission: mlr_form_ajax.user_commission, context: mlr_form_ajax.context || 'mlr_loan_request_form' };
        resultDiv.html('<p class="mlr-loading">در حال محاسبه...</p>').slideDown();
        $('#next_step_2').prop('disabled', true);
        $.post(mlr_form_ajax.ajax_url, data, function(response) {
            if (response.success) {
                resultDiv.html(response.data.html).removeClass('mlr-error');
                $('#next_step_2').prop('disabled', false);
                if (response.data.results) {
                    $('#guarantee_check_principal').val(response.data.results.guarantee_check_principal || 0);
                    $('#guarantee_check_total').val(response.data.results.guarantee_check_total || 0);
                    $('#prepayment').val(response.data.results.prepayment || 0);
                }
            } else {
                resultDiv.html('<p class="mlr-error">' + (response.data.message || 'خطای ناشناخته') + '</p>').addClass('mlr-error');
            }
        });
    });

    // --- Credit Validation Logic (Step 3) ---
    $('#mlr-start-credit-check-btn').on('click', function() {
        const btn = $(this);
        const nc = $('#national_code').val();
        const mob = $('#mobile_number').val();

        if (!nc || !mob) {
            alert('اطلاعات هویتی یافت نشد. لطفاً مرحله ۱ را مجدداً انجام دهید.');
            goToStep(1);
            return;
        }

        btn.prop('disabled', true).text('در حال ارسال...');
        
        $.ajax({
            url: mlr_form_ajax.ajax_url + '?action=mlr_credit_request_otp', // Force action in URL to avoid 400 error
            type: 'POST',
            data: {
                action: 'mlr_credit_request_otp', 
                nonce: mlr_form_ajax.nonce,
                national_code: nc, 
                mobile: mob
            },
            success: function(res) {
            if (res.success) {
                creditCheckHashCode = res.data.hash_code;
                $('#mlr-credit-check-start').slideUp();
                $('#mlr-credit-check-otp').slideDown();
            } else {
                alert(res.data.message || 'خطا در ارسال درخواست.');
                btn.prop('disabled', false).text('ارسال کد اعتبارسنجی');
            }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error, xhr.responseText);
                alert('خطای ارتباط با سرور (کد ' + xhr.status + '). لطفاً مجدداً تلاش کنید.');
                btn.prop('disabled', false).text('ارسال کد اعتبارسنجی');
            }
        });
    });

    $('#mlr-verify-credit-otp-btn').on('click', function() {
        const otp = $('#mlr_credit_otp_input').val();
        if (!otp) { alert('لطفاً کد تایید را وارد کنید.'); return; }
        const btn = $(this);
        btn.prop('disabled', true).text('در حال بررسی...');
        
        $.post(mlr_form_ajax.ajax_url, {
            action: 'mlr_credit_verify_otp', nonce: mlr_form_ajax.nonce, hash_code: creditCheckHashCode, otp: otp
        }).done(function(res) {
            if (res.success) {
                $('#mlr-credit-check-otp').slideUp();
                $('#mlr-credit-check-loading').slideDown();
                startCreditStatusPolling();
            } else {
                alert(res.data.message || 'کد اشتباه است.');
                btn.prop('disabled', false).text('تایید و دریافت گزارش');
            }
        }).fail(() => { alert('خطای سرور.'); btn.prop('disabled', false).text('تایید و دریافت گزارش'); });
    });

    function startCreditStatusPolling() {
        let attempts = 0;
        
        function poll() {
            attempts++;
            // افزایش تعداد تلاش‌ها به ۶۰ (حدود ۵ دقیقه)
            if (attempts > 60) {
                $('#mlr-credit-check-loading').html('<p class="mlr-error">زمان انتظار به پایان رسید. لطفاً مجدداً تلاش کنید.</p>');
                $('#mlr-start-credit-check-btn').prop('disabled', false).text('تلاش مجدد');
                return;
            }
            
            $.post(mlr_form_ajax.ajax_url, {
                action: 'mlr_credit_check_status', nonce: mlr_form_ajax.nonce, hash_code: creditCheckHashCode
            }).done(function(res) {
                console.log('Credit Check Status (' + attempts + '):', res); // لاگ دقیق‌تر
                if (res.success) {
                    if (res.data.status === 'ready') {
                        $('#mlr-credit-check-loading').slideUp();
                        renderCreditReport(res.data.data);
                        $('#mlr-credit-check-result').slideDown();
                    } else {
                        // نمایش پیام وضعیت فعلی (مثلاً: احراز هویت انجام شد)
                        let msg = res.data.message || 'در حال پردازش...';
                        if (res.data.api_status) {
                            console.log('API Status:', res.data.api_status);
                        }
                        $('#mlr-credit-loading-text').text(msg + ' (لطفاً شکیبا باشید...)');
                        // افزایش فاصله زمانی به ۵ ثانیه
                        setTimeout(poll, 5000); 
                    }
                } else {
                    // Handle error status (e.g. ReportGenerationFailed)
                    $('#mlr-credit-check-loading').hide();
                    $('#mlr-credit-check-start').slideDown();
                    $('#mlr-start-credit-check-btn').prop('disabled', false).text('تلاش مجدد');
                    alert(res.data.message || 'خطا در استعلام وضعیت.');
                }
            }).fail(function() {
                console.error('Polling Error:', status, error, xhr.responseText);
                $('#mlr-credit-check-loading').hide();
                $('#mlr-credit-check-start').slideDown();
                $('#mlr-start-credit-check-btn').prop('disabled', false).text('تلاش مجدد');
                alert('خطای ارتباط با سرور در دریافت وضعیت.');
            });
        }

        poll(); // Start polling
    }

    function renderCreditReport(data) {
        const fmt = (num) => new Intl.NumberFormat('fa-IR').format(num || 0);
        let html = '<div class="mlr-credit-report">';
        
        // 1. Score Section (Graphical Gauge)
        const scoreObj = data.score || {};
        const reportObj = data.report || {};
        const score = scoreObj.score !== undefined ? scoreObj.score : 0;
        const risk = scoreObj.risk || 'نامشخص';
        const desc = scoreObj.description || '';
        const minScore = scoreObj.minLimit || 0;
        const maxScore = scoreObj.maxLimit || 1000;
        
        // Calculate percentage for gauge
        let percent = 0;
        if (maxScore > minScore) {
             percent = ((score - minScore) / (maxScore - minScore)) * 100;
        }
        percent = Math.max(0, Math.min(100, percent));
        const strokeDashArray = `${percent}, 100`;
        
        let riskClass = 'mlr-risk-unknown';
        if (risk.includes('کم') || risk.includes('Low') || ['A1','A2','A3'].includes(risk)) riskClass = 'mlr-risk-low';
        else if (risk.includes('متوسط') || risk.includes('Medium') || ['B1','B2','B3'].includes(risk)) riskClass = 'mlr-risk-medium';
        else riskClass = 'mlr-risk-high';

        html += `
            <div class="mlr-report-header ${riskClass}">
                <div class="mlr-score-circle-wrapper">
                    <svg viewBox="0 0 36 36" class="mlr-circular-chart">
                        <path class="mlr-circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                        <path class="mlr-circle" stroke-dasharray="${strokeDashArray}" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                        <text x="18" y="20.35" class="mlr-percentage">${score}</text>
                    </svg>
                    <span class="mlr-score-label">امتیاز اعتباری</span>
                </div>
                <div class="mlr-risk-box">
                    <div class="mlr-risk-title">ریسک: ${risk}</div>
                    <div class="mlr-risk-desc">${desc}</div>
                </div>
            </div>
        `;

        // 2. Personal Info
        const pInfo = scoreObj.personInformation || reportObj.personInformation || {};
        if (Object.keys(pInfo).length > 0) {
            html += `
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-id-alt"></span> اطلاعات هویتی</h4>
                    <div class="mlr-report-grid">
                        <div><span class="mlr-label">نام و نام خانوادگی:</span> <strong>${pInfo.name || pInfo.firstName || ''} ${pInfo.family || pInfo.lastName || ''}</strong></div>
                        <div><span class="mlr-label">کد ملی:</span> <strong>${pInfo.nationalCode || '-'}</strong></div>
                        <div><span class="mlr-label">نام پدر:</span> <strong>${pInfo.fatherName || '-'}</strong></div>
                        <div><span class="mlr-label">تاریخ تولد:</span> <strong>${pInfo.dateOfBirth || pInfo.birthDate || '-'}</strong></div>
                    </div>
                </div>
            `;
        }

        // 3. Summary Dashboard (New)
        const summary = (reportObj.summaryInformationRelatedToContractsSum && reportObj.summaryInformationRelatedToContractsSum[0]) ? reportObj.summaryInformationRelatedToContractsSum[0] : {};
        const bouncedObj = data.bouncedCheque || {};
        const bouncedCount = bouncedObj.bouncedCheques ? bouncedObj.bouncedCheques.length : 0;
        
        html += `
            <div class="mlr-report-section">
                <h4><span class="dashicons dashicons-chart-bar"></span> خلاصه وضعیت مالی</h4>
                <div class="mlr-summary-grid">
                    <div class="mlr-summary-card">
                        <span class="mlr-summary-icon dashicons dashicons-media-document"></span>
                        <span class="mlr-summary-val">${summary.inProgressContractsCount || 0}</span>
                        <span class="mlr-summary-label">تسهیلات جاری</span>
                    </div>
                    <div class="mlr-summary-card">
                        <span class="mlr-summary-icon dashicons dashicons-money-alt"></span>
                        <span class="mlr-summary-val">${fmt(summary.overdueAmount)}</span>
                        <span class="mlr-summary-label">معوقات (ریال)</span>
                    </div>
                    <div class="mlr-summary-card">
                        <span class="mlr-summary-icon dashicons dashicons-warning"></span>
                        <span class="mlr-summary-val">${bouncedCount}</span>
                        <span class="mlr-summary-label">چک برگشتی</span>
                    </div>
                    <div class="mlr-summary-card">
                        <span class="mlr-summary-icon dashicons dashicons-portfolio"></span>
                        <span class="mlr-summary-val">${fmt(summary.totalAmount)}</span>
                        <span class="mlr-summary-label">کل تسهیلات (ریال)</span>
                    </div>
                </div>
            </div>
        `;

        // 4. Direct Contracts (Loans)
        const loans = reportObj.directContracts || [];
        if (loans.length > 0) {
            html += `<div class="mlr-report-section"><h4><span class="dashicons dashicons-bank"></span> تسهیلات بانکی (وام‌ها)</h4><div class="mlr-cards-container">`;
            loans.forEach(loan => {
                const statusText = loan.negativeContractStatus || 'جاری';
                const statusClass = (statusText.includes('معوق') || statusText.includes('مشکوک')) ? 'mlr-badge-danger' : (statusText.includes('گذشته') ? 'mlr-badge-warning' : 'mlr-badge-success');
                
                html += `
                <div class="mlr-contract-card">
                    <div class="mlr-contract-header">
                        <span class="mlr-contract-org">${loan.organizationName || 'بانک'}</span>
                        <span class="mlr-contract-badge ${statusClass}">${statusText}</span>
                    </div>
                    <div class="mlr-contract-body">
                        <div class="mlr-contract-row"><span>نوع:</span> <strong>${loan.typeOfFinancingTitle || '-'}</strong></div>
                        <div class="mlr-contract-row"><span>مبلغ کل:</span> <strong>${fmt(loan.totalAmount)} ریال</strong></div>
                        <div class="mlr-contract-row"><span>مانده بدهی:</span> <strong>${fmt(loan.overdueAmount)} ریال</strong></div>
                        <div class="mlr-contract-row"><span>شروع:</span> <strong>${loan.startDate || '-'}</strong></div>
                        <div class="mlr-contract-row"><span>پایان:</span> <strong>${loan.expectedEndDate || '-'}</strong></div>
                    </div>
                </div>`;
            });
            html += `</div></div>`;
        }

        // 5. Indirect Contracts (Guarantees)
        const guarantees = reportObj.indirectContracts || [];
        if (guarantees.length > 0) {
            html += `<div class="mlr-report-section"><h4><span class="dashicons dashicons-groups"></span> تعهدات (ضمانت‌ها)</h4><div class="mlr-cards-container">`;
            guarantees.forEach(g => {
                const statusText = g.negativeContractStatus || 'جاری';
                const statusClass = (statusText.includes('معوق')) ? 'mlr-badge-danger' : 'mlr-badge-success';
                html += `
                <div class="mlr-contract-card">
                    <div class="mlr-contract-header">
                        <span class="mlr-contract-org">${g.organizationName || 'بانک'} (ضامن)</span>
                        <span class="mlr-contract-badge ${statusClass}">${statusText}</span>
                    </div>
                    <div class="mlr-contract-body">
                        <div class="mlr-contract-row"><span>مبلغ ضمانت:</span> <strong>${fmt(g.totalAmount)} ریال</strong></div>
                        <div class="mlr-contract-row"><span>معوقات وام‌گیرنده:</span> <strong>${fmt(g.overdueAmount)} ریال</strong></div>
                        <div class="mlr-contract-row"><span>سررسید:</span> <strong>${g.expectedEndDate || '-'}</strong></div>
                    </div>
                </div>`;
            });
            html += `</div></div>`;
        }

        // 6. Pichak (Cheque Summary)
        const pichak = data.pichak && data.pichak.personChequesData ? data.pichak.personChequesData.personChequeItems : [];
        if (pichak.length > 0) {
            html += `<div class="mlr-report-section"><h4><span class="dashicons dashicons-tickets-alt"></span> وضعیت چک‌های صیادی (پیچک)</h4>
            <div class="mlr-table-wrapper"><table class="mlr-report-table">
                <thead><tr><th>وضعیت</th><th>تعداد</th><th>مبلغ کل (ریال)</th></tr></thead>
                <tbody>`;
            pichak.forEach(item => {
                html += `<tr><td>${item.checkStatusTitle}</td><td>${item.count}</td><td>${fmt(item.totalAmount)}</td></tr>`;
            });
            html += `</tbody></table></div></div>`;
        }

        // 7. Bounced Cheques (Detailed Table)
        const chequeItems = bouncedObj.bouncedCheques || [];
        
        html += `<div class="mlr-report-section"><h4><span class="dashicons dashicons-warning"></span> سوابق چک برگشتی</h4>`;
        if (chequeItems.length > 0) {
             html += `<div class="mlr-table-wrapper"><table class="mlr-report-table">
                <thead><tr><th>بانک</th><th>مبلغ (ریال)</th><th>تاریخ برگشت</th><th>تاریخ رفع سوءاثر</th></tr></thead>
                <tbody>`;
             chequeItems.forEach(item => {
                 const cleared = item.clearedDate ? item.clearedDate.replace('T', ' ').split(' ')[0] : '---';
                 const bouncedDate = item.bouncedDate ? item.bouncedDate.replace('T', ' ').split(' ')[0] : '-';
                 html += `<tr>
                    <td>${item.organizationName || '-'}</td>
                    <td>${fmt(item.amount)}</td>
                    <td>${bouncedDate}</td>
                    <td>${cleared}</td>
                 </tr>`;
             });
             html += `</tbody></table></div>`;
        } else {
            html += `<div class="mlr-status-item status-success">✅ فاقد چک برگشتی</div>`;
        }
        html += `</div>`;

        // 8. Tax (Detailed Table)
        const tax = data.tax || {};
        const taxItems = tax.taxResult || [];

        html += `<div class="mlr-report-section"><h4><span class="dashicons dashicons-money"></span> بدهی مالیاتی</h4>`;
        if (taxItems.length > 0) {
             html += `<div class="mlr-table-wrapper"><table class="mlr-report-table">
                <thead><tr><th>سال</th><th>درآمد ابرازی</th><th>مالیات قطعی</th><th>بدهی</th></tr></thead>
                <tbody>`;
             let hasTax = false;
             taxItems.forEach(item => {
                 if(item.year) {
                     hasTax = true;
                     html += `<tr><td>${item.year}</td><td>${fmt(item.daramadEbrazi)}</td><td>${fmt(item.maliatGhati)}</td><td>${fmt(item.bedehiMaliatAmalkard)}</td></tr>`;
                 }
             });
             html += `</tbody></table></div>`;
             if(!hasTax) html += `<div class="mlr-status-item status-success">✅ فاقد اطلاعات مالیاتی</div>`;
        } else {
            html += `<div class="mlr-status-item status-success">✅ فاقد بدهی مالیاتی</div>`;
        }
        html += `</div>`;
        
        // 9. Judiciary
        const jud = data.judiciary && data.judiciary.judiciaryData ? data.judiciary.judiciaryData : {};
        if (jud.sumExecuteCount > 0 || jud.sumNotExecuteCount > 0) {
             html += `<div class="mlr-report-section"><h4><span class="dashicons dashicons-gavel"></span> پرونده‌های قضایی</h4>
             <div class="mlr-report-grid">
                <div><span>پرونده‌های اجرا شده:</span> <strong>${jud.sumExecuteCount}</strong></div>
                <div><span>پرونده‌های اجرا نشده:</span> <strong>${jud.sumNotExecuteCount}</strong></div>
                <div><span>محکومیت اجرا نشده:</span> <strong>${fmt(jud.sumNotExecuteSumPenaltyAmount)} ریال</strong></div>
             </div></div>`;
        }

        // Save full report JSON to hidden input for submission
        $('#credit_report_json').val(JSON.stringify(data));

        html += '</div>'; // End .mlr-credit-report
        $('#mlr-credit-score-display').html(html);
    }

    $('#birth_day, #birth_month, #birth_year').on('change', function() {
        const year = $('#birth_year').val(); const month = $('#birth_month').val(); const day = $('#birth_day').val();
        if (year && month && day) {
            // Store as jalali string (backend should handle conversion if needed or store as is)
            $('input[name="birth_date"]').val(`${year}/${String(month).padStart(2, '0')}/${String(day).padStart(2, '0')}`);
        } else {
            $('input[name="birth_date"]').val('');
        }
        validateStep4();
    });

    function updateProductTotal() {
        let grandTotal = 0;
        $('.mlr-product-row').each(function() {
            const price = parseFormattedNumber($(this).find('.product-price').val());
            const qty = parseInt($(this).find('.product-qty').val()) || 0;
            grandTotal += price * qty;
            $(this).find('.product-row-total').text(formatNumber(price * qty) + ' ریال');
        });
        $('#order_total').val(grandTotal);
        $('#display_product_total').text(formatNumber(grandTotal));
        const summaryDiv = $('.mlr-product-total-summary');
        summaryDiv.removeClass('match mismatch');
        if (grandTotal === loanAmountForProducts && grandTotal > 0) {
            summaryDiv.addClass('match');
        } else {
            summaryDiv.addClass('mismatch');
        }
        validateStep4();
    }

    $('#mlr-product-repeater').on('keyup input change', '.product-price, .product-qty', updateProductTotal);
    $('#mlr-product-repeater').on('blur', '.product-price', function() { $(this).val(formatNumber(parseFormattedNumber($(this).val()))); });
    $('#mlr-add-product-btn').on('click', () => {
        const newRow = $('.mlr-product-row:first').clone();
        newRow.find('input').val(''); newRow.find('.product-qty').val('1'); newRow.find('.product-row-total').text('0 ریال'); newRow.find('.mlr-remove-product-btn').show();
        $('#mlr-product-repeater').append(newRow); updateProductTotal();
    });
    $('#mlr-product-repeater').on('click', '.mlr-remove-product-btn', function() {
        if ($('.mlr-product-row').length > 1) { $(this).closest('.mlr-product-row').remove(); updateProductTotal(); }
    });

    $('.mlr-next-btn').on('click', function() {
        if ($(this).is(':disabled')) return;
        const targetStep = $(this).data('target-step');
        if ($(this).attr('id') === 'next_step_2') {
            loanAmountForProducts = parseFormattedNumber($('#calc_amount').val());
            $('#display_loan_amount').text(formatNumber(loanAmountForProducts));
            updateProductTotal();
            goToStep(requiresBankValidation ? 3 : 4);
        } else if (targetStep === 5) {
            let productData = [];
            $('.mlr-product-row').each(function() { productData.push({ id: $(this).find('.product-id').val().trim(), name: $(this).find('.product-name').val().trim(), price: parseFormattedNumber($(this).find('.product-price').val()), qty: parseInt($(this).find('.product-qty').val()) }); });
            $('#order_items_json').val(JSON.stringify(productData));
            if (documentsSectionPlanId === selectedPlan.id && $('#dynamic-documents .mlr-doc-upload-group').length > 0) {
                goToStep(5);
            } else {
                updateDynamicDocuments(function() {
                    documentsSectionPlanId = selectedPlan.id;
                    goToStep(5);
                });
            }
        } else {
            goToStep(targetStep);
        }
    });
    
    $('.mlr-prev-btn').on('click', function() {
        let targetStep = $(this).data('target-step');
        if (currentStep === 4 && !requiresBankValidation) {
            goToStep(2);
        } else {
            goToStep(targetStep);
        }
    });

    $('#final-submit-btn').on('click', function() {
        const btn = $(this);
        const feedbackDiv = $('#mlr-submission-feedback');

        validateStep5();
        if (btn.is(':disabled')) {
            feedbackDiv.html('<div id="mlr-message" class="mlr-error" style="display:block;">لطفا تمام مدارک الزامی را بارگذاری نمایید و تا پایان آپلود هر فایل صبر کنید.</div>');
            return;
        }

        btn.prop('disabled', true).text('در حال ارسال...');
        feedbackDiv.html('<div id="mlr-message" class="mlr-loading" style="display:block;">لطفاً صبر کنید...</div>');

        var formData = new FormData();
        var $form = form;
        $.each($form.serializeArray(), function(i, field) {
            if (field.name)
                formData.append(field.name, field.value);
        });
        formData.set('action', 'mlr_submit_loan_request');
        formData.set('_wpnonce', mlr_form_ajax.submit_nonce);

        $.ajax({
            url: mlr_form_ajax.ajax_url, type: 'POST', data: formData, processData: false, contentType: false,
        }).done(function(response) {
            if (response.success) {
                feedbackDiv.html('<div id="mlr-message" class="mlr-success" style="display:block;">' + response.data.message + '</div>');
                setTimeout(function() { window.location.href = response.data.redirect_url; }, 2000);
            } else {
                feedbackDiv.html('<div id="mlr-message" class="mlr-error" style="display:block;">' + (response.data.message || 'خطای ناشناخته رخ داد.') + '</div>');
                btn.prop('disabled', false).text('ارسال نهایی درخواست');
            }
        }).fail(function() {
            feedbackDiv.html('<div id="mlr-message" class="mlr-error" style="display:block;">خطا در ارتباط با سرور.</div>');
            btn.prop('disabled', false).text('ارسال نهایی درخواست');
        });
    });
    
    goToStep(1);
});