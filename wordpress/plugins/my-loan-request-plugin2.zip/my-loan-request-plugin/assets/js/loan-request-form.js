jQuery(document).ready(function($) {
    if ($('#mlr-loan-request-form-main').length === 0) return;

    let currentStep = 1;
    let selectedPlan = null;
    let requiresBankValidation = false;
    let loanAmountForProducts = 0;
    const form = $('#mlr-loan-request-form-main');
    
    function parseFormattedNumber(str) {
        if (!str) return 0;
        const persianNumbersMap = { '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9' };
        let englishStr = String(str);
        englishStr = englishStr.replace(/[۰-۹]/g, (match) => persianNumbersMap[match]);
        englishStr = englishStr.replace(/[٬,.]|\s/g, '');
        return parseInt(englishStr, 10) || 0;
    }

    function formatNumber(num) {
        if (!num || isNaN(num)) return '';
        return new Intl.NumberFormat('fa-IR').format(num);
    }

    function showError(element, message) {
        element.addClass('is-invalid');
        element.closest('.mlr-form-group').find('.mlr-error-message').text(message).show();
    }

    function hideError(element) {
        element.removeClass('is-invalid');
        element.closest('.mlr-form-group').find('.mlr-error-message').hide();
    }

    function validateStep1() {
        let isStepValid = true;
        const nationalCode = $('#national_code_verify');
        const mobileNumber = $('#mobile_number_verify');

        if (!/^\d{10}$/.test(nationalCode.val())) {
            showError(nationalCode, 'کد ملی باید ۱۰ رقم باشد.');
            isStepValid = false;
        } else {
            hideError(nationalCode);
        }

        if (!/^09\d{9}$/.test(mobileNumber.val())) {
            showError(mobileNumber, 'شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.');
            isStepValid = false;
        } else {
            hideError(mobileNumber);
        }

        $('#verify_shahkar_btn').prop('disabled', !isStepValid);
    }

    function validateStep2() {
        const planSelect = $('#calc_plan_select');
        const amountInput = $('#calc_amount');
        const intervalInput = $('#calc_interval');
        
        const amount = parseFormattedNumber(amountInput.val());
        const interval = parseInt(intervalInput.val());

        const minAmount = selectedPlan ? parseInt(selectedPlan.view_settings.min_amount) : 0;
        const maxAmount = selectedPlan ? parseInt(selectedPlan.view_settings.max_amount) : Infinity;
        const minInterval = selectedPlan ? parseInt(selectedPlan.view_settings.min_interval) : 1;
        const maxInterval = selectedPlan ? parseInt(selectedPlan.view_settings.max_interval) : 12;
        
        let isStepValid = true;

        if (!planSelect.val()) {
            showError(planSelect, 'انتخاب طرح الزامی است.');
            isStepValid = false;
        } else {
            hideError(planSelect);
        }

        if (!selectedPlan || amount < minAmount || amount > maxAmount) {
            const minText = selectedPlan ? formatNumber(minAmount) : '...';
            const maxText = selectedPlan ? formatNumber(maxAmount) : '...';
            showError(amountInput, `مبلغ باید بین ${minText} و ${maxText} باشد.`);
            isStepValid = false;
        } else {
            hideError(amountInput);
        }

        // --- START: New validation for interval ---
        if (selectedPlan && selectedPlan.type === 'leasing') {
            if (isNaN(interval) || interval < minInterval || interval > maxInterval) {
                showError(intervalInput, `فاصله اقساط باید بین ${minInterval} و ${maxInterval} ماه باشد.`);
                isStepValid = false;
            } else {
                hideError(intervalInput);
            }
        } else {
            hideError(intervalInput); // Hide error if not a leasing plan
        }
        // --- END: New validation for interval ---

        $('#run_calculator').prop('disabled', !isStepValid);
        if ($('#calculation-result').find('.mlr-error').length > 0 || $('#calculation-result').is(':empty')) {
             $('#next_step_2').prop('disabled', true);
        }
    }

    function validateStep4() {
        let isStepValid = true;
        
        const fullName = $('#full_name');
        if (fullName.val().trim() === '') {
            showError(fullName, 'نام و نام خانوادگی الزامی است.'); isStepValid = false;
        } else {
            hideError(fullName);
        }

        const birthDateError = $('#birthdate-error');
        if ($('#birth_year').val() === '' || $('#birth_month').val() === '' || $('#birth_day').val() === '') {
            birthDateError.show(); isStepValid = false;
        } else {
            birthDateError.hide();
        }

        const occupation = $('#occupation');
        if (occupation.val() === '') {
            showError(occupation, 'انتخاب شغل الزامی است.'); isStepValid = false;
        } else {
            hideError(occupation);
        }

        const resAddress = $('#residential_address');
        if (resAddress.val().trim() === '') {
            showError(resAddress, 'آدرس محل سکونت الزامی است.'); isStepValid = false;
        } else {
            hideError(resAddress);
        }

        const workAddress = $('#work_address');
        if (workAddress.val().trim() === '') {
            showError(workAddress, 'آدرس محل فعالیت الزامی است.'); isStepValid = false;
        } else {
            hideError(workAddress);
        }
        
        const postalCode = $('#postal_code');
        if (!/^\d{10}$/.test(postalCode.val())) {
            showError(postalCode, 'کد پستی ۱۰ رقمی الزامی است.'); isStepValid = false;
        } else {
            hideError(postalCode);
        }

        let productTotal = 0;
        let productsValid = true;
        const productError = $('#product-error');
        if ($('.mlr-product-row').length === 0) {
            productsValid = false;
        }
        $('.mlr-product-row').each(function() {
            const name = $(this).find('.product-name').val().trim();
            const price = parseFormattedNumber($(this).find('.product-price').val());
            const qty = parseInt($(this).find('.product-qty').val());
            if (!name || isNaN(price) || price <= 0 || isNaN(qty) || qty <= 0) {
                productsValid = false;
            }
            productTotal += price * qty;
        });

        if (!productsValid || productTotal !== loanAmountForProducts) {
            productError.show(); isStepValid = false;
        } else {
            productError.hide();
        }
        
        $('#next_step_4').prop('disabled', !isStepValid);
    }

    function validateStep5() {
        let allFilesValid = true;
        $('#dynamic-documents input[type="file"][required]').each(function() {
            if ($(this).get(0).files.length === 0) {
                allFilesValid = false;
            }
        });
        $('#final-submit-btn').prop('disabled', !allFilesValid);
    }

    function goToStep(stepNumber) {
        $('.mlr-step-content').removeClass('is-active');
        $('#step' + stepNumber).addClass('is-active');

        $('.mlr-step-item').each(function() {
            const stepId = $(this).data('step-id');
            $(this).removeClass('is-active is-completed');
            if (stepId < stepNumber) { $(this).addClass('is-completed'); } 
            else if (stepId === stepNumber) { $(this).addClass('is-active'); }
        });
        currentStep = stepNumber;
        if (stepNumber === 1) validateStep1();
        if (stepNumber === 2) validateStep2();
        if (stepNumber === 4) validateStep4();
        if (stepNumber === 5) validateStep5();
    }

    function updateDynamicDocuments() {
        if (!selectedPlan) return;
        $('#dynamic-documents').html('<p class="mlr-loading">در حال بارگذاری مدارک مورد نیاز...</p>');
        $.post(mlr_form_ajax.ajax_url, {
            action: 'mlr_get_plan_documents', nonce: mlr_form_ajax.nonce, plan_id: selectedPlan.id
        }, function(response) {
            if (response.success && Array.isArray(response.data) && response.data.length > 0) {
                let documentsHtml = '';
                response.data.forEach(function(doc) {
                    documentsHtml += `<div class="mlr-form-group"><label for="doc_${doc.key}">${doc.label}:</label><input type="file" name="${doc.multiple ? `${doc.key}[]` : doc.key}" id="doc_${doc.key}" class="mlr-input" ${doc.multiple ? 'multiple' : ''} required></div>`;
                });
                $('#dynamic-documents').html(documentsHtml);
            } else {
                $('#dynamic-documents').html('<p>برای این طرح، مدرکی جهت بارگذاری مورد نیاز نیست.</p>');
            }
            validateStep5();
        }).fail(() => { $('#dynamic-documents').html('<p class="mlr-error">خطا در بارگذاری لیست مدارک.</p>'); validateStep5(); });
    }

    $('#national_code_verify, #mobile_number_verify').on('keyup input', validateStep1);
    $('#calc_plan_select, #calc_amount, #calc_interval').on('change keyup input', validateStep2);
    $('#step4').on('keyup input change', 'input, select, textarea', validateStep4);
    $('#dynamic-documents').on('change', 'input[type="file"]', validateStep5);

    $('#verify_shahkar_btn').on('click', function() {
        // ... (این بخش بدون تغییر باقی می‌ماند) ...
        const btn = $(this), msgDiv = $('#mlr-message');
        btn.prop('disabled', true).text('در حال بررسی...');
        msgDiv.html('درحال ارسال اطلاعات...').removeClass().addClass('mlr-loading').fadeIn();
        $.post(mlr_form_ajax.ajax_url, {
            action: 'mlr_verify_shahkar', nonce: mlr_form_ajax.nonce, national_code: $('#national_code_verify').val(), mobile_number: $('#mobile_number_verify').val()
        }).done(function(res) {
            if (res.success) {
                msgDiv.html('✅ ' + res.data.message).removeClass().addClass('mlr-success');
                $('#national_code').val($('#national_code_verify').val());
                $('#mobile_number').val($('#mobile_number_verify').val());
                setTimeout(() => { goToStep(2); msgDiv.fadeOut().empty(); }, 1500);
            } else {
                msgDiv.html('❌ ' + (res.data.message || 'خطا')).removeClass().addClass('mlr-error');
                btn.prop('disabled', false).text('بررسی تطابق و ادامه');
            }
        }).fail(() => { msgDiv.html('خطای سرور.').removeClass().addClass('mlr-error'); btn.prop('disabled', false).text('بررسی تطابق و ادامه'); });
    });
    
    $('#calc_plan_select').on('change', function() {
        const selectedPlanId = $(this).val();
        $('#calculation-result').empty().hide();
        $('#next_step_2').prop('disabled', true);
        const amountInput = $('#calc_amount');
        const intervalInput = $('#calc_interval');
        if (!selectedPlanId) {
            $('#calc_installments').html(''); selectedPlan = null; validateStep2(); return;
        }
        selectedPlan = mlr_form_ajax.plans.find(p => p.id == selectedPlanId);
        if (!selectedPlan) return;
        const viewSettings = selectedPlan.view_settings;
        requiresBankValidation = viewSettings.requires_bank_validation == 1;
        $('#step-indicator-3').toggle(requiresBankValidation);
        if (viewSettings.active_installments) {
            const installmentsOptions = viewSettings.active_installments.split(',');
            let optionsHtml = '';
            installmentsOptions.forEach(function(inst) { optionsHtml += `<option value="${inst.trim()}">${inst.trim()} ماه</option>`; });
            $('#calc_installments').html(optionsHtml);
        }
        if (viewSettings.min_amount && viewSettings.max_amount) {
            amountInput.attr({'min': viewSettings.min_amount, 'max': viewSettings.max_amount, 'placeholder': `بین ${formatNumber(viewSettings.min_amount)} تا ${formatNumber(viewSettings.max_amount)} ریال`});
        }
        amountInput.off('keyup.formatter').on('keyup.formatter', function(e) {
            if (['ArrowLeft', 'ArrowRight', 'Backspace', 'Delete', 'Tab'].includes(e.key)) return;
            let rawValue = parseFormattedNumber($(this).val());
            $(this).val(formatNumber(rawValue));
        });
        if (selectedPlan.type === 'leasing') {
            $('#calc_interval_wrapper').slideDown(); 
            $('#calc_amount_label').text('مبلغ خرید (ریال):');
            if (viewSettings.min_interval && viewSettings.max_interval) {
                intervalInput.attr({ 'min': viewSettings.min_interval, 'max': viewSettings.max_interval });
                intervalInput.val(viewSettings.min_interval);
            }
        } else {
            $('#calc_interval_wrapper').slideUp(); 
            $('#calc_amount_label').text('مبلغ تسهیلات (ریال):');
        }
        validateStep2();
    });

    $('#run_calculator').on('click', function() {
        // ... (این بخش بدون تغییر باقی می‌ماند) ...
        const resultDiv = $('#calculation-result');
        const data = { action: 'mlr_frontend_calculate_loan', nonce: mlr_form_ajax.calc_nonce, plan_id: selectedPlan.id, amount: parseFormattedNumber($('#calc_amount').val()), installments: $('#calc_installments').val(), installment_interval: $('#calc_interval').val(), user_commission: mlr_form_ajax.user_commission };
        resultDiv.html('<p class="mlr-loading">در حال محاسبه...</p>').slideDown();
        $('#next_step_2').prop('disabled', true);
        $.post(mlr_form_ajax.ajax_url, data, function(response) {
            if (response.success) {
                resultDiv.html(response.data.html).removeClass('mlr-error');
                $('#next_step_2').prop('disabled', false);
            } else {
                resultDiv.html('<p class="mlr-error">' + (response.data.message || 'خطای ناشناخته') + '</p>').addClass('mlr-error');
            }
        });
    });

    $('#birth_day, #birth_month, #birth_year').on('change', function() {
        // ... (این بخش بدون تغییر باقی می‌ماند) ...
        const year = $('#birth_year').val(); const month = $('#birth_month').val(); const day = $('#birth_day').val();
        if (year && month && day) {
            $('input[name="birth_date"]').val(`${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`);
        } else {
            $('input[name="birth_date"]').val('');
        }
        validateStep4();
    });

    function updateProductTotal() {
        // ... (این بخش بدون تغییر باقی می‌ماند) ...
        let grandTotal = 0;
        $('.mlr-product-row').each(function() {
            const price = parseFormattedNumber($(this).find('.product-price').val());
            const qty = parseInt($(this).find('.product-qty').val()) || 0;
            grandTotal += price * qty;
            $(this).find('.product-row-total').text(formatNumber(price * qty) + ' ریال');
        });
        $('#display_product_total').text(formatNumber(grandTotal));
        const summaryDiv = $('.mlr-product-total-summary');
        summaryDiv.removeClass('match mismatch');
        if (grandTotal === loanAmountForProducts && grandTotal > 0) {
            summaryDiv.addClass('match');
        } else {
            summaryDiv.addClass('mismatch');
        }
        validateStep4();
    }

    $('#mlr-product-repeater').on('keyup input change', '.product-price, .product-qty', updateProductTotal);
    $('#mlr-product-repeater').on('blur', '.product-price', function() { $(this).val(formatNumber(parseFormattedNumber($(this).val()))); });
    $('#mlr-add-product-btn').on('click', () => {
        const newRow = $('.mlr-product-row:first').clone();
        newRow.find('input').val(''); newRow.find('.product-qty').val('1'); newRow.find('.product-row-total').text('0 ریال'); newRow.find('.mlr-remove-product-btn').show();
        $('#mlr-product-repeater').append(newRow); updateProductTotal();
    });
    $('#mlr-product-repeater').on('click', '.mlr-remove-product-btn', function() {
        if ($('.mlr-product-row').length > 1) { $(this).closest('.mlr-product-row').remove(); updateProductTotal(); }
    });

    $('.mlr-next-btn').on('click', function() {
        // ... (این بخش بدون تغییر باقی می‌ماند) ...
        if ($(this).is(':disabled')) return;
        const targetStep = $(this).data('target-step');
        if ($(this).attr('id') === 'next_step_2') {
            loanAmountForProducts = parseFormattedNumber($('#calc_amount').val());
            $('#display_loan_amount').text(formatNumber(loanAmountForProducts));
            updateProductTotal();
            goToStep(requiresBankValidation ? 3 : 4);
        } else if (targetStep === 5) {
            let productData = [];
            $('.mlr-product-row').each(function() { productData.push({ id: $(this).find('.product-id').val().trim(), name: $(this).find('.product-name').val().trim(), price: parseFormattedNumber($(this).find('.product-price').val()), qty: parseInt($(this).find('.product-qty').val()) }); });
            $('#order_items_json').val(JSON.stringify(productData));
            updateDynamicDocuments();
            goToStep(5);
        } else {
            goToStep(targetStep);
        }
    });
    
    $('.mlr-prev-btn').on('click', function() {
        // ... (این بخش بدون تغییر باقی می‌ماند) ...
        let targetStep = $(this).data('target-step');
        if (currentStep === 4 && !requiresBankValidation) {
            goToStep(2);
        } else {
            goToStep(targetStep);
        }
    });

    $('#final-submit-btn').on('click', function() {
        // ... (این بخش بدون تغییر باقی می‌ماند) ...
        const btn = $(this);
        const feedbackDiv = $('#mlr-submission-feedback');
        
        validateStep5();
        if (btn.is(':disabled')) {
            feedbackDiv.html('<div id="mlr-message" class="mlr-error" style="display:block;">لطفا تمام مدارک الزامی را بارگذاری نمایید.</div>');
            return;
        }

        btn.prop('disabled', true).text('در حال ارسال...');
        feedbackDiv.html('<div id="mlr-message" class="mlr-loading" style="display:block;">لطفاً صبر کنید...</div>');

        const formData = new FormData(form[0]);
        formData.append('action', 'mlr_submit_loan_request');
        formData.append('_wpnonce', mlr_form_ajax.submit_nonce);

        $.ajax({
            url: mlr_form_ajax.ajax_url, type: 'POST', data: formData, processData: false, contentType: false,
        }).done(function(response) {
            if (response.success) {
                feedbackDiv.html('<div id="mlr-message" class="mlr-success" style="display:block;">' + response.data.message + '</div>');
                setTimeout(() => { window.location.href = response.data.redirect_url; }, 2000);
            } else {
                feedbackDiv.html('<div id="mlr-message" class="mlr-error" style="display:block;">' + (response.data.message || 'خطای ناشناخته رخ داد.') + '</div>');
                btn.prop('disabled', false).text('ارسال نهایی درخواست');
            }
        }).fail(function() {
            feedbackDiv.html('<div id="mlr-message" class="mlr-error" style="display:block;">خطا در ارتباط با سرور.</div>');
            btn.prop('disabled', false).text('ارسال نهایی درخواست');
        });
    });
    
    goToStep(1);
});