<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class MLR_MeliPayamak_Provider
 * Handles all interactions with the MeliPayamak web service based on official documentation.
 */
class MLR_MeliPayamak_Provider {
    private $credentials;
    private $send_wsdl = 'http://api.payamak-panel.com/post/send.asmx?wsdl';

    public function __construct() {
        $settings = get_option('mlr_sms_settings', []);
        $this->credentials = [
            'username' => $settings['username'] ?? '',
            'password' => $settings['password'] ?? '',
        ];
    }

    /**
     * Sends an SMS using a pre-defined pattern (template).
     *
     * @param string $to Recipient mobile number.
     * @param int $pattern_id The Body ID of the pattern on MeliPayamak.
     * @param array $variables An array of strings to replace placeholders like {0}, {1}, {2}.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public function send_pattern($to, $pattern_id, $variables) {
        mlr_log("Attempting to send pattern SMS to {$to} with Body ID {$pattern_id}.");
        if (!class_exists('SoapClient')) {
            mlr_log('SOAP Client class does not exist.');
            return new WP_Error('soap_inactive', 'افزونه SOAP در هاست شما فعال نیست.');
        }
        if (empty($this->credentials['username']) || empty($this->credentials['password'])) {
            mlr_log('SMS credentials are not set.');
            return new WP_Error('credentials_missing', 'نام کاربری یا رمز عبور پنل پیامک وارد نشده است.');
        }

        // Validate mobile number format
        if (!preg_match('/^09\d{9}$/', $to)) {
             mlr_log("Invalid mobile number format for sending pattern SMS: {$to}");
             return new WP_Error('invalid_mobile', 'فرمت شماره موبایل گیرنده نامعتبر است.');
        }

        try {
            ini_set("soap.wsdl_cache_enabled", "0");
            $client = new SoapClient($this->send_wsdl, [
                'encoding' => 'UTF-8',
                'connection_timeout' => 15 // Connection timeout in seconds
            ]);

            $parameters = [
                'username' => $this->credentials['username'],
                'password' => $this->credentials['password'],
                'to'       => $to,
                'bodyId'   => (int)$pattern_id,
                'text'     => implode(';', $variables), // Variables separated by semicolon
            ];

            mlr_log(['Sending pattern SMS with parameters:' => $parameters]); // Log parameters before sending

            // Execute the SOAP call
            $result = $client->SendByBaseNumber2($parameters)->SendByBaseNumber2Result;

            mlr_log(['Send pattern SMS result:' => $result]); // Log the result

            // MeliPayamak returns a long string (message ID) on success, or an error code
            if (is_numeric($result) && strlen($result) > 10) { // Check if it looks like a message ID
                return true; // Success
            } else {
                return new WP_Error('sms_api_error', $this->get_pattern_error_message($result)); // Failure
            }
        } catch (SoapFault $e) {
            mlr_log('SOAP Fault (Send Pattern): ' . $e->getMessage());
            // Log request/response for debugging SOAP issues
            if (isset($client) && is_object($client) && method_exists($client, '__getLastRequestHeaders')) { // Check if client exists and has methods
                 mlr_log(['SOAP Last Request Headers:' => $client->__getLastRequestHeaders()]);
                 mlr_log(['SOAP Last Request Body:' => $client->__getLastRequest()]);
                 mlr_log(['SOAP Last Response Headers:' => $client->__getLastResponseHeaders()]);
                 mlr_log(['SOAP Last Response Body:' => $client->__getLastResponse()]);
            }
            return new WP_Error('soap_fault', 'خطای SOAP در ارسال پیامک: ' . $e->getMessage());
        } catch (Exception $e) {
            mlr_log('General Exception (Send Pattern): ' . $e->getMessage());
            return new WP_Error('soap_connection_error', 'خطا در اتصال به سرور ملی پیامک (ارسال): ' . $e->getMessage());
        }
    }

    /**
     * Gets the current credit balance from MeliPayamak.
     *
     * @return string|WP_Error Formatted credit balance on success, WP_Error on failure.
     */
    public function get_credit() {
        mlr_log('--- Starting GetCredit Process ---');
        if (!class_exists('SoapClient')) {
            mlr_log('SOAP Client class does not exist.');
            return new WP_Error('soap_inactive', 'افزونه SOAP در هاست شما فعال نیست.');
        }
        if (empty($this->credentials['username']) || empty($this->credentials['password'])) {
            mlr_log('SMS credentials are not set.');
            return new WP_Error('credentials_missing', 'نام کاربری یا رمز عبور پنل پیامک وارد نشده است.');
        }

        $client = null; // Initialize client variable
        try {
            mlr_log('WSDL URL for GetCredit: ' . $this->send_wsdl); // Using the same WSDL
            ini_set("soap.wsdl_cache_enabled", "0");
            $client = new SoapClient($this->send_wsdl, [
                'encoding'           => 'UTF-8',
                'trace'              => 1, // Enable tracing for debugging
                'exceptions'         => true, // Throw exceptions on SOAP faults
                'connection_timeout' => 15,
            ]);

            $params = ['username' => $this->credentials['username'], 'password' => '**********']; // Mask password for logging
            mlr_log(['Requesting credit with parameters:' => $params]);

            // Execute the SOAP call
            $response = $client->GetCredit(['username' => $this->credentials['username'], 'password' => $this->credentials['password']]);

            mlr_log(['Raw SOAP response object (GetCredit):' => $response]);

            // Check if the expected property exists in the response object
            if (!isset($response->GetCreditResult)) {
                 mlr_log('Invalid SOAP response structure for GetCredit. Raw response body: ' . $client->__getLastResponse());
                 return new WP_Error('credit_api_error', 'پاسخ نامعتبر از سرور پیامک (اعتبار) دریافت شد.');
            }

            $result = $response->GetCreditResult;
            mlr_log('GetCreditResult value: ' . $result);

            // MeliPayamak returns credit as a number (float/double) or an error code
            if (is_numeric($result) && $result >= 0) {
                mlr_log('Credit check successful.');
                // Format the number with commas
                return number_format(floatval($result)); // Format the numeric result
            } else {
                mlr_log('Credit check returned an error code or invalid value.');
                return new WP_Error('credit_api_error', $this->get_credit_error_message($result));
            }

        } catch (SoapFault $e) {
            mlr_log('SOAP Fault (Get Credit): ' . $e->getMessage());
            // Log request/response for debugging SOAP faults
            if (isset($client) && is_object($client) && method_exists($client, '__getLastRequestHeaders')) { // Check if client exists and has methods
                mlr_log(['SOAP Last Request Headers (GetCredit):' => $client->__getLastRequestHeaders()]);
                mlr_log(['SOAP Last Request Body (GetCredit):' => $client->__getLastRequest()]);
                mlr_log(['SOAP Last Response Headers (GetCredit):' => $client->__getLastResponseHeaders()]);
                mlr_log(['SOAP Last Response Body (GetCredit):' => $client->__getLastResponse()]);
            }
            return new WP_Error('soap_fault', 'خطای SOAP در بررسی اعتبار: ' . $e->getMessage());
        } catch (Exception $e) {
            mlr_log('General Exception (Get Credit): ' . $e->getMessage());
            return new WP_Error('soap_connection_error', 'خطا در اتصال به سرور ملی پیامک (اعتبار). لطفاً از فعال بودن پورت SOAP در هاست خود اطمینان حاصل کنید.');
        }
    }

    /**
     * Maps MeliPayamak pattern sending error codes to readable messages.
     *
     * @param string|int $code The error code returned by the API.
     * @return string The error message.
     */
    private function get_pattern_error_message($code) {
        $messages = [
            '0' => 'نام کاربری یا رمز عبور صحیح نمی‌باشد.',
            '1' => 'اعتبار کافی نمی‌باشد.',
            '2' => 'دسترسی برای استفاده از این وب‌سرویس غیرفعال است.',
            '3' => 'محدودیت تعداد شماره (ارسال به بیش از 100 شماره در هر فراخوانی).',
            '4' => 'شناسه قالب (Body ID) صحیح نمی‌باشد.',
            '5' => 'متغیرهای ارسالی با تعداد متغیرهای تعریف شده در متن پیش‌فرض همخوانی ندارد.',
            '6' => 'سامانه در حال بروزرسانی می‌باشد.',
            '7' => 'متن حاوی کلمه فیلتر شده است.',
            '10' => 'کاربر مورد نظر فعال نمی‌باشد.',
            '11' => 'ارسال نشده.',
            '12' => 'مدارک کاربر کامل نمی‌باشد.',
            '18' => 'شماره موبایل گیرنده معتبر نمی‌باشد.',
            // Add more codes as documented or discovered
        ];
        return $messages[strval($code)] ?? 'خطای نامشخص در ارسال پیامک با کد: ' . esc_html($code);
    }

    /**
     * Maps MeliPayamak credit check error codes to readable messages.
     *
     * @param string|int $code The error code returned by the API.
     * @return string The error message.
     */
    private function get_credit_error_message($code) {
        $messages = [
            '-1' => 'نام کاربری و رمز عبور صحیح نمی‌باشد.',
            '-2' => 'کاربر غیرفعال می‌باشد.',
            // Add more codes if documented
        ];
        return $messages[strval($code)] ?? 'پاسخ نامشخص از وب‌سرویس اعتبار (کد: ' . esc_html($code) . ')';
    }

    /**
     * Sends an OTP using a pre-defined pattern.
     *
     * @param string $to Recipient mobile number.
     * @param int $pattern_id The Body ID of the OTP pattern on MeliPayamak.
     * @param array $variables An array containing the OTP code and potentially other variables based on settings.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public function send_otp_pattern($to, $pattern_id, $variables) {
        mlr_log('Attempting to send OTP pattern SMS.');
        // Re-use the send_pattern logic for OTP as well
        return $this->send_pattern($to, $pattern_id, $variables);
    }
}


// ===================================================================
// Cooperation Requests SMS Functions
// ===================================================================

/**
 * Returns the list of possible statuses for cooperation requests.
 *
 * @return array List of status strings.
 */
function mlr_get_cooperation_statuses() {
    // Ensure 'عقد قرارداد' is included
    return ['در حال بررسی', 'نقص مدارک', 'تکمیل مدارک', 'تایید مدارک', 'عقد قرارداد', 'انصراف', 'رد شده'];
}

/**
 * Returns the available placeholders for cooperation request SMS templates.
 *
 * @return array Associative array of placeholder => description.
 */
function mlr_get_cooperation_placeholders() {
    return [
        '[[request_id]]' => 'شناسه درخواست',
        '[[status]]' => 'وضعیت جدید',
        '[[store_name]]' => 'نام فروشگاه (برای حقیقی)',
        '[[store_owner_name]]' => 'نام مالک فروشگاه (برای حقیقی)',
        '[[company_name]]' => 'نام شرکت (برای حقوقی)',
        '[[contact_person]]' => 'نام رابط (برای حقوقی)',
        '[[applicant_name]]' => 'نام متقاضی (مالک/رابط)', // Combined for convenience
        '[[contract_link]]' => 'توکن (کد) قرارداد آنلاین', // Description changed
        '[[otp_code]]' => 'کد تایید امضا (فقط برای الگوی OTP)',
    ];
}

/**
 * Replaces placeholders in an SMS template string with actual data from a cooperation request.
 *
 * @param string $string The template string containing placeholders.
 * @param object $request The cooperation request object from the database.
 * @param string|null $otp_code Optional OTP code to include.
 * @return string The processed string with placeholders replaced.
 */
function mlr_replace_cooperation_placeholders($string, $request, $otp_code = null) { // Added $otp_code parameter
    // Decode the JSON data safely
    $request_data = json_decode($request->data, true);
    if (!is_array($request_data)) $request_data = []; // Ensure it's an array to prevent errors

    // Determine applicant name based on type
    $applicant_name = ($request->request_type === 'individual')
        ? ($request_data['store_owner_name'] ?? '')
        : ($request_data['contact_person'] ?? '');

    // Get only the token for contract_link placeholder
    $contract_token_only = $request->contract_token ?? ''; // Get the token itself

    // Define all replacements
    $replacements = [
        '[[request_id]]'       => $request->id ?? 'N/A', // Use null coalescing for safety
        '[[status]]'           => $request->status ?? 'N/A',
        '[[store_name]]'       => $request_data['store_name'] ?? '',
        '[[store_owner_name]]' => $request_data['store_owner_name'] ?? '',
        '[[company_name]]'     => $request_data['company_name'] ?? '',
        '[[contact_person]]'   => $request_data['contact_person'] ?? '',
        '[[applicant_name]]'   => $applicant_name,
        '[[contract_link]]'    => $contract_token_only, // Use token only
        '[[otp_code]]'         => $otp_code ?? '', // Use OTP code if provided
    ];

    // Replace placeholders
    return str_replace(array_keys($replacements), array_values($replacements), $string);
}

/**
 * Sends an SMS notification when a cooperation request status changes.
 *
 * @param int $request_id The ID of the cooperation request.
 * @param string $new_status The new status being set.
 * @param object|null $request_object Optional. The cooperation request object (fetches if null).
 */
function mlr_send_sms_on_cooperation_status_change($request_id, $new_status, $request_object = null) {
    global $wpdb;

    // Fetch the request object if it wasn't passed directly
    if (is_null($request_object)) {
        // Fetch necessary fields including contract_token and data
        $request_object = $wpdb->get_row($wpdb->prepare("SELECT id, request_type, status, data, contract_token FROM {$wpdb->prefix}cooperation_requests WHERE id = %d", $request_id));
    }

    if (!$request_object) {
        mlr_log("SMS Error: Cooperation request object not found for ID {$request_id}");
        return; // Request not found
    }

    // IMPORTANT: Update the status on the passed/fetched object for correct placeholder replacement
    $request_object->status = $new_status;

    // Get SMS settings from WordPress options
    $sms_settings = get_option('mlr_sms_settings', []);
    // Find the specific settings for this new status
    $status_settings = $sms_settings['cooperation_statuses'][$new_status] ?? [];

    // Check if SMS is enabled and a pattern ID (bodyId) is set for this status
    if (empty($status_settings['enabled']) || empty($status_settings['bodyId'])) {
         mlr_log("SMS for cooperation status '{$new_status}' (ID: {$request_id}) is disabled or Body ID is missing.");
        return; // SMS is disabled or pattern ID missing
    }

    // Decode the JSON data stored in the request object
    $request_data = json_decode($request_object->data, true);
    if (!is_array($request_data)) $request_data = []; // Ensure it's an array

    // Get the recipient's mobile number from the request data
    $mobile_number = $request_data['mobile_number'] ?? null;

    // Validate the mobile number format
    if (!$mobile_number || !preg_match('/^09\d{9}$/', $mobile_number)) {
        mlr_log("SMS Error: Invalid or missing mobile number for cooperation request ID {$request_id}. Found: " . ($mobile_number ?? 'NULL'));
        return; // Invalid or missing mobile number
    }

    // Prepare the variables to be sent in the SMS pattern
    $text_variables = [];
    $all_placeholders_used = true; // Flag to check if all placeholders seem replaced
    // Loop through the possible variable fields (var_0, var_1, var_2)
    for ($i = 0; $i < 3; $i++) {
        $var_key = "var_{$i}";
        // Check if the setting for this variable exists and is not empty
        if (!empty($status_settings[$var_key])) {
            // Replace placeholders in the variable text using the request object (pass null for OTP)
            $replaced_text = mlr_replace_cooperation_placeholders($status_settings[$var_key], $request_object, null);
            $text_variables[] = $replaced_text; // Add the processed text to the array

            // Basic check if any placeholder markers remain (indicates missing data or typo)
            // Exclude the [[otp_code]] placeholder from this check as it's intentionally null here
            if (strpos($replaced_text, '[[') !== false && strpos($replaced_text, ']]') !== false && strpos($replaced_text, '[[otp_code]]') === false) {
                $all_placeholders_used = false;
                 mlr_log("SMS Warning: Unreplaced placeholder detected in var_{$i} for cooperation request ID {$request_id}, status '{$new_status}'. Text: '{$replaced_text}'");
            }
        } else {
            // If MeliPayamak requires exactly N variables, even empty ones, add empty string.
             //$text_variables[] = ''; // Or a default value like '-'
        }
    }

    // If no variables were generated (e.g., all settings fields were empty), don't send
    if (empty($text_variables)) {
         mlr_log("SMS Error: No text variables were generated for cooperation request ID {$request_id}, status '{$new_status}'. Check SMS settings variable fields.");
        return;
    }

    // Log if proceeding with potentially unreplaced placeholders
    if (!$all_placeholders_used) {
        mlr_log("SMS Sending Proceeding despite potential unreplaced placeholders for cooperation request ID {$request_id}.");
    }

    // Instantiate the SMS provider class
    $sms_provider = new MLR_MeliPayamak_Provider();
    // Send the SMS using the pattern method
    $result = $sms_provider->send_pattern($mobile_number, $status_settings['bodyId'], $text_variables);

    // Check the result and log accordingly
    if (is_wp_error($result)) {
        // Log the error message if sending failed
        mlr_log('MLR Cooperation SMS Error for Request ID ' . $request_id . ', Status "' . $new_status . '": ' . $result->get_error_message());
        // Optionally, notify the admin about the failure here
    } else {
        // Log success
         mlr_log('MLR Cooperation SMS Sent Successfully for Request ID ' . $request_id . ', Status "' . $new_status . '". Recipient: ' . $mobile_number);
    }
}


// ===================================================================
// Loan Requests SMS Functions
// ===================================================================

/**
 * Returns the list of possible statuses for loan requests relevant for SMS.
 *
 * @return array List of status strings.
 */
function mlr_get_loan_statuses() {
    // These are statuses likely requiring customer notification
    return ['در حال بررسی', 'نقص مدارک', 'تکمیل مدارک', 'تأیید مدارک', 'اعطا شده', 'رد شده'];
}

/**
 * Returns the available placeholders for loan request SMS templates.
 *
 * @return array Associative array of placeholder => description.
 */
function mlr_get_loan_placeholders() {
    return [
        '[[request_id]]' => 'شناسه درخواست',
        '[[status]]' => 'وضعیت جدید',
        '[[full_name]]' => 'نام کامل متقاضی',
        '[[national_code]]' => 'کد ملی متقاضی',
        '[[mobile_number]]' => 'شماره موبایل متقاضی',
        '[[loan_amount]]' => 'مبلغ تسهیلات (ریال)', // Added unit for clarity
        '[[installment_count]]' => 'تعداد اقساط',
        '[[installment_amount]]' => 'مبلغ هر قسط (ریال)', // Added unit for clarity
        '[[plan_name]]' => 'نام طرح تسهیلاتی',
        '[[acceptor_name]]' => 'نام پذیرنده (ثبت کننده درخواست)', // *** ADDED Acceptor Name Placeholder ***
    ];
}

/**
 * Replaces placeholders in an SMS template string with actual data from a loan request.
 *
 * @param string $string The template string containing placeholders.
 * @param object $request The loan request object from the database.
 * @param WP_User|null $acceptor_user Optional. The user object for the acceptor.
 * @return string The processed string with placeholders replaced.
 */
function mlr_replace_loan_placeholders($string, $request, $acceptor_user = null) { // Added $acceptor_user parameter
    global $wpdb;
    $plan_name = '';
    // Fetch the plan name if the plan ID exists on the request object
    if (!empty($request->installment_plan_id)) {
        $plan_name = $wpdb->get_var($wpdb->prepare(
            "SELECT name FROM {$wpdb->prefix}installment_plans WHERE id = %d",
            $request->installment_plan_id
        ));
    }

    // Get acceptor name
    $acceptor_name = '---';
    if ($acceptor_user instanceof WP_User) {
        $acceptor_name = $acceptor_user->display_name;
    } elseif (!empty($request->user_id)) {
        // Fetch acceptor user data if not provided
        $acceptor_info = get_userdata($request->user_id);
        if ($acceptor_info) {
            $acceptor_name = $acceptor_info->display_name;
        }
    }


    // Define all replacements with null coalescing for safety
    $replacements = [
        '[[request_id]]'         => $request->id ?? 'N/A',
        '[[status]]'             => $request->status ?? 'N/A',
        '[[full_name]]'          => $request->full_name ?? '',
        '[[national_code]]'      => $request->national_code ?? '',
        '[[mobile_number]]'      => $request->mobile_number ?? '',
        // Use number_format for currency values, check if they exist first
        '[[loan_amount]]'        => isset($request->loan_amount) ? number_format(floatval($request->loan_amount)) : '0',
        '[[installment_count]]'  => $request->installment_count ?? '0',
        '[[installment_amount]]' => isset($request->installment_amount) ? number_format(floatval($request->installment_amount)) : '0',
        '[[plan_name]]'          => $plan_name ?: '---', // Use '---' if plan name not found
        '[[acceptor_name]]'      => $acceptor_name, // *** ADDED Acceptor Name Replacement ***
    ];

    // Replace placeholders
    return str_replace(array_keys($replacements), array_values($replacements), $string);
}

/**
 * Sends an SMS notification when a loan request status changes, potentially to both applicant and acceptor.
 *
 * @param int $request_id The ID of the loan request.
 * @param string $new_status The new status being set.
 */
function mlr_send_sms_on_loan_status_change($request_id, $new_status) {
    global $wpdb;
    // Fetch the complete loan request object
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}loan_requests WHERE id = %d", $request_id));

    if (!$request) {
        mlr_log("SMS Error: Loan request object not found for ID {$request_id}");
        return; // Exit if request not found
    }

    // IMPORTANT: Update the status on the fetched object for correct placeholder replacement
    $request->status = $new_status;

    // Get SMS settings
    $sms_settings = get_option('mlr_sms_settings', []);
    // Get settings specific to this new status
    $status_settings = $sms_settings['loan_statuses'][$new_status] ?? [];

    // --- Check if SMS is enabled and Body ID exists ---
    if (empty($status_settings['enabled']) || empty($status_settings['bodyId'])) {
         mlr_log("SMS for loan status '{$new_status}' (ID: {$request_id}) is disabled or Body ID is missing.");
        return; // SMS disabled or pattern ID missing
    }

    // --- Determine Recipients ---
    // Default to applicant=ON, acceptor=OFF if settings are not saved for this status yet
    $send_to_applicant = isset($status_settings['send_to_applicant']) ? (bool)$status_settings['send_to_applicant'] : true;
    $send_to_acceptor = isset($status_settings['send_to_acceptor']) ? (bool)$status_settings['send_to_acceptor'] : false;

    // Exit if no recipient is selected
    if (!$send_to_applicant && !$send_to_acceptor) {
        mlr_log("SMS for loan status '{$new_status}' (ID: {$request_id}) is enabled but no recipient (Applicant/Acceptor) is selected.");
        return;
    }

    // --- Get Recipient Mobile Numbers ---
    $applicant_mobile = $request->mobile_number ?? null;
    $acceptor_mobile = null;
    $acceptor_user = null; // Store user object for placeholder

    if ($send_to_acceptor && !empty($request->user_id)) {
        // The 'user_id' column in loan_requests stores the ID of the acceptor (the logged-in user who submitted the request)
        $acceptor_user = get_userdata($request->user_id);
        if ($acceptor_user) {
            // *** USE 'acceptor_mobile_number' meta key first, fallback to 'billing_phone' ***
            $acceptor_mobile = get_user_meta($request->user_id, 'acceptor_mobile_number', true);
            if (empty($acceptor_mobile)) {
                 $acceptor_mobile = get_user_meta($request->user_id, 'billing_phone', true); // Fallback to WooCommerce billing phone
                 if (empty($acceptor_mobile)) {
                      mlr_log("SMS Warning: Acceptor mobile number not found in 'acceptor_mobile_number' or 'billing_phone' meta for User ID: {$request->user_id}. Acceptor SMS skipped.");
                      $acceptor_mobile = null;
                 }
            }

            // Basic validation if mobile was found
            if ($acceptor_mobile) {
                 $acceptor_mobile = preg_replace('/[^0-9]/', '', $acceptor_mobile); // Clean non-digits
                 // Normalize Persian/Arabic numbers if necessary (though preg_replace handles most)
                 $acceptor_mobile = str_replace(['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'], range(0,9), $acceptor_mobile);

                 if (!preg_match('/^09\d{9}$/', $acceptor_mobile)) {
                      mlr_log("SMS Warning: Invalid mobile number format found for acceptor (User ID: {$request->user_id}) on loan request ID {$request_id}. Found: '{$acceptor_mobile}'. Acceptor SMS skipped.");
                      $acceptor_mobile = null; // Invalidate if format is wrong
                 }
            }
        } else {
             mlr_log("SMS Warning: Could not find acceptor user data (User ID: {$request->user_id}) for loan request ID {$request_id}. Acceptor SMS skipped.");
        }
    }

    // Validate applicant mobile
    if ($send_to_applicant) {
        $applicant_mobile = preg_replace('/[^0-9]/', '', $applicant_mobile); // Clean
        $applicant_mobile = str_replace(['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'], range(0,9), $applicant_mobile);
        if (!preg_match('/^09\d{9}$/', $applicant_mobile)) {
            mlr_log("SMS Error: Invalid mobile number for applicant on loan request ID {$request_id}. Found: '{$applicant_mobile}'. Applicant SMS skipped.");
            $applicant_mobile = null; // Invalidate if format is wrong
        }
    } else {
         $applicant_mobile = null; // Not sending to applicant
    }


    // Exit if no valid recipient mobile number found for the selected recipients
    if (!$applicant_mobile && !$acceptor_mobile) {
         mlr_log("SMS Error: No valid recipient mobile numbers found for loan request ID {$request_id}, status '{$new_status}'. SMS not sent.");
        return;
    }


    // --- Prepare SMS Variables ---
    $text_variables = [];
    $all_placeholders_used = true; // Flag for checking replacements
    for ($i = 0; $i < 3; $i++) {
        $var_key = "var_{$i}";
        if (isset($status_settings[$var_key])) { // Use isset to include empty strings
            // Replace placeholders using the request object and acceptor user object
            $replaced_text = mlr_replace_loan_placeholders($status_settings[$var_key], $request, $acceptor_user);
            $text_variables[] = $replaced_text;

            // Basic check for remaining placeholders
            if (strpos($replaced_text, '[[') !== false && strpos($replaced_text, ']]') !== false) {
                $all_placeholders_used = false;
                 mlr_log("SMS Warning: Unreplaced placeholder detected in var_{$i} for loan request ID {$request_id}, status '{$new_status}'. Text: '{$replaced_text}'");
            }
        } else {
             // If MeliPayamak pattern requires exactly N params, send a default/empty value
             // $text_variables[] = '-'; // Send a dash if variable is empty? Adjust as needed.
        }
    }

    // Check if any variables were defined in settings. If yes, $text_variables should not be empty.
    if (empty($text_variables) && (!empty($status_settings["var_0"]) || !empty($status_settings["var_1"]) || !empty($status_settings["var_2"]))) {
        // This case might happen if all defined vars were empty strings
        mlr_log("SMS Info: All variable fields were empty for loan request ID {$request_id}, status '{$new_status}'. Sending pattern with variables: " . implode(';', $text_variables));
    }
    // If no var fields were defined at all, text_variables will be empty, which might be intended (if pattern has 0 params)
    if (empty($text_variables) && empty($status_settings["var_0"]) && empty($status_settings["var_1"]) && empty($status_settings["var_2"])) {
         mlr_log("SMS Info: No variable fields defined for loan request ID {$request_id}, status '{$new_status}'. Sending pattern with 0 variables.");
    }


    if (!$all_placeholders_used) {
        mlr_log("SMS Sending Proceeding despite potential unreplaced placeholders for loan request ID {$request_id}.");
    }

    $sms_provider = new MLR_MeliPayamak_Provider();
    $pattern_id = $status_settings['bodyId'];

    // --- Send to Applicant ---
    if ($send_to_applicant && $applicant_mobile) {
        mlr_log("Attempting SMS to Applicant: {$applicant_mobile} for Request ID {$request->id}");
        $result_applicant = $sms_provider->send_pattern($applicant_mobile, $pattern_id, $text_variables);
        if (is_wp_error($result_applicant)) {
            mlr_log('MLR Loan SMS Error (Applicant) for Request ID ' . $request_id . ', Status "' . $new_status . '": ' . $result_applicant->get_error_message());
        } else {
            mlr_log('MLR Loan SMS Sent Successfully (Applicant) for Request ID ' . $request_id . ', Status "' . $new_status . '". Recipient: ' . $applicant_mobile);
        }
    }

    // --- Send to Acceptor ---
    if ($send_to_acceptor && $acceptor_mobile) {
        // Check if acceptor mobile is different from applicant mobile to avoid duplicates (unless applicant SMS was skipped)
        if ($acceptor_mobile !== $applicant_mobile || !$send_to_applicant || !$applicant_mobile) {
             mlr_log("Attempting SMS to Acceptor: {$acceptor_mobile} for Request ID {$request->id}");
            $result_acceptor = $sms_provider->send_pattern($acceptor_mobile, $pattern_id, $text_variables);
            if (is_wp_error($result_acceptor)) {
                mlr_log('MLR Loan SMS Error (Acceptor) for Request ID ' . $request_id . ', Status "' . $new_status . '": ' . $result_acceptor->get_error_message());
            } else {
                mlr_log('MLR Loan SMS Sent Successfully (Acceptor) for Request ID ' . $request_id . ', Status "' . $new_status . '". Recipient: ' . $acceptor_mobile);
            }
        } else {
             mlr_log("SMS Info: Skipped sending duplicate SMS to acceptor for loan request ID {$request_id} as mobile matches applicant and applicant SMS was already sent (or attempted).");
        }
    }
}
// --- END: Loan Requests SMS Functions ---

?>