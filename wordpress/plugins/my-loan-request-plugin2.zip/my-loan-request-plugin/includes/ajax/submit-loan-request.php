<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_submit_loan_request', 'mlr_submit_loan_request_callback');

function mlr_submit_loan_request_callback() {
    check_ajax_referer('mlr_loan_request_action', '_wpnonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای ثبت درخواست، لطفاً ابتدا وارد شوید.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $errors = [];

    $phone_number = sanitize_text_field($_POST['phone_number'] ?? '');
    $mobile_number = sanitize_text_field($_POST['mobile_number'] ?? '');
    if (empty($phone_number)) $phone_number = $mobile_number;

    $birth_date_jalali = sanitize_text_field($_POST['birth_date'] ?? '');
    $birth_date_gregorian = !empty($birth_date_jalali) ? mlr_jalali_to_gregorian($birth_date_jalali) : null;
    
    $persian_numbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    $loan_amount_str = str_replace([',', '٬'], '', str_replace($persian_numbers, $english_numbers, sanitize_text_field($_POST['loan_amount'] ?? '0')));
    $loan_amount = floatval($loan_amount_str);

    $order_items_json = isset($_POST['order_items']) ? stripslashes($_POST['order_items']) : '[]';
    $order_items_array = json_decode($order_items_json, true);
    $cleaned_items = [];
    if (is_array($order_items_array)) {
        foreach($order_items_array as $item) {
            $cleaned_items[] = ['name' => sanitize_text_field($item['name'] ?? ''), 'id' => sanitize_text_field($item['id'] ?? ''), 'qty' => intval($item['qty'] ?? 1), 'price' => floatval($item['price'] ?? 0)];
        }
    }
    $product_name_string = implode(', ', array_map(fn($item) => $item['name'] . ' (تعداد: ' . $item['qty'] . ')', $cleaned_items));

    $data = [
        'user_id' => get_current_user_id(),
        'full_name' => sanitize_text_field($_POST['full_name'] ?? ''),
        'national_code' => sanitize_text_field($_POST['national_code'] ?? ''),
        'mobile_number' => $mobile_number,
        'phone_number' => $phone_number,
        'birth_date' => $birth_date_gregorian,
        'occupation' => sanitize_text_field($_POST['occupation'] ?? ''),
        'residential_address' => sanitize_textarea_field($_POST['residential_address'] ?? ''),
        'postal_code' => sanitize_text_field($_POST['postal_code'] ?? ''),
        'work_address' => sanitize_textarea_field($_POST['work_address'] ?? ''),
        'product_name' => $product_name_string,
        'order_items' => wp_json_encode($cleaned_items, JSON_UNESCAPED_UNICODE),
        'installment_plan_id' => intval($_POST['installment_plan_id'] ?? 0),
        'loan_amount' => $loan_amount,
        'installment_count' => intval($_POST['installment_count'] ?? 0),
        'installment_interval' => isset($_POST['installment_interval']) ? intval($_POST['installment_interval']) : 1,
        'status' => 'در حال بررسی',
        'created_at' => current_time('mysql'),
        'last_edited_at' => current_time('mysql'),
    ];

    $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $plans_table WHERE id = %d", $data['installment_plan_id']));
    if ($plan) {
        $settings = maybe_unserialize($plan->settings);
        $user_id = get_current_user_id();
        $user_commission = get_user_meta($user_id, 'acceptor_commission_percent', true);
        $calculation_results = [];
        if ($plan->type === 'market') {
            $calculation_results = calculateMarketLoan($data['loan_amount'], $data['installment_count'], $settings, $user_commission);
        } elseif ($plan->type === 'leasing') {
            $calculation_results = calculateLeasingLoan($data['loan_amount'], $data['installment_count'], $data['installment_interval'], $settings, $user_commission);
        }
        if (!empty($calculation_results)) {
            $data['prepayment'] = $calculation_results['prepayment'] ?? 0;
            $data['installment_amount'] = $calculation_results['installmentAmount'] ?? 0;
            $data['wallet_charge'] = $calculation_results['walletCharge'] ?? 0;
            $data['acceptor_payment_amount'] = $calculation_results['acceptorPayment'] ?? 0;
            $data['total_payment'] = $calculation_results['totalPayment'] ?? 0;
            $data['profit'] = $calculation_results['profit'] ?? 0;
            $data['final_settlement_amount'] = $data['acceptor_payment_amount'];
        }
    }

    if (!function_exists('wp_handle_upload')) { require_once(ABSPATH . 'wp-admin/includes/file.php'); }
    $uploaded_documents = [];
    if (!empty($_FILES)) {
        foreach ($_FILES as $file_key => $file_data) {
            $pure_file_key = str_replace('[]', '', $file_key);
            if (is_array($file_data['name'])) {
                $file_urls = [];
                foreach ($file_data['name'] as $key => $name) {
                    if ($file_data['error'][$key] === UPLOAD_ERR_OK) {
                        $single_file = ['name' => $file_data['name'][$key], 'type' => $file_data['type'][$key], 'tmp_name' => $file_data['tmp_name'][$key], 'error' => $file_data['error'][$key], 'size' => $file_data['size'][$key]];
                        $movefile = wp_handle_upload($single_file, ['test_form' => false]);
                        if ($movefile && !isset($movefile['error'])) { $file_urls[] = $movefile['url']; } else { $errors[] = "خطا در آپلود فایل {$name}: " . ($movefile['error'] ?? 'خطای نامشخص'); }
                    }
                }
                if (!empty($file_urls)) { $uploaded_documents[$pure_file_key] = $file_urls; }
            } elseif ($file_data['error'] === UPLOAD_ERR_OK) {
                $movefile = wp_handle_upload($file_data, ['test_form' => false]);
                if ($movefile && !isset($movefile['error'])) { $uploaded_documents[$pure_file_key] = $movefile['url']; } else { $errors[] = "خطا در آپلود فایل {$file_data['name']}: " . ($movefile['error'] ?? 'خطای نامشخص'); }
            }
        }
    }
    $data['required_documents'] = serialize($uploaded_documents);

    if (empty($errors)) {
        $result = $wpdb->insert($table_name, $data);
        if ($result === false) {
            $errors[] = "خطایی در ثبت درخواست در دیتابیس رخ داد. <br><small>پیام خطا: " . $wpdb->last_error . "</small>";
        } else {
            $new_request_id = $wpdb->insert_id;
            mlr_send_sms_on_loan_status_change($new_request_id, 'در حال بررسی');
        }
    }

    if (!empty($errors)) {
        wp_send_json_error(['message' => implode('<br>', $errors)]);
    } else {
        $user_requests_page_url = home_url('/panel/');
        wp_send_json_success(['message' => 'درخواست شما با موفقیت ثبت شد و برای بررسی ارسال گردید.', 'redirect_url' => esc_url($user_requests_page_url)]);
    }
}