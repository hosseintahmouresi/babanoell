<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_submit_cooperation_request', 'mlr_submit_cooperation_request_callback');
add_action('wp_ajax_nopriv_mlr_submit_cooperation_request', 'mlr_submit_cooperation_request_callback');

function mlr_submit_cooperation_request_callback() {
    check_ajax_referer('mlr_cooperation_request_action', '_wpnonce');

    global $wpdb;
    $errors = [];
    $data = []; // To store sanitized non-file field values
    $files = []; // To store successfully uploaded file URLs

    $request_type = isset($_POST['request_type']) ? sanitize_text_field($_POST['request_type']) : '';
    if (empty($request_type) || !in_array($request_type, ['individual', 'legal'])) {
        wp_send_json_error(['message' => 'نوع درخواست نامعتبر است.']);
        return;
    }

    // Get form configuration and field definitions
    // Use wp_parse_args to ensure defaults are applied if options haven't been saved yet
    $all_fields = mlr_get_all_cooperation_fields();
    $default_config = [];
    foreach ($all_fields as $key => $info) {
        $default_config[$key] = ['visible' => $info['default_visible'] ?? true, 'required' => $info['default_required'] ?? false];
    }
    $form_config = wp_parse_args(get_option('mlr_cooperation_form_config', []), $default_config);


    // --- Process and Validate Fields based on Configuration ---
    foreach ($all_fields as $field_key => $field_info) {
        // Skip if field is not for this form type
        if ($field_info['form'] !== 'both' && $field_info['form'] !== $request_type) {
            continue;
        }

        // Get config for this field (visibility and required status)
        // Defaults are already merged into $form_config
        $config = $form_config[$field_key];
        $is_visible = (bool)$config['visible'];
        $is_required = (bool)$config['required'];

        // --- Handle File Uploads ---
        if ($field_info['type'] === 'file') {
            if (!$is_visible) continue; // Skip invisible file fields entirely

            $file_input_name = $field_key . '[]'; // Name used in the form for multiple uploads

            // Check if any files were submitted for this field key (even if empty)
            if (isset($_FILES[$field_key])) {
                if (!function_exists('wp_handle_upload')) {
                    require_once ABSPATH . 'wp-admin/includes/file.php';
                }
                // More restrictive mimes for security
                $allowed_mimes = ['jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf'];
                $uploaded_files_for_field = [];
                $file_data_arr = $_FILES[$field_key];

                // Re-structure the $_FILES array for iteration if multiple files were uploaded
                $rearranged_files = [];
                if(isset($file_data_arr['name']) && is_array($file_data_arr['name'])) {
                    foreach ($file_data_arr['name'] as $key => $name) {
                        // Only process if a file was actually attempted (error is not NO_FILE)
                        if ($file_data_arr['error'][$key] !== UPLOAD_ERR_NO_FILE) {
                            $rearranged_files[] = [
                                'name'     => $file_data_arr['name'][$key],
                                'type'     => $file_data_arr['type'][$key],
                                'tmp_name' => $file_data_arr['tmp_name'][$key],
                                'error'    => $file_data_arr['error'][$key],
                                'size'     => $file_data_arr['size'][$key]
                            ];
                        }
                    }
                } elseif (isset($file_data_arr['name']) && $file_data_arr['error'] !== UPLOAD_ERR_NO_FILE) {
                     // Handle single file upload case for consistency (though unlikely with name ending in [])
                     $rearranged_files[] = $file_data_arr;
                }


                // Upload each file in the rearranged array
                foreach ($rearranged_files as $single_file) {
                    if ($single_file['error'] === UPLOAD_ERR_OK) {
                        // Validate file type using wp_check_filetype
                        $file_type = wp_check_filetype(basename($single_file['name']), $allowed_mimes);
                        if (empty($file_type['ext']) || empty($file_type['type']) || !in_array($file_type['type'], array_values($allowed_mimes))) {
                            $errors[] = 'خطا: نوع فایل "' . esc_html($single_file['name']) . '" برای فیلد "' . esc_html($field_info['label']) . '" مجاز نیست (فقط jpg, png, pdf).';
                            continue; // Skip this file
                        }

                        // Check file size (example: max 5MB)
                        $max_size = 5 * 1024 * 1024; // 5MB in bytes
                        if ($single_file['size'] > $max_size) {
                             $errors[] = 'خطا: حجم فایل "' . esc_html($single_file['name']) . '" (فیلد: ' . esc_html($field_info['label']) . ') بیشتر از حد مجاز (5 مگابایت) است.';
                             continue; // Skip this file
                        }

                        // Sanitize filename before upload
                        $clean_name = sanitize_file_name($single_file['name']);
                        $single_file['name'] = $clean_name;


                        $uploaded_file = wp_handle_upload($single_file, ['test_form' => false, 'mimes' => $allowed_mimes]);
                        if ($uploaded_file && !isset($uploaded_file['error'])) {
                            $uploaded_files_for_field[] = $uploaded_file['url']; // Store the URL
                            mlr_log("File uploaded successfully for field {$field_key}: {$uploaded_file['url']}");
                        } else {
                            $error_msg = $uploaded_file['error'] ?? 'خطای نامشخص در آپلود فایل.';
                            $errors[] = 'خطا در آپلود فایل "' . esc_html($single_file['name']) . '" (فیلد: ' . esc_html($field_info['label']) . '): ' . $error_msg;
                             mlr_log("File upload error for field {$field_key}, file {$single_file['name']}: {$error_msg}");
                        }
                    } elseif ($single_file['error'] !== UPLOAD_ERR_NO_FILE) {
                         // Report other PHP upload errors
                         $upload_errors = [ UPLOAD_ERR_INI_SIZE => 'بیش از حد مجاز سرور', UPLOAD_ERR_FORM_SIZE => 'بیش از حد مجاز فرم', UPLOAD_ERR_PARTIAL => 'بارگذاری ناقص', UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت یافت نشد', UPLOAD_ERR_CANT_WRITE => 'خطا در نوشتن فایل', UPLOAD_ERR_EXTENSION => 'پسوند غیرمجاز توسط افزونه‌ای دیگر', ];
                         $error_msg = $upload_errors[$single_file['error']] ?? 'خطای نامشخص آپلود (کد: '.$single_file['error'].')';
                         $errors[] = 'خطا در فایل "' . esc_html($single_file['name']) . '" (فیلد: ' . esc_html($field_info['label']) . '): ' . $error_msg;
                          mlr_log("PHP Upload error for field {$field_key}, file {$single_file['name']}: {$error_msg}");
                    }
                } // End foreach $rearranged_files

                if (!empty($uploaded_files_for_field)) {
                    $files[$field_key] = $uploaded_files_for_field; // Store URLs for this field
                } elseif ($is_required) {
                    // If required and no files were successfully uploaded for this field
                    $errors[] = 'فیلد "' . esc_html($field_info['label']) . '" اجباری است و هیچ فایل معتبری بارگذاری نشد.';
                     mlr_log("Validation Error: Required file field {$field_key} had no successful uploads.");
                }

            } elseif ($is_required) {
                // If required and no file input was found in $_FILES at all
                $errors[] = 'فیلد "' . esc_html($field_info['label']) . '" اجباری است.';
                 mlr_log("Validation Error: Required file field {$field_key} was not found in submission.");
            }

        // --- Handle Other Field Types (Text, Select, Textarea, Email) ---
        } else {
            // Get value from POST
            $value = isset($_POST[$field_key]) ? stripslashes($_POST[$field_key]) : ''; // Use stripslashes before sanitizing

            // Sanitize based on field type
            switch ($field_info['type']) {
                case 'email':
                    $sanitized_value = sanitize_email($value);
                    if (!empty($value) && !is_email($sanitized_value)) {
                         $errors[] = 'فرمت ایمیل وارد شده در فیلد "' . esc_html($field_info['label']) . '" نامعتبر است.';
                         $sanitized_value = ''; // Clear invalid email for safety, error message is already added
                         mlr_log("Validation Error: Invalid email format for field {$field_key}. Value: {$value}");
                    }
                    break;
                case 'textarea':
                    $sanitized_value = sanitize_textarea_field($value);
                    break;
                case 'text':
                case 'select':
                default:
                    $sanitized_value = sanitize_text_field($value);
                    break;
            }

            // Check if required and empty after sanitization
            if ($is_required && empty(trim($sanitized_value))) {
                $errors[] = 'فیلد "' . esc_html($field_info['label']) . '" اجباری است.';
                 mlr_log("Validation Error: Required field {$field_key} is empty.");
            }

            $data[$field_key] = $sanitized_value; // Store sanitized value in the data array
        }

    } // End foreach $all_fields

    // --- Proceed if no validation errors occurred ---
    if (empty($errors)) {
        $table_requests = $wpdb->prefix . 'cooperation_requests';
        // Prepare data for database insertion
        $insert_data = [
            'request_type' => $request_type,
            'status' => 'در حال بررسی', // Initial status
            'data' => wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), // Store sanitized non-file data as JSON
            'files' => wp_json_encode($files, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), // Store uploaded file URLs as JSON
            'created_at' => current_time('mysql')
        ];

        // Insert into database
        $result = $wpdb->insert($table_requests, $insert_data);

        // Check insertion result
        if ($result === false) {
             mlr_log("Database Error inserting cooperation request: " . $wpdb->last_error . " | Data: " . print_r($insert_data, true));
            wp_send_json_error(['message' => 'خطا در ثبت درخواست در پایگاه داده. لطفاً دوباره امتحان کنید یا با پشتیبانی تماس بگیرید.']);
        } else {
            $new_request_id = $wpdb->insert_id;
             mlr_log("Cooperation request submitted successfully. ID: {$new_request_id}");
            // Send SMS notification for the new request
            $new_request_obj = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_requests} WHERE id = %d", $new_request_id));
            if ($new_request_obj) {
                 mlr_send_sms_on_cooperation_status_change($new_request_id, 'در حال بررسی', $new_request_obj);
            }
            // Send success response
            wp_send_json_success(['message' => 'درخواست همکاری شما با موفقیت ثبت و برای کارشناسان ارسال گردید.']);
        }
    } else {
        // Send back validation errors to the frontend
         mlr_log("Cooperation form submission failed validation. Errors: " . implode(' | ', $errors));
        wp_send_json_error(['message' => implode('<br>', $errors)]);
    }
}