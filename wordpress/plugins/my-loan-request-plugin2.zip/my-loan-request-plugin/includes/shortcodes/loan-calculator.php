<?php
if (!defined('ABSPATH')) {
    exit;
}

add_shortcode('mlr_loan_calculator', 'mlr_loan_calculator_shortcode');

function mlr_loan_calculator_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'installment_plans';
    $plans = $wpdb->get_results("SELECT id, name, type, settings, display_fields FROM $table_name WHERE is_active = 1 ORDER BY name ASC");

    if (empty($plans)) {
        return '<p>در حال حاضر هیچ طرح فعالی برای محاسبه وجود ندارد.</p>';
    }

    $js_plans = array_map(function($plan) {
        $plan->settings = maybe_unserialize($plan->settings);
        $plan->display_fields = maybe_unserialize($plan->display_fields);
        return $plan;
    }, $plans);

    wp_enqueue_script('mlr-calculator-js', MLR_PLUGIN_URL . 'assets/js/loan-calculator.js', ['jquery'], '2.3.0', true);
    wp_localize_script('mlr-calculator-js', 'mlrCalculatorAjax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('mlr_frontend_calc_nonce'),
        'plans'   => $js_plans
    ]);

    ob_start();
    ?>
    <div class="mlr-calc-wrapper">
        <div class="mlr-calc-container">
            <div class="mlr-calc-inputs">
                <h3>محاسبه‌گر اقساط</h3>
                <p>طرح، مبلغ درخواستی و مدت زمان بازپرداخت را مشخص کنید.</p>

                <div class="mlr-calc-group">
                    <label>انتخاب طرح تسهیلات</label>
                    <div id="mlr_plan_tabs_container" class="mlr-calc-tabs plan-tabs">
                        </div>
                </div>

                <div class="mlr-calc-group">
                    <label id="mlr_amount_label">مبلغ (ریال)</label>
                    <div class="mlr-calc-amount-input-new">
                         <button class="mlr-calc-control" data-action="minus">&#8722;</button>
                         <input type="text" id="mlr_loan_amount" disabled>
                         <button class="mlr-calc-control" data-action="plus">&#43;</button>
                    </div>
                </div>

                <div class="mlr-calc-group">
                    <input type="range" id="mlr_loan_slider" disabled>
                    <div class="mlr-calc-slider-labels">
                        <span id="mlr_slider_min_label"></span>
                        <span id="mlr_slider_max_label"></span>
                    </div>
                </div>

                <div class="mlr-calc-group">
                    <label>مدت زمان بازپرداخت</label>
                    <div id="mlr_installments_tabs" class="mlr-calc-tabs installment-tabs">
                        </div>
                </div>
                 
                <div id="calc_interval_wrapper_front" style="display:none;" class="mlr-calc-group">
                    <label for="calc_interval_front">فاصله اقساط (ماه)</label>
                    <div id="mlr_interval_tabs_container" class="mlr-calc-tabs interval-tabs">
                        </div>
                </div>

                <button id="mlr_calculate_btn" class="mlr-calc-button calculate-btn">محاسبه اقساط</button>
            </div>

            <div class="mlr-calc-results">
                <div class="mlr-calc-result-content">
                    <img src="https://babanoell.com/wp-content/uploads/لوگو-واتر-سایت-1.png" alt="Babanoell Logo" class="mlr-calc-logo"/>
                    <div id="mlr_result_display">
                        <p class="mlr-calc-placeholder">لطفا یک طرح را برای مشاهده نتایج انتخاب کنید.</p>
                    </div>
                    <a href="https://babanoell.com/panel/" class="mlr-calc-button request-btn">درخواست تسهیلات</a>
                </div>
            </div>
        </div>
    </div>
    <style>
        .mlr-calc-wrapper { font-family: 'IRANSans', 'Vazir', 'Tahoma', sans-serif; direction: rtl; }
        .mlr-calc-container { display: flex; flex-wrap: wrap; max-width: 1024px; margin: 40px auto; background: #fff; border-radius: 24px; box-shadow: 0 15px 40px rgba(0,0,0,0.1); overflow: hidden; }
        .mlr-calc-inputs { flex: 60%; background: #fff; padding: 40px; }
        .mlr-calc-results { flex: 40%; background: #d0e2f2; padding: 40px; }
        .mlr-calc-inputs h3 { font-size: 24px; color: #1d3558; margin-top: 0; }
        .mlr-calc-inputs p { font-size: 16px; color: #5a789a; margin-bottom: 30px; }
        .mlr-calc-group { margin-bottom: 25px; }
        .mlr-calc-group label { display: block; font-weight: bold; margin-bottom: 12px; font-size: 14px; color: #1d3558; }
        .mlr-calc-tabs { display: flex; flex-wrap: wrap; gap: 10px; }
        .mlr-calc-tab { padding: 10px 15px; background: #d0e2f2; border: 1px solid #b9cde0; color: #1d3558; border-radius: 8px; cursor: pointer; font-size: 14px; transition: all 0.2s ease; }
        .mlr-calc-tab.active { background: #1d3558; color: #d0e2f2; border-color: #1d3558; font-weight: bold; }
        .mlr-calc-amount-input-new { display: flex; align-items: stretch; border: 1px solid #b9cde0; border-radius: 8px; background: #fff; }
        .mlr-calc-amount-input-new input { flex-grow: 1; border: none; font-size: 20px; font-weight: bold; color: #1a1a1a; width: 70%; padding: 12px 15px; text-align: center; background: transparent; }
        .mlr-calc-amount-input-new input:focus { outline: none; }
        .mlr-calc-control { border: none; background: #d0e2f2; width: 44px; cursor: pointer; color: #1d3558; font-size: 24px; line-height: 1; }
        .mlr-calc-control:first-of-type { border-left: 1px solid #b9cde0; border-top-right-radius: 8px; border-bottom-right-radius: 8px;}
        .mlr-calc-control:last-of-type { border-right: 1px solid #b9cde0; border-top-left-radius: 8px; border-bottom-left-radius: 8px;}
        input[type=range] { -webkit-appearance: none; width: 100%; background: transparent; margin-top: 15px; }
        input[type=range]::-webkit-slider-runnable-track { height: 8px; background: #d0e2f2; border-radius: 4px; }
        input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; height: 24px; width: 24px; border-radius: 50%; background: #1d3558; cursor: pointer; margin-top: -8px; }
        .mlr-calc-slider-labels { display: flex; justify-content: space-between; font-size: 12px; color: #5a789a; margin-top: 8px; }
        .mlr-calc-result-content { display: flex; flex-direction: column; height: 100%; text-align: center; }
        .mlr-calc-logo { max-width: 150px !important; height: auto; display: block; margin: 0 auto 30px auto; }
        #mlr_result_display { flex-grow: 1; }
        .mlr-calc-placeholder { color: #1d3558; margin-top: 40px; }
        .mlr-calc-result-item { display: flex; justify-content: space-between; align-items: center; padding: 15px 0; border-bottom: 1px solid #b9cde0; }
        .mlr-calc-result-item:last-child { border-bottom: none; }
        .mlr-calc-result-item .label { font-size: 14px; color: #5a789a; }
        .mlr-calc-result-item .value { font-size: 18px; font-weight: bold; color: #1d3558; }
        .mlr-calc-result-item .value.loading { color: #888; }
        .mlr-calc-button { display: flex; align-items: center; justify-content: center; height: 60px; text-align: center; width: 100%; padding: 16px; border: none; border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; text-decoration: none; }
        .mlr-calc-button.calculate-btn { margin-top: 20px; background: #1d3558; color: #d0e2f2; }
        .mlr-calc-button.request-btn { margin-top: auto; background: #1d3558; color: #d0e2f2; }
    </style>
    <?php
    return ob_get_clean();
}