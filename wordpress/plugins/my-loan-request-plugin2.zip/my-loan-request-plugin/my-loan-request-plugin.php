<?php
/*
Plugin Name: درخواست تسهیلات بابانوئل
Description: افزونه‌ای برای مدیریت درخواست‌های تسهیلات با قابلیت محاسبه اقساط و ثبت-نام پذیرندگان
Version: 8.3.9
Author: شرکت پدیده تجارت
*/

if (!defined('ABSPATH')) {
    exit;
}

define('MLR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MLR_PLUGIN_URL', plugin_dir_url(__FILE__));

// --- START: MLR Logging Function ---
if (!function_exists('mlr_log')) {
    function mlr_log($message) {
        $log_file = MLR_PLUGIN_DIR . 'mlr_debug.log';
        $timestamp = date('Y-m-d H:i:s');
        // Simple check for array/object for better formatting
        if (is_array($message) || is_object($message)) {
            $formatted_message = sprintf("[%s] %s\n", $timestamp, print_r($message, true));
        } else {
            $formatted_message = sprintf("[%s] %s\n", $timestamp, $message);
        }
        // Add file locking for safer concurrent writes
        $file_handle = @fopen($log_file, 'a'); // Use @ to suppress errors if file is not writable
        if ($file_handle) {
            if (flock($file_handle, LOCK_EX)) {
                fwrite($file_handle, $formatted_message);
                fflush($file_handle); // Ensure data is written
                flock($file_handle, LOCK_UN); // Release the lock
            }
            fclose($file_handle);
        } else {
             error_log("MLR_Log Error: Could not open log file for writing: " . $log_file); // Log error if file cannot be opened
        }
    }
}
// --- END: MLR Logging Function ---


// --- START: افزودن فیلدهای سفارشی به پروفایل کاربر ---
add_action('show_user_profile', 'mlr_add_custom_user_profile_fields');
add_action('edit_user_profile', 'mlr_add_custom_user_profile_fields');
function mlr_add_custom_user_profile_fields($user) {
    ?>
    <h3>اطلاعات تکمیلی پذیرنده</h3>
    <table class="form-table">
        <tr>
            <th><label for="shebaaa">شماره شبا</label></th>
            <td>
                <input type="text" name="shebaaa" id="shebaaa" value="<?php echo esc_attr(get_the_author_meta('shebaaa', $user->ID)); ?>" class="regular-text ltr" pattern="[0-9]{24}" title="شماره شبا 24 رقمی" />
                <p class="description">شماره شبا ۲۴ رقمی بدون IR</p>
            </td>
        </tr>
        <?php if (current_user_can('manage_options') || current_user_can('edit_user', $user->ID)): // Allow user to edit their own, admin to edit all ?>
        <?php // Allow admin to edit commission ?>
        <?php if (current_user_can('manage_options')): ?>
        <tr>
            <th><label for="acceptor_commission_percent">کمیسیون پذیرنده (%)</label></th>
            <td>
                <input type="number" name="acceptor_commission_percent" id="acceptor_commission_percent" value="<?php echo esc_attr(get_the_author_meta('acceptor_commission_percent', $user->ID)); ?>" class="small-text ltr" step="0.01" min="0" max="100" />
                <p class="description">این مقدار در محاسبه‌گر فرم ثبت‌نام استفاده خواهد شد (پیش‌فرض تنظیمات طرح اعمال می‌شود).</p>
            </td>
        </tr>
        <?php endif; ?>
         <?php // *** ADDED: Field for Acceptor Mobile Number (for SMS) *** ?>
         <tr>
             <th><label for="acceptor_mobile_number">شماره موبایل پذیرنده (برای پیامک)</label></th>
             <td>
                 <input type="text" name="acceptor_mobile_number" id="acceptor_mobile_number" value="<?php echo esc_attr(get_the_author_meta('acceptor_mobile_number', $user->ID)); ?>" class="regular-text ltr" pattern="09[0-9]{9}" title="شماره موبایل 11 رقمی با شروع 09" />
                 <p class="description">این شماره موبایل برای دریافت پیامک‌های مربوط به وضعیت درخواست‌های تسهیلات استفاده خواهد شد. (جایگزین شماره موبایل پیش‌فرض حساب کاربری یا ووکامرس)</p>
             </td>
         </tr>
        <?php endif; ?>
    </table>
    <?php
}

add_action('personal_options_update', 'mlr_save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'mlr_save_custom_user_profile_fields');
function mlr_save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    if (isset($_POST['shebaaa'])) {
        // Basic validation for 24 digits
        $sheba = preg_replace('/[^0-9]/', '', $_POST['shebaaa']);
        if (strlen($sheba) === 24) {
            update_user_meta($user_id, 'shebaaa', $sheba);
        } else {
             // Clear if invalid
             delete_user_meta($user_id, 'shebaaa');
        }
    }

    // *** MODIFIED: Split permissions for saving ***
    // Only Admin can save commission
    if (current_user_can('manage_options') && isset($_POST['acceptor_commission_percent'])) {
        $commission_value = sanitize_text_field($_POST['acceptor_commission_percent']);
        // Validate numeric and within range 0-100
        if (is_numeric($commission_value) && $commission_value >= 0 && $commission_value <= 100) {
             update_user_meta($user_id, 'acceptor_commission_percent', $commission_value);
        } else {
             delete_user_meta($user_id, 'acceptor_commission_percent');
        }
    }
    
    // User can save their own mobile number (admin can too)
    if (isset($_POST['acceptor_mobile_number'])) {
        $mobile = preg_replace('/[^0-9]/', '', $_POST['acceptor_mobile_number']);
         if (preg_match('/^09\d{9}$/', $mobile)) {
            update_user_meta($user_id, 'acceptor_mobile_number', $mobile);
        } else {
             // Clear if invalid
             delete_user_meta($user_id, 'acceptor_mobile_number');
        }
    }
    // *** END MODIFICATION ***
}
// --- END: افزودن فیلدهای سفارشی ---


add_action('admin_init', 'mlr_check_and_update_database_schema');
function mlr_check_and_update_database_schema() {
    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $table_cooperation = $wpdb->prefix . 'cooperation_requests';
    $version_option_name = 'mlr_db_version';
    $current_db_version = '1.3'; // DB version from previous step

    $installed_ver = get_option($version_option_name);

    // Run schema updates if version doesn't match
    if ($installed_ver != $current_db_version) {

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php'); // Ensure dbDelta is loaded

        // --- Loan Requests Table Updates ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_requests)) == $table_requests) {
             $existing_columns_requests = $wpdb->get_col("DESC `{$table_requests}`", 0);
             if (in_array('expert_note', $existing_columns_requests)) $wpdb->query("ALTER TABLE `{$table_requests}` DROP COLUMN `expert_note`;");
             if (in_array('bank_note', $existing_columns_requests)) $wpdb->query("ALTER TABLE `{$table_requests}` DROP COLUMN `bank_note`;");

             // Define and add new columns for loan_requests
             $required_columns_requests = [
                 'phone_number' => "varchar(20) DEFAULT '' NOT NULL AFTER `mobile_number`",
                 'birth_date' => "date DEFAULT NULL AFTER `phone_number`",
                 'occupation' => "varchar(100) DEFAULT '' NOT NULL AFTER `birth_date`",
                 'residential_address' => "text AFTER `occupation`",
                 'postal_code' => "varchar(10) DEFAULT '' NOT NULL AFTER `residential_address`",
                 'work_address' => "text AFTER `postal_code`",
                 'product_name' => "text AFTER `work_address`",
                 'comments' => "TEXT DEFAULT NULL",
                 'prepayment' => "DECIMAL(15,2) DEFAULT 0 AFTER `loan_amount`",
                 'installment_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `installment_count`",
                 'total_payment' => "DECIMAL(15,2) DEFAULT 0 AFTER `installment_amount`",
                 'profit' => "DECIMAL(15,2) DEFAULT 0 AFTER `total_payment`",
                 'wallet_charge' => "DECIMAL(15,2) DEFAULT 0 AFTER `prepayment`",
                 'acceptor_payment_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `wallet_charge`",
                 'final_settlement_amount' => "DECIMAL(15,2) DEFAULT 0 AFTER `acceptor_payment_amount`",
                 'assigned_bank_user_id' => "bigint(20) UNSIGNED DEFAULT NULL AFTER `settlement_status`",
                 'settlement_cycle_id' => "bigint(20) UNSIGNED DEFAULT NULL AFTER `assigned_bank_user_id`",
                 'settlement_date' => "datetime DEFAULT NULL AFTER `settlement_cycle_id`"
             ];
             $current_columns_requests = $wpdb->get_col("DESC `{$table_requests}`", 0); // Get columns once before loop
             foreach ($required_columns_requests as $column_name => $column_definition) {
                 if (!in_array($column_name, $current_columns_requests)) {
                     if ($wpdb->query("ALTER TABLE `{$table_requests}` ADD COLUMN `{$column_name}` {$column_definition};") === false) {
                          mlr_log("Error adding column {$column_name} to {$table_requests}: " . $wpdb->last_error);
                     } else {
                          mlr_log("Successfully added column {$column_name} to {$table_requests}");
                          $current_columns_requests[] = $column_name;
                     }
                 }
             }
             // Add Indexes if they don't exist
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_requests}` WHERE Key_name = %s", 'idx_settlement_cycle_id'))) {
                 $wpdb->query("ALTER TABLE `{$table_requests}` ADD INDEX `idx_settlement_cycle_id` (`settlement_cycle_id`);");
             }
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_requests}` WHERE Key_name = %s", 'idx_assigned_bank_user_id'))) {
                 $wpdb->query("ALTER TABLE `{$table_requests}` ADD INDEX `idx_assigned_bank_user_id` (`assigned_bank_user_id`);");
             }
        } else { mlr_log("Table {$table_requests} not found during schema update check."); }

        // --- Cooperation Requests Table Updates ---
        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_cooperation)) == $table_cooperation) {
             $existing_columns_coop = $wpdb->get_col("DESC `{$table_cooperation}`", 0);
             // Define new columns for cooperation table
             $required_columns_coop = [
                 'contract_token' => "VARCHAR(64) DEFAULT NULL AFTER `status`",
                 'contract_signed_status' => "VARCHAR(20) DEFAULT 'pending' NOT NULL AFTER `contract_token`",
                 'contract_signed_at' => "DATETIME DEFAULT NULL AFTER `contract_signed_status`",
                 'contract_expires_at' => "DATETIME DEFAULT NULL AFTER `contract_signed_at`",
                 'otp_code' => "VARCHAR(255) DEFAULT NULL AFTER `contract_expires_at`",
                 'otp_expires_at' => "DATETIME DEFAULT NULL AFTER `otp_code`"
             ];
             foreach ($required_columns_coop as $column_name => $column_definition) {
                if (!in_array($column_name, $existing_columns_coop)) {
                    if ($wpdb->query("ALTER TABLE `{$table_cooperation}` ADD COLUMN `{$column_name}` {$column_definition};") === false) {
                         mlr_log("Error adding column {$column_name} to {$table_cooperation}: " . $wpdb->last_error);
                    } else {
                         mlr_log("Successfully added column {$column_name} to {$table_cooperation}");
                         $existing_columns_coop[] = $column_name;
                    }
                }
             }
             // Add UNIQUE Index for contract_token if it doesn't exist
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_cooperation}` WHERE Key_name = %s", 'idx_contract_token'))) {
                 if (in_array('contract_token', $existing_columns_coop)) {
                    $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD UNIQUE INDEX `idx_contract_token` (`contract_token`);");
                 } else { mlr_log("Cannot add index idx_contract_token: column contract_token does not exist yet."); }
             }
             // Add index for signed status
             if (!$wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `{$table_cooperation}` WHERE Key_name = %s", 'idx_signed_status'))) {
                  if (in_array('contract_signed_status', $existing_columns_coop)) { $wpdb->query("ALTER TABLE `{$table_cooperation}` ADD INDEX `idx_signed_status` (`contract_signed_status`);"); }
             }
        } else { mlr_log("Table {$table_cooperation} not found during schema update check."); }


        update_option($version_option_name, $current_db_version);
        mlr_log("Database schema checked/updated to version {$current_db_version}");
    }
}


// Helper & Core Functions
require_once MLR_PLUGIN_DIR . 'includes/sms-functions.php';
require_once MLR_PLUGIN_DIR . 'includes/loan-calculations.php';
require_once MLR_PLUGIN_DIR . 'includes/functions.php';

// AJAX Handlers (Consolidated loading)
foreach (glob(MLR_PLUGIN_DIR . 'includes/ajax/*.php') as $filename) {
    require_once $filename;
}
require_once MLR_PLUGIN_DIR . 'includes/ajax/cooperation-otp-actions.php';


// Admin Pages
if (is_admin()) {
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/loan-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/installment-plans.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/granted-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/unsettled-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/settled-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/cooperation-requests.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/form-editor.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/sms-settings.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/log-viewer.php';
    require_once MLR_PLUGIN_DIR . 'includes/admin-pages/cooperation-contract-settings.php';
}

// Shortcodes
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/loan-request-form.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-loan-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/needs-review-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/processing-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/granted-user-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-settlement-cycles.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/bank-expert-dashboard.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/verified-docs-dashboard.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/cooperation-request-form.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/loan-calculator.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/user-stats.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/invoice.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/edit-requests.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/complete-request.php';
require_once MLR_PLUGIN_DIR . 'includes/shortcodes/cooperation-contract-viewer.php';


register_activation_hook(__FILE__, 'mlr_install_and_update');
register_deactivation_hook(__FILE__, 'mlr_deactivate'); // Add deactivation hook

function mlr_install_and_update() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // --- Loan Requests Table ---
    $table_requests = $wpdb->prefix . 'loan_requests';
    $sql_requests = "CREATE TABLE $table_requests (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        full_name varchar(255) NOT NULL,
        national_code varchar(10) NOT NULL,
        mobile_number varchar(15) NOT NULL,
        phone_number varchar(20) DEFAULT '' NOT NULL,
        birth_date date DEFAULT NULL,
        occupation varchar(100) DEFAULT '' NOT NULL,
        residential_address text,
        postal_code varchar(10) DEFAULT '' NOT NULL,
        work_address text,
        product_name text,
        installment_plan_id bigint(20) UNSIGNED NOT NULL,
        loan_amount DECIMAL(15,2) NOT NULL,
        prepayment DECIMAL(15,2) DEFAULT 0,
        wallet_charge DECIMAL(15,2) DEFAULT 0,
        acceptor_payment_amount DECIMAL(15,2) DEFAULT 0,
        final_settlement_amount DECIMAL(15,2) DEFAULT 0,
        installment_interval int(11) NOT NULL DEFAULT 1,
        installment_count int(11) NOT NULL,
        installment_amount DECIMAL(15,2) DEFAULT 0,
        total_payment DECIMAL(15,2) DEFAULT 0,
        profit DECIMAL(15,2) DEFAULT 0,
        required_documents longtext,
        order_items longtext,
        comments longtext,
        status varchar(50) NOT NULL,
        settlement_status varchar(50) DEFAULT '',
        assigned_bank_user_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_cycle_id bigint(20) UNSIGNED DEFAULT NULL,
        settlement_date datetime DEFAULT NULL,
        created_at datetime NOT NULL,
        last_edited_at datetime DEFAULT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status),
        KEY national_code (national_code),
        KEY installment_plan_id (installment_plan_id),
        KEY idx_settlement_cycle_id (settlement_cycle_id),
        KEY idx_assigned_bank_user_id (assigned_bank_user_id)
    ) $charset_collate;";
    dbDelta($sql_requests);

    // --- Installment Plans Table ---
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $sql_installment_plans = "CREATE TABLE $table_installment_plans (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        type varchar(50) NOT NULL,
        is_active tinyint(1) DEFAULT 1,
        settings longtext,
        display_fields longtext,
        required_documents text,
        created_at datetime NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql_installment_plans);

    // --- Cooperation Requests Table ---
    $table_cooperation_requests = $wpdb->prefix . 'cooperation_requests';
    $sql_cooperation_requests = "CREATE TABLE $table_cooperation_requests (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        request_type varchar(50) NOT NULL,
        status varchar(50) NOT NULL DEFAULT 'در حال بررسی',
        contract_token varchar(64) DEFAULT NULL,
        contract_signed_status varchar(20) NOT NULL DEFAULT 'pending',
        contract_signed_at datetime DEFAULT NULL,
        contract_expires_at datetime DEFAULT NULL,
        otp_code varchar(255) DEFAULT NULL,
        otp_expires_at datetime DEFAULT NULL,
        data longtext,
        files longtext,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY idx_contract_token (contract_token),
        KEY status (status),
        KEY request_type (request_type),
        KEY idx_signed_status (contract_signed_status)
    ) $charset_collate;";
    dbDelta($sql_cooperation_requests);

    // --- Activity Fields Table (Kept for now) ---
    $table_activity_fields = $wpdb->prefix . 'mlr_activity_fields';
    $sql_activity_fields = "CREATE TABLE $table_activity_fields (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        field_name varchar(255) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta($sql_activity_fields);

    // --- Settlement Cycles Table ---
    $table_settlement_cycles = $wpdb->prefix . 'mlr_settlement_cycles';
    $sql_settlement_cycles = "CREATE TABLE $table_settlement_cycles (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        total_amount DECIMAL(15,2) NOT NULL,
        description text,
        settlement_date datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql_settlement_cycles);

    // Call schema update function AFTER dbDelta to handle modifications
    mlr_check_and_update_database_schema();

    // Create contract viewer page if it doesn't exist
    $contract_page_slug = 'cooperation-contract';
    $contract_page_title = 'قرارداد همکاری';
    if ( null == get_page_by_path( $contract_page_slug ) ) {
      $page_id = wp_insert_post(
        array(
          'comment_status' => 'closed',
          'ping_status'    => 'closed',
          'post_author'    => 1, // Or another appropriate user ID
          'post_name'      => $contract_page_slug, // Slug
          'post_title'     => $contract_page_title,        // Title
          'post_status'    => 'publish',
          'post_type'      => 'page',
          'post_content'   => '[mlr_cooperation_contract_viewer]' // Add the shortcode
        )
      );
      if ($page_id && !is_wp_error($page_id)){
          update_option('mlr_contract_viewer_page_id', $page_id); // Optionally store the page ID
          mlr_log("Created Cooperation Contract viewer page ('{$contract_page_slug}') with ID: {$page_id}");
      } else {
          mlr_log("Failed to create Cooperation Contract viewer page. Error: " . ($page_id instanceof WP_Error ? $page_id->get_error_message() : 'Unknown'));
      }
    }

}

function mlr_deactivate() {
    // Optional cleanup
}


add_action('admin_menu', 'mlr_admin_menu');
function mlr_admin_menu() {
    add_menu_page('عملیات تسهیلات', 'عملیات تسهیلات', 'manage_options', 'mlr-loan-requests', 'mlr_loan_requests_page', 'dashicons-money-alt', 6);
    add_submenu_page('mlr-loan-requests', 'همه‌درخواست‌ها', 'همه‌درخواست‌ها', 'manage_options', 'mlr-loan-requests', 'mlr_loan_requests_page');
    // Add specific status pages as submenus
    add_submenu_page('mlr-loan-requests', 'در حال بررسی', 'در حال بررسی', 'manage_options', 'admin.php?page=mlr-loan-requests&status=در حال بررسی');
    add_submenu_page('mlr-loan-requests', 'نقص مدارک', 'نقص مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=نقص مدارک');
    add_submenu_page('mlr-loan-requests', 'رد شده', 'رد شده', 'manage_options', 'admin.php?page=mlr-loan-requests&status=رد شده');
    add_submenu_page('mlr-loan-requests', 'تأیید کارشناس', 'تأیید کارشناس', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تأیید کارشناس');
    add_submenu_page('mlr-loan-requests', 'تکمیل مدارک', 'تکمیل مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تکمیل مدارک');
    add_submenu_page('mlr-loan-requests', 'تأیید مدارک', 'تأیید مدارک', 'manage_options', 'admin.php?page=mlr-loan-requests&status=تأیید مدارک');
    // Submenus for settlement workflow
    add_submenu_page('mlr-loan-requests', 'اعطا شده', 'اعطا شده', 'manage_options', 'mlr-granted-requests', 'mlr_granted_requests_page');
    add_submenu_page('mlr-loan-requests', 'در انتظار تسویه', 'در انتظار تسویه', 'manage_options', 'mlr-unsettled-requests', 'mlr_unsettled_requests_page');
    add_submenu_page('mlr-loan-requests', 'تسویه شده', 'تسویه شده', 'manage_options', 'mlr-settled-requests', 'mlr_settled_requests_page');
    // Other settings submenus
    add_submenu_page('mlr-loan-requests', 'طرح‌های اقساطی', 'طرح‌های اقساطی', 'manage_options', 'mlr-installment-plans', 'mlr_installment_plans_page');
    add_submenu_page('mlr-loan-requests', 'تنظیمات API', 'تنظیمات API', 'manage_options', 'mlr-api-settings', 'mlr_api_settings_page_callback');


    add_menu_page('مدیریت همکاری', 'مدیریت همکاری', 'manage_options', 'mlr-cooperation-main', 'mlr_cooperation_requests_page', 'dashicons-groups', 7);
    add_submenu_page('mlr-cooperation-main', 'درخواست‌های همکاری', 'درخواست‌های همکاری', 'manage_options', 'mlr-cooperation-main', 'mlr_cooperation_requests_page');
    // *** MODIFIED: Renamed Submenu and changed callback function ***
    add_submenu_page('mlr-cooperation-main', 'ویرایشگر فرم همکاری', 'ویرایشگر فرم', 'manage_options', 'mlr-form-editor', 'mlr_form_editor_page');
    add_submenu_page('mlr-cooperation-main', 'تنظیمات قرارداد', 'تنظیمات قرارداد', 'manage_options', 'mlr-cooperation-contract-settings', 'mlr_cooperation_contract_settings_page');


    add_menu_page('تنظیمات پیامک', 'تنظیمات پیامک', 'manage_options', 'mlr-sms-settings', 'mlr_sms_settings_page', 'dashicons-email-alt', 8);
    add_submenu_page('mlr-sms-settings', 'مشاهده لاگ', 'مشاهده لاگ', 'manage_options', 'mlr-log-viewer', 'mlr_log_viewer_page');
}


add_action('admin_init', 'mlr_register_plugin_settings'); // Consolidated settings registration
function mlr_register_plugin_settings() {
    // API Settings
    register_setting('mlr_api_settings_group', 'mlr_shahkar_client_id', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_api_settings_group', 'mlr_shahkar_client_secret', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('mlr_api_settings_group', 'mlr_shahkar_owner_nid', ['sanitize_callback' => 'sanitize_text_field']);

    // SMS Settings
    register_setting('mlr_sms_settings_group', 'mlr_sms_settings', ['sanitize_callback' => 'mlr_sanitize_sms_settings']);

    // Cooperation Contract Settings
    register_setting('mlr_cooperation_contract_settings_group', 'mlr_cooperation_contract_settings', ['sanitize_callback' => 'mlr_sanitize_cooperation_contract_settings']);

    // Form Editor Settings
    register_setting('mlr_cooperation_form_editor_group', 'mlr_cooperation_form_options', ['sanitize_callback' => 'mlr_sanitize_cooperation_form_options']);
    register_setting('mlr_cooperation_form_editor_group', 'mlr_cooperation_form_config', ['sanitize_callback' => 'mlr_sanitize_cooperation_form_config']);
}

// Sanitize callback for Form Options
function mlr_sanitize_cooperation_form_options($input) {
    $sanitized_input = [];
    // Define keys for fields that have selectable options managed here
    $option_keys = ['activity_field_options', 'how_heard_options']; // Add more keys as needed

    foreach ($option_keys as $key) {
        if (isset($input[$key])) {
            // Sanitize options entered one per line in a textarea
            $lines = explode("\n", $input[$key]);
            $options = [];
            foreach ($lines as $line) {
                $trimmed_line = trim($line);
                if (!empty($trimmed_line)) {
                    $options[] = sanitize_text_field($trimmed_line); // Sanitize each line
                }
            }
            $sanitized_input[$key] = $options;
        } else {
            $sanitized_input[$key] = []; // Default to empty array if not set
        }
    }
    return $sanitized_input;
}

// Sanitize callback for Form Config
function mlr_sanitize_cooperation_form_config($input) {
    $sanitized_input = [];
    $all_fields = mlr_get_all_cooperation_fields(); // Get the master list of fields

    if (!is_array($input)) {
        $input = []; // Ensure input is an array
    }

    foreach ($all_fields as $field_key => $field_info) {
        // Sanitize 'visible' setting (only relevant for file types currently)
        if ($field_info['type'] === 'file') {
             $sanitized_input[$field_key]['visible'] = isset($input[$field_key]['visible']) ? 1 : 0;
        } else {
             // Non-file fields are assumed visible, store 1
             $sanitized_input[$field_key]['visible'] = 1;
        }

        // Sanitize 'required' setting - can only be required if visible
        $is_visible = $sanitized_input[$field_key]['visible']; // Use the just sanitized value
        $sanitized_input[$field_key]['required'] = (isset($input[$field_key]['required']) && $is_visible) ? 1 : 0;
    }
    return $sanitized_input;
}


// Sanitize callback for Cooperation Contract Settings
function mlr_sanitize_cooperation_contract_settings($input) {
    $sanitized_input = [];
    if (!is_array($input)) $input = []; // Ensure input is an array
    $sanitized_input['header_image_url'] = isset($input['header_image_url']) ? esc_url_raw(trim($input['header_image_url'])) : '';
    $sanitized_input['footer_image_url'] = isset($input['footer_image_url']) ? esc_url_raw(trim($input['footer_image_url'])) : '';
    // Allow more tags in contract text, similar to post content
    $sanitized_input['contract_text'] = isset($input['contract_text']) ? wp_kses_post($input['contract_text']) : '';
    return $sanitized_input;
}

// *** MODIFIED: Sanitize callback for SMS settings ***
function mlr_sanitize_sms_settings($input) {
    $sanitized_input = [];
    if (!is_array($input)) $input = []; // Ensure input is an array

    $sanitized_input['username'] = isset($input['username']) ? sanitize_text_field(trim($input['username'])) : '';
    // Store password only if a new value is provided, otherwise keep the old one
    $current_options = get_option('mlr_sms_settings', []);
    if (!empty($input['password'])) {
        $sanitized_input['password'] = sanitize_text_field(trim($input['password']));
    } elseif (isset($current_options['password'])) {
        $sanitized_input['password'] = $current_options['password'];
    } else {
        $sanitized_input['password'] = '';
    }

    // Iterate through all groups: cooperation statuses, loan statuses, and otp settings
    foreach (['cooperation_statuses', 'loan_statuses', 'otp_settings'] as $group_key) {
        if (isset($input[$group_key]) && is_array($input[$group_key])) {
            foreach ($input[$group_key] as $key => $settings) {
                if (!is_array($settings)) continue; // Skip if settings is not an array
                $sanitized_key = sanitize_text_field($key);

                // Sanitize common fields: enabled and bodyId
                $sanitized_input[$group_key][$sanitized_key]['enabled'] = isset($settings['enabled']) ? 1 : 0;
                $sanitized_input[$group_key][$sanitized_key]['bodyId'] = isset($settings['bodyId']) ? sanitize_text_field(trim($settings['bodyId'])) : '';

                // Sanitize variables for all groups
                for ($i = 0; $i < 3; $i++) {
                    $var_field_key = "var_{$i}";
                    $sanitized_input[$group_key][$sanitized_key][$var_field_key] = isset($settings[$var_field_key]) ? sanitize_text_field(trim($settings[$var_field_key])) : '';
                }

                // *** ADDED: Sanitize recipient toggles specifically for loan_statuses ***
                if ($group_key === 'loan_statuses') {
                    $sanitized_input[$group_key][$sanitized_key]['send_to_applicant'] = isset($settings['send_to_applicant']) ? 1 : 0;
                    $sanitized_input[$group_key][$sanitized_key]['send_to_acceptor'] = isset($settings['send_to_acceptor']) ? 1 : 0;
                }
                // *** END: Sanitize recipient toggles ***
            }
        }
    }
    return $sanitized_input;
}
// *** END MODIFIED Sanitize callback ***

// Helper function to define all fields in the cooperation form
function mlr_get_all_cooperation_fields() {
    // Defines the structure and default properties of each field in the cooperation form.
    return [
        // --- Individual Specific Fields ---
        'store_name' => ['type' => 'text', 'form' => 'individual', 'label' => 'نام فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_owner_name' => ['type' => 'text', 'form' => 'individual', 'label' => 'نام مالک فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_address' => ['type' => 'textarea', 'form' => 'individual', 'label' => 'آدرس فروشگاه', 'default_required' => true, 'default_visible' => true],
        'store_images' => ['type' => 'file', 'form' => 'individual', 'label' => 'تصاویر فروشگاه', 'default_required' => true, 'default_visible' => true],

        // --- Legal Specific Fields ---
        'company_name' => ['type' => 'text', 'form' => 'legal', 'label' => 'نام شرکت', 'default_required' => true, 'default_visible' => true],
        'contact_person' => ['type' => 'text', 'form' => 'legal', 'label' => 'نام رابط', 'default_required' => true, 'default_visible' => true],
        'company_address' => ['type' => 'textarea', 'form' => 'legal', 'label' => 'آدرس شرکت', 'default_required' => true, 'default_visible' => true],
        'email' => ['type' => 'email', 'form' => 'legal', 'label' => 'ایمیل', 'default_required' => true, 'default_visible' => true],
        'company_images' => ['type' => 'file', 'form' => 'legal', 'label' => 'تصاویر شرکت', 'default_required' => true, 'default_visible' => true],
        'company_docs' => ['type' => 'file', 'form' => 'legal', 'label' => 'اساسنامه و روزنامه رسمی', 'default_required' => true, 'default_visible' => true],

        // --- Common Fields (Appear on both forms) ---
        'activity_field' => ['type' => 'select', 'form' => 'both', 'label' => 'زمینه فعالیت', 'options_key' => 'activity_field_options', 'default_required' => true, 'default_visible' => true],
        'how_heard' => ['type' => 'select', 'form' => 'both', 'label' => 'نحوه آشنایی با ما', 'options_key' => 'how_heard_options', 'default_required' => false, 'default_visible' => true],
        'activity_description' => ['type' => 'text', 'form' => 'both', 'label' => 'شرح فعالیت', 'default_required' => false, 'default_visible' => true],
        'postal_code' => ['type' => 'text', 'form' => 'both', 'label' => 'کد پستی', 'default_required' => true, 'default_visible' => true],
        'mobile_number' => ['type' => 'text', 'form' => 'both', 'label' => 'شماره همراه', 'default_required' => true, 'default_visible' => true],
        'phone_number' => ['type' => 'text', 'form' => 'both', 'label' => 'تلفن ثابت', 'default_required' => false, 'default_visible' => true],
        'website' => ['type' => 'text', 'form' => 'both', 'label' => 'آدرس سایت', 'default_required' => false, 'default_visible' => true],
        'branches' => ['type' => 'textarea', 'form' => 'both', 'label' => 'آدرس شعب', 'default_required' => false, 'default_visible' => true],
        'description' => ['type' => 'textarea', 'form' => 'both', 'label' => 'توضیحات تکمیلی', 'default_required' => false, 'default_visible' => true],

        // --- Common Document Fields ---
        'national_card' => ['type' => 'file', 'form' => 'both', 'label' => 'کارت ملی (رو و پشت)', 'default_required' => true, 'default_visible' => true],
        'id_card' => ['type' => 'file', 'form' => 'both', 'label' => 'شناسنامه (تمام صفحات)', 'default_required' => true, 'default_visible' => true],
        'business_license' => ['type' => 'file', 'form' => 'both', 'label' => 'جواز کسب', 'default_required' => true, 'default_visible' => true],
        'ownership_or_lease' => ['type' => 'file', 'form' => 'both', 'label' => 'سند مالکیت یا اجاره‌نامه', 'default_required' => true, 'default_visible' => true],
        'thana_certificate' => ['type' => 'file', 'form' => 'both', 'label' => 'گواهی ثبت ثنا', 'default_required' => true, 'default_visible' => true],
        'logo' => ['type' => 'file', 'form' => 'both', 'label' => 'لوگو', 'default_required' => false, 'default_visible' => true],
        'check_image' => ['type' => 'file', 'form' => 'both', 'label' => 'تصویر چک صیادی', 'default_required' => false, 'default_visible' => true],
        'signature_certificate' => ['type' => 'file', 'form' => 'both', 'label' => 'گواهی امضا', 'default_required' => false, 'default_visible' => true],
        'tax_info' => ['type' => 'file', 'form' => 'both', 'label' => 'اطلاعات سامانه مالیاتی', 'default_required' => false, 'default_visible' => true],
        'enamad' => ['type' => 'file', 'form' => 'both', 'label' => 'تصویر اینماد', 'default_required' => false, 'default_visible' => true],
    ];
}


// API Settings Page Callback
function mlr_api_settings_page_callback() {
    ?>
    <div class="wrap mlr-admin-wrap">
        <h1>تنظیمات اتصال به API فینوتک (شاهکار)</h1>
        <p>این اطلاعات برای تأیید تطابق کد ملی و شماره موبایل کاربران در فرم ثبت درخواست تسهیلات استفاده می‌شود.</p>
        <form method="post" action="options.php">
            <?php settings_fields('mlr_api_settings_group'); ?>
            <?php do_settings_sections('mlr_api_settings_group'); ?>
             <div class="mlr-settings-card">
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_client_id">Client ID</label></th>
                        <td><input type="text" id="mlr_shahkar_client_id" name="mlr_shahkar_client_id" value="<?php echo esc_attr(get_option('mlr_shahkar_client_id')); ?>" class="regular-text ltr" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_client_secret">Client Secret</label></th>
                        <td><input type="password" id="mlr_shahkar_client_secret" name="mlr_shahkar_client_secret" value="" placeholder="<?php echo esc_attr(get_option('mlr_shahkar_client_secret')) ? '•••••••• (برای تغییر، مقدار جدید را وارد کنید)' : ''; ?>" class="regular-text ltr" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="mlr_shahkar_owner_nid">Owner NID <br>(کد ملی مالک سرویس)</label></th>
                        <td><input type="text" id="mlr_shahkar_owner_nid" name="mlr_shahkar_owner_nid" value="<?php echo esc_attr(get_option('mlr_shahkar_owner_nid')); ?>" class="regular-text ltr" pattern="[0-9]{10}" title="کد ملی 10 رقمی" />
                        <p class="description">کد ملی شخصی که سرویس فینوتک به نام ایشان ثبت شده است.</p></td>
                    </tr>
                </table>
            </div>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Enqueue Admin Scripts
add_action('admin_enqueue_scripts', 'mlr_enqueue_admin_scripts');
function mlr_enqueue_admin_scripts($hook) {
    // List all admin page hooks associated with your plugin
     $plugin_pages = [
        'toplevel_page_mlr-loan-requests',
        'عملیات-تسهیلات_page_mlr-granted-requests',
        'عملیات-تسهیلات_page_mlr-unsettled-requests',
        'عملیات-تسهیلات_page_mlr-settled-requests',
        'عملیات-تسهیلات_page_mlr-installment-plans',
        'عملیات-تسهیلات_page_mlr-api-settings',
        'toplevel_page_mlr-cooperation-main',
        // 'مدیریت-همکاری_page_mlr-activity-fields', // Keep commented out
        'مدیریت-همکاری_page_mlr-form-editor', // New Page Hook
        'مدیریت-همکاری_page_mlr-cooperation-contract-settings',
        'toplevel_page_mlr-sms-settings',
        'تنظیمات-پیامک_page_mlr-log-viewer',
    ];

    // Check if the current hook is one of the plugin's main pages
    $is_plugin_page = in_array($hook, $plugin_pages);

    // Also check for subpages created using admin.php?page=...&status=...
    if (!$is_plugin_page && isset($_GET['page']) && $_GET['page'] === 'mlr-loan-requests' && isset($_GET['status'])) {
        $is_plugin_page = true;
    }

    // Also check for user profile/edit pages
    if (!$is_plugin_page && ($hook === 'profile.php' || $hook === 'user-edit.php')) {
         $is_plugin_page = true; // Load scripts on user profile pages as well
    }

    if (!$is_plugin_page) {
        return; // Don't load scripts on unrelated admin pages
    }

    $version = '8.3.9'; // Update version
    wp_enqueue_style('mlr-admin-css', MLR_PLUGIN_URL . 'assets/css/admin.css', [], $version);

    // Enqueue Media Uploader scripts only on pages that use it
    if ($hook === 'مدیریت-همکاری_page_mlr-cooperation-contract-settings'
        || $hook === 'عملیات-تسهیلات_page_mlr-installment-plans'
        /* || $hook === 'مدیریت-همکاری_page_mlr-form-editor' */ ) { // Media uploader not currently used in form editor
        wp_enqueue_media();
    }

    // Enqueue Datepicker and Main Admin JS
    wp_enqueue_script('mlr-jalali-datepicker', MLR_PLUGIN_URL . 'assets/js/jalali-datepicker.js', ['jquery'], $version, true);
    wp_enqueue_script('mlr-admin-js', MLR_PLUGIN_URL . 'assets/js/admin.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);

    // Localize data for admin.js
    wp_localize_script('mlr-admin-js', 'mlrAjax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('mlr_ajax_nonce_action')
    ]);

    // Inline JS specifically for Form Editor interactions
    if ($hook === 'مدیریت-همکاری_page_mlr-form-editor') {
        // This script handles disabling/enabling the 'required' toggle based on the 'visible' toggle for file fields.
        wp_add_inline_script('mlr-admin-js', '
            jQuery(document).ready(function($){
                // Function to update required state based on visibility
                function updateRequiredState(visibilityToggle) {
                    var isChecked = $(visibilityToggle).is(":checked");
                    var controlsDiv = $(visibilityToggle).closest(".mlr-field-controls");
                    var requiredSwitch = controlsDiv.find(".mlr-required-switch");
                    var requiredLabel = controlsDiv.find(".mlr-required-label");
                    var requiredInput = requiredSwitch.find("input[type=checkbox]");

                    if (isChecked) {
                        // Enable required toggle
                        requiredSwitch.removeClass("mlr-disabled");
                        requiredLabel.removeClass("mlr-disabled");
                        requiredInput.prop("disabled", false);
                    } else {
                        // Disable and uncheck required toggle
                        requiredSwitch.addClass("mlr-disabled");
                        requiredLabel.addClass("mlr-disabled");
                        requiredInput.prop("disabled", true).prop("checked", false);
                    }
                }

                // Apply logic on change
                $(".mlr-visibility-toggle").on("change", function(){
                    updateRequiredState(this);
                });

                // Apply logic on initial page load for all toggles
                $(".mlr-visibility-toggle").each(function(){
                    updateRequiredState(this);
                });
            });
        ');
    }

}

// Enqueue Frontend Scripts
add_action('wp_enqueue_scripts', 'mlr_enqueue_frontend_scripts');
function mlr_enqueue_frontend_scripts() {
    global $post;
    $version = '8.3.9'; // Update version

    // General frontend styles
    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], $version);

    // Jalali Datepicker (Load globally for now, can be conditional later)
    wp_enqueue_script('mlr-jalali-datepicker', MLR_PLUGIN_URL . 'assets/js/jalali-datepicker.js', ['jquery'], $version, true);

    // Check if the current page contains the contract viewer shortcode
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_cooperation_contract_viewer')) {
        // Enqueue specific CSS for the contract viewer page
        wp_enqueue_style('mlr-contract-viewer-css', MLR_PLUGIN_URL . 'assets/css/contract-viewer.css', [], $version);
        // Enqueue specific JS for the contract viewer page (handling OTP)
        wp_enqueue_script('mlr-contract-viewer-js', MLR_PLUGIN_URL . 'assets/js/contract-viewer.js', ['jquery'], $version, true);
        // Localize script with necessary data for AJAX calls on the contract page
        wp_localize_script('mlr-contract-viewer-js', 'mlr_contract_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'send_otp_nonce' => wp_create_nonce('mlr_send_cooperation_otp_nonce'),
            'verify_otp_nonce' => wp_create_nonce('mlr_verify_cooperation_otp_nonce'),
            'resend_cooldown' => 60 // Cooldown in seconds
        ]);
    }

    // Conditionally load cooperation form JS if shortcode exists
    if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'mlr_individual_request_form') || has_shortcode($post->post_content, 'mlr_legal_request_form'))) {
         wp_enqueue_script('mlr-cooperation-form-js', MLR_PLUGIN_URL . 'assets/js/cooperation-form.js', ['jquery'], '1.0.3', true); // Update version if needed
         wp_localize_script('mlr-cooperation-form-js', 'mlr_coop_ajax', [
             'ajax_url' => admin_url('admin-ajax.php'),
             'nonce'    => wp_create_nonce('mlr_cooperation_request_action'),
         ]);
         // Also enqueue cooperation form specific styles if needed
         // wp_enqueue_style('mlr-cooperation-form-css', MLR_PLUGIN_URL . 'assets/css/cooperation-form.css', [], $version);
    }

    // Conditionally load user requests JS if shortcode exists
     if (is_a($post, 'WP_Post') && (
         has_shortcode($post->post_content, 'mlr_user_loan_requests') ||
         has_shortcode($post->post_content, 'mlr_needs_review_requests') ||
         has_shortcode($post->post_content, 'mlr_processing_requests') ||
         has_shortcode($post->post_content, 'mlr_granted_user_requests') ||
         has_shortcode($post->post_content, 'mlr_user_settlement_cycles') ||
         has_shortcode($post->post_content, 'mlr_bank_expert_dashboard') || // Load for dashboards too
         has_shortcode($post->post_content, 'mlr_verified_docs_dashboard')
         )) {
        wp_enqueue_script('mlr-user-requests-js', MLR_PLUGIN_URL . 'assets/js/mlr-user-requests.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
        // This localization needs careful review based on which shortcode is present
        // We'll pass all nonces needed by mlr-user-requests.js
        wp_localize_script('mlr-user-requests-js', 'mlr_ajax_obj', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'filter_nonce'    => wp_create_nonce('mlr_user_requests_nonce'), // Used by loadRequests
            'details_nonce'   => wp_create_nonce('mlr_frontend_nonce'),     // Used by showDetailsModal
            'cycle_nonce'     => wp_create_nonce('mlr_user_cycle_nonce'),     // Used by cycle details toggle
            'allowed_statuses' => [] // This should be dynamically set by the shortcode rendering function if needed
        ]);

     }

     // Conditionally load bank expert JS if shortcode exists
     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_bank_expert_dashboard')) {
          wp_enqueue_style('mlr-bank-expert-dashboard-css', MLR_PLUGIN_URL . 'assets/css/bank-expert-dashboard.css', [], $version);
          wp_enqueue_script('mlr-bank-expert-dashboard-js', MLR_PLUGIN_URL . 'assets/js/bank-expert-dashboard.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
          wp_localize_script('mlr-bank-expert-dashboard-js', 'mlr_bank_ajax_obj', [
              'ajax_url' => admin_url('admin-ajax.php'),
              'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
          ]);
     }
      // Conditionally load verified docs JS if shortcode exists
     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_verified_docs_dashboard')) {
          // CSS is likely shared with bank-expert dashboard, enqueue if needed:
          // wp_enqueue_style('mlr-bank-expert-dashboard-css', MLR_PLUGIN_URL . 'assets/css/bank-expert-dashboard.css', [], $version);
          wp_enqueue_script('mlr-verified-docs-dashboard-js', MLR_PLUGIN_URL . 'assets/js/verified-docs-dashboard.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
          wp_localize_script('mlr-verified-docs-dashboard-js', 'mlr_verified_ajax_obj', [
              'ajax_url' => admin_url('admin-ajax.php'),
              'nonce'    => wp_create_nonce('mlr_frontend_nonce'),
          ]);
     }

     // Conditionally load loan form JS if shortcode exists
     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_loan_request_form')) {
         wp_enqueue_style('mlr-loan-form-style', MLR_PLUGIN_URL . 'assets/css/loan-request-form.css', [], $version);
         wp_enqueue_script('mlr-front-form-js', MLR_PLUGIN_URL . 'assets/js/loan-request-form.js', ['jquery'], $version, true);

         $user_commission = null;
         if (is_user_logged_in()) {
             $user_commission = get_user_meta(get_current_user_id(), 'acceptor_commission_percent', true);
         }

         wp_localize_script('mlr-front-form-js', 'mlr_form_ajax', [
             'ajax_url' => admin_url('admin-ajax.php'),
             'nonce' => wp_create_nonce('mlr_frontend_nonce'), // General frontend actions
             'calc_nonce' => wp_create_nonce('mlr_frontend_calc_nonce'), // Calculator
             'submit_nonce' => wp_create_nonce('mlr_loan_request_action'), // Form submission
             'plans' => mlr_get_js_plans(), // Get active plans data
             'user_commission' => $user_commission // Pass user-specific commission if available
         ]);
     }

     // Conditionally load loan calculator JS if shortcode exists
     if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'mlr_loan_calculator')) {
        // wp_enqueue_style('mlr-loan-calculator-style', MLR_PLUGIN_URL . 'assets/css/loan-calculator.css', [], $version); // Style is now in shortcode file
        wp_enqueue_script('mlr-calculator-js', MLR_PLUGIN_URL . 'assets/js/loan-calculator.js', ['jquery'], $version, true);
        $user_commission = null;
         if (is_user_logged_in()) {
             $user_commission = get_user_meta(get_current_user_id(), 'acceptor_commission_percent', true);
         }
        wp_localize_script('mlr-calculator-js', 'mlrCalculatorAjax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('mlr_frontend_calc_nonce'),
            'plans'   => mlr_get_js_plans(),
            'user_commission' => $user_commission
        ]);
     }

}


// Function to get JS plans for loan form/calculator
function mlr_get_js_plans() {
    global $wpdb;
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    // Ensure DB query is safe
    $plans = $wpdb->get_results("SELECT id, name, type, settings FROM `$table_installment_plans` WHERE is_active = 1 ORDER BY id DESC");

    // Check if $plans is an array before processing
    if (!is_array($plans)) {
        return []; // Return empty array if DB query fails or returns non-array
    }

    return array_map(function($plan) {
        $settings = maybe_unserialize($plan->settings);
        // Ensure settings is an array
        if (!is_array($settings)) {
            $settings = [];
        }
        // Extract only necessary settings for frontend JS
        $plan->view_settings = [
            'requires_bank_validation' => $settings['requires_bank_validation'] ?? 0,
            'min_amount' => $settings['min_amount'] ?? 0,
            'max_amount' => $settings['max_amount'] ?? 0,
            'active_installments' => $settings['active_installments'] ?? '',
            'min_interval' => $settings['min_interval'] ?? 1,
            'max_interval' => $settings['max_interval'] ?? 12,
            // Add other settings if needed by JS, e.g., 'prepayment_percent' for Market
            'prepayment_percent' => $settings['prepayment_percent'] ?? null,
        ];
        unset($plan->settings); // Don't send all settings to frontend
        return $plan;
    }, $plans); // Process the array
}


// Shahkar verification callback (AJAX) - Corrected based on HTML documentation
add_action('wp_ajax_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');
add_action('wp_ajax_nopriv_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');
function mlr_verify_shahkar_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce'); // Use the correct nonce defined for loan form

    $user_national_code = isset($_POST['national_code']) ? sanitize_text_field($_POST['national_code']) : '';
    $user_mobile = isset($_POST['mobile_number']) ? sanitize_text_field($_POST['mobile_number']) : '';

    // Basic validation
    if (!preg_match('/^\d{10}$/', $user_national_code) || !preg_match('/^09\d{9}$/', $user_mobile)) {
        wp_send_json_error(['message' => 'کد ملی یا شماره موبایل وارد شده نامعتبر است.']);
        return;
    }

    $client_id = get_option('mlr_shahkar_client_id');
    $client_secret = get_option('mlr_shahkar_client_secret');
    $owner_nid = get_option('mlr_shahkar_owner_nid');

    // Check if settings are configured
    if (empty($client_id) || empty($client_secret) || empty($owner_nid)) {
        mlr_log("Shahkar API Error: Settings not configured.");
        wp_send_json_error(['message' => 'سرویس احراز هویت در حال حاضر در دسترس نیست. لطفاً بعداً تلاش کنید.']);
        return;
    }

    mlr_log("Shahkar Verification Initiated for NID: {$user_national_code}, Mobile: {$user_mobile}");

    // --- Step 1: Get Access Token ---
    $token_url = 'https://api.finnotech.ir/dev/v2/oauth2/token'; // Use production URL 'https://api.finnotech.ir/v2/oauth2/token' if needed
    $auth_string = base64_encode("{$client_id}:{$client_secret}");
    // *** CORRECTED SCOPE according to HTML documentation ***
    $scope_for_token = 'card:shahkar:get'; // Scope likely needed for GET request as per انطباق کد ملی و شماره موبایل.html

    $token_args = [
        'method' => 'POST',
        'timeout' => 20,
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Basic ' . $auth_string,
        ],
        'body' => json_encode([
            'grant_type' => 'client_credentials',
            'nid' => $owner_nid,
            'scopes' => $scope_for_token, // Use corrected scope
        ]),
    ];

    mlr_log(["Shahkar Token Request Args:" => $token_args]);
    $token_response = wp_remote_post($token_url, $token_args);

    // Handle WP Error during token request
    if (is_wp_error($token_response)) {
        mlr_log("Shahkar API Error (Token Request wp_error): " . $token_response->get_error_message());
        wp_send_json_error(['message' => 'خطا در ارتباط با سرویس احراز هویت (مرحله ۱).']);
        return;
    }

    // Process token response
    $token_body_raw = wp_remote_retrieve_body($token_response);
    $token_body = json_decode($token_body_raw, true);
    $access_token = isset($token_body['result']['value']) ? $token_body['result']['value'] : null;
    $response_code = wp_remote_retrieve_response_code($token_response);
    $response_headers = wp_remote_retrieve_headers($token_response); // For debugging

    mlr_log([
        "Shahkar Token Response Code:" => $response_code,
        // "Shahkar Token Response Headers:" => $response_headers, // Optional: Log headers
        "Shahkar Token Response Body:" => $token_body_raw
    ]);

    // Check if token acquisition was successful
    if ($response_code !== 200 || !$access_token) {
        $error_message = 'پاسخ نامعتبر از سرور توکن.'; // Default message
        if (isset($token_body['error']['message'])) {
             $error_message = $token_body['error']['message'];
        } elseif (isset($token_body['errors'][0]['message'])) { // Check alternative error structure
             $error_message = $token_body['errors'][0]['message'];
        }
        mlr_log("Shahkar API Error (Token Response {$response_code}): Failed to get access token. Message: " . $error_message);
        // Provide a more user-friendly message, log the specific error
        wp_send_json_error(['message' => 'دریافت مجوز احراز هویت ناموفق بود. لطفا تنظیمات API را بررسی کنید یا با پشتیبانی تماس بگیرید.']);
        return;
    }

    mlr_log("Shahkar Token Acquired Successfully.");

    // --- Step 2: Verify National Code and Mobile ---
    // *** CORRECTED ENDPOINT, METHOD, and PARAMETER PASSING based on HTML doc ***
    $verify_base_url = "https://api.finnotech.ir/mpg/v2/clients/{$client_id}/shahkar/verify"; // Use production URL if needed
    $track_id = 'MLR' . time() . rand(100, 999); // Unique track ID

    // Add parameters as query arguments to the URL
    $verify_url_with_params = add_query_arg([
        'trackId' => $track_id,
        'mobile' => $user_mobile,
        'nationalCode' => $user_national_code,
    ], $verify_base_url);


    $verify_args = [
        'method' => 'GET', // *** Use GET method ***
        'timeout' => 25,
        'headers' => [
            // No Content-Type needed for GET usually
            'Authorization' => 'Bearer ' . $access_token,
        ],
        // 'body' => REMOVED - Parameters are in URL
    ];

    mlr_log(["Shahkar Verify Request URL:" => $verify_url_with_params, "Shahkar Verify Request Args:" => $verify_args]);
    $verify_response = wp_remote_get($verify_url_with_params, $verify_args); // *** Use wp_remote_get ***

    // Handle WP Error during verification request
    if (is_wp_error($verify_response)) {
        mlr_log("Shahkar API Error (Verify Request wp_error): " . $verify_response->get_error_message());
        wp_send_json_error(['message' => 'خطا در ارتباط با سرویس احراز هویت (مرحله ۲).']);
        return;
    }

    // Process verification response
    $verify_body_raw = wp_remote_retrieve_body($verify_response);
    $verify_body = json_decode($verify_body_raw, true);
    $verify_response_code = wp_remote_retrieve_response_code($verify_response);
    $verify_response_headers = wp_remote_retrieve_headers($verify_response); // For debugging

    mlr_log([
        "Shahkar Verify Response Code:" => $verify_response_code,
        // "Shahkar Verify Response Headers:" => $verify_response_headers, // Optional: Log headers
        "Shahkar Verify Response Body:" => $verify_body_raw
    ]);


    // Check verification result based on HTML documentation
    if ($verify_response_code === 200 && isset($verify_body['result']['isValid']) && $verify_body['result']['isValid'] === true && isset($verify_body['status']) && $verify_body['status'] === 'DONE') {
         mlr_log("Shahkar Verification Success for NID: {$user_national_code}, Mobile: {$user_mobile}");
        wp_send_json_success(['message' => 'تطابق شماره موبایل و کد ملی با موفقیت تأیید شد.']);
    } else {
        // Determine the error message
        $error_detail = 'عدم تطابق یا خطای نامشخص.'; // Default error
        if (isset($verify_body['result']['isValid']) && $verify_body['result']['isValid'] === false) {
             $error_detail = 'شماره موبایل وارد شده متعلق به این کد ملی نمی‌باشد.';
             mlr_log("Shahkar Verification Failed (Mismatch) for NID: {$user_national_code}, Mobile: {$user_mobile}");
        } elseif (isset($verify_body['error']['message'])) { // Check for standard error structure
             $error_detail = $verify_body['error']['message'];
             mlr_log("Shahkar API Error (Verify Response {$verify_response_code}): " . $error_detail);
        } elseif ($verify_response_code !== 200) { // Handle non-200 responses without specific error message
            $error_detail = "خطای سرویس احراز هویت (کد: {$verify_response_code}).";
            mlr_log("Shahkar API Error (Verify Response {$verify_response_code}): Unexpected status code. Raw Body: " . $verify_body_raw);
        } else {
             mlr_log("Shahkar API Error (Verify Response {$verify_response_code}): Unexpected response structure or status not DONE. Raw Body: " . $verify_body_raw);
        }

        wp_send_json_error(['message' => $error_detail]);
    }
}

?>