
jQuery(document).ready(function($) {

    // --- 1. SHARED JALALI DATEPICKER (ADMIN VERSION) ---
    (function() {
        if (window.MLR_JALALI_DATEPICKER_ACTIVE) { return; }
        if ($('#mlr-admin-datepicker').length > 0) return;

        let activeInput = null;
        let datepicker, yearSelect, monthSelect, grid;
        let currentYear, currentMonth;

        const dayNames = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
        const monthNames = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];

        function initDatepicker() {
            const now = new Date();
            const todayJalali = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric' }).format(now);
            const thisYear = parseInt(todayJalali) || 1403;

            let yearOptions = '<option value="" disabled>سال</option>';
            for (let y = thisYear + 1; y >= 1350; y--) {
                yearOptions += `<option value="${y}">${y}</option>`;
            }

            let monthOptions = '<option value="" disabled>ماه</option>';
            monthNames.forEach((name, index) => {
                monthOptions += `<option value="${index + 1}">${name}</option>`;
            });

            const html = `
                <div id="mlr-admin-datepicker" style="display:none; position:absolute; z-index:9999999; background:#fff; border:1px solid #ccd0d4; border-radius:4px; padding:10px; width:220px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); font-family: Tahoma, sans-serif; direction: rtl;">
                    <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                        <select class="year-select" style="width:48%; height:30px; font-size:12px;">${yearOptions}</select>
                        <select class="month-select" style="width:48%; height:30px; font-size:12px;">${monthOptions}</select>
                    </div>
                    <div class="mlr-dp-grid" style="display:grid; grid-template-columns:repeat(7, 1fr); gap:2px; text-align:center;"></div>
                </div>`;

            $('body').append(html);

            datepicker = $('#mlr-admin-datepicker');
            yearSelect = datepicker.find('.year-select');
            monthSelect = datepicker.find('.month-select');
            grid = datepicker.find('.mlr-dp-grid');

            yearSelect.on('change', function(e) { e.stopPropagation(); currentYear = parseInt($(this).val()); renderCalendar(); });
            monthSelect.on('change', function(e) { e.stopPropagation(); currentMonth = parseInt($(this).val()); renderCalendar(); });
            
            grid.on('click', '.day-cell', function(e) {
                e.stopPropagation();
                if (!activeInput) return;
                
                const day = $(this).data('day');
                const formattedDate = `${currentYear}/${String(currentMonth).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
                
                $(activeInput).val(formattedDate).trigger('change');
                datepicker.fadeOut(100);
                activeInput = null;
            });

            datepicker.on('click', function(e){ e.stopPropagation(); });
        }

        function isJalaliLeap(year) { return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(year % 33) > -1; }
        
        function toGregorian(jy, jm, jd) {
            var sal_a, gy, gm, gd, days; jy += 1595; days = -355668 + (365 * jy) + (~~(jy / 33) * 8) + ~~(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
            gy = 400 * ~~(days / 146097); days %= 146097; if (days > 36524) { gy += 100 * ~~(--days / 36524); days %= 36524; if (days >= 365) days++; }
            gy += 4 * ~~(days / 1461); days %= 1461; if (days > 365) { gy += ~~((days - 1) / 365); days = (days - 1) % 365; }
            gd = days + 1; sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
            return new Date(gy, gm - 1, gd);
        }

        function renderCalendar() {
            if(!currentYear || !currentMonth) return;
            grid.empty();
            dayNames.forEach(d => grid.append(`<span style="font-size:11px; font-weight:bold; color:#777; padding:4px 0;">${d}</span>`));
            
            const daysInMonth = (currentMonth <= 6) ? 31 : (currentMonth <= 11) ? 30 : (isJalaliLeap(currentYear)) ? 30 : 29;
            const startDayIndex = (new Date(toGregorian(currentYear, currentMonth, 1)).getDay() + 1) % 7;
            
            for (let i = 0; i < startDayIndex; i++) grid.append('<span></span>');
            
            for (let day = 1; day <= daysInMonth; day++) {
                grid.append($(`<span class="day-cell" style="padding:5px; cursor:pointer; border-radius:3px; font-size:12px; transition:0.2s;">${day}</span>`)
                    .data('day', day)
                    .hover(
                        function(){ $(this).css('background', '#f0f0f1'); }, 
                        function(){ $(this).css('background', 'transparent'); }
                    )
                );
            }
        }

        function openDatepicker(inputEl) {
            initDatepicker();
            activeInput = inputEl;
            const val = $(activeInput).val();
            
            if (val && val.match(/^\d{4}\/\d{2}\/\d{2}$/)) {
                const parts = val.split('/');
                currentYear = parseInt(parts[0]);
                currentMonth = parseInt(parts[1]);
            } else {
                const now = new Date();
                const todayParts = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: 'numeric' }).format(now).split('/');
                currentYear = parseInt(todayParts[0]);
                currentMonth = parseInt(todayParts[1]);
            }
            
            yearSelect.val(currentYear);
            monthSelect.val(currentMonth);
            renderCalendar();

            const offset = $(activeInput).offset();
            const height = $(activeInput).outerHeight();
            
            datepicker.css({
                top: (offset.top + height + 2) + 'px',
                left: 'auto',
                right: ($(window).width() - (offset.left + $(activeInput).outerWidth())) + 'px',
                display: 'block'
            });
        }

        $(document).on('click', '.jalali-datepicker, .mlr-datepicker-trigger', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            let targetInput;
            if ($(this).hasClass('mlr-datepicker-trigger')) {
                targetInput = $(this).prev('.jalali-datepicker');
            } else {
                targetInput = $(this);
            }
            
            if (targetInput.length) {
                openDatepicker(targetInput[0]);
            }
        });

        $(document).on('click', function(e) {
            if (datepicker && datepicker.is(':visible')) {
                datepicker.fadeOut(100);
                activeInput = null;
            }
        });

        initDatepicker();
    })();


    // --- 2. مدیریت امن درخواست‌های AJAX ---

    // تابع کمکی برای استخراج پیام خطا
    function getErrorMessage(res) {
        if (!res) {
            return 'پاسخ خالی از سرور دریافت شد (ممکن است خطای دیتابیس یا انکدینگ باشد).';
        }
        if (res.data && res.data.message) {
            return res.data.message;
        }
        if (res === 0 || res === '0' || res === -1 || res === '-1') {
            return 'خطای امنیتی یا انقضای نشست کاربری. لطفاً صفحه را رفرش کنید.';
        }
        if (typeof res === 'string') {
            if (res.length < 100) return res;
            return 'خطای ناشناخته در سرور (پاسخ نامعتبر).';
        }
        return 'خطای نامشخص در دریافت اطلاعات.';
    }

    // تغییر وضعیت
    $(document).on('change', '.mlr-status-select', function() {
        var select = $(this), rid = select.data('id'), status = select.val(), spinner = select.next('.spinner');
        spinner.addClass('is-active'); select.prop('disabled', true);
        
        $.post(mlrAjax.ajaxurl, { action: 'mlr_update_cooperation_status', nonce: mlrAjax.nonce, request_id: rid, status: status }, function(res) {
            spinner.removeClass('is-active'); select.prop('disabled', false);
            if(res && res.success) {
                select.data('original-value', status);
            } else {
                alert(getErrorMessage(res));
                select.val(select.data('original-value'));
            }
        }).fail(function() {
            spinner.removeClass('is-active'); select.prop('disabled', false);
            alert('خطا در برقراری ارتباط با سرور.');
            select.val(select.data('original-value'));
        });
    });

    // باز کردن جزئیات سیکل (رفع باگ کنسول)
    $(document).on('click', '.mlr-cycle-row', function(e) {
        e.stopPropagation();
        var row = $(this), id = row.data('cycle-id'), details = $('#cycle-details-' + id), container = details.find('.cycle-details-container');
        row.toggleClass('open'); details.toggle();
        
        if(!row.data('loaded') && details.is(':visible')) {
            container.html('<div style="text-align:center;padding:15px;"><span class="spinner is-active"></span> در حال دریافت اطلاعات...</div>');
            
            $.post(mlrAjax.ajaxurl, { action: 'mlr_get_cycle_details', nonce: mlrAjax.nonce, cycle_id: id }, function(res) {
                if (res && res.success) {
                    container.html(res.data.html);
                    row.data('loaded', true);
                } else {
                    container.html('<div class="notice notice-error inline"><p>' + getErrorMessage(res) + '</p></div>');
                }
            }).fail(function(xhr) {
                container.html('<div class="notice notice-error inline"><p>خطای سرور: ' + xhr.status + '</p></div>');
            });
        }
    });

    // دکمه‌های عملیات (آکاردئون)
    $(document).on('click', '.mlr-actions-btn-icon:not(.mlr-view-details-btn)', function(e) {
        e.stopPropagation();
        var row = $('#actions-row-' + $(this).data('id'));
        if (row.length) {
            $('.mlr-actions-row').not(row).hide();
            row.toggle();
        }
    });

    // نمایش مودال جزئیات درخواست
    $(document).on('click', 'tr.mlr-request-row, tr.mlr-cooperation-request-row', function(e) {
        if ($(e.target).closest('a, button, input, select, .dashicons, .mlr-actions-container, .mlr-status-select-wrapper').length) return;
        triggerModal($(this));
    });

    $(document).on('click', '.mlr-view-details-btn', function(e) {
        e.preventDefault();
        e.stopPropagation(); 
        triggerModal($(this).closest('tr'));
    });

    function triggerModal(row) {
        var action = 'mlr_get_request_details';
        if (row.hasClass('mlr-cooperation-request-row')) {
            action = 'mlr_get_cooperation_request_details';
        }
        
        var rid = row.data('id');
        if(!rid) return;
        
        $('#mlr-overlay, #mlr-details-content').fadeIn(200);
        $('#mlr-details-inner').html('<div style="text-align:center;padding:40px;"><span class="spinner is-active"></span> در حال بارگذاری...</div>');
        
        $.post(mlrAjax.ajaxurl, { action: action, nonce: mlrAjax.nonce, request_id: rid }, function(res) {
            if (res && res.success) {
                $('#mlr-details-inner').html(res.data.html);
            } else {
                $('#mlr-details-inner').html('<div class="notice notice-error"><p>' + getErrorMessage(res) + '</p></div>');
            }
        }).fail(function() {
             $('#mlr-details-inner').html('<div class="notice notice-error"><p>خطای شبکه.</p></div>');
        });
    }

    $(document).on('click', '#mlr-overlay, #mlr-close-details', function() { $('#mlr-overlay, #mlr-details-content').fadeOut(200); });
    
    // ثبت نظر
    $(document).on('click', '#mlr-add-comment-btn', function() {
        var btn = $(this), rid = btn.data('id'), txt = $('#mlr_new_comment_text').val();
        if(!txt) return alert('متن نظر نمی‌تواند خالی باشد.');
        
        btn.prop('disabled', true).next('.spinner').addClass('is-active');
        $.post(mlrAjax.ajaxurl, { action: 'mlr_add_comment', nonce: mlrAjax.nonce, request_id: rid, comment: txt }, function(res) {
            btn.prop('disabled', false).next('.spinner').removeClass('is-active');
            if(res && res.success) { 
                $('#mlr-comments-history-container').append(res.data.new_comment_html); 
                $('#mlr_new_comment_text').val(''); 
            } else { 
                alert(getErrorMessage(res)); 
            }
        }).fail(function() {
            btn.prop('disabled', false).next('.spinner').removeClass('is-active');
            alert('خطای شبکه.');
        });
    });

    $('.mlr-status-select').each(function() { $(this).data('original-value', $(this).val()); });
});