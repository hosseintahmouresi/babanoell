<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_cycle_details', 'mlr_get_cycle_details_callback');

function mlr_get_cycle_details_callback() {
    // 1. Clean output buffer aggressively
    while (ob_get_level()) { ob_end_clean(); }

    // 2. Set Header
    header('Content-Type: application/json; charset=utf-8');

    // 3. Check Nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mlr_ajax_nonce_action')) {
         echo json_encode(['success' => false, 'data' => ['message' => 'نشست کاربری نامعتبر است. لطفاً صفحه را رفرش کنید.']]);
         wp_die();
    }

    if (!current_user_can('manage_options')) {
        echo json_encode(['success' => false, 'data' => ['message' => 'عدم دسترسی.']]);
        wp_die();
    }

    $cycle_id = isset($_POST['cycle_id']) ? intval($_POST['cycle_id']) : 0;
    if (!$cycle_id) {
        echo json_encode(['success' => false, 'data' => ['message' => 'شناسه سیکل نامعتبر است.']]);
        wp_die();
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';

    $requests = $wpdb->get_results($wpdb->prepare(
        "SELECT id, full_name, national_code, loan_amount, settlement_date 
         FROM {$table_requests} 
         WHERE settlement_cycle_id = %d 
         ORDER BY id ASC",
        $cycle_id
    ));

    if (empty($requests)) {
        echo json_encode(['success' => false, 'data' => ['message' => 'هیچ درخواستی در این سیکل یافت نشد.']]);
        wp_die();
    }

    // 4. Generate HTML and ensure UTF-8
    ob_start();
    ?>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>شناسه درخواست</th>
                <th>نام متقاضی</th>
                <th>کد ملی</th>
                <th>مبلغ (ریال)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $request): ?>
                <tr class="mlr-request-row" data-id="<?php echo esc_attr($request->id); ?>" style="cursor:pointer;">
                    <td><?php echo esc_html($request->id); ?></td>
                    <td><strong><?php echo esc_html($request->full_name); ?></strong></td>
                    <td><?php echo esc_html($request->national_code); ?></td>
                    <td><?php echo number_format($request->loan_amount); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php
    $html_output = ob_get_clean();

    // Force UTF-8 encoding if mbstring is available
    if (function_exists('mb_convert_encoding')) {
        $html_output = mb_convert_encoding($html_output, 'UTF-8', 'UTF-8');
    }

    // 5. Send JSON manually to catch errors
    $response = ['success' => true, 'data' => ['html' => $html_output]];
    $json = json_encode($response);

    if ($json === false) {
        $error = json_last_error_msg();
        echo json_encode(['success' => false, 'data' => ['message' => 'خطای انکدینگ JSON: ' . $error]]);
    } else {
        echo $json;
    }
    wp_die();
}