
<?php
// FILE: my-loan-request-plugin/includes/ajax/get-frontend-request-details.php
if (!defined('ABSPATH')) {
    exit;
}

// اگر این اکشن قبلاً تعریف شده، دوباره آن را اضافه نکن (جلوگیری از تداخل احتمالی)
if (!has_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback')) {
    add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');
}

function mlr_get_frontend_request_details_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه نامعتبر.']);
        return;
    }

    global $wpdb;
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $is_admin = current_user_can('manage_options');
    $is_bank_expert = in_array('bank', (array) $current_user->roles);

    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';

    // Fetch Request
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name, p.* FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    // Security Check
    if (!$is_admin) {
        if ($is_bank_expert) {
            if ($request->assigned_bank_user_id != $user_id) {
                wp_send_json_error(['message' => 'شما دسترسی به این پرونده ندارید.']);
                return;
            }
        } else {
            if ($request->user_id != $user_id) {
                wp_send_json_error(['message' => 'عدم دسترسی.']);
                return;
            }
        }
    }

    // Data Processing
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $order_items = !empty($request->order_items) ? json_decode($request->order_items, true) : [];
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];

    // Extra Files processing
    $extra_files = [];
    $extra_files['bank_validation_file'] = $request->bank_validation_file ?? '';
    $extra_files['signature_image'] = $request->signature_image ?? '';
    $extra_files['contract_file'] = $request->contract_file ?? '';

    $parsed_check_images = [];
    if (!empty($request->check_images)) {
        $maybe = maybe_unserialize($request->check_images);
        if (is_array($maybe)) {
            $parsed_check_images = $maybe;
        } else {
            $json = json_decode($request->check_images, true);
            if (is_array($json)) {
                $parsed_check_images = $json;
            } else {
                $parts = preg_split('/[\r\n,]+/', (string)$request->check_images);
                $parts = array_filter(array_map('trim', $parts));
                $parsed_check_images = $parts ? $parts : [(string)$request->check_images];
            }
        }
    }
    if (!empty($parsed_check_images)) {
        $extra_files['check_images'] = $parsed_check_images;
    }

    $extra_file_labels = [
        'bank_validation_file' => 'فایل اعتبارسنجی بانک',
        'signature_image'      => 'تصویر امضا',
        'contract_file'        => 'فایل قرارداد',
        'check_images'         => 'تصاویر چک',
    ];

    $occupations = ['official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر'];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : $request->occupation;
    $all_doc_labels = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست #<?php echo esc_html($request->id); ?></h3>
        <span class="mlr-status-badge status-<?php echo sanitize_html_class($request->status); ?>"><?php echo esc_html($request->status); ?></span>
    </div>
    
    <div class="mlr-modal-body">
        
        <div class="mlr-info-box">
            <h4>مشخصات فردی</h4>
            <div class="mlr-info-grid">
                <div><span>نام:</span> <strong><?php echo esc_html($request->full_name); ?></strong></div>
                <div><span>کد ملی:</span> <?php echo esc_html($request->national_code); ?></div>
                <div><span>موبایل:</span> <?php echo esc_html($request->mobile_number); ?></div>
                <div><span>شغل:</span> <?php echo esc_html($occupation_display); ?></div>
                <div style="grid-column: 1 / -1;"><span>آدرس:</span> <?php echo esc_html($request->residential_address); ?></div>
            </div>
        </div>

        <div class="mlr-info-box">
            <h4>اطلاعات مالی</h4>
            <div class="mlr-info-grid">
                <div><span>طرح:</span> <?php echo esc_html($request->plan_name); ?></div>
                <div><span>مبلغ وام:</span> <?php echo number_format($request->loan_amount); ?> ریال</div>
                <div><span>اقساط:</span> <?php echo esc_html($request->installment_count); ?> ماهه</div>
                <div><span>مبلغ قسط:</span> <?php echo number_format($request->installment_amount); ?> ریال</div>
                <?php if (!empty($request->final_settlement_amount)): ?>
                    <div><span>تسویه نهایی:</span> <strong><?php echo number_format((int)$request->final_settlement_amount); ?> ریال</strong></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($request->description)): ?>
        <div class="mlr-info-box">
            <h4>توضیحات تکمیلی</h4>
            <div class="mlr-long-text"><?php echo nl2br(esc_html($request->description)); ?></div>
        </div>
        <?php endif; ?>

        <?php if (!empty($extra_files) && is_array($extra_files) && array_filter($extra_files)): ?>
        <div class="mlr-info-box">
            <h4>فایل‌های تکمیلی</h4>
            <div class="mlr-file-grid">
                <?php foreach ($extra_files as $fkey => $fval): 
                    if (empty($fval)) continue;
                    $label = isset($extra_file_labels[$fkey]) ? $extra_file_labels[$fkey] : ucfirst(str_replace('_',' ', $fkey));
                ?>
                    <div class="mlr-file-item">
                        <div class="mlr-file-label"><?php echo esc_html($label); ?></div>
                        <div class="mlr-file-actions">
                            <?php if (is_array($fval)): ?>
                                <?php foreach ($fval as $idx => $url): if (empty($url)) continue; ?>
                                    <a class="mlr-view-file-btn" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">
                                        مشاهده <?php echo intval($idx)+1; ?>
                                    </a>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <a class="mlr-view-file-btn" href="<?php echo esc_url($fval); ?>" target="_blank" rel="noopener noreferrer">
                                    مشاهده فایل
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($uploaded_documents)): ?>
        <div class="mlr-info-box">
            <h4>مدارک بارگذاری شده</h4>
            <div class="mlr-docs-list">
                <?php foreach($uploaded_documents as $key => $val): 
                     $label = $all_doc_labels[$key] ?? $key;
                ?>
                    <div class="mlr-doc-item">
                        <strong><?php echo esc_html($label); ?>:</strong>
                        <?php if(is_array($val)): ?>
                            <?php foreach($val as $i => $url): ?>
                                <a href="<?php echo esc_url($url); ?>" target="_blank" class="mlr-btn-small">فایل <?php echo $i+1; ?></a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <a href="<?php echo esc_url($val); ?>" target="_blank" class="mlr-btn-small">مشاهده</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($comments)): ?>
        <div class="mlr-info-box">
            <h4>پیام‌های سیستم/کارشناس</h4>
            <div class="mlr-comments-list">
                <?php foreach($comments as $cm): ?>
                    <div class="mlr-comment">
                        <small><?php echo esc_html($cm['display_name']); ?> - <?php echo (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($cm['timestamp'], 'Y/m/d H:i') : $cm['timestamp']); ?></small>
                        <p><?php echo esc_html($cm['text']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if ($request->status === 'نقص مدارک' && $request->user_id == $user_id): ?>
        <div class="mlr-action-box" style="border: 2px solid #e6a800; background: #fff8e5; padding: 20px; border-radius: 8px; margin-top: 25px;">
            <h3 style="color: #b76e00; border-bottom: 1px solid #f0c330; padding-bottom: 10px; margin-top: 0;">
                <span class="dashicons dashicons-warning"></span> رفع نقص مدارک
            </h3>
            <p style="margin-bottom: 15px; font-weight: bold; color: #333;">کارشناس پرونده شما را به دلیل نقص در مدارک بازگردانده است. لطفاً پیام کارشناس را در بالا مطالعه کرده و مدارک تکمیلی یا اصلاح شده را در اینجا بارگذاری نمایید.</p>
            
            <form id="mlr-additional-docs-form" enctype="multipart/form-data">
                <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                
                <div class="mlr-form-group">
                    <label for="additional_documents_upload" class="mlr-label-required">انتخاب مدارک جدید:</label>
                    <input type="file" name="additional_documents[]" id="additional_documents_upload" multiple accept="image/*,.pdf" required class="mlr-file-input" style="background: #fff; border: 1px solid #ccd0d4; padding: 10px; width: 100%;">
                    <small style="display:block; margin-top:5px; color:#666;">می‌توانید چند فایل انتخاب کنید (تصویر یا PDF).</small>
                </div>

                <div id="mlr-upload-message" class="mlr-upload-status" style="display:none; margin-top: 10px; padding: 10px; border-radius: 4px;"></div>

                <button type="submit" class="mlr-btn mlr-btn-warning" style="width: 100%; margin-top: 15px; background: #f0c330; border: 1px solid #dcb020; color: #000; padding: 10px; cursor: pointer; border-radius: 5px; font-weight: bold;">
                    <span class="dashicons dashicons-upload"></span> ارسال مدارک و بررسی مجدد
                </button>
            </form>
        </div>
        <?php endif; ?>


        <?php if ($request->status === 'تکمیل مدارک' && $request->user_id == $user_id): ?>
            
            <?php
            // Prepare Contract Text
            $contract_raw = isset($request->contract_template) ? $request->contract_template : '';
            if (empty($contract_raw)) {
                $contract_raw = get_option('mlr_default_contract_text', 'متن قرارداد یافت نشد. لطفاً با پشتیبانی تماس بگیرید.');
            }
            $contract_html = function_exists('mlr_replace_contract_placeholders') ? mlr_replace_contract_placeholders($contract_raw, $request) : $contract_raw;
            ?>

            <div class="mlr-action-box mlr-complete-docs-section" style="border: 2px solid #2271b1; background: #f0f6fc;">
                <h3 style="color: #2271b1; border-bottom: 1px solid #c5d9ed; padding-bottom: 10px; margin-top: 0;">
                    <span class="dashicons dashicons-edit"></span> تکمیل و ارسال مدارک نهایی
                </h3>
                
                <div class="mlr-steps-indicator">
                    <div class="mlr-step active" data-step="1">۱. قرارداد</div>
                    <div class="mlr-step" data-step="2">۲. فاکتور</div>
                    <div class="mlr-step" data-step="3">۳. آپلود مدارک</div>
                </div>

                <form id="mlr-complete-docs-form" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                    
                    <div class="mlr-step-pane active" data-step-pane="1">
                        <div class="mlr-alert-info">لطفاً متن قرارداد را مطالعه کرده و جهت امضا، پرینت بگیرید.</div>
                        
                        <div class="mlr-preview-box">
                            <div class="printable-contract-area">
                                <?php echo wp_kses_post($contract_html); ?>
                            </div>
                        </div>
                        
                        <div class="mlr-step-actions">
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-print-contract-step-btn">
                                <span class="dashicons dashicons-printer"></span> چاپ قرارداد
                            </button>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-next-step-btn">مرحله بعد &larr;</button>
                        </div>
                    </div>

                    <div class="mlr-step-pane" data-step-pane="2">
                        <div class="mlr-alert-info">لطفاً فاکتور را بررسی و جهت امضا، پرینت بگیرید.</div>
                        
                        <div class="mlr-preview-box">
                            <div class="printable-invoice-area">
                                <?php echo do_shortcode('[mlr_invoice id="' . $request->id . '"]'); ?>
                            </div>
                        </div>

                        <div class="mlr-step-actions">
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-prev-step-btn">&rarr; مرحله قبل</button>
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-print-invoice-step-btn">
                                <span class="dashicons dashicons-printer"></span> چاپ فاکتور
                            </button>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-next-step-btn">مرحله بعد &larr;</button>
                        </div>
                    </div>

                    <div class="mlr-step-pane" data-step-pane="3">
                        <div class="mlr-alert-info">لطفاً تصاویر مدارک امضا شده را با کیفیت مناسب بارگذاری کنید.</div>
                        
                        <div class="mlr-form-group">
                            <label class="mlr-label-required">تصویر چک‌های صیادی (پشت و رو):</label>
                            <input type="file" name="completed_check_files[]" multiple accept="image/*,.pdf" required class="mlr-file-input">
                            <small>تصویر چک ضمانت که ثبت صیادی شده است.</small>
                        </div>

                        <div class="mlr-form-group">
                            <label class="mlr-label-required">تصویر قرارداد امضا شده (تمام صفحات):</label>
                            <input type="file" name="signed_contract_files[]" multiple accept="image/*,.pdf" required class="mlr-file-input">
                        </div>

                        <div class="mlr-form-group">
                            <label class="mlr-label-required">تصویر فاکتور امضا شده:</label>
                            <input type="file" name="signed_invoice_files[]" multiple accept="image/*,.pdf" required class="mlr-file-input">
                        </div>

                        <div class="mlr-form-group">
                            <label>سایر مدارک (اختیاری):</label>
                            <input type="file" name="other_completed_files[]" multiple accept="image/*,.pdf" class="mlr-file-input">
                        </div>

                        <div id="mlr-complete-upload-message" class="mlr-upload-status" style="display:none;"></div>

                        <div class="mlr-step-actions">
                            <button type="button" class="mlr-btn mlr-btn-secondary mlr-prev-step-btn">&rarr; مرحله قبل</button>
                            <button type="submit" class="mlr-btn mlr-btn-success mlr-submit-btn">
                                <span class="dashicons dashicons-yes"></span> ارسال نهایی مدارک
                            </button>
                        </div>
                    </div>

                </form>
            </div>
            
            <style>
                .mlr-complete-docs-section { padding: 20px; border-radius: 8px; margin-top: 25px; }
                .mlr-steps-indicator { display: flex; margin-bottom: 20px; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
                .mlr-step { padding: 5px 15px; color: #aaa; font-weight: bold; }
                .mlr-step.active { color: #2271b1; border-bottom: 3px solid #2271b1; margin-bottom: -12px; }
                .mlr-step.completed { color: #46b450; }
                .mlr-step-pane { display: none; animation: fadeIn 0.3s; }
                .mlr-step-pane.active { display: block; }
                .mlr-step-actions { margin-top: 20px; display: flex; gap: 10px; justify-content: flex-end; border-top: 1px solid #eee; padding-top: 15px; }
                .mlr-preview-box { background: #fff; border: 1px solid #ccc; padding: 15px; max-height: 300px; overflow-y: auto; margin-bottom: 15px; border-radius: 4px; box-shadow: inset 0 0 5px rgba(0,0,0,0.05); }
                .mlr-alert-info { background: #fff8e5; border-right: 4px solid #f0c330; padding: 10px; margin-bottom: 15px; font-size: 13px; color: #333; }
                .mlr-label-required::after { content: ' *'; color: red; }
                .mlr-file-input { width: 100%; padding: 8px; border: 1px solid #ddd; background: #fff; border-radius: 4px; margin-top: 5px; }
                @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
            </style>
        <?php endif; ?>


        <?php if ($is_bank_expert && $request->assigned_bank_user_id == $user_id): ?>
            <?php 
            $can_take_action = false;
            $options = [];
            
            if ($request->status == 'تأیید کارشناس') {
                $can_take_action = true;
                $options = ['تکمیل مدارک' => 'ارسال برای تکمیل مدارک', 'نقص مدارک' => 'اعلام نقص مدارک', 'رد شده' => 'رد درخواست'];
            } elseif ($request->status == 'تأیید مدارک') {
                $can_take_action = true;
                $options = ['اعطا شده' => 'تأیید نهایی و اعطا شده', 'رد شده' => 'رد درخواست', 'تکمیل مدارک' => 'بازگشت به تکمیل مدارک'];
            }
            ?>
            <?php if ($can_take_action): ?>
            <div class="mlr-action-box" style="background: #e8f0fe; padding: 15px; border-radius: 8px; margin-top: 20px; border: 1px solid #b3d7ff;">
                <h4 style="margin-top:0; color:#0056b3;">بررسی کارشناس بانک</h4>
                <form id="mlr-bank-expert-action-form">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request->id); ?>">
                    <div class="mlr-form-group">
                        <label for="new_status">تغییر وضعیت به:</label>
                        <select name="new_status" id="new_status" class="mlr-select" style="width:100%; margin-bottom:10px;">
                            <?php foreach($options as $val => $label): ?><option value="<?php echo esc_attr($val); ?>"><?php echo esc_html($label); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mlr-form-group">
                        <label for="comment_text">توضیحات (اختیاری):</label>
                        <textarea name="comment_text" id="comment_text" rows="3" class="mlr-textarea" style="width:100%;" placeholder="علت رد یا توضیحات تکمیلی..."></textarea>
                    </div>
                    <div class="mlr-action-message" style="display:none; margin-bottom:10px;"></div>
                    <button type="submit" class="mlr-btn mlr-btn-primary" style="width:100%;">ثبت بررسی</button>
                </form>
            </div>
            <?php endif; ?>
        <?php endif; ?>
        
    </div>
    <?php
    $html = ob_get_clean();
    wp_send_json_success(['html' => $html]);
}
?>