<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!has_action('wp_ajax_mlr_upload_additional_docs', 'mlr_upload_additional_docs_callback')) {
    add_action('wp_ajax_mlr_upload_additional_docs', 'mlr_upload_additional_docs_callback');
}

function mlr_upload_additional_docs_callback() {
    // 1. Security and Permission Checks
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای بارگذاری مدارک، لطفاً ابتدا وارد شوید.']);
        return;
    }
    // ... ادامه کدهای آپلود که در مرحله قبل ارسال شد ...
    // اگر فایل را کامل دارید نیاز به کپی مجدد نیست، مهم این است که در فایل قبلی نباشد.
    
    // جهت اطمینان، کد کامل این فایل را هم مجدد قرار می‌دهم:
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    $file_input_key = 'additional_documents'; 
    if (empty($_FILES[$file_input_key])) {
        wp_send_json_error(['message' => 'هیچ فایلی برای بارگذاری انتخاب نشده است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $user_id = get_current_user_id();

    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT required_documents FROM $table_name WHERE id = %d AND user_id = %d AND status = 'نقص مدارک'",
        $request_id, $user_id
    ));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد یا در حال حاضر در وضعیت "نقص مدارک" نیست.']);
        return;
    }

    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }

    $files = $_FILES[$file_input_key]; 
    $uploaded_urls = [];
    $errors = [];
    $upload_overrides = array('test_form' => false); 

    $allowed_mimes = [
        'jpg|jpeg|jpe' => 'image/jpeg',
        'png'          => 'image/png',
        'pdf'          => 'application/pdf',
    ];

    $rearranged_files = [];
    if(isset($files['name']) && is_array($files['name'])){
        foreach ($files['name'] as $key => $value) {
            if ($files['name'][$key] && $files['error'][$key] !== UPLOAD_ERR_NO_FILE) {
                if ($files['error'][$key] !== UPLOAD_ERR_OK) {
                     $errors[] = 'خطا در آپلود فایل (کد: '.$files['error'][$key].')';
                     continue; 
                }
                $rearranged_files[] = [
                    'name'     => $files['name'][$key],
                    'type'     => $files['type'][$key],
                    'tmp_name' => $files['tmp_name'][$key],
                    'error'    => $files['error'][$key],
                    'size'     => $files['size'][$key]
                ];
            }
        }
    }

    if (empty($rearranged_files) && empty($errors)) {
         wp_send_json_error(['message' => 'هیچ فایل معتبری انتخاب نشده است.']);
         return;
    }

    foreach ($rearranged_files as $file) {
         $file_type = wp_check_filetype(basename($file['name']), $allowed_mimes);
         if (empty($file_type['ext'])) {
             $errors[] = 'خطا: نوع فایل "' . esc_html($file['name']) . '" مجاز نیست.';
             continue; 
         }
         if ($file['size'] > 5 * 1024 * 1024) {
              $errors[] = 'خطا: حجم فایل "' . esc_html($file['name']) . '" بیشتر از 5 مگابایت است.';
              continue; 
         }
        $file['name'] = sanitize_file_name($file['name']);
        $movefile = wp_handle_upload($file, $upload_overrides);

        if ($movefile && !isset($movefile['error'])) {
            $uploaded_urls[] = $movefile['url']; 
        } else {
            $errors[] = 'خطا در آپلود: ' . ($movefile['error'] ?? 'نامشخص');
        }
    }

    if (!empty($errors)) {
        wp_send_json_error(['message' => implode('<br>', $errors)]);
        return;
    }

    $existing_documents = maybe_unserialize($request->required_documents);
    if (!is_array($existing_documents)) $existing_documents = [];
    if (!isset($existing_documents['additional_documents'])) $existing_documents['additional_documents'] = [];
    
    $existing_documents['additional_documents'] = array_merge($existing_documents['additional_documents'], $uploaded_urls);

    $updated = $wpdb->update($table_name, [
            'required_documents' => serialize($existing_documents), 
            'status'             => 'در حال بررسی',                   
            'last_edited_at'     => current_time('mysql')          
        ], ['id' => $request_id]);

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطای دیتابیس.']);
    } else {
        if(function_exists('mlr_send_sms_on_loan_status_change')) {
            mlr_send_sms_on_loan_status_change($request_id, 'در حال بررسی');
        }
        wp_send_json_success(['message' => 'مدارک ارسال شد و وضعیت به "در حال بررسی" تغییر کرد.']);
    }
}