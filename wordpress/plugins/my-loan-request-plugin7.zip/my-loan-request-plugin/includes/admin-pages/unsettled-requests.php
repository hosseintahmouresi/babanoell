<?php
function mlr_unsettled_requests_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $table_cycles = $wpdb->prefix . 'mlr_settlement_cycles';
    $users_table = $wpdb->prefix . 'users';
    $success_message = '';
    $error_message = '';

    // --- Process form to CREATE a settlement cycle ---
    if (isset($_POST['mlr_create_settlement_cycle']) && check_admin_referer('mlr_create_settlement_cycle_action')) {
        $request_ids = isset($_POST['request_ids']) ? array_map('intval', $_POST['request_ids']) : [];
        $description = isset($_POST['settlement_description']) ? sanitize_textarea_field($_POST['settlement_description']) : '';

        if (!empty($request_ids)) {
            // Verify all selected requests belong to the same user and have the same settlement date
            $first_request = $wpdb->get_row($wpdb->prepare(
                "SELECT user_id, settlement_date FROM $table_requests WHERE id = %d AND settlement_status = 'در انتظار تسویه' AND settlement_cycle_id IS NULL",
                $request_ids[0]
            ));

            if ($first_request) {
                $user_id = $first_request->user_id;
                $settlement_date = $first_request->settlement_date; // Use the date from the request
                $all_valid = true;
                $ids_placeholder = implode(',', array_fill(0, count($request_ids), '%d'));

                // Check if all selected IDs are valid for this user and date
                $valid_count_query = $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table_requests}
                     WHERE id IN ($ids_placeholder) AND user_id = %d AND settlement_date = %s AND settlement_status = 'در انتظار تسویه' AND settlement_cycle_id IS NULL",
                     array_merge($request_ids, [$user_id, $settlement_date]) // Pass array directly
                );
                $valid_count = $wpdb->get_var($valid_count_query);


                if ((int)$valid_count !== count($request_ids)) {
                    $error_message = 'خطا: تمام درخواست‌های انتخاب شده باید متعلق به یک پذیرنده، دارای یک تاریخ تسویه، در وضعیت "در انتظار تسویه" باشند و قبلاً به سیکل دیگری تخصیص نیافته باشند.';
                    $all_valid = false;
                    mlr_log("Cycle creation validation failed. Expected count: " . count($request_ids) . ", Found valid: " . $valid_count . " for user $user_id and date $settlement_date. IDs: " . implode(',', $request_ids));
                }

                if ($all_valid) {
                    // Calculate total amount for the cycle
                    $total_cycle_amount = $wpdb->get_var($wpdb->prepare(
                        "SELECT SUM(final_settlement_amount) FROM {$table_requests} WHERE id IN ($ids_placeholder)",
                         $request_ids // Pass array directly for IN clause
                    ));

                    if (isset($total_cycle_amount)) {
                        $cycle_insert_result = $wpdb->insert($table_cycles, [
                            'user_id' => $user_id,
                            'total_amount' => $total_cycle_amount,
                            'description' => $description,
                            'settlement_date' => $settlement_date ?: current_time('mysql') // Fallback just in case
                        ]);

                        if($cycle_insert_result === false) {
                            $error_message = 'خطا در ایجاد رکورد سیکل تسویه: ' . $wpdb->last_error;
                            mlr_log("Error inserting cycle: " . $wpdb->last_error);
                        } else {
                            $cycle_id = $wpdb->insert_id;
                            // Update requests with the new cycle ID (do not change settlement_status here)
                            $updated_request_ids = [];
                            $all_updated = true;

                            foreach ($request_ids as $rid) {
                                $rid = (int) $rid;
                                $affected = $wpdb->query($wpdb->prepare(
                                    "UPDATE $table_requests SET settlement_cycle_id = %d WHERE id = %d AND settlement_status = 'در انتظار تسویه' AND settlement_cycle_id IS NULL",
                                    $cycle_id,
                                    $rid
                                ));

                                if ($affected === false || (int) $affected !== 1) {
                                    $all_updated = false;
                                    break;
                                }
                                $updated_request_ids[] = $rid;
                            }

                            if ($all_updated) {
                                $success_message = 'سیکل تسویه برای ' . count($request_ids) . ' درخواست با موفقیت ایجاد شد.';
                            } else {
                                // Rollback: unset cycle_id for already-updated requests and delete the created cycle
                                if (!empty($updated_request_ids)) {
                                    $rollback_placeholders = implode(',', array_fill(0, count($updated_request_ids), '%d'));
                                    $rollback_sql = $wpdb->prepare(
                                        "UPDATE $table_requests SET settlement_cycle_id = NULL WHERE id IN ($rollback_placeholders)",
                                        $updated_request_ids
                                    );
                                    $wpdb->query($rollback_sql);
                                }

                                $error_message = 'خطا در تخصیص شناسه سیکل به تمام درخواست‌ها. عملیات برگشت داده شد.';
                                mlr_log("Cycle creation partial update detected for cycle ID $cycle_id. Last DB error: " . $wpdb->last_error);
                                $wpdb->delete($table_cycles, ['id' => $cycle_id]);
                            }
                        }
                    } else {
                         $error_message = 'خطا در محاسبه مجموع مبلغ سیکل.';
                    }
                }
            } else {
                 $error_message = 'خطا: درخواست‌های انتخاب شده معتبر نیستند یا قبلاً پردازش شده‌اند.';
                 mlr_log("Cycle creation failed: First request ID " . $request_ids[0] . " not found or invalid.");
            }
        } else {
             $error_message = 'هیچ درخواستی برای ایجاد سیکل تسویه انتخاب نشده است.';
        }
    }

    // Query for requests that have a date but no cycle yet
    $requests_ready = $wpdb->get_results("
        SELECT r.id, r.full_name, r.national_code, r.final_settlement_amount, r.user_id, r.settlement_date, u.display_name
        FROM $table_requests r
        LEFT JOIN $users_table u ON r.user_id = u.ID
        WHERE r.status = 'اعطا شده' AND r.settlement_status = 'در انتظار تسویه' AND r.settlement_cycle_id IS NULL
        ORDER BY u.display_name, r.settlement_date, r.id ASC
    ");

    // Group requests by user and then by settlement date
    $grouped_requests = [];
    foreach ($requests_ready as $request) {
        // Generate a unique key combining user_id and display_name for robustness
        $user_key = $request->user_id . '_' . sanitize_key($request->display_name ?: 'کاربر-حذف-شده');
        $date_key = date('Y-m-d', strtotime($request->settlement_date)); // Group by date only (YYYY-MM-DD)
        if (!isset($grouped_requests[$user_key])) {
            $grouped_requests[$user_key] = [
                'name' => $request->display_name ?: 'کاربر حذف شده',
                'user_id' => $request->user_id, // Store user ID for grouping checkboxes
                'dates' => []
            ];
        }
        if (!isset($grouped_requests[$user_key]['dates'][$date_key])) {
             $grouped_requests[$user_key]['dates'][$date_key] = [
                 'jalali_date' => mlr_gregorian_to_jalali($date_key, 'Y/m/d'),
                 'requests' => []
             ];
        }
        $grouped_requests[$user_key]['dates'][$date_key]['requests'][] = $request;
    }

    wp_enqueue_script('jquery');
    // Ensure admin.js (containing toggle logic) is enqueued
    ?>
    <div class="wrap mlr-admin-wrap mlr-settlement-page mlr-unsettled-page">
         <div class="mlr-page-header">
             <h1><span class="dashicons dashicons-controls-repeat"></span> مرحله ۲: ایجاد سیکل تسویه</h1>
        </div>
        <p class="mlr-page-description">درخواست‌هایی که تاریخ تسویه آنها تعیین شده در اینجا بر اساس پذیرنده و تاریخ گروه‌بندی شده‌اند. درخواست‌های مربوط به یک گروه (یک پذیرنده و یک تاریخ مشخص) را انتخاب کرده و برای آنها سیکل تسویه ایجاد کنید. با کلیک روی هدر هر گروه تاریخ، لیست درخواست‌های آن باز/بسته می‌شود.</p>

        <?php if ($success_message) : ?><div id="message" class="notice notice-success is-dismissible mlr-notice"><p><?php echo wp_kses_post($success_message); ?></p></div><?php endif; ?>
        <?php if ($error_message) : ?><div id="message" class="notice notice-error is-dismissible mlr-notice"><p><?php echo wp_kses_post($error_message); ?></p></div><?php endif; ?>

        <?php if (empty($grouped_requests)): ?>
             <div class="mlr-card">
                <div class="mlr-card-content" style="text-align: center; padding: 30px;">
                    <span class="dashicons dashicons-info-outline" style="font-size: 30px; color: #777; margin-bottom: 10px; display: block;"></span>
                    <p>در حال حاضر هیچ درخواستی آماده ایجاد سیکل نیست.</p>
                     <a href="<?php echo admin_url('admin.php?page=mlr-granted-requests'); ?>" class="button">بازگشت به مرحله تعیین تاریخ</a>
                </div>
            </div>
        <?php else: ?>
            <form id="mlr-settlement-form" method="post">
                <?php wp_nonce_field('mlr_create_settlement_cycle_action'); ?>

                 <div class="mlr-card mlr-bulk-action-card">
                    <div class="mlr-card-content">
                        <label for="settlement_description" class="mlr-label">توضیحات سیکل تسویه (اختیاری):</label>
                        <div class="mlr-bulk-action-controls">
                            <textarea id="settlement_description" name="settlement_description" placeholder="مثلا: تسویه مهر ماه ۱۴۰۴" rows="1" class="mlr-input"></textarea>
                            <button type="submit" name="mlr_create_settlement_cycle" class="button button-primary" value="create_cycle"><span class="dashicons dashicons-plus-alt"></span> ایجاد سیکل برای موارد انتخابی</button>
                        </div>
                         <p class="description mlr-form-description">توجه: فقط درخواست‌های مربوط به **یک پذیرنده** و **یک تاریخ تسویه** را همزمان انتخاب کنید.</p>
                    </div>
                </div>

                <?php foreach ($grouped_requests as $user_key => $user_data): ?>
                    <div class="mlr-user-group-card mlr-card">
                        <h2 class="mlr-card-title"><span class="dashicons dashicons-admin-users"></span> پذیرنده: <?php echo esc_html($user_data['name']); ?></h2>
                        <div class="mlr-card-content no-padding">
                            <?php foreach ($user_data['dates'] as $date_key => $date_data):
                                // Generate a unique group key for checkboxes AND toggle
                                $group_key_attr = esc_attr($user_data['user_id'] . '-' . $date_key);
                                $details_id = 'details-group-' . $group_key_attr; // Unique ID for details section
                            ?>
                                <div class="mlr-date-group">
                                    <div class="mlr-date-group-header mlr-group-toggle" data-target="#<?php echo $details_id; ?>">
                                        <div class="mlr-group-header-left">
                                            <span class="mlr-toggle-indicator dashicons dashicons-arrow-down-alt2"></span>
                                            <label onclick="event.stopPropagation();"> <?php // Prevent header click when clicking label/checkbox ?>
                                                <input type="checkbox" class="mlr-select-all-group" data-group-key="<?php echo $group_key_attr; ?>">
                                                تاریخ تسویه: <strong><?php echo esc_html($date_data['jalali_date']); ?></strong>
                                            </label>
                                        </div>
                                        <span class="mlr-group-count"><?php echo count($date_data['requests']); ?> درخواست</span>
                                    </div>
                                    <div class="mlr-group-details" id="<?php echo $details_id; ?>" style="display: none;"> <?php // Hidden by default ?>
                                        <div class="mlr-table-wrapper">
                                            <table class="wp-list-table widefat fixed striped mlr-inner-table mlr-compact-table">
                                                <thead>
                                                    <tr>
                                                        <td class="manage-column column-cb check-column"></td>
                                                        <th class="column-id">شناسه</th>
                                                        <th>نام متقاضی</th>
                                                        <th>کد ملی</th>
                                                        <th class="column-amount">مبلغ تسویه (ریال)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($date_data['requests'] as $request) : ?>
                                                    <tr class="mlr-request-row" data-id="<?php echo esc_attr($request->id); ?>">
                                                        <th scope="row" class="check-column">
                                                            <input type="checkbox" name="request_ids[]" value="<?php echo esc_attr($request->id); ?>" class="mlr-request-checkbox" data-group-key="<?php echo $group_key_attr; ?>">
                                                        </th>
                                                        <td class="column-id"><?php echo esc_html($request->id); ?></td>
                                                        <td><?php echo esc_html($request->full_name); ?></td>
                                                        <td><?php echo esc_html($request->national_code); ?></td>
                                                        <td class="column-amount"><?php echo number_format($request->final_settlement_amount); ?></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; // End date group loop ?>
                        </div>
                    </div>
                <?php endforeach; // End user group loop ?>
            <?php endif; ?>
        </form>
    </div>

    <?php // --- START: Add Styles directly --- ?>
    <style>
        /* --- Settlement Pages Common Styles --- */
        .mlr-settlement-page .mlr-page-description { color: #50575e; margin-top: 5px; font-size: 14px; margin-bottom: 20px; padding: 0 5px; }
        .mlr-settlement-page .mlr-card { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; margin-bottom: 25px; box-shadow: 0 1px 1px rgba(0,0,0,.04); overflow: hidden; }
        .mlr-settlement-page .mlr-card-title { font-size: 16px; font-weight: 600; padding: 14px 20px; margin: 0; border-bottom: 1px solid #dcdcde; color: #1d2327; display: flex; align-items: center; gap: 8px; background-color: #f6f7f7; }
        .mlr-settlement-page .mlr-card-title .dashicons { color: #50575e; }
        .mlr-settlement-page .mlr-card-content { padding: 20px; }
        .mlr-settlement-page .mlr-card-content.no-padding { padding: 0; }
        .mlr-settlement-page .mlr-compact-table { margin-bottom: 0; }
        .mlr-settlement-page .mlr-compact-table th, .mlr-settlement-page .mlr-compact-table thead td { font-size: 12px; padding: 10px 12px; background: #f9f9f9; text-align: right; color: #50575e;}
        .mlr-settlement-page .mlr-compact-table tbody td, .mlr-settlement-page .mlr-compact-table tbody th { padding: 10px 12px; font-size: 13px; vertical-align: middle; text-align: right; }
        .mlr-settlement-page .column-id { width: 10%; font-weight: 500; color: #646970; }
        .mlr-settlement-page .column-amount { width: 25%; font-weight: 500; }
        .mlr-settlement-page .column-date { width: 15%; font-size: 12px; color: #646970; }
        .mlr-settlement-page .mlr-notice { margin: 15px 5px !important; }

        /* --- Unsettled Requests Page (Step 2) Specific Styles --- */
        .mlr-unsettled-page .mlr-bulk-action-card .mlr-card-content { display: flex; flex-direction: column; gap: 10px; background-color: #f0f6fc; border-bottom: 1px solid #cce2ff;}
        .mlr-unsettled-page .mlr-label { font-weight: 600; color: #1d2327; margin-bottom: 5px; display: block; }
        .mlr-unsettled-page .mlr-bulk-action-controls { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .mlr-unsettled-page .mlr-bulk-action-controls textarea.mlr-input { flex-grow: 1; min-width: 250px; height: 38px; padding: 8px 10px; border-radius: 4px; border: 1px solid #8c8f94; box-sizing: border-box;}
        .mlr-unsettled-page .mlr-bulk-action-controls .button .dashicons { vertical-align: middle; margin-top: -2px; margin-left: 2px; font-size: 18px; }
        .mlr-unsettled-page .mlr-form-description { font-size: 12px; color: #50575e; margin-top: 5px; }

        .mlr-user-group-card { margin-bottom: 30px; }
        .mlr-user-group-card > .mlr-card-content.no-padding { padding: 10px 15px 15px; } /* Add padding back */
        .mlr-date-group { margin-bottom: 15px; border: 1px solid #e0e0e0; border-radius: 6px; overflow: hidden; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,0.03); }
        .mlr-date-group:last-child { margin-bottom: 0; }
        .mlr-date-group-header { background-color: #f9fafb; padding: 12px 15px; border-bottom: 1px solid #e0e0e0; display: flex; justify-content: space-between; align-items: center; cursor: pointer; /* Make header clickable */ transition: background-color 0.15s ease;}
        .mlr-date-group-header:hover { background-color: #f0f6fc; }
        .mlr-date-group-header .mlr-group-header-left { display: flex; align-items: center; gap: 8px; }
        .mlr-date-group-header .mlr-toggle-indicator { font-size: 18px; color: #787c82; transition: transform 0.2s ease-in-out; }
        .mlr-date-group-header.open .mlr-toggle-indicator { transform: rotate(180deg); color: #2271b1; }
        .mlr-date-group-header label { font-weight: 500; font-size: 14px; color: #333; display: flex; align-items: center; gap: 8px; margin: 0;}
        .mlr-date-group-header input[type="checkbox"] { margin-left: 5px; cursor: pointer;}
        .mlr-date-group-header strong { color: #007cba; }
        .mlr-group-count { font-size: 12px; color: #50575e; background: #eef0f2; padding: 3px 10px; border-radius: 12px; }
        .mlr-group-details { padding: 0; background: #fdfdff; border-top: 1px solid #e0e0e0;} /* Details area */
        .mlr-table-wrapper { /* Remove wrapper if table directly inside */ }
        .mlr-inner-table { margin-bottom: 0 !important; border: none !important; box-shadow: none !important; border-top: none !important; } /* Remove top border */
        .mlr-inner-table thead { display: none; } /* Hide inner table header */
        .mlr-inner-table th, .mlr-inner-table td { font-size: 13px; padding: 10px 15px; border-bottom: 1px solid #f0f0f5; }
        .mlr-inner-table tr:last-child td, .mlr-inner-table tr:last-child th { border-bottom: none; }
        .mlr-inner-table .check-column { padding-right: 15px !important; width: 3em !important; }
        .mlr-inner-table tr:hover { background-color: #eaf2fa !important; }
        .mlr-inner-table input[type="checkbox"]:disabled { opacity: 0.5; cursor: not-allowed;}
    </style>
    <?php // --- END: Add Styles --- ?>

    <?php // --- START: Add JS --- ?>
    <script>
    jQuery(document).ready(function($) {

        // --- Group Details Toggle ---
        $('.mlr-group-toggle').on('click', function(e) {
             // Prevent toggle if clicking on checkbox or its label
            if ($(e.target).is('input[type="checkbox"]') || $(e.target).closest('label').length > 0) {
                 return;
            }
            var targetId = $(this).data('target');
            $(this).toggleClass('open');
            $(targetId).slideToggle(200);
        });

        // --- Checkbox Logic (Existing) ---
        $('.mlr-select-all-group').on('click', function() { /* ... */
            var groupKey = $(this).data('group-key');
            var isChecked = $(this).is(':checked');
            $('.mlr-request-checkbox[data-group-key="' + groupKey + '"]:not(:disabled)').prop('checked', isChecked).trigger('change');
         });
        $('.mlr-request-checkbox').on('change', function() { /* ... */
            var $checkedCheckboxes = $('.mlr-request-checkbox:checked');
            var isAnyChecked = $checkedCheckboxes.length > 0;
            if (!isAnyChecked) {
                $('.mlr-request-checkbox, .mlr-select-all-group').prop('disabled', false);
                $('.mlr-select-all-group').prop('checked', false); return;
            }
            var selectedGroupKey = $checkedCheckboxes.first().data('group-key');
            $('.mlr-request-checkbox, .mlr-select-all-group').each(function() {
                var currentGroupKey = $(this).data('group-key');
                if (currentGroupKey !== selectedGroupKey) {
                    $(this).prop('disabled', true);
                     if ($(this).hasClass('mlr-select-all-group')) $(this).prop('checked', false);
                     if ($(this).hasClass('mlr-request-checkbox')) $(this).prop('checked', false);
                } else { $(this).prop('disabled', false); }
            });
             var $groupCheckboxes = $('.mlr-request-checkbox[data-group-key="' + selectedGroupKey + '"]');
             var $groupHeaderCheckbox = $('.mlr-select-all-group[data-group-key="' + selectedGroupKey + '"]');
             var allCheckedInGroup = $groupCheckboxes.length === $groupCheckboxes.filter(':checked').length;
             if (!$groupHeaderCheckbox.is(':disabled')) { $groupHeaderCheckbox.prop('checked', allCheckedInGroup); }
         });
        $('#mlr-settlement-form').on('submit', function(e) { /* ... */
            if ($('input[name="request_ids[]"]:checked').length === 0) { alert('لطفاً حداقل یک درخواست را انتخاب کنید.'); e.preventDefault(); return false; }
            if (!confirm('آیا از ایجاد سیکل تسویه مطمئن هستید؟ وضعیت به "تسویه شده" تغییر خواهد کرد.')) { e.preventDefault(); return false; }
         });
    });
    </script>
     <?php // --- END: Add JS --- ?>
    <?php
}
?>