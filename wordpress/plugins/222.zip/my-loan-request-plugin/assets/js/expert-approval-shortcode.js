var $ = jQuery.noConflict();

$(document).ready(function () {
    if (typeof $ === 'undefined') {
        console.error('jQuery لود نشده است.');
        return;
    }

    console.log('اسکریپت شورت‌کد لود شد');

    // Ensure frontend modal containers exist (Reachability/UI)
    if ($('#mlr-overlay').length === 0) {
        $('body').append('<div id="mlr-overlay" style="display:none;"></div>');
    }
    if ($('#mlr-details-content').length === 0) {
        $('body').append('<div id="mlr-details-content" style="display:none;"><button type="button" id="mlr-close-details" aria-label="بستن">×</button><div id="mlr-loading" style="display:none;text-align:center;padding:20px;"><span class="spinner is-active" style="float:none;visibility:visible;"></span></div><div id="mlr-details-inner"></div></div>');
    }

    $(document).on('click', '.mlr-actions-btn', function (e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('دکمه عملیات کلیک شد');
        let requestId = $(this).data('id');
        let actionsRow = $('#actions-row-' + requestId);
        $('.mlr-actions-row').not(actionsRow).removeClass('active').hide();
        actionsRow.toggleClass('active').toggle();
    });

    $(document).on('click', function (e) {
        if (!$(e.target).closest('.mlr-actions-container, .mlr-actions-row').length) {
            console.log('کلیک خارج از ردیف عملیات');
            $('.mlr-actions-row').removeClass('active').hide();
        }
    });

    $(document).on('click', '.mlr-request-row', function (e) {
        if ($(e.target).closest('#mlr-details-content, #mlr-overlay').length) { return; }
        if ($(e.target).is('a') || $(e.target).closest('a').length) { return; }
        e.preventDefault();
        e.stopPropagation();
        if ($(e.target).closest('.mlr-actions-btn, .mlr-actions-row, form, a').length) return;

        let requestId = $(this).data('id');
        if (!requestId) {
            console.error('شناسه درخواست یافت نشد.');
            alert('شناسه درخواست یافت نشد.');
            return;
        }

        console.log('نمایش جزئیات برای درخواست:', requestId);
        $('#mlr-loading').show();
        $('#mlr-details-inner').empty();
        $('#mlr-overlay').css('display', 'block');
        $('#mlr-details-content').css('display', 'block');
        $('#mlr-details-content').off('click.mlrModal').on('click.mlrModal', function(ev){ ev.stopPropagation(); });
        $('#mlr-overlay').off('click.mlrModal').on('click.mlrModal', function(ev){ ev.stopPropagation(); });

        $.ajax({
            url: (typeof mlr_bank_ajax_obj !== 'undefined' ? mlr_bank_ajax_obj.ajax_url : mlrAjax.ajaxurl),
            type: 'POST',
            data: {
                action: 'mlr_get_frontend_request_details',
                nonce: (typeof mlr_bank_ajax_obj !== 'undefined' ? mlr_bank_ajax_obj.nonce : mlrAjax.nonce),
                request_id: requestId
            },
            cache: false,
            success: function (response) {
                $('#mlr-loading').hide();
                if (response.success) {
                    $('#mlr-details-inner').html(response.data);
                } else {
                    console.error('خطا در AJAX:', response.data || 'پاسخ نامشخص');
                    alert('خطایی رخ داد: ' + (response.data || 'پاسخ نامشخص'));
                    $('#mlr-details-content').css('display', 'none');
                    $('#mlr-overlay').css('display', 'none');
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('#mlr-loading').hide();
                console.error('خطای AJAX:', textStatus, errorThrown);
                alert('خطا در ارتباط با سرور: ' + textStatus);
                $('#mlr-details-content').css('display', 'none');
                $('#mlr-overlay').css('display', 'none');
            }
        });
    });

    $(document).on('click', '.mlr-comment-btn', function (e) {
        e.preventDefault();
        let requestId = $(this).data('id');
        MLRCommon.showCommentForm(requestId);
    });

    $(document).on('submit', '[id^="mlr-comment-form-"]', function (e) {
        e.preventDefault();
        let requestId = $(this).find('input[name="request_id"]').val();
        let comment = $(this).find('textarea[name="comment"]').val();
        MLRCommon.submitComment(requestId, comment);
    });

    $('#mlr-invoice-form').on('submit', function (e) {
        let nationalCode = $('#customer_national_code').val();
        let mobileNumber = $('#customer_mobile').val();
        let loanAmount = $('#loan_amount').val();
        let totalAmount = $('#total_amount').val();

        if (!/^\d{10}$/.test(nationalCode)) {
            alert('کد ملی باید 10 رقم باشد.');
            e.preventDefault();
            return;
        }
        if (!/^09\d{9}$/.test(mobileNumber)) {
            alert('شماره موبایل باید با 09 شروع شود و 11 رقم باشد.');
            e.preventDefault();
            return;
        }
        if (loanAmount <= 0) {
            alert('مبلغ درخواست باید بیشتر از صفر باشد.');
            e.preventDefault();
            return;
        }
        if (totalAmount <= 0) {
            alert('جمع کل باید بیشتر از صفر باشد.');
            e.preventDefault();
            return;
        }
    });

    $('#mlr-close-details, #mlr-overlay').on('click', function () {
        $('#mlr-overlay').css('display', 'none');
        $('#mlr-details-content').css('display', 'none');
    });

    $('#mlr-details-content').on('click', function (e) {
        e.stopPropagation();
    });
});