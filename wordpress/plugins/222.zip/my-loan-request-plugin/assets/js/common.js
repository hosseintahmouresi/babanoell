var MLRCommon = MLRCommon || {};

/**
 * نمایش یا مخفی کردن فرم نظر برای یک درخواست مشخص.
 * @param {number} requestId - شناسه درخواست
 */
MLRCommon.showCommentForm = function (requestId) {
    var form = jQuery('#mlr-comment-form-' + requestId);
    form.toggle(); // ساده‌تر و خواناتر از if-else
};

/**
 * ارسال نظر برای یک درخواست مشخص از طریق AJAX.
 * @param {number} requestId - شناسه درخواست
 * @param {string} comment - متن نظر
 */
MLRCommon.submitComment = function (requestId, comment) {
    // بررسی اینکه نظر خالی نباشد
    if (!comment.trim()) {
        alert('لطفاً نظر خود را وارد کنید.');
        return;
    }

    // غیرفعال کردن دکمه ارسال و تغییر متن آن
    var submitButton = jQuery('#mlr-comment-form-' + requestId + ' button');
    submitButton.prop('disabled', true).text('در حال ارسال...');

    jQuery.ajax({
        url: mlrAjax.ajaxurl,
        type: 'POST',
        data: {
            action: 'mlr_add_comment',
            nonce: mlrAjax.nonce,
            request_id: requestId,
            comment: comment
        },
        success: function (response) {
            // بازگرداندن دکمه به حالت اولیه
            submitButton.prop('disabled', false).text('ارسال نظر');
            if (response.success) {
                alert('نظر با موفقیت اضافه شد.');
                jQuery('#mlr-comment-form-' + requestId).hide();
                jQuery('#mlr-comment-form-' + requestId + ' textarea').val('');
            } else {
                // نمایش پیام خطای دقیق‌تر
                var errorMessage = response.data && response.data.message ? response.data.message : 'نمی‌توان نظر را اضافه کرد.';
                alert('خطا: ' + errorMessage);
            }
        },
        error: function () {
            // بازگرداندن دکمه در صورت خطا
            submitButton.prop('disabled', false).text('ارسال نظر');
            alert('خطا در ارتباط با سرور.');
        }
    });
};