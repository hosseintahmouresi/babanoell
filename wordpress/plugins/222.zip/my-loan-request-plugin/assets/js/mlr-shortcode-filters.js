jQuery(document).ready(function($) {
    // Exit if the main container for this shortcode doesn't exist.
    if ($('.mlr-user-requests').length === 0) {
        return;
    }

    // --- Initialize Jalali Datepicker Safely ---
    // We wrap this in a try-catch block to prevent a fatal JS error if the library fails.
    try {
        if (typeof $.fn.persianDatepicker === 'function') {
            $('.jalali-datepicker').persianDatepicker({
                format: 'YYYY/MM/DD',
                autoClose: true
            });
        } else {
            console.warn("Persian Datepicker library not found or initialized correctly.");
        }
    } catch (e) {
        console.error("Error initializing Persian Datepicker:", e);
    }

    // --- Main function to load requests via AJAX ---
    function loadRequests() {
        var container = $('.mlr-user-requests'); 
        
        var search = container.find('#mlr-search').val();
        var status = container.find('#mlr-status').val();
        var settlement_status = container.find('#mlr-settlement-status').val();
        var dateFrom = container.find('#mlr-date-from').val();
        var dateTo = container.find('#mlr-date-to').val();
        var tableBody = container.find('#mlr-requests-table-body');

        $.ajax({
            url: mlr_ajax_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_get_user_requests',
                nonce: mlr_ajax_obj.filter_nonce,
                search: search,
                status: status,
                settlement_status: settlement_status,
                date_from: dateFrom,
                date_to: dateTo,
                allowed_statuses: mlr_ajax_obj.allowed_statuses
            },
            beforeSend: function() {
                tableBody.html('<tr><td colspan="10" style="text-align:center; padding: 20px;">در حال بارگذاری...</td></tr>');
            },
            success: function(response) {
                if (response.success) {
                    tableBody.html(response.data.html);
                } else {
                    tableBody.html('<tr><td colspan="10" style="text-align:center; padding: 20px; color: red;">خطا: ' + (response.data.message || 'مشکلی در دریافت اطلاعات رخ داد.') + '</td></tr>');
                }
            },
            error: function() {
                tableBody.html('<tr><td colspan="10" style="text-align:center; padding: 20px; color: red;">خطا در ارتباط با سرور. لطفاً صفحه را رفرش کنید.</td></tr>');
            }
        });
    }

    // --- Event Handlers (Final & Robust Version) ---

    // Initial load when the page is ready.
    loadRequests();

    // Use event delegation on the document for maximum reliability for the filter button.
    $(document).on('click', '#mlr-filter-btn', function() {
        loadRequests();
    });

    // Also trigger filter on Enter key press in the search box.
    $(document).on('keyup', '#mlr-search', function(e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            loadRequests();
        }
    });

    // --- Modal Logic ---
    $(document).on('click', '.mlr-view-details-btn', function() {
        const button = $(this);
        const container = button.closest('.mlr-user-requests');
        const requestId = button.closest('tr').data('id');
        const modalOverlay = container.find('.mlr-modal-overlay');
        const modal = container.find('.mlr-modal');
        const modalContent = container.find('.mlr-modal-content');

        if (!requestId) return;

        modalOverlay.fadeIn(200);
        modal.fadeIn(200);
        modalContent.html('<p style="text-align:center; padding: 40px;">در حال بارگذاری جزئیات...</p>');

        $.ajax({
            url: mlr_ajax_obj.ajax_url, 
            type: 'POST',
            data: {
                action: 'mlr_get_frontend_request_details',
                nonce: mlr_ajax_obj.details_nonce,
                request_id: requestId
            },
            success: function(response) {
                if (response.success) {
                    modalContent.html(response.data.html);
                } else {
                    modalContent.html('<p style="color:red; text-align:center; padding: 40px;">' + (response.data.message || 'خطا در دریافت جزئیات.') + '</p>');
                }
            },
            error: function() {
                modalContent.html('<p class="mlr-error">خطا در ارتباط با سرور.</p>');
            }
        });
    });

    $(document).on('click', '.mlr-modal-overlay, .mlr-modal-close', function() {
        const container = $(this).closest('.mlr-user-requests');
        container.find('.mlr-modal-overlay').fadeOut(200);
        container.find('.mlr-modal').fadeOut(200);
    });
});