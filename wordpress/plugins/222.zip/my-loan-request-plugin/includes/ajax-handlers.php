<?php
/**
 * Consolidated AJAX Handlers
 */

if (!defined('ABSPATH')) {
    exit;
}

// Admin Actions
add_action('wp_ajax_mlr_get_request_details', 'mlr_get_request_details_callback');
add_action('wp_ajax_mlr_add_comment', 'mlr_add_comment_callback');
add_action('wp_ajax_mlr_add_request_message', 'mlr_add_request_message_callback');
add_action('wp_ajax_mlr_admin_calculate_loan', 'mlr_admin_calculate_loan_callback');

// Frontend Actions
add_action('wp_ajax_mlr_get_user_requests', 'mlr_get_user_requests_callback');
add_action('wp_ajax_mlr_filter_user_requests', 'mlr_get_user_requests_callback'); // Alias for compatibility
add_action('wp_ajax_mlr_get_bank_expert_requests', 'mlr_get_bank_expert_requests_callback');
add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');
add_action('wp_ajax_mlr_upload_additional_docs', 'mlr_upload_additional_docs_callback');
add_action('wp_ajax_mlr_submit_completed_docs', 'mlr_submit_completed_docs_callback');
add_action('wp_ajax_mlr_get_user_cycle_details', 'mlr_get_user_cycle_details_callback');

// Public Actions
add_action('wp_ajax_nopriv_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');
add_action('wp_ajax_mlr_frontend_calculate_loan', 'mlr_frontend_calculate_loan_callback');


/**
 * ===================================================================
 * UPLOAD HANDLER (FIXED)
 * ===================================================================
 */
function mlr_upload_additional_docs_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً وارد شوید.']);
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $user_note = isset($_POST['user_note']) ? sanitize_textarea_field($_POST['user_note']) : '';
    $user_id = get_current_user_id();

    // Check limits
    if (empty($_FILES) && empty($_POST) && isset($_SERVER['REQUEST_METHOD']) && strtolower($_SERVER['REQUEST_METHOD']) == 'post') {
        wp_send_json_error(['message' => "خطا: حجم فایل ارسالی بیشتر از محدودیت سرور است."]);
    }

    // Check existence
    if (!isset($_FILES['additional_files']) || empty($_FILES['additional_files']['name'])) {
         wp_send_json_error(['message' => 'هیچ فایلی دریافت نشد. لطفاً مجدداً تلاش کنید.']);
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_requests} WHERE id = %d AND user_id = %d", $request_id, $user_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست نامعتبر است.']);
    }

    if ($request->status !== 'نقص مدارک') {
        wp_send_json_error(['message' => 'فقط درخواست‌های دارای وضعیت نقص مدارک امکان آپلود مجدد دارند.']);
    }

    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');

    $uploaded_urls = [];
    $files = $_FILES['additional_files'];

    // Handle Upload
    if (is_array($files['name'])) {
        foreach ($files['name'] as $key => $value) {
            if (!empty($files['name'][$key])) {
                $file = [
                    'name' => $files['name'][$key],
                    'type' => $files['type'][$key],
                    'tmp_name' => $files['tmp_name'][$key],
                    'error' => $files['error'][$key],
                    'size' => $files['size'][$key]
                ];

                $upload_error = '';
                $validated_file = mlr_validate_uploaded_file($file, $upload_error);
                if (!$validated_file) {
                    continue;
                }
                $file = $validated_file;

                $upload_overrides = ['test_form' => false];
                $movefile = wp_handle_upload($file, $upload_overrides);

                if ($movefile && !isset($movefile['error'])) {
                    $uploaded_urls[] = $movefile['url'];
                }
            }
        }
    }

    if (empty($uploaded_urls)) {
        wp_send_json_error(['message' => 'خطا در ذخیره‌سازی فایل‌ها.']);
    }

    // Update DB
    $current_docs = maybe_unserialize($request->required_documents);
    if (!is_array($current_docs)) $current_docs = [];

    if (!isset($current_docs['additional_documents'])) {
        $current_docs['additional_documents'] = [];
    }
    if (!is_array($current_docs['additional_documents'])) {
         $existing = $current_docs['additional_documents'];
         $current_docs['additional_documents'] = !empty($existing) ? [$existing] : [];
    }
    
    $current_docs['additional_documents'] = array_merge($current_docs['additional_documents'], $uploaded_urls);

    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    $comments[] = [
        'user_id' => $user_id,
        'display_name' => 'کاربر (رفع نقص)',
        'text' => 'مدارک تکمیلی آپلود شد.' . (!empty($user_note) ? "\nتوضیحات: $user_note" : ''),
        'timestamp' => current_time('mysql')
    ];

    $updated = $wpdb->update($table_requests, [
        'required_documents' => serialize($current_docs),
        'comments' => json_encode($comments, JSON_UNESCAPED_UNICODE),
        'status' => 'در حال بررسی',
        'last_edited_at' => current_time('mysql')
    ], ['id' => $request_id]);

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطای دیتابیس رخ داد.']);
    }

    wp_send_json_success(['message' => 'مدارک ارسال شد و وضعیت پرونده به "در حال بررسی" تغییر یافت.']);
}


// --- CALCULATOR HANDLER ---
function mlr_frontend_calculate_loan_callback() {
    try {
        check_ajax_referer('mlr_frontend_calc_nonce', 'nonce');

        $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
        $amount = isset($_POST['amount']) ? floatval(str_replace(',', '', $_POST['amount'])) : 0;
        $installments = isset($_POST['installments']) ? intval($_POST['installments']) : 0;
        $installment_interval = isset($_POST['installment_interval']) ? intval($_POST['installment_interval']) : 1;
        $user_commission = (isset($_POST['user_commission']) && is_numeric($_POST['user_commission'])) ? floatval($_POST['user_commission']) : null;
        $context = isset($_POST['context']) ? sanitize_text_field($_POST['context']) : '';

        if (!$plan_id) wp_send_json_error(['message' => 'لطفاً یک طرح معتبر را انتخاب کنید.']);
        if ($amount <= 0 || $installments <= 0) wp_send_json_error(['message' => 'مبلغ و تعداد اقساط باید اعداد مثبت باشند.']);

        global $wpdb;
        $table_name = $wpdb->prefix . 'installment_plans';
        $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND is_active = 1", $plan_id));

        if (!$plan) wp_send_json_error(['message' => 'طرح انتخاب شده یافت نشد.']);

        $settings = maybe_unserialize($plan->settings);
        
        $display_fields_default = maybe_unserialize($plan->display_fields);
        if (!is_array($display_fields_default)) $display_fields_default = [];

        $display_fields_context = maybe_unserialize($plan->display_fields_context);
        if (!is_array($display_fields_context)) $display_fields_context = [];
        
        $display_fields = $display_fields_default;
        
        if (!empty($context) && isset($display_fields_context[$context]) && is_array($display_fields_context[$context]) && !empty($display_fields_context[$context])) {
            $display_fields = $display_fields_context[$context];
        }

        $min_amount = floatval($settings['min_amount'] ?? 0);
        $max_amount = floatval($settings['max_amount'] ?? 0);

        if (($min_amount > 0 && $amount < $min_amount) || ($max_amount > 0 && $amount > $max_amount)) {
            $message = sprintf('مبلغ وارد شده باید بین %s و %s ریال باشد.', number_format($min_amount), number_format($max_amount));
            wp_send_json_error(['message' => $message]);
        }
        
        $results = [];
        if ($plan->type === 'market') {
            $results = calculateMarketLoan($amount, $installments, $settings, $user_commission, $display_fields);
        } elseif ($plan->type === 'leasing') {
            $results = calculateLeasingLoan($amount, $installments, $installment_interval, $settings, $user_commission);
        }

        if (empty($results)) wp_send_json_error(['message' => 'خطا در انجام محاسبات.']);

        $labels_with_units = mlr_get_calculation_labels();
        
        // نگاشت کلیدهای خروجی محاسبه (snake_case) به کلیدهای تنظیمات (camelCase)
        $key_map = [
            'loan_amount' => 'loanAmount',
            'installment_count' => 'installmentCount',
            'prepayment' => 'prepayment',
            'total_payment' => 'totalPayment',
            'installment_amount' => 'installmentAmount',
            'profit' => 'profit',
            'operation_cost' => 'operationCost',
            'wallet_charge' => 'walletCharge',
            'acceptor_payment' => 'acceptorPayment',
            'guarantee_check_principal' => 'guaranteeCheckPrincipal',
            'guarantee_check_total' => 'guaranteeCheckTotal',
            'number_of_installments' => 'numberOfInstallments',
            'operation_cost_percent' => 'operationCostPercent',
            'operation_cost_with_vat' => 'operationCostWithVat',
            'net_leasing_payment' => 'netLeasingPayment',
            'acceptor_commission' => 'acceptorCommission',
            'acceptor_commission_with_vat' => 'acceptorCommissionWithVat',
        ];

        ob_start();
        echo '<table>';
        foreach ($results as $key => $value) {
            $display_key = isset($key_map[$key]) ? $key_map[$key] : $key;
            
            // شرط نمایش: اگر هیچ فیلدی تنظیم نشده باشد (نمایش همه) یا فیلد جاری در لیست مجاز باشد
            if (empty($display_fields) || (is_array($display_fields) && (in_array($display_key, $display_fields) || in_array($key, $display_fields)))) {
                $label_info = $labels_with_units[$display_key] ?? ($labels_with_units[$key] ?? ['label' => ucwords(str_replace('_', ' ', $key)), 'unit' => '']);
                $formatted_value = (strpos($key, 'Percent') !== false || $label_info['unit'] === 'درصد') 
                    ? number_format_i18n($value * 100, 2) . ' ' . $label_info['unit'] 
                    : number_format_i18n(round($value)) . ' ' . $label_info['unit'];
                
                echo '<tr><td><strong>' . esc_html($label_info['label']) . '</strong></td><td>' . esc_html($formatted_value) . '</td></tr>';
            }
        }
        echo '</table>';
        wp_send_json_success(['html' => ob_get_clean(), 'results' => $results]);

    } catch (Exception $e) {
        wp_send_json_error(['message' => 'خطای داخلی سرور.']);
    }
}

// --- ADMIN DETAILS HANDLER ---
function mlr_get_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'عدم دسترسی.']);
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) wp_send_json_error(['message' => 'درخواست یافت نشد.']);
    
    $occupations = [ 'official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر' ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : esc_html($request->occupation);
    $all_doc_labels = mlr_get_all_document_options();
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    
    // استخراج گزارش اعتبارسنجی
    $credit_report = null;
    if (!empty($request->credit_report_json)) {
        $credit_report = json_decode($request->credit_report_json, true);
    } elseif (isset($request->form_data)) {
        $fd = json_decode($request->form_data, true);
        if (isset($fd['credit_report_json'])) {
            $credit_report = is_string($fd['credit_report_json']) ? json_decode($fd['credit_report_json'], true) : $fd['credit_report_json'];
        }
    }
    
    // نکته: در این تابع متغیر $form_data مستقیماً استفاده نشده و فقط برای استخراج گزارش استفاده شد.
    // اما اگر در آینده استفاده شود، باید credit_report_json از آن حذف شود.
    

    ob_start();
    ?>
    <div class="mlr-modal-content">
        <h3 class="mlr-modal-title">جزئیات درخواست (شناسه: <?php echo esc_html($request->id); ?>)</h3>
        
        <div class="mlr-modal-comments-section">
            <h4>یادداشت‌های کارشناسان</h4>
            <div class="mlr-comments-history">
                <?php if (!empty($comments) && is_array($comments)): foreach ($comments as $comment): ?>
                        <div class="mlr-comment-bubble">
                            <div class="mlr-comment-header">
                                <strong class="mlr-comment-author"><?php echo esc_html($comment['display_name'] ?? 'کاربر'); ?></strong>
                                <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i'); ?></span>
                            </div>
                            <div class="mlr-comment-body"><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></div>
                        </div>
                <?php endforeach; else: echo '<p>هنوز یادداشتی ثبت نشده است.</p>'; endif; ?>
            </div>
            <div class="mlr-add-comment-form">
                <textarea id="mlr_new_comment_text" rows="3" class="widefat" placeholder="یادداشت جدید..."></textarea>
                <button type="button" class="button button-primary" id="mlr-add-comment-btn" data-id="<?php echo esc_attr($request->id); ?>">افزودن یادداشت</button>
            </div>
        </div>

        <div class="mlr-modal-grid">
            <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">اطلاعات متقاضی و تسهیلات</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام:</strong></td><td><?php echo esc_html($request->full_name); ?></td></tr>
                    <tr><td><strong>کدملی:</strong></td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td><strong>موبایل:</strong></td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td><strong>شغل:</strong></td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td><strong>نام طرح:</strong></td><td><?php echo esc_html($request->plan_name); ?></td></tr>
                    <tr><td><strong>مبلغ وام:</strong></td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td><strong>وضعیت:</strong></td><td><?php echo esc_html($request->status); ?></td></tr>
                </table>
            </div>

            <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">مدارک</h4>
                <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                    <ul class="mlr-file-list">
                        <?php foreach($uploaded_documents as $doc_key => $doc_value): ?>
                            <li>
                                <strong><?php echo esc_html($all_doc_labels[$doc_key] ?? $doc_key); ?>:</strong>
                                <?php if (is_array($doc_value)): foreach ($doc_value as $i => $url): ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank">فایل <?php echo $i+1; ?></a>
                                <?php endforeach; elseif (is_string($doc_value)): ?>
                                    <a href="<?php echo esc_url($doc_value); ?>" target="_blank">مشاهده فایل</a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>مدارکی یافت نشد.</p>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($credit_report): ?>
            <?php
                // Helper for formatting
                $fmt = function($n) { return number_format((float)$n); };
                
                // Extract Data
                $scoreObj = $credit_report['score'] ?? [];
                $reportObj = $credit_report['report'] ?? [];
                
                $score = $scoreObj['score'] ?? 0;
                $risk = $scoreObj['risk'] ?? 'نامشخص';
                $desc = $scoreObj['description'] ?? '';
                
                // اصلاح محدوده امتیاز برای نمودار
                $minScore = $scoreObj['minLimit'] ?? 0;
                $maxScore = $scoreObj['maxLimit'] ?? 1000;
                if ($maxScore < $score) $maxScore = 1000; // اگر ماکسیمم اشتباه بود
                
                $percent = ($maxScore > $minScore) ? (($score - $minScore) / ($maxScore - $minScore)) * 100 : 0;
                $percent = max(0, min(100, $percent));
                
                // Risk Color
                $riskClass = 'mlr-risk-unknown';
                if (strpos($risk, 'کم') !== false || strpos($risk, 'Low') !== false || in_array($risk, ['A1','A2','A3'])) $riskClass = 'mlr-risk-low';
                elseif (strpos($risk, 'متوسط') !== false || strpos($risk, 'Medium') !== false || in_array($risk, ['B1','B2','B3'])) $riskClass = 'mlr-risk-medium';
                else $riskClass = 'mlr-risk-high';
                
                // Person Info
                $pInfo = $scoreObj['personInformation'] ?? ($reportObj['personInformation'] ?? []);
                
                // Summary
                $summary = ($reportObj['summaryInformationRelatedToContractsSum'][0]) ?? [];
                $bouncedObj = $credit_report['bouncedCheque'] ?? [];
                $bouncedCount = isset($bouncedObj['bouncedCheques']) && is_array($bouncedObj['bouncedCheques']) ? count($bouncedObj['bouncedCheques']) : 0;
            ?>
            
            <div class="mlr-report-container" style="margin-top: 30px;">
                <h3 style="border-bottom: 1px solid #ddd; padding-bottom: 10px; margin-bottom: 20px;">گزارش اعتبارسنجی</h3>
                
                <!-- Header -->
                <div class="mlr-report-header <?php echo $riskClass; ?>">
                    <div class="mlr-score-circle">
                        <svg viewBox="0 0 36 36" class="mlr-circular-chart">
                            <path class="mlr-circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            <path class="mlr-circle" stroke-dasharray="<?php echo $percent; ?>, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            <text x="18" y="20.35" class="mlr-percentage"><?php echo $score; ?></text>
                        </svg>
                        <span class="mlr-score-label">امتیاز</span>
                    </div>
                    <div>
                        <div style="font-size: 18px; font-weight: 700;">ریسک: <?php echo esc_html($risk); ?></div>
                        <div style="font-size: 13px; opacity: 0.9;"><?php echo esc_html($desc); ?></div>
                    </div>
                </div>
                
                <!-- Person Info -->
                <?php if (!empty($pInfo)): ?>
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-id-alt"></span> اطلاعات هویتی</h4>
                    <div class="mlr-report-content mlr-grid-view">
                        <div class="mlr-info-item">نام و نام خانوادگی: <strong><?php echo esc_html(($pInfo['name'] ?? '') . ' ' . ($pInfo['family'] ?? '')); ?></strong></div>
                        <div class="mlr-info-item">کد ملی: <strong><?php echo esc_html($pInfo['nationalCode'] ?? '-'); ?></strong></div>
                        <div class="mlr-info-item">نام پدر: <strong><?php echo esc_html($pInfo['fatherName'] ?? '-'); ?></strong></div>
                        <div class="mlr-info-item">تاریخ تولد: <strong><?php echo esc_html($pInfo['dateOfBirth'] ?? '-'); ?></strong></div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Summary Cards -->
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-chart-bar"></span> خلاصه وضعیت مالی</h4>
                    <div class="mlr-report-content mlr-summary-cards">
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $summary['inProgressContractsCount'] ?? 0; ?></span>
                            <span class="mlr-summary-lbl">تسهیلات جاری</span>
                        </div>
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $fmt($summary['overdueAmount'] ?? 0); ?></span>
                            <span class="mlr-summary-lbl">معوقات (ریال)</span>
                        </div>
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $bouncedCount; ?></span>
                            <span class="mlr-summary-lbl">چک برگشتی</span>
                        </div>
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $fmt($summary['totalAmount'] ?? 0); ?></span>
                            <span class="mlr-summary-lbl">کل تسهیلات (ریال)</span>
                        </div>
                    </div>
                </div>
                
                <!-- Loans -->
                <?php if (!empty($reportObj['directContracts'])): ?>
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-bank"></span> تسهیلات بانکی (وام‌ها)</h4>
                    <div class="mlr-report-content">
                        <table class="mlr-table">
                            <thead><tr><th>بانک</th><th>نوع</th><th>مبلغ کل (ریال)</th><th>مانده بدهی (ریال)</th><th>وضعیت</th></tr></thead>
                            <tbody>
                                <?php foreach($reportObj['directContracts'] as $loan): 
                                    $statusText = $loan['negativeContractStatus'] ?? 'جاری';
                                    $badgeClass = (strpos($statusText, 'معوق') !== false || strpos($statusText, 'مشکوک') !== false) ? 'mlr-badge-danger' : ((strpos($statusText, 'گذشته') !== false) ? 'mlr-badge-warning' : 'mlr-badge-success');
                                ?>
                                <tr>
                                    <td><?php echo esc_html($loan['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo esc_html($loan['typeOfFinancingTitle'] ?? '-'); ?></td>
                                    <td><?php echo $fmt($loan['totalAmount'] ?? 0); ?></td>
                                    <td><?php echo $fmt($loan['overdueAmount'] ?? 0); ?></td>
                                    <td><span class="mlr-badge <?php echo $badgeClass; ?>"><?php echo esc_html($statusText); ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Guarantees -->
                <?php if (!empty($reportObj['indirectContracts'])): ?>
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-groups"></span> تعهدات (ضمانت‌ها)</h4>
                    <div class="mlr-report-content">
                        <table class="mlr-table">
                            <thead><tr><th>بانک (ضامن)</th><th>مبلغ ضمانت (ریال)</th><th>معوقات وام‌گیرنده</th><th>وضعیت</th></tr></thead>
                            <tbody>
                                <?php foreach($reportObj['indirectContracts'] as $g): 
                                    $statusText = $g['negativeContractStatus'] ?? 'جاری';
                                    $badgeClass = (strpos($statusText, 'معوق') !== false) ? 'mlr-badge-danger' : 'mlr-badge-success';
                                ?>
                                <tr>
                                    <td><?php echo esc_html($g['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo $fmt($g['totalAmount'] ?? 0); ?></td>
                                    <td><?php echo $fmt($g['overdueAmount'] ?? 0); ?></td>
                                    <td><span class="mlr-badge <?php echo $badgeClass; ?>"><?php echo esc_html($statusText); ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Pichak -->
                <?php if (!empty($credit_report['pichak']['personChequesData']['personChequeItems'])): ?>
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-tickets-alt"></span> وضعیت چک‌های صیادی (پیچک)</h4>
                    <div class="mlr-report-content">
                        <table class="mlr-table">
                            <thead><tr><th>وضعیت</th><th>تعداد</th><th>مبلغ کل (ریال)</th></tr></thead>
                            <tbody>
                                <?php foreach($credit_report['pichak']['personChequesData']['personChequeItems'] as $item): 
                                    if ($item['count'] == 0) continue;
                                ?>
                                <tr>
                                    <td><?php echo esc_html($item['checkStatusTitle']); ?></td>
                                    <td><?php echo esc_html($item['count']); ?></td>
                                    <td><?php echo $fmt($item['totalAmount']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Bounced Cheques -->
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-warning"></span> سوابق چک برگشتی</h4>
                    <div class="mlr-report-content">
                        <?php if (!empty($bouncedObj['bouncedCheques'])): ?>
                        <table class="mlr-table">
                            <thead><tr><th>بانک</th><th>مبلغ (ریال)</th><th>تاریخ برگشت</th><th>تاریخ رفع سوءاثر</th></tr></thead>
                            <tbody>
                                <?php foreach($bouncedObj['bouncedCheques'] as $item): 
                                    $bouncedDate = isset($item['bouncedDate']) ? preg_split('/[ T]/', $item['bouncedDate'])[0] : '-';
                                    $clearedDate = isset($item['clearedDate']) ? preg_split('/[ T]/', $item['clearedDate'])[0] : '---';
                                ?>
                                <tr>
                                    <td><?php echo esc_html($item['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo $fmt($item['amount'] ?? 0); ?></td>
                                    <td><?php echo esc_html($bouncedDate); ?></td>
                                    <td><?php echo esc_html($clearedDate); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <div class="mlr-badge mlr-badge-success" style="display:inline-block; font-size:13px; padding:5px 10px;">✅ فاقد چک برگشتی</div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Tax -->
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-money"></span> وضعیت مالیاتی</h4>
                    <div class="mlr-report-content">
                        <?php 
                        $taxItems = $credit_report['tax']['taxResult'] ?? [];
                        $hasTax = false;
                        foreach($taxItems as $t) { if($t['year']) $hasTax = true; }
                        
                        if ($hasTax): ?>
                        <table class="mlr-table">
                            <thead><tr><th>سال</th><th>درآمد ابرازی</th><th>مالیات قطعی</th><th>بدهی</th></tr></thead>
                            <tbody>
                                <?php foreach($taxItems as $item): if(!$item['year']) continue; ?>
                                <tr>
                                    <td><?php echo esc_html($item['year']); ?></td>
                                    <td><?php echo $fmt($item['daramadEbrazi']); ?></td>
                                    <td><?php echo $fmt($item['maliatGhati']); ?></td>
                                    <td><?php echo $fmt($item['bedehiMaliatAmalkard']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <div class="mlr-badge mlr-badge-success" style="display:inline-block; font-size:13px; padding:5px 10px;">✅ فاقد بدهی مالیاتی</div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Judiciary -->
                <?php 
                $jud = $credit_report['judiciary']['judiciaryData'] ?? [];
                if (($jud['sumExecuteCount'] ?? 0) > 0 || ($jud['sumNotExecuteCount'] ?? 0) > 0): 
                ?>
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-gavel"></span> پرونده‌های قضایی</h4>
                    <div class="mlr-report-content mlr-grid-view">
                        <div class="mlr-info-item">پرونده‌های اجرا شده: <strong><?php echo esc_html($jud['sumExecuteCount']); ?></strong></div>
                        <div class="mlr-info-item">پرونده‌های اجرا نشده: <strong><?php echo esc_html($jud['sumNotExecuteCount']); ?></strong></div>
                        <div class="mlr-info-item">محکومیت اجرا نشده: <strong><?php echo $fmt($jud['sumNotExecuteSumPenaltyAmount']); ?> ریال</strong></div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
            
            <style>
                .mlr-report-container { font-family: 'Vazirmatn', Tahoma, sans-serif; direction: rtl; background: #fff; }
                .mlr-report-header { display: flex; align-items: center; padding: 20px; color: #fff; border-radius: 12px; margin-bottom: 20px; }
                .mlr-risk-low { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
                .mlr-risk-medium { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
                .mlr-risk-high { background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); }
                .mlr-risk-unknown { background: linear-gradient(135deg, #64748b 0%, #475569 100%); }
                
                .mlr-score-circle { width: 80px; height: 80px; margin-left: 20px; position: relative; flex-shrink: 0; text-align: center; }
                .mlr-circular-chart { display: block; margin: 0 auto; max-width: 100%; max-height: 100%; }
                .mlr-circle-bg { fill: none; stroke: rgba(255,255,255,0.3); stroke-width: 3.8; }
                .mlr-circle { fill: none; stroke: #fff; stroke-width: 2.8; stroke-linecap: round; transition: stroke-dasharray 1s ease-out; }
                .mlr-percentage { fill: #fff; font-family: sans-serif; font-weight: bold; font-size: 0.5em; text-anchor: middle; }
                
                .mlr-score-label { font-size: 10px; font-weight: normal; margin-top: 2px; opacity: 0.9; }
                
                .mlr-report-section { border: 1px solid #e2e8f0; border-radius: 12px; margin-bottom: 20px; overflow: hidden; }
                .mlr-report-section h4 { background: #f8fafc; padding: 12px 15px; margin: 0; border-bottom: 1px solid #e2e8f0; font-size: 14px; font-weight: 700; color: #334155; display: flex; align-items: center; gap: 8px; }
                .mlr-report-content { padding: 15px; }
                
                .mlr-grid-view { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; }
                .mlr-info-item { font-size: 13px; color: #475569; }
                .mlr-info-item strong { color: #1e293b; display: block; margin-top: 4px; }
                
                .mlr-summary-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px; }
                .mlr-summary-card { background: #f1f5f9; padding: 15px; border-radius: 10px; text-align: center; }
                .mlr-summary-val { font-size: 16px; font-weight: 800; color: #334155; display: block; margin-bottom: 4px; }
                .mlr-summary-lbl { font-size: 11px; color: #64748b; }
                
                .mlr-table { width: 100%; border-collapse: collapse; font-size: 12px; }
                .mlr-table th { background: #f8fafc; padding: 10px; text-align: right; color: #64748b; border-bottom: 1px solid #e2e8f0; white-space: nowrap; }
                .mlr-table td { padding: 10px; border-bottom: 1px solid #f1f5f9; color: #334155; }
                .mlr-table tr:last-child td { border-bottom: none; }
                
                .mlr-badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; color: #fff; display: inline-block; }
                .mlr-badge-success { background: #10b981; }
                .mlr-badge-warning { background: #f59e0b; }
                .mlr-badge-danger { background: #ef4444; }
        
        .mlr-cards-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px; }
        .mlr-contract-card { border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; background: #fff; }
        .mlr-contract-header { background: #f1f5f9; padding: 10px 15px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; }
        .mlr-contract-org { font-weight: 700; font-size: 13px; color: #334155; }
        .mlr-contract-badge { font-size: 11px; padding: 3px 8px; border-radius: 12px; color: #fff; font-weight: 600; }
        .mlr-contract-body { padding: 15px; font-size: 13px; }
        .mlr-contract-row { display: flex; justify-content: space-between; margin-bottom: 8px; border-bottom: 1px dashed #f1f5f9; padding-bottom: 4px; }
        .mlr-contract-row:last-child { margin-bottom: 0; border-bottom: none; }
            </style>
        <?php endif; ?>
    </div>
    <?php
    wp_send_json_success(['html' => ob_get_clean()]);
}

// --- User Requests List Handler ---
if (!function_exists('mlr_get_user_requests_callback')) {
function mlr_get_user_requests_callback() {
    // Clean output buffer to prevent JSON errors
    if (ob_get_length()) ob_clean();

    // Check both nonces to support different JS implementations
    $nonce = isset($_REQUEST['nonce']) ? $_REQUEST['nonce'] : '';
    if (!wp_verify_nonce($nonce, 'mlr_user_requests_nonce') && !wp_verify_nonce($nonce, 'mlr_frontend_nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی (Nonce نامعتبر).']);
    }

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً وارد شوید.']);
    }

    $user_id = get_current_user_id();
    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $table_plans = $wpdb->prefix . 'installment_plans';

    // Filters
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $date_from = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '';
    $date_to = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '';
    $settlement_status = isset($_POST['settlement_status']) ? sanitize_text_field($_POST['settlement_status']) : '';
    $allowed_statuses = isset($_POST['allowed_statuses']) ? $_POST['allowed_statuses'] : [];

    $where = ["r.user_id = %d"];
    $params = [$user_id];

    if (!empty($status)) {
        $where[] = "r.status = %s";
        $params[] = $status;
    }

    if (!empty($allowed_statuses) && is_array($allowed_statuses)) {
        $allowed_statuses = array_map('sanitize_text_field', $allowed_statuses);
        $placeholders = implode(',', array_fill(0, count($allowed_statuses), '%s'));
        $where[] = "r.status IN ($placeholders)";
        foreach ($allowed_statuses as $s) $params[] = $s;
    }

    if (!empty($settlement_status)) {
        $where[] = "r.settlement_status = %s";
        $params[] = $settlement_status;
    }

    if (!empty($search)) {
        $where[] = "(r.id LIKE %s OR r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s)";
        $search_term = '%' . $wpdb->esc_like($search) . '%';
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }

    if (!empty($date_from) && function_exists('mlr_jalali_to_gregorian')) {
        $g_date_from = mlr_jalali_to_gregorian($date_from);
        if ($g_date_from) {
            $where[] = "r.created_at >= %s";
            $params[] = $g_date_from . ' 00:00:00';
        }
    }

    if (!empty($date_to) && function_exists('mlr_jalali_to_gregorian')) {
        $g_date_to = mlr_jalali_to_gregorian($date_to);
        if ($g_date_to) {
            $where[] = "r.created_at <= %s";
            $params[] = $g_date_to . ' 23:59:59';
        }
    }

    $where_sql = implode(' AND ', $where);
    $query = "SELECT r.*, p.name as plan_name 
              FROM $table_requests r 
              LEFT JOIN $table_plans p ON r.installment_plan_id = p.id 
              WHERE $where_sql 
              ORDER BY r.created_at DESC";

    $requests = $wpdb->get_results($wpdb->prepare($query, $params));

    $status_map = [
        'در حال بررسی' => 'pending',
        'نقص مدارک' => 'incomplete',
        'رد شده' => 'rejected',
        'تأیید کارشناس' => 'expert-approved',
        'تایید کارشناس' => 'expert-approved',
        'تکمیل مدارک' => 'docs-completed',
        'تأیید مدارک' => 'docs-verified',
        'تایید مدارک' => 'docs-verified',
        'اعطا شده' => 'granted',
        'تسویه شده' => 'settled',
        'در انتظار تسویه' => 'pending-settlement',
        'تأیید نهایی' => 'final-approved',
        'تایید نهایی' => 'final-approved',
    ];

    ob_start();
    if ($requests) {
        foreach ($requests as $req) {
            $created_at = function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($req->created_at, 'Y/m/d') : $req->created_at;
            $status_slug = isset($status_map[$req->status]) ? $status_map[$req->status] : 'unknown';
            $status_class = 'status-' . $status_slug;
            
            $actions = '<button type="button" class="mlr-btn mlr-btn-secondary mlr-view-details-btn" data-id="' . esc_attr($req->id) . '">جزئیات</button>';

            echo '<tr>';
            echo '<td>' . esc_html($req->id) . '</td>';
            echo '<td>' . esc_html($req->full_name) . '</td>';
            echo '<td>' . esc_html($req->mobile_number) . '</td>';
            echo '<td>' . esc_html($req->national_code) . '</td>';
            echo '<td>' . number_format($req->loan_amount) . '</td>';
            echo '<td>' . esc_html($req->plan_name) . '</td>';
            echo '<td><span class="mlr-glass-badge ' . esc_attr($status_class) . '">' . esc_html($req->status) . '</span></td>';
            echo '<td>' . esc_html($req->settlement_status ?: '-') . '</td>';
            echo '<td>' . esc_html($created_at) . '</td>';
            echo '<td>' . $actions . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="10" style="text-align:center;">هیچ درخواستی یافت نشد.</td></tr>';
    }
    $html = ob_get_clean();

    // Return HTML string directly as 'data' to support frontend.js expectations
    wp_send_json_success($html);
}
}

// --- Bank Expert Requests List Handler ---
if (!function_exists('mlr_get_bank_expert_requests_callback')) {
function mlr_get_bank_expert_requests_callback() {
    // Clean output buffer to prevent JSON errors
    if (ob_get_length()) ob_clean();

    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً وارد شوید.']);
    }
    
    $user = wp_get_current_user();
    if (!in_array('bank', (array)$user->roles)) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز.']);
    }

    $user_id = $user->ID;
    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $table_plans = $wpdb->prefix . 'installment_plans';

    // Filters
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $date_from = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '';
    $date_to = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '';

    $where = ["r.assigned_bank_user_id = %d"];
    $params = [$user_id];

    if (!empty($search)) {
        $where[] = "(r.id LIKE %s OR r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s)";
        $search_term = '%' . $wpdb->esc_like($search) . '%';
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }

    if (!empty($date_from) && function_exists('mlr_jalali_to_gregorian')) {
        $g_date_from = mlr_jalali_to_gregorian($date_from);
        if ($g_date_from) {
            $where[] = "r.created_at >= %s";
            $params[] = $g_date_from . ' 00:00:00';
        }
    }

    if (!empty($date_to) && function_exists('mlr_jalali_to_gregorian')) {
        $g_date_to = mlr_jalali_to_gregorian($date_to);
        if ($g_date_to) {
            $where[] = "r.created_at <= %s";
            $params[] = $g_date_to . ' 23:59:59';
        }
    }

    $where_sql = implode(' AND ', $where);
    $query = "SELECT r.*, p.name as plan_name 
              FROM $table_requests r 
              LEFT JOIN $table_plans p ON r.installment_plan_id = p.id 
              WHERE $where_sql 
              ORDER BY r.created_at DESC";

    $requests = $wpdb->get_results($wpdb->prepare($query, $params));

    $status_map = [
        'در حال بررسی' => 'pending',
        'نقص مدارک' => 'incomplete',
        'رد شده' => 'rejected',
        'تأیید کارشناس' => 'expert-approved',
        'تایید کارشناس' => 'expert-approved',
        'تکمیل مدارک' => 'docs-completed',
        'تأیید مدارک' => 'docs-verified',
        'تایید مدارک' => 'docs-verified',
        'اعطا شده' => 'granted',
        'تسویه شده' => 'settled',
        'در انتظار تسویه' => 'pending-settlement',
        'تأیید نهایی' => 'final-approved',
        'تایید نهایی' => 'final-approved',
    ];

    ob_start();
    if ($requests) {
        foreach ($requests as $req) {
            $created_at = function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($req->created_at, 'Y/m/d') : $req->created_at;
            $referral_date = !empty($req->referral_date) ? (function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($req->referral_date, 'Y/m/d') : $req->referral_date) : '-';
            $status_slug = isset($status_map[$req->status]) ? $status_map[$req->status] : 'unknown';
            $status_class = 'status-' . $status_slug;
            
            $actions = '<button type="button" class="mlr-btn mlr-btn-secondary mlr-view-details-btn" data-id="' . esc_attr($req->id) . '">بررسی</button>';

            echo '<tr>';
            echo '<td>' . esc_html($req->id) . '</td>';
            echo '<td>' . esc_html($req->full_name) . '</td>';
            echo '<td>' . esc_html($req->mobile_number) . '</td>';
            echo '<td>' . esc_html($req->national_code) . '</td>';
            echo '<td>' . number_format($req->loan_amount) . '</td>';
            echo '<td>' . esc_html($req->plan_name) . '</td>';
            echo '<td><span class="mlr-glass-badge ' . esc_attr($status_class) . '">' . esc_html($req->status) . '</span></td>';
            echo '<td>' . esc_html($referral_date) . '</td>';
            echo '<td>' . $actions . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="9" style="text-align:center;">هیچ درخواستی یافت نشد.</td></tr>';
    }
    $html = ob_get_clean();

    // Return HTML string directly as 'data'
    wp_send_json_success($html);
}
}

// --- ADD COMMENT HANDLER ---
function mlr_add_comment_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'عدم دسترسی.']);

    $request_id = intval($_POST['request_id']);
    $comment_text = sanitize_textarea_field($_POST['comment']);

    if (!$request_id || empty($comment_text)) wp_send_json_error(['message' => 'اطلاعات نامعتبر.']);

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $comments = json_decode($wpdb->get_var($wpdb->prepare("SELECT comments FROM $table_name WHERE id = %d", $request_id)), true) ?: [];
    
    $current_user = wp_get_current_user();
    $new_comment = [
        'user_id' => $current_user->ID,
        'display_name' => $current_user->display_name,
        'text' => $comment_text,
        'timestamp' => current_time('mysql'),
    ];
    $comments[] = $new_comment;

    $updated = $wpdb->update($table_name, ['comments' => json_encode($comments, JSON_UNESCAPED_UNICODE)], ['id' => $request_id]);
    
    if ($updated === false) wp_send_json_error(['message' => 'خطا در ذخیره.']);

    ob_start();
    ?>
    <div class="mlr-comment-bubble">
        <div class="mlr-comment-header">
            <strong class="mlr-comment-author"><?php echo esc_html($new_comment['display_name']); ?></strong>
            <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($new_comment['timestamp'], 'Y/m/d H:i'); ?></span>
        </div>
        <div class="mlr-comment-body"><?php echo nl2br(esc_html($new_comment['text'])); ?></div>
    </div>
    <?php
    wp_send_json_success(['message' => 'ثبت شد.', 'new_comment_html' => ob_get_clean()]);
}

function mlr_admin_calculate_loan_callback() {
    // This function acts as a placeholder if needed for admin specific calculations via AJAX
    wp_send_json_success(['message' => 'Admin calculation endpoint ready.']);
}


function mlr_add_request_message_callback() {
    if (!function_exists('mlr_verify_any_nonce') || !mlr_verify_any_nonce('nonce')) {
        wp_send_json_error(['message' => 'خطای امنیتی (nonce نامعتبر).']);
        return;
    }
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? absint($_POST['request_id']) : 0;
    $message = isset($_POST['message']) ? wp_unslash($_POST['message']) : '';
    $message = wp_kses_post($message);

    if (!$request_id || empty(trim(wp_strip_all_tags($message)))) {
        wp_send_json_error(['message' => 'اطلاعات نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_requests} WHERE id = %d", $request_id));
    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        return;
    }

    if (!function_exists('mlr_can_access_loan_request') || !mlr_can_access_loan_request($request)) {
        wp_send_json_error(['message' => 'شما دسترسی به این درخواست ندارید.']);
        return;
    }

    $inserted_id = function_exists('mlr_add_request_message') ? mlr_add_request_message($request_id, $message) : 0;
    if (!$inserted_id) {
        wp_send_json_error(['message' => 'خطا در ذخیره پیام.']);
        return;
    }

    if (function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'message', 'ارسال پیام/یادداشت');
    }

    $current_user = wp_get_current_user();
    ob_start();
    ?>
    <div class="mlr-message-bubble" style="padding:8px 10px; margin:0 0 8px; border:1px solid #f2f2f2; border-radius:8px;">
        <div style="font-size:12px; color:#666; margin-bottom:6px;">
            <?php echo esc_html($current_user->display_name); ?> — <?php echo esc_html(mlr_gregorian_to_jalali(current_time('mysql'), 'Y/m/d H:i')); ?>
        </div>
        <div><?php echo wp_kses_post(nl2br($message)); ?></div>
    </div>
    <?php
    wp_send_json_success(['message' => 'ارسال شد.', 'html' => ob_get_clean()]);
}

// ===================================================================
// MISSING HANDLERS (Fixing 400 Errors)
// ===================================================================

// --- Step 1: Shahkar Verification (Placeholder) ---
add_action('wp_ajax_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');
add_action('wp_ajax_nopriv_mlr_verify_shahkar', 'mlr_verify_shahkar_callback');

// هندلر استعلام شاهکار (مرحله ۱)
// این تابع فعلاً پاسخ مثبت برمی‌گرداند تا کاربر بتواند عبور کند.
function mlr_verify_shahkar_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    
    $national_code = isset($_POST['national_code']) ? sanitize_text_field($_POST['national_code']) : '';
    $mobile_number = isset($_POST['mobile_number']) ? sanitize_text_field($_POST['mobile_number']) : '';

    if (empty($national_code) || empty($mobile_number)) {
        wp_send_json_error(['message' => 'کد ملی و شماره موبایل الزامی است.']);
    }
    
    // پاسخ موفقیت‌آمیز
    wp_send_json_success(['message' => 'اطلاعات هویتی تایید شد.']);
}

// --- Step 5: Get Plan Documents ---
add_action('wp_ajax_mlr_get_plan_documents', 'mlr_get_plan_documents_callback');
add_action('wp_ajax_nopriv_mlr_get_plan_documents', 'mlr_get_plan_documents_callback');

// هندلر دریافت لیست مدارک طرح (مرحله ۵)
function mlr_get_plan_documents_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    
    $plan_id = isset($_POST['plan_id']) ? intval($_POST['plan_id']) : 0;
    if (!$plan_id) wp_send_json_error(['message' => 'طرح نامعتبر است.']);
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'installment_plans';
    $plan = $wpdb->get_row($wpdb->prepare("SELECT required_documents FROM $table_name WHERE id = %d", $plan_id));
    
    if (!$plan) wp_send_json_error(['message' => 'طرح یافت نشد.']);
    
    $doc_keys = maybe_unserialize($plan->required_documents);
    if (!is_array($doc_keys)) $doc_keys = [];
    
    $all_docs = function_exists('mlr_get_all_document_options') ? mlr_get_all_document_options() : [];
    $response = [];
    
    foreach ($doc_keys as $key) {
        if (isset($all_docs[$key])) {
            $response[] = [
                'key' => $key,
                'label' => $all_docs[$key],
                'multiple' => in_array($key, ['check_images', 'other_completed_files', 'additional_documents'])
            ];
        }
    }
    
    wp_send_json_success($response);
}

// --- Frontend Request Details Handler (Added for Graphical Report) ---
if (!function_exists('mlr_get_frontend_request_details_callback')) {
function mlr_get_frontend_request_details_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'لطفاً وارد شوید.']);
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $user_id = get_current_user_id();

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    // Ensure user owns the request
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d AND r.user_id = %d
    ", $request_id, $user_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست یافت نشد.']);
    }
    
    $all_doc_labels = mlr_get_all_document_options();
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    
    // Decode Credit Report if exists
    $credit_report = null;
    if (!empty($request->credit_report_json)) {
        $credit_report = json_decode($request->credit_report_json, true);
    }

    ob_start();
    ?>
    <div class="mlr-modal-content">
        <h3 class="mlr-modal-title">جزئیات درخواست (شناسه: <?php echo esc_html($request->id); ?>)</h3>
        
        <div class="mlr-modal-grid">
            <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">اطلاعات تسهیلات</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام طرح:</strong></td><td><?php echo esc_html($request->plan_name); ?></td></tr>
                    <tr><td><strong>مبلغ وام:</strong></td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td><strong>وضعیت:</strong></td><td><?php echo esc_html($request->status); ?></td></tr>
                    <tr><td><strong>تاریخ ثبت:</strong></td><td><?php echo mlr_gregorian_to_jalali($request->created_at, 'Y/m/d'); ?></td></tr>
                </table>
            </div>
             <div class="mlr-modal-col">
                <h4 class="mlr-modal-subtitle">مدارک ارسالی</h4>
                <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                    <ul class="mlr-file-list">
                        <?php foreach($uploaded_documents as $doc_key => $doc_value): ?>
                            <li>
                                <strong><?php echo esc_html($all_doc_labels[$doc_key] ?? $doc_key); ?>:</strong>
                                <?php if (is_array($doc_value)): foreach ($doc_value as $i => $url): ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank">فایل <?php echo $i+1; ?></a>
                                <?php endforeach; elseif (is_string($doc_value)): ?>
                                    <a href="<?php echo esc_url($doc_value); ?>" target="_blank">مشاهده فایل</a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>مدارکی یافت نشد.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="mlr-modal-comments-section">
            <h4>پیام‌ها و یادداشت‌ها</h4>
            <div class="mlr-comments-history">
                <?php if (!empty($comments) && is_array($comments)): foreach ($comments as $comment): ?>
                        <div class="mlr-comment-bubble">
                            <div class="mlr-comment-header">
                                <strong class="mlr-comment-author"><?php echo esc_html($comment['display_name'] ?? 'سیستم'); ?></strong>
                                <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i'); ?></span>
                            </div>
                            <div class="mlr-comment-body"><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></div>
                        </div>
                <?php endforeach; else: echo '<p>پیامی وجود ندارد.</p>'; endif; ?>
            </div>
        </div>

        <?php if ($credit_report): ?>
            <?php
                // Helper for formatting
                $fmt = function($n) { return number_format((float)$n); };
                
                // Extract Data
                $scoreObj = $credit_report['score'] ?? [];
                $reportObj = $credit_report['report'] ?? [];
                
                $score = $scoreObj['score'] ?? 0;
                $risk = $scoreObj['risk'] ?? 'نامشخص';
                $desc = $scoreObj['description'] ?? '';
                
                // اصلاح محدوده امتیاز برای نمودار
                $minScore = $scoreObj['minLimit'] ?? 0;
                $maxScore = $scoreObj['maxLimit'] ?? 1000;
                if ($maxScore < $score) $maxScore = 1000;
                
                $percent = ($maxScore > $minScore) ? (($score - $minScore) / ($maxScore - $minScore)) * 100 : 0;
                $percent = max(0, min(100, $percent));
                
                // Risk Color
                $riskClass = 'mlr-risk-unknown';
                if (strpos($risk, 'کم') !== false || strpos($risk, 'Low') !== false || in_array($risk, ['A1','A2','A3'])) $riskClass = 'mlr-risk-low';
                elseif (strpos($risk, 'متوسط') !== false || strpos($risk, 'Medium') !== false || in_array($risk, ['B1','B2','B3'])) $riskClass = 'mlr-risk-medium';
                else $riskClass = 'mlr-risk-high';
                
                // Person Info
                $pInfo = $scoreObj['personInformation'] ?? ($reportObj['personInformation'] ?? []);
                
                // Summary
                $summary = ($reportObj['summaryInformationRelatedToContractsSum'][0]) ?? [];
                $bouncedObj = $credit_report['bouncedCheque'] ?? [];
                $bouncedCount = isset($bouncedObj['bouncedCheques']) && is_array($bouncedObj['bouncedCheques']) ? count($bouncedObj['bouncedCheques']) : 0;
            ?>
            
            <div class="mlr-report-container" style="margin-top: 30px;">
                <h3 style="border-bottom: 1px solid #ddd; padding-bottom: 10px; margin-bottom: 20px;">گزارش اعتبارسنجی</h3>
                
                <!-- Header -->
                <div class="mlr-report-header <?php echo $riskClass; ?>">
                    <div class="mlr-score-circle">
                        <svg viewBox="0 0 36 36" class="mlr-circular-chart">
                            <path class="mlr-circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            <path class="mlr-circle" stroke-dasharray="<?php echo $percent; ?>, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            <text x="18" y="20.35" class="mlr-percentage"><?php echo $score; ?></text>
                        </svg>
                        <span class="mlr-score-label">امتیاز</span>
                    </div>
                    <div>
                        <div style="font-size: 18px; font-weight: 700;">ریسک: <?php echo esc_html($risk); ?></div>
                        <div style="font-size: 13px; opacity: 0.9;"><?php echo esc_html($desc); ?></div>
                    </div>
                </div>
                
                <!-- Person Info -->
                <?php 
                $pInfo = $scoreObj['personInformation'] ?? ($reportObj['personInformation'] ?? []);
                if (!empty($pInfo)): ?>
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-id-alt"></span> اطلاعات هویتی</h4>
                    <div class="mlr-report-content mlr-grid-view">
                        <div class="mlr-info-item">نام و نام خانوادگی: <strong><?php echo esc_html(($pInfo['name'] ?? '') . ' ' . ($pInfo['family'] ?? '')); ?></strong></div>
                        <div class="mlr-info-item">کد ملی: <strong><?php echo esc_html($pInfo['nationalCode'] ?? '-'); ?></strong></div>
                        <div class="mlr-info-item">نام پدر: <strong><?php echo esc_html($pInfo['fatherName'] ?? '-'); ?></strong></div>
                        <div class="mlr-info-item">تاریخ تولد: <strong><?php echo esc_html($pInfo['dateOfBirth'] ?? '-'); ?></strong></div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Summary Cards -->
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-chart-bar"></span> خلاصه وضعیت مالی</h4>
                    <div class="mlr-report-content mlr-summary-cards">
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $summary['inProgressContractsCount'] ?? 0; ?></span>
                            <span class="mlr-summary-lbl">تسهیلات جاری</span>
                        </div>
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $fmt($summary['overdueAmount'] ?? 0); ?></span>
                            <span class="mlr-summary-lbl">معوقات (ریال)</span>
                        </div>
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $bouncedCount; ?></span>
                            <span class="mlr-summary-lbl">چک برگشتی</span>
                        </div>
                        <div class="mlr-summary-card">
                            <span class="mlr-summary-val"><?php echo $fmt($summary['totalAmount'] ?? 0); ?></span>
                            <span class="mlr-summary-lbl">کل تسهیلات (ریال)</span>
                        </div>
                    </div>
                </div>
                
                <!-- Loans -->
                <?php if (!empty($reportObj['directContracts'])): ?>
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-bank"></span> تسهیلات بانکی (وام‌ها)</h4>
                    <div class="mlr-report-content">
                        <table class="mlr-table">
                            <thead><tr><th>بانک</th><th>نوع</th><th>مبلغ کل (ریال)</th><th>مانده بدهی (ریال)</th><th>وضعیت</th></tr></thead>
                            <tbody>
                                <?php foreach($reportObj['directContracts'] as $loan): 
                                    $statusText = $loan['negativeContractStatus'] ?? 'جاری';
                                    $badgeClass = (strpos($statusText, 'معوق') !== false || strpos($statusText, 'مشکوک') !== false) ? 'mlr-badge-danger' : ((strpos($statusText, 'گذشته') !== false) ? 'mlr-badge-warning' : 'mlr-badge-success');
                                ?>
                                <tr>
                                    <td><?php echo esc_html($loan['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo esc_html($loan['typeOfFinancingTitle'] ?? '-'); ?></td>
                                    <td><?php echo $fmt($loan['totalAmount'] ?? 0); ?></td>
                                    <td><?php echo $fmt($loan['overdueAmount'] ?? 0); ?></td>
                                    <td><span class="mlr-badge <?php echo $badgeClass; ?>"><?php echo esc_html($statusText); ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Bounced Cheques -->
                <div class="mlr-report-section">
                    <h4><span class="dashicons dashicons-warning"></span> سوابق چک برگشتی</h4>
                    <div class="mlr-report-content">
                        <?php if (!empty($bouncedObj['bouncedCheques'])): ?>
                        <table class="mlr-table">
                            <thead><tr><th>بانک</th><th>مبلغ (ریال)</th><th>تاریخ برگشت</th><th>تاریخ رفع سوءاثر</th></tr></thead>
                            <tbody>
                                <?php foreach($bouncedObj['bouncedCheques'] as $item): 
                                    $bouncedDate = isset($item['bouncedDate']) ? preg_split('/[ T]/', $item['bouncedDate'])[0] : '-';
                                    $clearedDate = isset($item['clearedDate']) ? preg_split('/[ T]/', $item['clearedDate'])[0] : '---';
                                ?>
                                <tr>
                                    <td><?php echo esc_html($item['organizationName'] ?? '-'); ?></td>
                                    <td><?php echo $fmt($item['amount'] ?? 0); ?></td>
                                    <td><?php echo esc_html($bouncedDate); ?></td>
                                    <td><?php echo esc_html($clearedDate); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <div class="mlr-badge mlr-badge-success" style="display:inline-block; font-size:13px; padding:5px 10px;">✅ فاقد چک برگشتی</div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
            
            <style>
                .mlr-report-container { font-family: 'Vazirmatn', Tahoma, sans-serif; direction: rtl; background: #fff; }
                .mlr-report-header { display: flex; align-items: center; padding: 20px; color: #fff; border-radius: 12px; margin-bottom: 20px; }
                .mlr-risk-low { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
                .mlr-risk-medium { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
                .mlr-risk-high { background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); }
                .mlr-risk-unknown { background: linear-gradient(135deg, #64748b 0%, #475569 100%); }
                
                .mlr-score-circle { width: 80px; height: 80px; margin-left: 20px; position: relative; flex-shrink: 0; text-align: center; }
                .mlr-circular-chart { display: block; margin: 0 auto; max-width: 100%; max-height: 100%; }
                .mlr-circle-bg { fill: none; stroke: rgba(255,255,255,0.3); stroke-width: 3.8; }
                .mlr-circle { fill: none; stroke: #fff; stroke-width: 2.8; stroke-linecap: round; transition: stroke-dasharray 1s ease-out; }
                .mlr-percentage { fill: #fff; font-family: sans-serif; font-weight: bold; font-size: 0.5em; text-anchor: middle; }
                
                .mlr-score-label { font-size: 10px; font-weight: normal; margin-top: 2px; opacity: 0.9; }
                
                .mlr-report-section { border: 1px solid #e2e8f0; border-radius: 12px; margin-bottom: 20px; overflow: hidden; }
                .mlr-report-section h4 { background: #f8fafc; padding: 12px 15px; margin: 0; border-bottom: 1px solid #e2e8f0; font-size: 14px; font-weight: 700; color: #334155; display: flex; align-items: center; gap: 8px; }
                .mlr-report-content { padding: 15px; }
                
                .mlr-grid-view { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; }
                .mlr-info-item { font-size: 13px; color: #475569; }
                .mlr-info-item strong { color: #1e293b; display: block; margin-top: 4px; }
                
                .mlr-summary-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 10px; }
                .mlr-summary-card { background: #f1f5f9; padding: 15px; border-radius: 10px; text-align: center; }
                .mlr-summary-val { font-size: 16px; font-weight: 800; color: #334155; display: block; margin-bottom: 4px; }
                .mlr-summary-lbl { font-size: 11px; color: #64748b; }
                
                .mlr-table { width: 100%; border-collapse: collapse; font-size: 12px; }
                .mlr-table th { background: #f8fafc; padding: 10px; text-align: right; color: #64748b; border-bottom: 1px solid #e2e8f0; white-space: nowrap; }
                .mlr-table td { padding: 10px; border-bottom: 1px solid #f1f5f9; color: #334155; }
                .mlr-table tr:last-child td { border-bottom: none; }
                
                .mlr-badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; color: #fff; display: inline-block; }
                .mlr-badge-success { background: #10b981; }
                .mlr-badge-warning { background: #f59e0b; }
                .mlr-badge-danger { background: #ef4444; }
            </style>
        <?php endif; ?>
    </div>
    <?php
    wp_send_json_success(ob_get_clean());
}
}
