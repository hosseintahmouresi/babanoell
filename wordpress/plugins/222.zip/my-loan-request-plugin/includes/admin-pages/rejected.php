<?php
function mlr_rejected_requests_page() {
    mlr_display_requests_page('رد شده', 'درخواست‌های رد شده');
}
?>