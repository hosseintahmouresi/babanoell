<?php
function mlr_pending_requests_page() {
    // Simply call the master function with the correct status
    mlr_display_requests_page('در حال بررسی', 'درخواست‌های در حال بررسی');
}