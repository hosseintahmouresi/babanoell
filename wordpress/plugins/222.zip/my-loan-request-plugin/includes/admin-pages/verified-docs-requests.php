<?php
function mlr_verified_docs_requests_page() {
    mlr_display_requests_page('تأیید مدارک', 'درخواست‌های تأیید مدارک');
}
?>