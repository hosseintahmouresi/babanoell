<?php
function mlr_awaiting_documents_requests_page() {
    mlr_display_requests_page('تکمیل مدارک', 'درخواست‌های تکمیل مدارک');
}
?>