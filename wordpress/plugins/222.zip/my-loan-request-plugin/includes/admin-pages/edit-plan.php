<?php
function mlr_edit_plan_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'installment_plans';
    $plan_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    // --- Handling Form Submission ---
    if (isset($_POST['mlr_update_plan']) && check_admin_referer('mlr_update_plan_action')) {
        // Sanitize and prepare data
        $data = [
            'name'        => sanitize_text_field($_POST['plan_name']),
            'description' => sanitize_textarea_field($_POST['plan_description']),
            'min_amount'  => intval($_POST['min_amount']),
            'max_amount'  => intval($_POST['max_amount']),
            'min_interval'=> intval($_POST['min_interval']),
            'max_interval'=> intval($_POST['max_interval']),
            'min_count'   => intval($_POST['min_count']),
            'max_count'   => intval($_POST['max_count']),
            'settings'    => serialize([
                'requires_bank_validation' => isset($_POST['requires_bank_validation']) ? 1 : 0,
                'issue_check'              => isset($_POST['issue_check']) ? 1 : 0,
            ]),
            'required_documents' => serialize(isset($_POST['required_documents']) ? array_map('sanitize_text_field', $_POST['required_documents']) : [])
        ];
        
        // Validate amounts
        if ($data['min_amount'] < 0 || $data['max_amount'] < $data['min_amount']) {
             echo '<div class="error"><p>مقادیر حداقل و حداکثر مبلغ نامعتبر است.</p></div>';
        } else {
            // Update the database
            $wpdb->update($table_name, $data, ['id' => $plan_id]);
            echo '<div class="updated"><p>طرح با موفقیت به‌روزرسانی شد.</p></div>';
        }
    }

    // Fetch the plan data from DB
    $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $plan_id));

    if (!$plan) {
        echo '<div class="wrap"><h1>خطا</h1><p>طرح مورد نظر یافت نشد.</p></div>';
        return;
    }
    
    // Unserialize data for form display
    $settings = maybe_unserialize($plan->settings);
    $current_docs = maybe_unserialize($plan->required_documents) ?: [];
    
    // List of all possible documents
    $doc_labels = [
        'national_card_front' => 'تصویر روی کارت ملی',
        'national_card_back'  => 'تصویر پشت کارت ملی',
        'birth_certificate'   => 'تصویر شناسنامه',
        'job_document'        => 'مدرک شغلی (جواز کسب یا نامه اشتغال)',
        'account_statement'   => 'گزارش گردش حساب',
        'check'               => 'چک صیادی',
        'promissory_note'     => 'سفته',
        'payslip'             => 'فیش حقوقی'
    ];
?>
<div class="wrap">
    <h1>ویرایش طرح اقساطی: <?php echo esc_html($plan->name); ?></h1>
    <hr class="wp-header-end">
    
    <form method="post">
        <?php wp_nonce_field('mlr_update_plan_action'); ?>

        <h2>اطلاعات اصلی طرح</h2>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="plan_name">نام طرح</label></th>
                    <td><input name="plan_name" type="text" id="plan_name" value="<?php echo esc_attr($plan->name); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="plan_description">توضیحات</label></th>
                    <td><textarea name="plan_description" id="plan_description" rows="5" class="large-text"><?php echo esc_textarea($plan->description); ?></textarea></td>
                </tr>
            </tbody>
        </table>

        <h2>محدودیت‌های مبلغ و اقساط</h2>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="min_amount">حداقل مبلغ (تومان)</label></th>
                    <td><input name="min_amount" type="number" id="min_amount" value="<?php echo esc_attr($plan->min_amount); ?>" min="0" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="max_amount">حداکثر مبلغ (تومان)</label></th>
                    <td><input name="max_amount" type="number" id="max_amount" value="<?php echo esc_attr($plan->max_amount); ?>" min="0" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="min_count">حداقل تعداد اقساط</label></th>
                    <td><input name="min_count" type="number" id="min_count" value="<?php echo esc_attr($plan->min_count); ?>" min="0" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="max_count">حداکثر تعداد اقساط</label></th>
                    <td><input name="max_count" type="number" id="max_count" value="<?php echo esc_attr($plan->max_count); ?>" min="0" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="min_interval">حداقل فاصله بین اقساط (ماه)</label></th>
                    <td><input name="min_interval" type="number" id="min_interval" value="<?php echo esc_attr($plan->min_interval); ?>" min="0" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="max_interval">حداکثر فاصله بین اقساط (ماه)</label></th>
                    <td><input name="max_interval" type="number" id="max_interval" value="<?php echo esc_attr($plan->max_interval); ?>" min="0" required></td>
                </tr>
            </tbody>
        </table>

        <h2>تنظیمات و مدارک الزامی</h2>
        <table class="form-table">
             <tbody>
                <tr>
                    <th scope="row">الزامات طرح</th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text"><span>الزامات طرح</span></legend>
                            <label><input type="checkbox" name="requires_bank_validation" value="1" <?php checked($settings['requires_bank_validation'] ?? 0); ?>> نیاز به اعتبارسنجی بانکی دارد</label><br>
                            <label><input type="checkbox" name="issue_check" value="1" <?php checked($settings['issue_check'] ?? 0); ?>> نیاز به صدور چک برای ضمانت دارد</label>
                        </fieldset>
                    </td>
                </tr>
                <tr>
                    <th scope="row">مدارک الزامی</th>
                    <td>
                        <fieldset>
                             <legend class="screen-reader-text"><span>مدارک الزامی</span></legend>
                            <?php foreach ($doc_labels as $key => $label) : ?>
                                <label style="display: block; margin-bottom: 5px;">
                                    <input type="checkbox" name="required_documents[]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key, $current_docs)); ?>>
                                    <?php echo esc_html($label); ?>
                                </label>
                            <?php endforeach; ?>
                        </fieldset>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <?php submit_button('به‌روزرسانی طرح', 'primary', 'mlr_update_plan'); ?>
    </form>
</div>
<?php
}
?>