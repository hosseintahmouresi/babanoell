<?php
function mlr_complete_request_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d AND status IN ('در انتظار مدارک', 'تأیید نهایی')", $request_id));

    if (!$request) {
        echo '<div class="wrap"><h1>خطا</h1><p>درخواست یافت نشد یا قابل تکمیل نیست.</p></div>';
        return;
    }

    $plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM $plans_table WHERE id = %d", $request->installment_plan_id));

    if (isset($_POST['mlr_complete_request']) && check_admin_referer('mlr_complete_request_action')) {
        $order_items = sanitize_textarea_field($_POST['order_items']);
        $order_total = intval($_POST['order_total']);
        $description = sanitize_textarea_field($_POST['description']);
        $check_images = $request->check_images;
        $national_card_front = $request->national_card_front;
        $national_card_back = $request->national_card_back;

        $error_messages = [];

        // Handle signature image upload
        if (!empty($_FILES['signature_image']['name'])) {
            $upload = mlr_handle_wp_upload($_FILES['signature_image']);
            if (is_wp_error($upload)) {
                $error_messages[] = 'خطا در آپلود تصویر امضا: ' . $upload->get_error_message();
            } else {
                $signature_image = $upload;
            }
        } elseif (!$request->signature_image) {
            $error_messages[] = 'تصویر امضا الزامی است.';
        }

        // Handle contract file upload
        if (!empty($_FILES['contract_file']['name'])) {
            $upload = mlr_handle_wp_upload($_FILES['contract_file']);
            if (is_wp_error($upload)) {
                $error_messages[] = 'خطا در آپلود فایل قرارداد: ' . $upload->get_error_message();
            } else {
                $contract_file = $upload;
            }
        }

        // Handle national card front upload if enabled
        if ($plan->requires_national_card_front && !empty($_FILES['national_card_front']['name'])) {
            $upload = mlr_handle_wp_upload($_FILES['national_card_front']);
            if (is_wp_error($upload)) {
                $error_messages[] = 'خطا در آپلود کارت ملی (رو): ' . $upload->get_error_message();
            } else {
                $national_card_front = $upload;
            }
        }

        // Handle national card back upload if enabled
        if ($plan->requires_national_card_back && !empty($_FILES['national_card_back']['name'])) {
            $upload = mlr_handle_wp_upload($_FILES['national_card_back']);
            if (is_wp_error($upload)) {
                $error_messages[] = 'خطا در آپلود کارت ملی (پشت): ' . $upload->get_error_message();
            } else {
                $national_card_back = $upload;
            }
        }

        // Handle check images upload if issue_check is enabled
        if ($plan->issue_check && !empty($_FILES['check_images']['name'][0])) {
            $check_urls = [];
            $files = $_FILES['check_images'];
            foreach ($files['name'] as $key => $value) {
                if ($files['error'][$key] === UPLOAD_ERR_OK) {
                    $file = ['name' => $files['name'][$key], 'type' => $files['type'][$key], 'tmp_name' => $files['tmp_name'][$key], 'error' => $files['error'][$key], 'size' => $files['size'][$key]];
                    $upload = mlr_handle_wp_upload($file);
                    if (is_wp_error($upload)) {
                        $error_messages[] = 'خطا در آپلود چک: ' . $upload->get_error_message();
                    } else {
                        $check_urls[] = $upload;
                    }
                }
            }
            if (!empty($check_urls)) {
                $check_images = implode(',', $check_urls);
            }
        }

        if (!empty($error_messages)) {
            echo '<div class="error"><p>' . esc_html(implode(' | ', $error_messages)) . '</p></div>';
        } else {
            $wpdb->update(
                $table_name,
                [
                    'order_items' => $order_items,
                    'order_total' => $order_total,
                    'description' => $description,
                    'signature_image' => $signature_image,
                    'contract_file' => $contract_file,
                    'national_card_front' => $national_card_front,
                    'national_card_back' => $national_card_back,
                    'check_images' => $check_images,
                    'status' => 'تأیید نهایی',
                    'last_edited_at' => current_time('mysql')
                ],
                ['id' => $request_id]
            );
            echo '<div class="updated"><p>درخواست با موفقیت تکمیل شد.</p></div>';
            // Refresh request data to show updated info
            $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $request_id));
        }
    }

    ?>
    <div class="wrap">
        <h1>تکمیل درخواست (شناسه: <?php echo $request_id; ?>)</h1>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('mlr_complete_request_action'); ?>
            <p><label>اقلام سفارش: <textarea name="order_items" required><?php echo esc_textarea($request->order_items); ?></textarea></label></p>
            <p><label>مبلغ کل سفارش (تومان): <input type="number" name="order_total" value="<?php echo esc_attr($request->order_total); ?>" required></label></p>
            <p><label>توضیحات: <textarea name="description"><?php echo esc_textarea($request->description); ?></textarea></label></p>
            <p><label>تصویر امضا: <input type="file" name="signature_image" <?php echo $request->signature_image ? '' : 'required'; ?>></label></p>
            <p><label>فایل فاکتور/قرارداد: <input type="file" name="contract_file" <?php echo $request->contract_file ? '' : 'required'; ?>></label></p>
            <?php if ($plan->requires_national_card_front) : ?>
                <p><label>عکس کارت ملی (رو): <input type="file" name="national_card_front" <?php echo $request->national_card_front ? '' : 'required'; ?>></label></p>
            <?php endif; ?>
            <?php if ($plan->requires_national_card_back) : ?>
                <p><label>عکس کارت ملی (پشت): <input type="file" name="national_card_back" <?php echo $request->national_card_back ? '' : 'required'; ?>></label></p>
            <?php endif; ?>
            <?php if ($plan->issue_check) : ?>
                <p><label>تصاویر چک: <input type="file" name="check_images[]" multiple <?php echo $request->check_images ? '' : 'required'; ?>></label></p>
            <?php endif; ?>
            <button type="submit" name="mlr_complete_request" class="button button-primary">ذخیره و تأیید نهایی</button>
        </form>
    </div>
    <?php
}
?>