<?php
function mlr_expert_approval_requests_page() {
    mlr_display_requests_page('تأیید کارشناس', 'درخواست‌های تأیید کارشناس');
}
?>