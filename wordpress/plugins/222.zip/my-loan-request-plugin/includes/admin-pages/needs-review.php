<?php
function mlr_needs_review_requests_page() {
    mlr_display_requests_page('نقص مدارک', 'درخواست‌های نقص مدارک');
}
?>