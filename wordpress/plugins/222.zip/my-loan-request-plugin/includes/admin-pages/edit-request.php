<?php
function mlr_edit_request_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    // --- Handle Form Submission ---
    if (isset($_POST['mlr_update_request']) && check_admin_referer('mlr_update_request_action')) {
        
        // Sanitize and prepare all data fields
        $data = [
            'full_name'           => sanitize_text_field($_POST['full_name']),
            'national_code'       => sanitize_text_field($_POST['national_code']),
            'mobile_number'       => sanitize_text_field($_POST['mobile_number']),
            'phone_number'        => sanitize_text_field($_POST['phone_number']),
            'birth_date'          => sanitize_text_field($_POST['birth_date']),
            'occupation'          => sanitize_text_field($_POST['occupation']),
            'residential_address' => sanitize_textarea_field($_POST['residential_address']),
            'postal_code'         => sanitize_text_field($_POST['postal_code']),
            'work_address'        => sanitize_textarea_field($_POST['work_address']),
            'product_name'        => sanitize_textarea_field($_POST['product_name']),
            'loan_amount'         => floatval($_POST['loan_amount']),
            'installment_count'   => intval($_POST['installment_count']),
            'last_edited_at'      => current_time('mysql')
        ];

        // Update the database
        $wpdb->update($table_name, $data, ['id' => $request_id]);
        
        echo '<div class="updated"><p>درخواست با موفقیت به‌روزرسانی شد.</p></div>';
    }

    // Fetch the latest request data for form display
    $request = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $request_id));

    if (!$request) {
        echo '<div class="wrap"><h1>خطا</h1><p>درخواست مورد نظر یافت نشد.</p></div>';
        return;
    }

    // Prepare occupation options for the dropdown
    $occupations = [
        'official_employee' => 'کارمند رسمی',
        'contract_employee' => 'کارمند قراردادی',
        'worker'            => 'کارگر',
        'freelancer'        => 'آزاد',
        'retired'           => 'بازنشسته',
        'pensioner'         => 'مستمری بگیر',
        'employer'          => 'کارفرما',
        'other'             => 'سایر'
    ];
?>
<div class="wrap">
    <h1>ویرایش درخواست (شناسه: <?php echo $request_id; ?>)</h1>
    <hr class="wp-header-end">
    
    <form method="post">
        <?php wp_nonce_field('mlr_update_request_action'); ?>

        <h2>اطلاعات فردی و تماس متقاضی</h2>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="full_name">نام کامل</label></th>
                    <td><input name="full_name" type="text" id="full_name" value="<?php echo esc_attr($request->full_name); ?>" class="regular-text" required></td>
                </tr>
                 <tr>
                    <th scope="row"><label for="national_code">کد ملی</label></th>
                    <td><input name="national_code" type="text" id="national_code" value="<?php echo esc_attr($request->national_code); ?>" class="regular-text" required pattern="\d{10}"></td>
                </tr>
                 <tr>
                    <th scope="row"><label for="mobile_number">شماره موبایل</label></th>
                    <td><input name="mobile_number" type="text" id="mobile_number" value="<?php echo esc_attr($request->mobile_number); ?>" class="regular-text" required pattern="09\d{9}"></td>
                </tr>
                 <tr>
                    <th scope="row"><label for="phone_number">شماره تلفن ثابت</label></th>
                    <td><input name="phone_number" type="text" id="phone_number" value="<?php echo esc_attr($request->phone_number); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="birth_date">تاریخ تولد</label></th>
                    <td><input name="birth_date" type="date" id="birth_date" value="<?php echo esc_attr($request->birth_date); ?>" class="regular-text"></td>
                </tr>
                 <tr>
                    <th scope="row"><label for="occupation">شغل</label></th>
                    <td>
                        <select name="occupation" id="occupation">
                            <option value="">انتخاب کنید...</option>
                            <?php foreach ($occupations as $key => $label) : ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($request->occupation, $key); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>

        <h2>اطلاعات آدرس و محصول</h2>
        <table class="form-table">
            <tbody>
                 <tr>
                    <th scope="row"><label for="residential_address">آدرس محل سکونت</label></th>
                    <td><textarea name="residential_address" id="residential_address" rows="4" class="large-text"><?php echo esc_textarea($request->residential_address); ?></textarea></td>
                </tr>
                 <tr>
                    <th scope="row"><label for="postal_code">کد پستی</label></th>
                    <td><input name="postal_code" type="text" id="postal_code" value="<?php echo esc_attr($request->postal_code); ?>" class="regular-text" pattern="\d{10}"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="work_address">آدرس محل فعالیت</label></th>
                    <td><textarea name="work_address" id="work_address" rows="4" class="large-text"><?php echo esc_textarea($request->work_address); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="product_name">نام کامل محصول</label></th>
                    <td><textarea name="product_name" id="product_name" rows="2" class="large-text"><?php echo esc_textarea($request->product_name); ?></textarea></td>
                </tr>
            </tbody>
        </table>

        <h2>اطلاعات تسهیلات</h2>
         <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><label for="loan_amount">مبلغ تسهیلات (تومان)</label></th>
                    <td><input name="loan_amount" type="number" id="loan_amount" value="<?php echo esc_attr($request->loan_amount); ?>" min="0" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="installment_count">تعداد اقساط</label></th>
                    <td><input name="installment_count" type="number" id="installment_count" value="<?php echo esc_attr($request->installment_count); ?>" min="1" required></td>
                </tr>
            </tbody>
        </table>
        
        <?php submit_button('به‌روزرسانی درخواست', 'primary', 'mlr_update_request'); ?>
    </form>
</div>
<?php
}
?>