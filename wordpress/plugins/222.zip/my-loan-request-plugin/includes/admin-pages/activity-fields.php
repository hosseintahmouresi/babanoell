<?php
if (!defined('ABSPATH')) {
    exit;
}

function mlr_activity_fields_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'mlr_activity_fields';
    $message = '';
    $error = '';

    if (isset($_POST['mlr_submit_field']) && check_admin_referer('mlr_activity_field_nonce')) {
        $field_id = isset($_POST['field_id']) ? intval($_POST['field_id']) : 0;
        $field_name = sanitize_text_field($_POST['field_name']);

        if (empty($field_name)) {
            $error = 'نام زمینه فعالیت نمی‌تواند خالی باشد.';
        } else {
            if ($field_id > 0) {
                $wpdb->update($table_name, ['field_name' => $field_name], ['id' => $field_id]);
                $message = 'زمینه فعالیت با موفقیت به‌روزرسانی شد.';
            } else {
                $wpdb->insert($table_name, ['field_name' => $field_name]);
                $message = 'زمینه فعالیت جدید با موفقیت اضافه شد.';
            }
        }
    }

    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        if (check_admin_referer('mlr_delete_field_' . $_GET['id'])) {
            $wpdb->delete($table_name, ['id' => intval($_GET['id'])]);
            $message = 'زمینه فعالیت حذف شد.';
        }
    }

    $fields = $wpdb->get_results("SELECT * FROM $table_name ORDER BY field_name ASC");
    $edit_field = null;
    if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
        $edit_field = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['id'])));
    }
    ?>
    <div class="wrap">
        <h1>مدیریت زمینه‌های فعالیت</h1>

        <?php if ($message): ?><div class="updated notice is-dismissible"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
        <?php if ($error): ?><div class="error notice is-dismissible"><p><?php echo esc_html($error); ?></p></div><?php endif; ?>

        <div id="col-container" class="wp-clearfix">
            <div id="col-left">
                <div class="col-wrap">
                    <div class="form-wrap">
                        <h2><?php echo $edit_field ? 'ویرایش زمینه فعالیت' : 'افزودن زمینه فعالیت جدید'; ?></h2>
                        <form method="post" class="validate">
                            <?php wp_nonce_field('mlr_activity_field_nonce'); ?>
                            <input type="hidden" name="field_id" value="<?php echo $edit_field ? esc_attr($edit_field->id) : '0'; ?>">
                            
                            <div class="form-field form-required">
                                <label for="field_name">نام زمینه فعالیت</label>
                                <input name="field_name" id="field_name" type="text" value="<?php echo $edit_field ? esc_attr($edit_field->field_name) : ''; ?>" required />
                                <p>این نام در فرم‌های درخواست همکاری به کاربران نمایش داده می‌شود.</p>
                            </div>
                            
                            <p class="submit">
                                <input type="submit" name="mlr_submit_field" class="button button-primary" value="<?php echo $edit_field ? 'به‌روزرسانی زمینه فعالیت' : 'افزودن زمینه فعالیت'; ?>" />
                                <?php if ($edit_field): ?>
                                    <a href="<?php echo admin_url('admin.php?page=mlr-activity-fields'); ?>" class="button">لغو ویرایش</a>
                                <?php endif; ?>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
            <div id="col-right">
                <div class="col-wrap">
                    <h2>لیست زمینه‌های فعالیت موجود</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>نام زمینه</th>
                                <th>شناسه</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($fields)): ?>
                                <tr class="no-items"><td class="colspanchange" colspan="2">هیچ زمینه‌ای یافت نشد.</td></tr>
                            <?php else: ?>
                                <?php foreach ($fields as $field): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo esc_html($field->field_name); ?></strong>
                                            <div class="row-actions">
                                                <span class="edit"><a href="<?php echo admin_url('admin.php?page=mlr-activity-fields&action=edit&id=' . $field->id); ?>">ویرایش</a> | </span>
                                                <span class="delete"><a href="<?php echo wp_nonce_url(admin_url('admin.php?page=mlr-activity-fields&action=delete&id=' . $field->id), 'mlr_delete_field_' . $field->id); ?>" class="delete-tag" onclick="return confirm('آیا از حذف این مورد مطمئن هستید؟');">حذف</a></span>
                                            </div>
                                        </td>
                                        <td><?php echo esc_html($field->id); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
}