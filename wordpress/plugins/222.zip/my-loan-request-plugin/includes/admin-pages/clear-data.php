<?php
function mlr_clear_data_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $table_installment_plans = $wpdb->prefix . 'installment_plans';

    if (isset($_POST['mlr_clear_data']) && check_admin_referer('mlr_clear_data_action')) {
        $wpdb->query("TRUNCATE TABLE $table_requests");
        $wpdb->query("TRUNCATE TABLE $table_installment_plans");
        echo '<div class="updated"><p>تمامی داده‌های افزونه با موفقیت حذف شدند.</p></div>';
    }

    ?>
    <div class="wrap mlr-admin-wrap">
        <div class="mlr-page-header">
            <h1>حذف تمامی داده‌های افزونه</h1>
        </div>
        <div class="mlr-card" style="border-color: #ef4444;">
            <div class="mlr-card-content">
                <p style="color: #b91c1c; font-weight: bold; margin-bottom: 20px;">هشدار: این عملیات غیرقابل بازگشت است و تمام داده‌های مربوط به درخواست‌ها و طرح‌های اقساطی حذف خواهد شد.</p>
                <form method="post">
                    <?php wp_nonce_field('mlr_clear_data_action'); ?>
                    <button type="submit" name="mlr_clear_data" class="button button-primary" style="background: #ef4444; border-color: #ef4444;" onclick="return confirm('آیا مطمئن هستید که می‌خواهید تمام داده‌ها را حذف کنید؟');">حذف تمامی داده‌ها</button>
                </form>
            </div>
        </div>
    </div>
    <?php
}
?>