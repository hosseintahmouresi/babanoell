<?php
if (!defined('ABSPATH')) {
    exit;
}

// Handler for fetching requests for the original bank expert dashboard (status: تأیید کارشناس)
add_action('wp_ajax_mlr_get_bank_expert_requests', 'mlr_get_bank_expert_requests_callback');
add_action('wp_ajax_mlr_export_bank_expert_requests', 'mlr_export_bank_expert_requests_callback');
function mlr_get_bank_expert_requests_callback() {
    // Clean output buffer to prevent JSON errors
    if (ob_get_length()) ob_clean();

    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'کاربر وارد نشده است.']);
    }
    
    $current_user = wp_get_current_user();
    if (!in_array('bank', (array) $current_user->roles)) {
        wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید.']);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $user_id = $current_user->ID;

    $where_sql = $wpdb->prepare(" WHERE r.assigned_bank_user_id = %d AND r.status IN ('تأیید کارشناس','تایید کارشناس')", $user_id);
    
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $date_from_jalali = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '';
    $date_to_jalali = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '';
    
    $date_from_gregorian = !empty($date_from_jalali) ? mlr_jalali_to_gregorian($date_from_jalali) : '';
    $date_to_gregorian = !empty($date_to_jalali) ? mlr_jalali_to_gregorian($date_to_jalali) : '';

    if (!empty($search)) {
        $search_term = '%' . $wpdb->esc_like($search) . '%';
        $where_sql .= $wpdb->prepare(" AND (r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s OR r.id LIKE %s)", $search_term, $search_term, $search_term, $search_term);
    }
    if (!empty($date_from_gregorian)) {
        $where_sql .= $wpdb->prepare(" AND r.last_edited_at >= %s", $date_from_gregorian . ' 00:00:00');
    }
    if (!empty($date_to_gregorian)) {
        $where_sql .= $wpdb->prepare(" AND r.last_edited_at <= %s", $date_to_gregorian . ' 23:59:59');
    }

    $query = "SELECT r.id, r.full_name, r.mobile_number, r.national_code, r.loan_amount, r.status, r.last_edited_at, p.name as plan_name FROM {$table_name} as r LEFT JOIN {$plans_table} as p ON r.installment_plan_id = p.id {$where_sql} ORDER BY r.last_edited_at DESC";
    $requests = $wpdb->get_results($query);
    
    $html_output = '';
    if (empty($requests)) {
        $html_output = '<tr><td colspan="9" style="text-align:center; padding: 20px;">هیچ درخواستی به شما ارجاع داده نشده است.</td></tr>';
    } else {
        foreach ($requests as $request) {
            $html_output .= '<tr data-id="' . esc_attr($request->id) . '">';
            $html_output .= '<td data-label="شناسه">' . esc_html($request->id) . '</td>';
            $html_output .= '<td data-label="متقاضی">' . esc_html($request->full_name) . '</td>';
            $html_output .= '<td data-label="شماره موبایل">' . esc_html($request->mobile_number) . '</td>';
            $html_output .= '<td data-label="کد ملی">' . esc_html($request->national_code) . '</td>';
            $html_output .= '<td data-label="مبلغ">' . number_format($request->loan_amount) . '</td>';
            $html_output .= '<td data-label="طرح">' . esc_html($request->plan_name ?: '---') . '</td>';
            $html_output .= '<td data-label="وضعیت"><span class="mlr-status-badge" data-status="' . esc_attr($request->status) . '">' . esc_html($request->status) . '</span></td>';
            $html_output .= '<td data-label="تاریخ ارجاع">' . mlr_gregorian_to_jalali($request->last_edited_at, 'Y/m/d H:i') . '</td>';
            $html_output .= '<td data-label="عملیات"><button class="mlr-view-details-btn" title="مشاهده جزئیات"><span class="dashicons dashicons-admin-generic"></span></button></td>';
            $html_output .= '</tr>';
        }
    }
    wp_send_json_success(['html' => $html_output]);
}


add_action('wp_ajax_mlr_get_verified_docs_requests', 'mlr_get_verified_docs_requests_callback');
function mlr_get_verified_docs_requests_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'کاربر وارد نشده است.']);
    }
    $current_user = wp_get_current_user();
    if (!in_array('bank', (array) $current_user->roles)) {
        wp_send_json_error(['message' => 'شما دسترسی لازم را ندارید.']);
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $user_id = $current_user->ID;
    $where_sql = $wpdb->prepare(" WHERE r.status IN ('تأیید مدارک','تایید مدارک') AND r.assigned_bank_user_id = %d", $user_id);
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    if (!empty($search)) {
        $search_term = '%' . $wpdb->esc_like($search) . '%';
        $where_sql .= $wpdb->prepare(" AND (r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s OR r.id LIKE %s)", $search_term, $search_term, $search_term, $search_term);
    }
    
$date_from_jalali = isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '';
$date_to_jalali   = isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '';
$date_from_gregorian = !empty($date_from_jalali) && function_exists('mlr_jalali_to_gregorian') ? mlr_jalali_to_gregorian($date_from_jalali) : '';
$date_to_gregorian   = !empty($date_to_jalali) && function_exists('mlr_jalali_to_gregorian') ? mlr_jalali_to_gregorian($date_to_jalali) : '';
if (!empty($date_from_gregorian)) {
    $where_sql .= $wpdb->prepare(" AND r.last_edited_at >= %s", $date_from_gregorian . ' 00:00:00');
}
if (!empty($date_to_gregorian)) {
    $where_sql .= $wpdb->prepare(" AND r.last_edited_at <= %s", $date_to_gregorian . ' 23:59:59');
}
$query = "SELECT r.id, r.full_name, r.mobile_number, r.national_code, r.loan_amount, r.status, r.last_edited_at, p.name as plan_name FROM {$table_name} as r LEFT JOIN {$plans_table} as p ON r.installment_plan_id = p.id {$where_sql} ORDER BY r.last_edited_at DESC";
    $requests = $wpdb->get_results($query);
    $html_output = '';
    if (empty($requests)) {
        $html_output = '<tr><td colspan="9" style="text-align:center; padding: 20px;">هیچ درخواستی در وضعیت تأیید مدارک برای شما یافت نشد.</td></tr>';
    } else {
        foreach ($requests as $request) {
             $html_output .= '<tr data-id="' . esc_attr($request->id) . '">';
            $html_output .= '<td data-label="شناسه">' . esc_html($request->id) . '</td>';
            $html_output .= '<td data-label="متقاضی">' . esc_html($request->full_name) . '</td>';
            $html_output .= '<td data-label="شماره موبایل">' . esc_html($request->mobile_number) . '</td>';
            $html_output .= '<td data-label="کد ملی">' . esc_html($request->national_code) . '</td>';
            $html_output .= '<td data-label="مبلغ">' . number_format($request->loan_amount) . '</td>';
            $html_output .= '<td data-label="طرح">' . esc_html($request->plan_name ?: '---') . '</td>';
            $html_output .= '<td data-label="وضعیت"><span class="mlr-status-badge" data-status="' . esc_attr($request->status) . '">' . esc_html($request->status) . '</span></td>';
            $html_output .= '<td data-label="تاریخ تأیید مدارک">' . mlr_gregorian_to_jalali($request->last_edited_at, 'Y/m/d H:i') . '</td>';
            $html_output .= '<td data-label="عملیات"><button class="mlr-view-details-btn" title="مشاهده جزئیات"><span class="dashicons dashicons-admin-generic"></span></button></td>';
            $html_output .= '</tr>';
        }
    }
    wp_send_json_success(['html' => $html_output]);
}


add_action('wp_ajax_mlr_submit_bank_expert_review', 'mlr_submit_bank_expert_review_callback');
function mlr_submit_bank_expert_review_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'کاربر وارد نشده است.']);
    }
    $current_user = wp_get_current_user();
    if (!in_array('bank', (array) $current_user->roles)) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
    }
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $new_status = isset($_POST['new_status']) ? sanitize_text_field($_POST['new_status']) : '';
    $comment_text = isset($_POST['comment_text']) ? sanitize_textarea_field(stripslashes($_POST['comment_text'])) : '';
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $current_status = $wpdb->get_var($wpdb->prepare("SELECT status FROM $table_name WHERE id = %d AND assigned_bank_user_id = %d", $request_id, $current_user->ID));
    $current_status_normalized = function_exists('mlr_normalize_status') ? mlr_normalize_status($current_status) : $current_status;
    if (!$current_status) {
        wp_send_json_error(['message' => 'درخواست یافت نشد یا به شما ارجاع داده نشده است.']);
    }
    $allowed_statuses = [];
    if ($current_status_normalized === 'تایید کارشناس') {
        $allowed_statuses = ['تکمیل مدارک', 'نقص مدارک', 'رد شده'];
    } elseif ($current_status_normalized === 'تایید مدارک') {
        $allowed_statuses = ['اعطا شده', 'تکمیل مدارک'];
    }
    if (empty($allowed_statuses) || !in_array($new_status, $allowed_statuses)) {
        wp_send_json_error(['message' => 'تغییر به این وضعیت مجاز نیست.']);
    }
    $data_to_update = ['status' => $new_status, 'last_edited_at' => current_time('mysql')];
    if (!empty($comment_text)) {
        if (function_exists('mlr_add_request_message')) {
            mlr_add_request_message($request_id, $comment_text);
        }
        if (function_exists('mlr_add_request_event')) {
            mlr_add_request_event($request_id, 'note', 'یادداشت کارشناس بانک');
        }
        $existing_comments_json = $wpdb->get_var($wpdb->prepare("SELECT comments FROM $table_name WHERE id = %d", $request_id));
        $comments = !empty($existing_comments_json) ? json_decode($existing_comments_json, true) : [];
        if (!is_array($comments)) { $comments = []; }
        $new_comment = ['user_id' => $current_user->ID, 'display_name' => $current_user->display_name, 'text' => $comment_text, 'timestamp' => current_time('mysql')];
        $comments[] = $new_comment;
        $data_to_update['comments'] = json_encode($comments, JSON_UNESCAPED_UNICODE);
    }
    $updated = $wpdb->update($table_name, $data_to_update, ['id' => $request_id]);
    if ($updated !== false && function_exists('mlr_add_request_event')) {
        mlr_add_request_event($request_id, 'status_change', 'تغییر وضعیت به: ' . $new_status);
    }
    if ($updated === false) {
        wp_send_json_error(['message' => 'خطایی در هنگام به‌روزرسانی درخواست رخ داد.']);
    }
    if ($updated !== false) {
        mlr_send_sms_on_loan_status_change($request_id, $new_status);
    }
    wp_send_json_success(['message' => 'بررسی شما با موفقیت ثبت شد.']);
}

function mlr_export_bank_expert_requests_callback() {
    // Export as real Excel-compatible file (SpreadsheetML XML) without any extra server extensions
    check_ajax_referer('mlr_frontend_nonce', 'nonce');

    if (!is_user_logged_in()) {
        wp_die('not_logged_in');
    }
    $current_user = wp_get_current_user();
    if (!in_array('bank', (array) $current_user->roles, true)) {
        wp_die('no_access');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $user_id = $current_user->ID;

    // Filters (match dashboard)
    $status = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : '';
    $allowed_status = ['تأیید کارشناس','تایید کارشناس','تأیید مدارک','تایید مدارک'];
    if (!in_array($status, $allowed_status, true)) {
        $status = 'تأیید کارشناس';
    }

    $where_sql = $wpdb->prepare(" WHERE r.assigned_bank_user_id = %d AND r.status = %s", $user_id, $status);

    $search = isset($_GET['search']) ? sanitize_text_field(wp_unslash($_GET['search'])) : '';
    $date_from_jalali = isset($_GET['date_from']) ? sanitize_text_field(wp_unslash($_GET['date_from'])) : '';
    $date_to_jalali = isset($_GET['date_to']) ? sanitize_text_field(wp_unslash($_GET['date_to'])) : '';

    $date_from_gregorian = !empty($date_from_jalali) && function_exists('mlr_jalali_to_gregorian') ? mlr_jalali_to_gregorian($date_from_jalali) : '';
    $date_to_gregorian = !empty($date_to_jalali) && function_exists('mlr_jalali_to_gregorian') ? mlr_jalali_to_gregorian($date_to_jalali) : '';

    if (!empty($search)) {
        $search_term = '%' . $wpdb->esc_like($search) . '%';
        $where_sql .= $wpdb->prepare(" AND (r.full_name LIKE %s OR r.national_code LIKE %s OR r.mobile_number LIKE %s OR r.id LIKE %s)", $search_term, $search_term, $search_term, $search_term);
    }
    if (!empty($date_from_gregorian)) {
        $where_sql .= $wpdb->prepare(" AND r.last_edited_at >= %s", $date_from_gregorian . ' 00:00:00');
    }
    if (!empty($date_to_gregorian)) {
        $where_sql .= $wpdb->prepare(" AND r.last_edited_at <= %s", $date_to_gregorian . ' 23:59:59');
    }

    $query = "SELECT r.*, p.name AS plan_name
              FROM {$table_name} r
              LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id
              {$where_sql}
              ORDER BY r.last_edited_at DESC";
    $rows = $wpdb->get_results($query);

    // SpreadsheetML XML (opens in Excel as .xls)
    $filename = 'bank-requests-' . date('Ymd-His') . '.xls';
    header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    // UTF-8 BOM helps Excel detect UTF-8 Persian correctly
    echo "\xEF\xBB\xBF";

    $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml .= '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40">' . "\n";
    $xml .= '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Title>Bank Requests</Title></DocumentProperties>' . "\n";
    $xml .= '<ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel"><WindowHeight>9000</WindowHeight><WindowWidth>13860</WindowWidth><WindowTopX>0</WindowTopX><WindowTopY>0</WindowTopY><ProtectStructure>False</ProtectStructure><ProtectWindows>False</ProtectWindows></ExcelWorkbook>' . "\n";
    $xml .= '<Styles>' . "\n";
    $xml .= '<Style ss:ID="Default" ss:Name="Normal"><Alignment ss:Vertical="Center" ss:ReadingOrder="RightToLeft"/><Borders/><Font ss:FontName="Calibri" ss:Size="11"/><Interior/><NumberFormat/><Protection/></Style>' . "\n";
    $xml .= '<Style ss:ID="Header"><Font ss:Bold="1"/><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:ReadingOrder="RightToLeft"/><Interior ss:Color="#F2F2F2" ss:Pattern="Solid"/></Style>' . "\n";
    $xml .= '<Style ss:ID="Text"><Alignment ss:ReadingOrder="RightToLeft"/><NumberFormat ss:Format="@"/></Style>' . "\n";
    $xml .= '<Style ss:ID="Number"><Alignment ss:ReadingOrder="RightToLeft"/><NumberFormat ss:Format="0"/></Style>' . "\n";
    $xml .= '</Styles>' . "\n";

    $xml .= '<Worksheet ss:Name="Requests"><Table>' . "\n";

    $headers = [
        'شناسه',
        'متقاضی',
        'کد ملی',
        'موبایل',
        'مبلغ وام',
        'طرح',
        'وضعیت',
        'تاریخ ایجاد',
        'آخرین ویرایش',
    ];

    // Header row
    $xml .= '<Row ss:StyleID="Header">';
    foreach ($headers as $h) {
        $xml .= '<Cell><Data ss:Type="String">' . htmlspecialchars($h, ENT_XML1 | ENT_COMPAT, 'UTF-8') . '</Data></Cell>';
    }
    $xml .= '</Row>' . "\n";

    if ($rows) {
        foreach ($rows as $r) {
            $created = !empty($r->created_at) && function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($r->created_at, 'Y/m/d H:i') : $r->created_at;
            $edited  = !empty($r->last_edited_at) && function_exists('mlr_gregorian_to_jalali') ? mlr_gregorian_to_jalali($r->last_edited_at, 'Y/m/d H:i') : $r->last_edited_at;

            $cells = [
                ['type' => 'Number', 'style' => 'Number', 'value' => (string) $r->id],
                ['type' => 'String', 'style' => 'Text', 'value' => (string) $r->full_name],
                ['type' => 'String', 'style' => 'Text', 'value' => (string) $r->national_code],
                ['type' => 'String', 'style' => 'Text', 'value' => (string) $r->mobile_number],
                ['type' => 'Number', 'style' => 'Number', 'value' => (string) $r->loan_amount],
                ['type' => 'String', 'style' => 'Text', 'value' => (string) $r->plan_name],
                ['type' => 'String', 'style' => 'Text', 'value' => (string) $r->status],
                ['type' => 'String', 'style' => 'Text', 'value' => (string) $created],
                ['type' => 'String', 'style' => 'Text', 'value' => (string) $edited],
            ];

            $xml .= '<Row>';
            foreach ($cells as $c) {
                $v = htmlspecialchars($c['value'], ENT_XML1 | ENT_COMPAT, 'UTF-8');
                $xml .= '<Cell ss:StyleID="' . $c['style'] . '"><Data ss:Type="' . $c['type'] . '">' . $v . '</Data></Cell>';
            }
            $xml .= '</Row>' . "\n";
        }
    }

    $xml .= '</Table></Worksheet></Workbook>';

    echo $xml;
    exit;
}
