jQuery(document).ready(function($) {
    const plansData = mlrCalculatorAjax.plans;
    let selectedPlan = null;

    $('#calc_plan_select_front').on('change', function() {
        const selectedPlanId = $(this).val();
        const resultDiv = $('#calculator_result_front');
        const amountInput = $('#calc_amount_front');
        
        resultDiv.removeClass('error').empty().hide();
        amountInput.attr('placeholder', 'مبلغ را وارد کنید');
        amountInput.val('');

        if (!selectedPlanId) {
            $('#calc_installments_front').html('');
            selectedPlan = null;
            return;
        }

        selectedPlan = plansData.find(p => p.id == selectedPlanId);
        if (selectedPlan && selectedPlan.settings && selectedPlan.settings.active_installments) {
            const installmentsOptions = selectedPlan.settings.active_installments.split(',');
            let optionsHtml = '';
            installmentsOptions.forEach(function(inst) {
                optionsHtml += `<option value="${inst.trim()}">${inst.trim()} ماه</option>`;
            });
            $('#calc_installments_front').html(optionsHtml);
        }
        
        if (selectedPlan.type === 'leasing') {
            $('#calc_interval_wrapper_front').slideDown();
            $('#calc_amount_label_front').text('مبلغ خرید (تومان):');
        } else {
            $('#calc_interval_wrapper_front').slideUp();
            $('#calc_amount_label_front').text('مبلغ تسهیلات (تومان):');
        }

        // Apply limits to the amount input
        if (selectedPlan.settings.min_amount && selectedPlan.settings.max_amount) {
            const min = parseInt(selectedPlan.settings.min_amount).toLocaleString('fa-IR');
            const max = parseInt(selectedPlan.settings.max_amount).toLocaleString('fa-IR');
            amountInput.attr('min', selectedPlan.settings.min_amount);
            amountInput.attr('max', selectedPlan.settings.max_amount);
            amountInput.attr('placeholder', `بین ${min} تا ${max} تومان`);
        }
    });

    $('#run_calculator_front').on('click', function() {
        const resultDiv = $('#calculator_result_front');
        const planId = $('#calc_plan_select_front').val();
        const amount = parseInt($('#calc_amount_front').val());
        const installments = $('#calc_installments_front').val();

        if (!selectedPlan) {
            resultDiv.html('لطفاً ابتدا یک طرح را انتخاب کنید.').addClass('error').slideDown();
            return;
        }

        // Validation against plan limits
        const minAmount = parseInt(selectedPlan.settings.min_amount);
        const maxAmount = parseInt(selectedPlan.settings.max_amount);
        if (amount < minAmount || amount > maxAmount) {
            const min = minAmount.toLocaleString('fa-IR');
            const max = maxAmount.toLocaleString('fa-IR');
            resultDiv.html(`مبلغ وارد شده باید بین ${min} و ${max} تومان باشد.`).addClass('error').slideDown();
            return;
        }
        
        if (!planId || !amount || !installments) {
            resultDiv.html('لطفاً تمام فیلدها را تکمیل کنید.').addClass('error').slideDown();
            return;
        }

        const data = {
            action: 'mlr_frontend_calculate_loan',
            nonce: mlrCalculatorAjax.nonce,
            plan_id: planId,
            amount: amount,
            installments: installments,
            installment_interval: $('#calc_interval_front').val(),
        };

        resultDiv.html('در حال محاسبه...').removeClass('error').addClass('loading').slideDown();

        $.post(mlrCalculatorAjax.ajax_url, data, function(response) {
            resultDiv.removeClass('loading');
            if (response.success) {
                resultDiv.html(response.data.html);
            } else {
                resultDiv.html(response.data.message || 'خطایی در محاسبه رخ داد.').addClass('error');
            }
        }).fail(function() {
            resultDiv.removeClass('loading').addClass('error').html('خطا در ارتباط با سرور.');
        });
    });
});