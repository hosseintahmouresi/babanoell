jQuery(document).ready(function($) {

    // Ensure frontend modal containers exist
    if ($('#mlr-overlay').length === 0) {
        $('body').append('<div id="mlr-overlay" style="display:none;"></div>');
    }
    if ($('#mlr-details-content').length === 0) {
        $('body').append('<div id="mlr-details-content" style="display:none;"><button type="button" id="mlr-close-details" aria-label="بستن">×</button><div id="mlr-loading" style="display:none;text-align:center;padding:20px;"><span class="spinner is-active" style="float:none;visibility:visible;"></span></div><div id="mlr-details-inner"></div></div>');
    }

    // Initial load
    loadRequests();

    // Filter button click
    $('#mlr-filter-btn').on('click', function() {
        loadRequests();
    });

    // Search input change
    $('#mlr-search, #mlr-status, #mlr-date-from, #mlr-date-to').on('change keyup', function() {
        loadRequests();
    });

    // View details button click
    $(document).on('click', '.mlr-view-details', function() {
        var requestId = $(this).closest('tr').data('id');
        $.ajax({
            url: mlr_ajax_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_get_frontend_request_details',
                nonce: mlr_ajax_obj.details_nonce,
                request_id: requestId
            },
            success: function(response) {
                if (response.success) {
                    $('#mlr-actions-content').html(response.data.content);
                    $('#mlr-overlay, #mlr-actions-popup').show();
                } else {
                    alert(response.data.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
            }
        });
    });

    // Close popup
    $('#mlr-close-actions').on('click', function() {
        $('#mlr-overlay, #mlr-actions-popup').hide();
    });

    function loadRequests() {
        var search = $('#mlr-search').val();
        var status = $('#mlr-status').val();
        var dateFrom = $('#mlr-date-from').val();
        var dateTo = $('#mlr-date-to').val();
        console.log('Loading requests for user_id:', mlr_ajax_obj.user_id, 'with filters:', { search, status, dateFrom, dateTo });

        $.ajax({
            url: mlr_ajax_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'mlr_get_user_requests',
                nonce: mlr_ajax_obj.details_nonce,
                search: search,
                status: status,
                date_from: dateFrom,
                date_to: dateTo
            },
            success: function(response) {
                if (response.success) {
                    $('#mlr-requests-table').html(response.data.rows);
                    console.log('Requests loaded successfully:', response.data.rows);
                } else {
                    $('#mlr-requests-table').html('<tr><td colspan="9">خطا: ' + response.data.message + '</td></tr>');
                    console.error('Failed to load requests:', response.data.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                $('#mlr-requests-table').html('<tr><td colspan="9">خطا در بارگذاری درخواست‌ها.</td></tr>');
            }
        });
    }
});