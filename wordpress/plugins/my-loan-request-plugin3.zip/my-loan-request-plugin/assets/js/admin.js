jQuery(document).ready(function($) {
    // This file now depends on jalali-datepicker.js for datepicker functionality.
    
    // --- START: Cooperation Request Status Update ---
    $(document).on('change', '.mlr-status-select', function() {
        var select = $(this);
        var requestId = select.data('id');
        var newStatus = select.val();
        var spinner = select.next('.spinner');
        var originalValue = select.data('original-value') || select.find('option:not(:selected)').val();

        spinner.addClass('is-active');
        select.prop('disabled', true);

        $.ajax({
            url: mlrAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'mlr_update_cooperation_status',
                nonce: mlrAjax.nonce,
                request_id: requestId,
                status: newStatus
            },
            success: function(response) {
                if (response.success) {
                    select.data('original-value', newStatus);
                } else {
                    alert('خطا در به‌روزرسانی وضعیت: ' + (response.data.message || 'خطای ناشناخته.'));
                    select.val(originalValue);
                }
            },
            error: function() {
                alert('خطای سرور. لطفا صفحه را رفرش کنید و دوباره تلاش نمایید.');
                select.val(originalValue);
            },
            complete: function() {
                spinner.removeClass('is-active');
                select.prop('disabled', false);
            }
        });
    });
    // --- END: Cooperation Request Status Update ---

    // --- START: Cycle Details Toggle ---
    $(document).on('click', '.mlr-cycle-row', function(e) {
        e.stopPropagation();
        const cycleRow = $(this);
        const cycleId = cycleRow.data('cycle-id');
        const detailsRow = $('#cycle-details-' + cycleId);
        const detailsContainer = detailsRow.find('.cycle-details-container');
        const isLoaded = cycleRow.data('loaded') === true;

        cycleRow.toggleClass('open');
        detailsRow.toggle();

        if (!isLoaded && detailsRow.is(':visible')) {
            detailsContainer.html('<div class="spinner-container" style="text-align:center; padding: 20px;"><span class="spinner is-active"></span></div>');
            $.ajax({
                url: mlrAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'mlr_get_cycle_details',
                    nonce: mlrAjax.nonce,
                    cycle_id: cycleId
                },
                success: function(response) {
                    if (response.success) {
                        detailsContainer.html(response.data.html);
                        cycleRow.data('loaded', true);
                    } else {
                        detailsContainer.html('<p style="color:red; text-align:center;">' + (response.data.message || 'خطا در بارگذاری جزئیات.') + '</p>');
                    }
                },
                error: function() {
                    detailsContainer.html('<p style="color:red; text-align:center;">خطا در ارتباط با سرور.</p>');
                }
            });
        }
    });
    // --- END: Cycle Details Toggle ---

    // --- START: Modal & Actions Logic ---
    // Toggle action rows
    $(document).on('click', '.mlr-actions-btn-icon', function(e) {
        e.stopPropagation();
        var requestId = $(this).data('id');
        var actionsRow = $('#actions-row-' + requestId);
        var requestRow = actionsRow.prev('.mlr-request-row');
        var isCurrentlyVisible = actionsRow.is(':visible');

        // Close all other action rows
        $('.mlr-actions-row').not(actionsRow).hide();
        $('.mlr-request-row').not(requestRow).removeClass('active');

        actionsRow.toggle(!isCurrentlyVisible);
        requestRow.toggleClass('active', !isCurrentlyVisible);
    });

    // Open details modal when a request row is clicked (but not the action button itself)
    $(document).on('click', 'tr.mlr-request-row, tr.mlr-cooperation-request-row', function(e) {
        if ($(e.target).closest('.mlr-actions-container, .mlr-status-select, form').length > 0) return;
        e.stopPropagation(); 
        
        let action = 'mlr_get_request_details';
        if ($(this).hasClass('mlr-cooperation-request-row')) {
            action = 'mlr_get_cooperation_request_details';
        }
        
        showDetailsModal(action, $(this).data('id'));
    });
    
    // Central function to show any details modal
    function showDetailsModal(ajaxAction, requestId) {
        if (!requestId) return;

        $('#mlr-overlay, #mlr-details-content').fadeIn(200);
        $('#mlr-details-inner').html('<div style="text-align:center; padding: 40px;"><span class="spinner is-active"></span></div>');

        $.ajax({
            url: mlrAjax.ajaxurl,
            type: 'POST',
            data: {
                action: ajaxAction,
                nonce: mlrAjax.nonce,
                request_id: requestId
            },
            success: function(response) {
                if (response.success && response.data && response.data.html) {
                    $('#mlr-details-inner').html(response.data.html);
                } else {
                    const errorMessage = (response.data && response.data.message) ? response.data.message : 'خطای ناشناخته در دریافت اطلاعات.';
                    $('#mlr-details-inner').html('<p style="color:red; text-align:center;">' + errorMessage + '</p>');
                }
            },
            error: function() {
                $('#mlr-details-inner').html('<p style="color:red; text-align:center;">خطا در ارتباط با سرور.</p>');
            }
        });
    }

    // Close modal handlers
    $(document).on('click', '#mlr-overlay, #mlr-close-details', () => $('#mlr-overlay, #mlr-details-content').fadeOut(200));
    $(document).on('click', '#mlr-details-content', e => e.stopPropagation());
    // --- END: Modal & Actions Logic ---
    
    // --- START: Add Comment Logic ---
    $(document).on('click', '#mlr-add-comment-btn', function() {
        var button = $(this);
        var spinner = button.next('.spinner');
        var requestId = button.data('id');
        var commentText = $('#mlr_new_comment_text').val();

        if (!commentText.trim()) {
            alert('متن یادداشت نمی‌تواند خالی باشد.');
            return;
        }

        spinner.addClass('is-active');
        button.add('#mlr_new_comment_text').prop('disabled', true);

        $.ajax({
            url: mlrAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'mlr_add_comment',
                nonce: mlrAjax.nonce,
                request_id: requestId,
                comment: commentText
            },
            success: function(response) {
                if (response.success) {
                    $('#mlr-no-comments-yet').hide();
                    var historyContainer = $('#mlr-comments-history-container');
                    historyContainer.append(response.data.new_comment_html);
                    historyContainer.scrollTop(historyContainer[0].scrollHeight);
                    $('#mlr_new_comment_text').val('');
                } else {
                    alert('خطا: ' + (response.data.message || 'مشکلی در ثبت یادداشت رخ داد.'));
                }
            },
            error: () => alert('خطای ارتباط با سرور.'),
            complete: () => {
                spinner.removeClass('is-active');
                button.add('#mlr_new_comment_text').prop('disabled', false);
                $('#mlr_new_comment_text').focus();
            }
        });
    });
    // --- END: Add Comment Logic ---

    // Store original value for status selects on page load
    $('.mlr-status-select').each(function() {
        $(this).data('original-value', $(this).val());
    });
});