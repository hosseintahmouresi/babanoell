jQuery(document).ready(function($) {
    // Exit if the main container for this shortcode doesn't exist.
    if ($('.mlr-user-requests').length === 0) {
        return;
    }

    // --- START: CUSTOM JALALI DATEPICKER V4 ---
    // (This self-contained function handles the datepicker logic)
    (function() {
        // Only run if there are datepicker inputs on the page
        if ($('.jalali-datepicker').length === 0) {
            return;
        }

        let activeInput = null;
        let datepicker, yearSelect, monthSelect, grid;
        let currentYear, currentMonth;

        const dayNames = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
        const monthNames = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];

        function createDatePickerUI() {
            if ($('.mlr-custom-datepicker').length > 0) return; // Prevent duplicates

            let yearOptions = '<option value="" disabled>سال</option>';
            // Dynamic year range
            const currentJalaliYear = parseInt(new Date().toLocaleDateString('fa-IR-u-nu-latn').split('/')[0]) || 1403;
            for (let y = currentJalaliYear + 1; y >= 1390; y--) { // Range from next year down to 1390
                yearOptions += `<option value="${y}">${y}</option>`;
            }

            let monthOptions = '<option value="" disabled>ماه</option>';
            monthNames.forEach((name, index) => {
                monthOptions += `<option value="${index + 1}">${name}</option>`;
            });

            // Added inline styles for robustness, mimicking admin.css
            const dp_html = `
                <div class="mlr-custom-datepicker" style="display:none; position:absolute; z-index:10000; background:#fff; border:1px solid #ccc; border-radius:4px; padding:10px; width:220px; box-shadow: 0 3px 6px rgba(0,0,0,0.1);">
                    <div class="mlr-dp-header" style="display:flex; justify-content:space-between; margin-bottom:10px;">
                        <select class="mlr-dp-select year-select" required style="width:48%; padding: 4px; border:1px solid #ddd; border-radius:3px;">${yearOptions}</select>
                        <select class="mlr-dp-select month-select" required style="width:48%; padding: 4px; border:1px solid #ddd; border-radius:3px;">${monthOptions}</select>
                    </div>
                    <div class="mlr-dp-grid" style="display:grid; grid-template-columns:repeat(7, 1fr); gap:2px; text-align:center;"></div>
                </div>`;
            $('body').append(dp_html);

            datepicker = $('.mlr-custom-datepicker');
            yearSelect = datepicker.find('.year-select');
            monthSelect = datepicker.find('.month-select');
            grid = datepicker.find('.mlr-dp-grid');

            yearSelect.on('change', () => {
                currentYear = parseInt(yearSelect.val());
                if (currentMonth) renderCalendar();
            });
            monthSelect.on('change', () => {
                currentMonth = parseInt(monthSelect.val());
                if (currentYear) renderCalendar();
            });
            grid.on('click', '.mlr-dp-day:not(.disabled)', selectDate);

            // Hide on outside click
            $(document).on('click', function(e) {
                if (datepicker.is(":visible") && !$(e.target).closest('.mlr-custom-datepicker').length && !$(e.target).is(activeInput)) {
                    datepicker.fadeOut(200);
                    activeInput = null;
                }
            });
        }

        function isJalaliLeap(year) {
            const remainders = [1, 5, 9, 13, 17, 22, 26, 30];
            return remainders.indexOf(year % 33) > -1;
        }

        function toGregorian(jy, jm, jd) {
            var sal_a, gy, gm, gd, days;
            jy += 1595;
            days = -355668 + (365 * jy) + (~~(jy / 33) * 8) + ~~(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
            gy = 400 * ~~(days / 146097);
            days %= 146097;
            if (days > 36524) {
                gy += 100 * ~~(--days / 36524);
                days %= 36524;
                if (days >= 365) days++;
            }
            gy += 4 * ~~(days / 1461);
            days %= 1461;
            if (days > 365) {
                gy += ~~((days - 1) / 365);
                days = (days - 1) % 365;
            }
            gd = days + 1;
            sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
            return new Date(gy, gm - 1, gd);
        }

        function renderCalendar() {
            grid.empty();
            dayNames.forEach(name => grid.append(`<span class="mlr-dp-day-name" style="font-size:12px; font-weight:bold; color:#666; padding:4px 0;">${name}</span>`));

            const daysInMonth = (currentMonth <= 6) ? 31 : (currentMonth <= 11) ? 30 : (isJalaliLeap(currentYear)) ? 30 : 29;
            const startDayIndex = (new Date(toGregorian(currentYear, currentMonth, 1)).getDay() + 1) % 7; // 0=Shanbeh

            for (let i = 0; i < startDayIndex; i++) {
                grid.append('<span class="disabled"></span>');
            }
            for (let day = 1; day <= daysInMonth; day++) {
                grid.append($(`<span class="mlr-dp-day" style="padding:6px 2px; cursor:pointer; border-radius:3px;">${day}</span>`).data('day', day).hover(function(){ $(this).css('background','#f0f0f0'); }, function(){ $(this).css('background','transparent'); }));
            }
        }

        function selectDate() {
            if (!activeInput) return;
            const day = $(this).data('day');
            const finalDate = `${currentYear}/${String(currentMonth).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
            $(activeInput).val(finalDate);
            datepicker.fadeOut(200);
            activeInput = null;
        }

        // Use event delegation for dynamically added inputs
        $(document).on('click', '.jalali-datepicker', function() {
            activeInput = this;
            grid.empty();

            const existingDate = $(this).val();
            const now = new Date();
            const todayJalali = new Intl.DateTimeFormat('fa-IR-u-nu-latn', { year: 'numeric', month: 'numeric' }).format(now).split('/');

            if (existingDate && existingDate.match(/^\d{4}\/\d{2}\/\d{2}$/)) {
                const parts = existingDate.split('/');
                currentYear = parseInt(parts[0]);
                currentMonth = parseInt(parts[1]);
                yearSelect.val(currentYear);
                monthSelect.val(currentMonth);
            } else {
                 currentYear = parseInt(todayJalali[0]);
                 currentMonth = parseInt(todayJalali[1]);
                 yearSelect.val(currentYear);
                monthSelect.val(currentMonth);
            }

            if (currentYear && currentMonth) {
                 renderCalendar();
            }

            const inputPos = $(activeInput).offset();
            const inputHeight = $(activeInput).outerHeight();
            datepicker.css({
                top: inputPos.top + inputHeight + 5,
                left: inputPos.left, // Align with left edge
                right: 'auto'
            }).fadeIn(200);
        });

        createDatePickerUI(); // Initialize the datepicker UI
    })();
    // --- END: CUSTOM JALALI DATEPICKER V4 ---

    // --- Function to load requests via AJAX ---
    function loadRequests() {
        var container = $('.mlr-user-requests:not(.mlr-settlement-cycles)');
        if (container.length === 0) return;

        // Check if mlr_ajax_obj and filter_nonce are defined
        if (typeof mlr_ajax_obj === 'undefined' || typeof mlr_ajax_obj.filter_nonce === 'undefined') {
            console.error('mlr_ajax_obj or filter_nonce is not defined.');
            // Display error to user in the table
            container.find('#mlr-requests-table-body').html('<tr><td colspan="10" style="text-align:center; color: red;">خطای بارگذاری اسکریپت‌ها. لطفاً صفحه را رفرش کنید.</td></tr>');
            return;
        }

        var data = {
            action: 'mlr_get_user_requests',
            nonce: mlr_ajax_obj.filter_nonce,
            search: container.find('#mlr-search').val(),
            status: container.find('#mlr-status').val(),
            settlement_status: container.find('#mlr-settlement-status').val(),
            date_from: container.find('#mlr-date-from').val(),
            date_to: container.find('#mlr-date-to').val(),
            allowed_statuses: mlr_ajax_obj.allowed_statuses || [] // Ensure allowed_statuses exists
        };

        $.ajax({
            url: mlr_ajax_obj.ajax_url,
            type: 'POST',
            data: data,
            beforeSend: () => container.find('#mlr-requests-table-body').html('<tr><td colspan="10" style="text-align:center; padding: 20px;">در حال بارگذاری...</td></tr>'),
            success: (res) => {
                if (res.success) {
                    container.find('#mlr-requests-table-body').html(res.data.html);
                    // --- START: Add class after loading ---
                    // Add the necessary class to the rows after they are loaded
                    container.find('#mlr-requests-table-body tr[data-id]').addClass('mlr-request-row-frontend');
                    // --- END: Add class after loading ---
                } else {
                    container.find('#mlr-requests-table-body').html(`<tr><td colspan="10" style="text-align:center; color: red;">خطا: ${res.data.message || 'خطا در بارگذاری'}</td></tr>`);
                }
            },
            error: () => container.find('#mlr-requests-table-body').html('<tr><td colspan="10" style="text-align:center; color: red;">خطای ارتباط با سرور.</td></tr>')
        });
    }

    // --- Function to show the details modal ---
    function showDetailsModal(requestId, container) {
        const modalOverlay = container.find('.mlr-modal-overlay');
        const modal = container.find('.mlr-modal');
        const modalContent = container.find('.mlr-modal-content');

        if (!requestId || typeof mlr_ajax_obj === 'undefined' || typeof mlr_ajax_obj.details_nonce === 'undefined') {
             console.error('Request ID or details_nonce is missing for modal.');
             alert('خطا: امکان نمایش جزئیات وجود ندارد. (خطای داخلی)');
             return;
        }

        modalOverlay.fadeIn(200);
        modal.fadeIn(200);
        modalContent.html('<p style="text-align:center; padding: 40px;">در حال بارگذاری جزئیات...</p>');

        $.post(mlr_ajax_obj.ajax_url, {
            action: 'mlr_get_frontend_request_details',
            nonce: mlr_ajax_obj.details_nonce,
            request_id: requestId
        })
        .done((res) => {
            if (res.success) {
                modalContent.html(res.data.html);
                if (typeof $.fn.persianDatepicker === 'function') {
                    modalContent.find('.jalali-datepicker').persianDatepicker({
                         format: 'YYYY/MM/DD',
                         autoClose: true
                    });
                }
            } else {
                 modalContent.html(`<p style="color:red; text-align:center;">${res.data.message || 'خطا در دریافت اطلاعات'}</p>`);
            }
        })
        .fail(() => modalContent.html('<p class="mlr-error">خطای ارتباط با سرور.</p>'));
    }

    // --- AJAX Handler for Additional Docs Form ---
    $(document).on('submit', '#mlr-additional-docs-form', function(e) {
        e.preventDefault();

        const form = $(this);
        const submitBtn = form.find('button[type="submit"]');
        const messageDiv = form.find('#mlr-upload-message');
        const fileInput = form.find('#additional_documents_upload');

        if (!fileInput[0].files || fileInput[0].files.length === 0) {
             messageDiv.removeClass().addClass('mlr-upload-status error').html('لطفاً حداقل یک فایل را برای بارگذاری انتخاب کنید.').slideDown();
             return;
        }

        if (typeof mlr_ajax_obj === 'undefined' || typeof mlr_ajax_obj.details_nonce === 'undefined') {
            messageDiv.removeClass().addClass('mlr-upload-status error').html('خطای امنیتی. لطفاً صفحه را رفرش کنید.').slideDown();
            return;
        }

        var formData = new FormData(this);
        formData.append('action', 'mlr_upload_additional_docs');
        formData.append('nonce', mlr_ajax_obj.details_nonce);

        $.ajax({
            url: mlr_ajax_obj.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function() {
                submitBtn.prop('disabled', true).text('در حال ارسال...');
                messageDiv.removeClass().addClass('mlr-upload-status loading').html('در حال بارگذاری فایل‌ها...').slideDown();
            },
            success: function(response) {
                if (response.success) {
                    messageDiv.removeClass().addClass('mlr-upload-status success').html(response.data.message);
                    setTimeout(function() {
                        form.closest('.mlr-modal').fadeOut(200);
                        form.closest('.mlr-user-requests').find('.mlr-modal-overlay').fadeOut(200);
                        loadRequests();
                    }, 2000);
                } else {
                    messageDiv.removeClass().addClass('mlr-upload-status error').html(response.data.message || 'خطای ناشناخته رخ داد.');
                    submitBtn.prop('disabled', false).text('ارسال مدارک و بازبینی مجدد');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error("Additional Docs Upload AJAX Error: ", textStatus, errorThrown);
                messageDiv.removeClass().addClass('mlr-upload-status error').html('خطا در ارتباط با سرور.');
                submitBtn.prop('disabled', false).text('ارسال مدارک و بازبینی مجدد');
            }
        });
    });

    // --- Event Handlers for Cycle Details ---
    $(document).on('click', '.mlr-cycle-row-frontend', function() {
        const cycleRow = $(this);
        const cycleId = cycleRow.data('cycle-id');
        const detailsRow = $('#cycle-details-frontend-' + cycleId);
        const detailsContainer = detailsRow.find('.cycle-details-container');

        if (!cycleId || typeof mlr_ajax_obj === 'undefined' || typeof mlr_ajax_obj.cycle_nonce === 'undefined') {
             console.error('Cycle ID or cycle_nonce is missing.');
             return;
        }

        cycleRow.toggleClass('open');
        detailsRow.toggle();

        if (!cycleRow.data('loaded') && detailsRow.is(':visible')) {
            detailsContainer.find('.spinner-container').show();
            $.post(mlr_ajax_obj.ajax_url, {
                action: 'mlr_get_user_cycle_details',
                nonce: mlr_ajax_obj.cycle_nonce,
                cycle_id: cycleId
            })
            .done((res) => {
                if (res.success) {
                    detailsContainer.html(res.data.html);
                    // --- START: Add class after loading cycle details ---
                    detailsContainer.find('tr[data-id]').addClass('mlr-request-row-frontend');
                    // --- END: Add class after loading cycle details ---
                    cycleRow.data('loaded', true);
                } else {
                    detailsContainer.html(`<p style="color:red; text-align:center;">${res.data.message || 'خطا'}</p>`);
                }
            })
            .fail(() => detailsContainer.html('<p style="color:red; text-align:center;">خطای سرور.</p>'));
        }
    });

    // --- Event Handlers for Loan Request Table ---

    // *** START: Corrected Click Handler for Table Rows ***
    // Ensure this targets the dynamically added class
    $(document).on('click', '#mlr-requests-table-body tr.mlr-request-row-frontend', function(e) {
         // Stop if clicking directly on an interactive element
        if ($(e.target).closest('button, a, input, select, textarea').length > 0) {
            return;
        }

        const requestId = $(this).data('id');
        const container = $(this).closest('.mlr-user-requests');

        if (!requestId) {
            console.error('Could not find request ID for the clicked row.');
            return;
        }
        console.log('Row clicked, opening modal for request ID:', requestId); // Debug log
        showDetailsModal(requestId, container);
    });
    // *** END: Corrected Click Handler for Table Rows ***

    // Keep the details button handler as a fallback or if needed elsewhere
    $(document).on('click', '.mlr-view-details-btn', function(e) {
        e.stopPropagation(); // Prevent the row click handler from firing again
        const requestId = $(this).closest('tr').data('id');
        const container = $(this).closest('.mlr-user-requests');
         if (!requestId) {
            console.error('Could not find request ID for the clicked button.');
            return;
        }
        console.log('Button clicked, opening modal for request ID:', requestId); // Debug log
        showDetailsModal(requestId, container);
    });

    // Initial Load for loan request tables (not settlement)
    if ($('.mlr-user-requests:not(.mlr-settlement-cycles)').length > 0) {
        loadRequests();
    }
    // Filter button
    $(document).on('click', '#mlr-filter-btn', function() {
         var container = $(this).closest('.mlr-user-requests');
         if (!container.hasClass('mlr-settlement-cycles')) {
             loadRequests();
         }
    });
    // Search Enter key
    $(document).on('keyup', '#mlr-search', (e) => {
        if (e.key === 'Enter') {
             var container = $(e.target).closest('.mlr-user-requests');
             if (!container.hasClass('mlr-settlement-cycles')) {
                 loadRequests();
             }
        }
    });
    // Modal close
    $(document).on('click', '.mlr-modal-overlay, .mlr-modal-close', function() {
        var container = $(this).closest('.mlr-user-requests');
        container.find('.mlr-modal-overlay, .mlr-modal').fadeOut(200);
    });
    // Prevent modal close when clicking inside
    $(document).on('click', '.mlr-modal', function(e) {
        e.stopPropagation();
    });
});