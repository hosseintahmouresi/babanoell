<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_frontend_request_details', 'mlr_get_frontend_request_details_callback');

function mlr_get_frontend_request_details_callback() {
    // 1. Security Check
    if (!check_ajax_referer('mlr_frontend_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => 'خطای امنیتی. لطفاً صفحه را رفرش کنید.']);
        return;
    }
    // 2. Authentication Check
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای مشاهده جزئیات، لطفاً ابتدا وارد شوید.']);
        return;
    }

    // 3. Input Validation
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    // 4. Database Query & Permission Check
    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    $current_user = wp_get_current_user();
    
    $is_bank_expert = in_array('bank', (array) $current_user->roles);

    // Prepare query to fetch request and related plan info
    $query = $wpdb->prepare("
        SELECT r.*, p.name as plan_name, p.settings as plan_settings
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d", $request_id);

    // Append permission logic
    if (!$is_bank_expert) {
        // Regular user: Must be the owner
        $query .= $wpdb->prepare(" AND r.user_id = %d", $current_user->ID);
    } else {
        // Bank Expert: Must be the owner (acceptor) OR the assigned expert
        $query .= $wpdb->prepare(" AND (r.user_id = %d OR r.assigned_bank_user_id = %d)", $current_user->ID, $current_user->ID);
    }

    $request = $wpdb->get_row($query);

    // 5. Check if request was found
    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد یا شما به آن دسترسی ندارید.']);
        return;
    }

    // 6. Prepare Data for Display
    $occupations = [ 'official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر' ];
    $occupation_display = $occupations[$request->occupation] ?? esc_html($request->occupation);
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $order_items = !empty($request->order_items) ? json_decode($request->order_items, true) : [];
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];
    $plan_settings = maybe_unserialize($request->plan_settings);
    
    // Get Acceptor (Seller) data
    $acceptor_user_data = get_userdata($request->user_id);
    
    $seller_shop_name = get_user_meta($request->user_id, 'shoppp', true); // Custom meta key 'shoppp'
    if (empty($seller_shop_name)) {
        $seller_shop_name = $acceptor_user_data ? $acceptor_user_data->display_name : '-'; // Fallback to display name
    }

    // Other seller meta data with fallbacks
    $seller_address = get_user_meta($request->user_id, 'addresss', true) ?: '-';
    $seller_postal_code = get_user_meta($request->user_id, 'postiii', true) ?: '-';
    $seller_economic_number = get_user_meta($request->user_id, 'eghtesadiii', true) ?: '-';
    $seller_national_id = get_user_meta($request->user_id, 'meliii', true) ?: '-';
    $seller_registration_number = get_user_meta($request->user_id, 'sabttt', true) ?: '-';

    // 7. Start Output Buffering
    ob_start();
    ?>
    <h3 class="mlr-modal-title">
        جزئیات کامل درخواست (شناسه: <?php echo esc_html($request->id); ?>)
        <?php // Print Button ?>
        <button class="mlr-print-btn" onclick="window.print();" title="چاپ"><span class="dashicons dashicons-printer"></span></button>
    </h3>
    <div class="mlr-modal-content-inner">
        
        <?php // --- START: Comments Section --- ?>
        <?php if (!empty($comments) && is_array($comments)): ?>
            <div class="mlr-frontend-chat-container">
                <h4 class="mlr-modal-subtitle">گفتگو با کارشناسان</h4>
                <?php foreach($comments as $comment): ?>
                    <div class="mlr-chat-bubble">
                        <div class="mlr-chat-header">
                            <span class="mlr-chat-author"><?php echo esc_html($comment['display_name'] ?? 'پشتیبانی'); ?></span>
                            <span class="mlr-chat-timestamp"><?php echo mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i'); ?></span>
                        </div>
                        <div class="mlr-chat-body">
                            <p><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php // --- END: Comments Section --- ?>


        <?php // --- START: "Complete Docs" Section (for 'تکمیل مدارک' status) --- ?>
        <?php if ($request->status === 'تکمیل مدارک' && (int)$request->user_id === $current_user->ID): ?>
            <div class="mlr-complete-docs-section">
                <?php // The Stepper UI ?>
                <div class="mlr-stepper">
                    <div class="mlr-step active" data-step="1"><div class="mlr-step-icon">1</div><div class="mlr-step-label">آپلود چک</div></div>
                    <div class="mlr-step-connector"></div>
                    <div class="mlr-step" data-step="2"><div class="mlr-step-icon">2</div><div class="mlr-step-label">قرارداد</div></div>
                    <div class="mlr-step-connector"></div>
                    <div class="mlr-step" data-step="3"><div class="mlr-step-icon">3</div><div class="mlr-step-label">فاکتور</div></div>
                    <div class="mlr-step-connector"></div>
                    <div class="mlr-step" data-step="4"><div class="mlr-step-icon">4</div><div class="mlr-step-label">تکمیل نهایی</div></div>
                </div>

                <?php // The Form containing all step panes ?>
                <form id="mlr-complete-docs-form" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request_id); ?>">

                    <div class="mlr-stepper-content">
                        <?php // Step 1 Pane: Check Upload ?>
                        <div class="mlr-step-pane active" data-step-pane="1">
                            <h4 class="mlr-modal-subtitle">مرحله ۱: آپلود تصویر چک</h4>
                            <div class="mlr-form-group">
                                <label for="completed_check_upload">تصویر چک تکمیل شده‌ی صیادی (امکان انتخاب چند فایل وجود دارد)</label>
                                <input type="file" id="completed_check_upload" name="completed_check_files[]" class="mlr-file-input" multiple required>
                            </div>
                        </div>

                        <?php // Step 2 Pane: Contract ?>
                        <div class="mlr-step-pane" data-step-pane="2">
                            <h4 class="mlr-modal-subtitle">مرحله ۲: دریافت و آپلود قرارداد</h4>
                            <p>لطفاً فایل قرارداد را از طریق دکمه زیر دریافت و چاپ کرده، پس از امضا، فایل اسکن شده آن را در بخش زیر بارگذاری نمایید.</p>
                            
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-print-contract-step-btn">دریافت و چاپ قرارداد</button>

                             <div class="printable-contract-area" style="display: none;">
                                <?php // Contract content injection ?>
                                <?php if (!empty($plan_settings['plan_letterhead_url'])): ?>
                                    <div class="mlr-contract-letterhead"><img src="<?php echo esc_url($plan_settings['plan_letterhead_url']); ?>" alt="سربرگ قرارداد"></div>
                                <?php endif; ?>
                                
                                <div class="mlr-contract-datetime">تاریخ و ساعت: <?php echo mlr_gregorian_to_jalali(current_time('mysql'), 'Y/m/d H:i:s'); ?></div>

                                <?php if (!empty($plan_settings['plan_contract_text'])) {
                                    $contract_text = $plan_settings['plan_contract_text'];
                                    $variables = [
                                        '[full_name]' => esc_html($request->full_name),
                                        '[national_code]' => esc_html($request->national_code),
                                        '[mobile_number]' => esc_html($request->mobile_number),
                                        '[loan_amount]' => number_format($request->loan_amount),
                                        '[installment_count]' => esc_html($request->installment_count),
                                        '[installment_amount]' => number_format($request->installment_amount),
                                        '[total_payment]' => number_format($request->total_payment),
                                    ];
                                    $processed_contract = str_replace(array_keys($variables), array_values($variables), $contract_text);
                                    echo '<div class="mlr-contract-box">' . wpautop($processed_contract) . '</div>';
                                } else {
                                     echo '<div class="mlr-contract-box"><p>متن قرارداد برای این طرح تنظیم نشده است.</p></div>';
                                }
                                ?>

                                <?php if (!empty($plan_settings['plan_footer_url'])): ?>
                                    <div class="mlr-contract-footer"><img src="<?php echo esc_url($plan_settings['plan_footer_url']); ?>" alt="پابرگ قرارداد"></div>
                                <?php endif; ?>
                            </div>

                            <div class="mlr-form-group" style="margin-top: 20px;">
                                <label for="signed_contract_upload">آپلود قرارداد امضا شده</label>
                                <p class="description">پسوندهای مجاز: تصاویر و PDF. محدودیتی در حجم و تعداد فایل‌ها وجود ندارد.</p>
                                <input type="file" id="signed_contract_upload" name="signed_contract_files[]" class="mlr-file-input" multiple accept="image/*,.pdf">
                            </div>
                        </div>

                        <?php // Step 3 Pane: Invoice ?>
                        <div class="mlr-step-pane" data-step-pane="3">
                            <h4 class="mlr-modal-subtitle">مرحله ۳: فاکتور</h4>
                            
                            <?php // Invoice CSS (scoped) ?>
                            <style>
                                #mlr-invoice-style-reset, #mlr-invoice-style-reset * { all: revert !important; font-family: 'iranyekan', Tahoma, Arial, sans-serif !important; font-size: 9pt !important; color: #333 !important; direction: rtl !important; box-sizing: border-box !important; line-height: 1.6; }
                                #mlr-invoice-style-reset .printable-invoice-area table:not(.header-table) { width: 100% !important; border-collapse: collapse !important; border-radius: 10px !important; border-spacing: 0 !important; border-style: hidden !important; box-shadow: 0 0 0 1px #ccc !important; }
                                #mlr-invoice-style-reset .printable-invoice-area td, #mlr-invoice-style-reset .printable-invoice-area th { border: 1px solid #ccc !important; padding: 8px !important; text-align: center !important; vertical-align: middle !important; }
                                #mlr-invoice-style-reset .header-table { border: none !important; box-shadow: none !important; margin-top: 0 !important; width: 100%;}
                                #mlr-invoice-style-reset .header-table .logo { width: 120px !important; height: auto !important; }
                                #mlr-invoice-style-reset .header-table .invoice-title { font-size: 18px !important; font-weight: 800 !important; }
                                #mlr-invoice-style-reset .info-table, #mlr-invoice-style-reset .info-table td { border: none !important; box-shadow: none !important; margin: 0 !important; padding: 2px 4px !important; }
                                #mlr-invoice-style-reset .items-table thead th, #mlr-invoice-style-reset .section-title th { background-color: #1d3558 !important; color: #d0e2f2 !important; font-size: 10pt !important; font-weight: bold !important; padding: 5px !important; }
                                #mlr-invoice-style-reset .section-title th { font-size: 11pt !important; border-radius: 8px 8px 0 0 !important; }
                                #mlr-invoice-style-reset .items-table tbody td { font-family: monospace, 'iranyekan' !important; }
                                #mlr-invoice-style-reset .items-table tbody td:nth-child(2) { text-align: right !important; }
                                #mlr-invoice-style-reset b { font-weight: bold !important; }
                                #mlr-invoice-style-reset .text-right { text-align: right !important; }
                                #mlr-invoice-style-reset .footer-total td { background-color: #f2f2f2 !important; font-weight: bold !important; }
                                #mlr-invoice-style-reset .signature-table { margin-top: 20px !important; width: 100%; border-collapse: collapse;}
                                #mlr-invoice-style-reset .signature-table td { width: 50% !important; height: 120px !important; text-align: center !important; vertical-align: top !important; border: 1px solid #ccc !important; }
                                #mlr-invoice-style-reset .signature-table p { margin: 5px 0 !important; font-weight: bold !important; }
                            </style>
                            
                            <div id="mlr-invoice-style-reset">
                                <div class="printable-invoice-area">
                                    <?php // Invoice HTML content... ?>
                                    <table class="header-table"><tr>
                                        <td class="text-right"><img class="logo" src="https://babanoell.com/wp-content/uploads/لوگو-واتر-سایت-1.png" alt="logo"></td>
                                        <td class="invoice-title">صورتحساب نیابتی فروش کالا و خدمات</td>
                                        <td><div>شماره سریال: <span><?php echo esc_html($request->id); ?></span><br>تاریخ: <span><?php echo mlr_gregorian_to_jalali($request->created_at, 'Y/m/d'); ?></span></div></td>
                                    </tr></table>
                                    <table>
                                        <tr class="section-title"><th colspan="3">مشخصات تسهیل گر</th></tr>
                                        <tr><td colspan="3"><table class="info-table"><tr><td class="text-right"><b>نام شخص حقیقی / حقوقی:</b> شرکت آرمان فراز هیوا</td><td class="text-right"><b>شماره اقتصادی:</b> <span>14011126653</span></td><td class="text-right"><b>شناسه ملی:</b> <span>14011126653</span></td></tr><tr><td class="text-right"><b>شماره ثبت:</b> <span>70935</span></td><td colspan="2" class="text-right"><b>آدرس:</b> اصفهان - بلوار کشاورز - مجتمع اداری ملل - طبقه 1 - واحد 104</td></tr><tr><td class="text-right"><b>کد پستی:</b> <span>8176995595</span></td><td class="text-right"><b>شماره تماس:</b> <span>031-91001055</span></td><td></td></tr></table></td></tr>
                                        <tr class="section-title"><th colspan="3">مشخصات فروشنده</th></tr>
                                        <tr><td colspan="3"><table class="info-table"><tr><td class="text-right"><b>نام شخص حقیقی / حقوقی:</b> <?php echo esc_html($seller_shop_name); ?></td><td class="text-right"><b>شماره اقتصادی:</b> <?php echo esc_html($seller_economic_number); ?></td><td class="text-right"><b>شناسه ملی:</b> <?php echo esc_html($seller_national_id); ?></td></tr><tr><td class="text-right"><b>شماره ثبت:</b> <?php echo esc_html($seller_registration_number); ?></td><td colspan="2" class="text-right"><b>آدرس:</b> <?php echo esc_html($seller_address); ?></td></tr><tr><td class="text-right"><b>کد پستی:</b> <?php echo esc_html($seller_postal_code); ?></td><td class="text-right"><b>شماره تماس:</b> -</td><td></td></tr></table></td></tr>
                                        <tr class="section-title"><th colspan="3">مشخصات خریدار</th></tr>
                                        <tr><td colspan="3"><table class="info-table"><tr><td class="text-right"><b>نام شخص حقیقی / حقوقی:</b> <?php echo esc_html($request->full_name ?? '-'); ?></td><td class="text-right"><b>شماره اقتصادی:</b> -</td><td class="text-right"><b>شناسه ملی:</b> <?php echo esc_html($request->national_code ?? '-'); ?></td></tr><tr><td class="text-right"><b>شماره ثبت:</b> -</td><td colspan="2" class="text-right"><b>آدرس:</b> <?php echo esc_html($request->residential_address ?? '-'); ?></td></tr><tr><td class="text-right"><b>کد پستی:</b> <?php echo esc_html($request->postal_code ?? '-'); ?></td><td class="text-right"><b>شماره تماس:</b> <?php echo esc_html($request->mobile_number ?? '-'); ?></td><td></td></tr></table></td></tr>
                                    </table>
                                    <p><b>مشخصات کالا یا خدمات</b></p>
                                    <table class="items-table">
                                        <thead><tr><th>ردیف</th><th>شرح کالا یا خدمات</th><th>تعداد</th><th>مبلغ واحد (ریال)</th><th>مبلغ کل (ریال)</th></tr></thead>
                                        <tbody>
                                            <?php $total_price = 0; $total_qty = 0; $counter = 1;
                                            if(!empty($order_items) && is_array($order_items)):
                                                foreach($order_items as $item): 
                                                    $item_qty = (int)($item['qty'] ?? 1); $item_price = (float)($item['price'] ?? 0); $item_total = $item_price * $item_qty;
                                                    $total_price += $item_total; $total_qty += $item_qty;
                                            ?>
                                            <tr><td><?php echo number_format_i18n($counter++); ?></td><td><?php echo esc_html($item['name'] ?? '---'); ?></td><td><?php echo number_format_i18n($item_qty); ?></td><td><?php echo number_format_i18n($item_price); ?></td><td><?php echo number_format_i18n($item_total); ?></td></tr>
                                            <?php endforeach; endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr class="footer-total"><td colspan="2" class="text-right">جمع کل</td><td><?php echo number_format_i18n($total_qty); ?></td><td>-</td><td><?php echo number_format_i18n($total_price); ?></td></tr>
                                            <tr class="footer-total"><td colspan="3" class="text-right"><b>جمع کل مبلغ تسهیلات + سود:</b> <?php echo number_format_i18n($request->total_payment); ?> ریال</td><td colspan="2" class="text-right"><b>مبلغ هر قسط:</b> <?php echo number_format_i18n($request->installment_amount); ?> ریال</td></tr>
                                        </tfoot>
                                    </table>
                                    <p>طبق فاکتور فوق، تعداد <?php echo esc_html(number_format_i18n($total_qty)); ?> عدد کالا به اینجانب <?php echo esc_html($request->full_name); ?> به شناسه / کدملی <?php echo esc_html($request->national_code); ?> به صورت صحیح و سالم تحویل گردید.</p>
                                    <table class="signature-table"><tr><td><p>مهر و امضاء فروشنده</p></td><td><p>امضا و اثرانگشت خریدار</p></td></tr></table>
                                </div>
                            </div>
                            <button type="button" class="mlr-btn mlr-btn-primary mlr-print-invoice-step-btn" style="margin-top: 15px;">دریافت و پرینت فاکتور</button>
                            <div class="mlr-form-group" style="margin-top: 20px;">
                                <label for="signed_invoice_upload">بارگذاری فاکتور امضا شده</label>
                                <p class="description">پسوندهای مجاز: تصاویر و PDF. محدودیتی در حجم و تعداد فایل‌ها وجود ندارد.</p>
                                <input type="file" id="signed_invoice_upload" name="signed_invoice_files[]" class="mlr-file-input" multiple accept="image/*,.pdf">
                            </div>
                        </div>
                        
                        <?php // Step 4 Pane: Other Files ?>
                        <div class="mlr-step-pane" data-step-pane="4">
                             <h4 class="mlr-modal-subtitle">مرحله ۴: دانلود و آپلود فایل‌های نهایی</h4>
                            <?php // Downloadable files
                            if (!empty($plan_settings['plan_downloadable_files']) && is_array($plan_settings['plan_downloadable_files'])) {
                                echo '<h5>دانلود سایر فایل‌ها (اختیاری)</h5>';
                                echo '<ul class="mlr-downloadable-files-list">';
                                foreach ($plan_settings['plan_downloadable_files'] as $file_url) {
                                    $filename = basename($file_url);
                                    echo '<li><a href="' . esc_url($file_url) . '" download>' . esc_html($filename) . '</a></li>';
                                }
                                echo '</ul>';
                            }
                            ?>
                             <div class="mlr-form-group">
                                <label for="other_completed_files_upload">آپلود سایر مدارک (اختیاری)</label>
                                 <p class="description">در این بخش می‌توانید فایل‌های مورد نیاز دیگر را با پسوندهای مجاز (jpg, jpeg, png, pdf) و بدون محدودیت در حجم و تعداد بارگذاری نمایید.</p>
                                <input type="file" id="other_completed_files_upload" name="other_completed_files[]" class="mlr-file-input" multiple accept=".jpg,.jpeg,.png,.pdf">
                            </div>
                        </div>
                    </div> <?php // End mlr-stepper-content ?>

                    <?php // Stepper Buttons ?>
                    <div class="mlr-stepper-buttons">
                        <button type="button" class="mlr-btn-secondary mlr-prev-step-btn" style="display: none;">قبلی</button>
                        <button type="button" class="mlr-btn-primary mlr-next-step-btn">بعدی</button>
                        <button type="submit" class="mlr-btn-success mlr-submit-btn" style="display: none;">ارسال مدارک و تأیید نهایی</button>
                    </div>
                    <div id="mlr-complete-upload-message" class="mlr-upload-status"></div> <?php // Feedback div ?>
                </form>
            </div>
        <?php endif; ?>
        <?php // --- END: "Complete Docs" Section --- ?>

        
        <?php // --- START: "Additional Docs" Section (for 'نقص مدارک' status) --- ?>
        <?php if ($request->status === 'نقص مدارک' && (int)$request->user_id === $current_user->ID): ?>
            <div class="mlr-additional-docs-section">
                <h4 class="mlr-modal-subtitle">بارگذاری مدارک تکمیلی (رفع نقص)</h4>
                <form id="mlr-additional-docs-form" enctype="multipart/form-data">
                    <input type="hidden" name="request_id" value="<?php echo esc_attr($request_id); ?>">
                    <div class="mlr-form-group">
                        <label for="additional_documents_upload">فایل‌های خود را انتخاب کنید (امکان انتخاب چند فایل وجود دارد)</label>
                        <input type="file" id="additional_documents_upload" name="additional_documents[]" class="mlr-file-input" multiple required>
                    </div>
                    <div id="mlr-upload-message" class="mlr-upload-status"></div> <?php // Feedback div ?>
                    <button type="submit" class="mlr-btn">ارسال مدارک و بازبینی مجدد</button>
                </form>
            </div>
        <?php endif; ?>
        <?php // --- END: "Additional Docs" Section --- ?>

        
        <?php // --- START: Bank Expert Action Forms --- ?>
        <?php if ($is_bank_expert && (int)$request->assigned_bank_user_id === $current_user->ID): ?>
            <?php // Form for 'تأیید کارشناس' status ?>
            <?php if ($request->status === 'تأیید کارشناس'): ?>
                <div class="mlr-bank-expert-actions">
                    <h4 class="mlr-modal-subtitle">ثبت بررسی کارشناس بانک</h4>
                    <form id="mlr-bank-expert-action-form">
                        <input type="hidden" name="request_id" value="<?php echo esc_attr($request_id); ?>">
                        <div class="mlr-form-group">
                            <label for="new_status_tk">تغییر وضعیت درخواست:</label>
                            <select name="new_status" id="new_status_tk" class="mlr-select" required>
                                <option value="تکمیل مدارک">تکمیل مدارک (تایید)</option>
                                <option value="نقص مدارک">نقص مدارک (نیاز به بازبینی)</option>
                                <option value="رد شده">رد شده (رد نهایی)</option>
                            </select>
                        </div>
                        <div class="mlr-form-group">
                            <label for="comment_text_tk">افزودن یادداشت (اختیاری):</label>
                            <textarea name="comment_text" id="comment_text_tk" rows="4" class="mlr-textarea" placeholder="در صورت نیاز، توضیحات خود را برای کاربر بنویسید..."></textarea>
                        </div>
                        <div class="mlr-action-message"></div> <?php // Feedback div ?>
                        <button type="submit" class="mlr-btn">ثبت بررسی</button>
                    </form>
                </div>
            <?php // Form for 'تأیید مدارک' status ?>
            <?php elseif ($request->status === 'تأیید مدارک'): ?>
                <div class="mlr-bank-expert-actions">
                    <h4 class="mlr-modal-subtitle">ثبت بررسی نهایی</h4>
                    <form id="mlr-bank-expert-action-form">
                        <input type="hidden" name="request_id" value="<?php echo esc_attr($request_id); ?>">
                        <div class="mlr-form-group">
                            <label for="new_status_tm">تغییر وضعیت درخواست:</label>
                            <select name="new_status" id="new_status_tm" class="mlr-select" required>
                                <option value="اعطا شده">اعطا شده (تایید نهایی)</option>
                                <option value="تکمیل مدارک">بازگشت به تکمیل مدارک (نقص مدارک نهایی)</option>
                            </select>
                        </div>
                        <div class="mlr-form-group">
                            <label for="comment_text_tm">افزودن یادداشت (اختیاری):</label>
                            <textarea name="comment_text" id="comment_text_tm" rows="4" class="mlr-textarea" placeholder="در صورت نیاز، توضیحات خود را برای کاربر یا مدیر بنویسید..."></textarea>
                        </div>
                        <div class="mlr-action-message"></div> <?php // Feedback div ?>
                        <button type="submit" class="mlr-btn">ثبت بررسی</button>
                    </form>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <?php // --- END: Bank Expert Action Forms --- ?>


        <?php // --- START: Main Details Grid --- ?>
        <div class="mlr-modal-grid">
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle">اطلاعات متقاضی</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام متقاضی:</strong></td><td><?php echo esc_html($request->full_name); ?></td></tr>
                    <tr><td><strong>کدملی:</strong></td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td><strong>شماره موبایل:</strong></td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td><strong>تلفن ثابت:</strong></td><td><?php echo esc_html($request->phone_number ?: '---'); ?></td></tr>
                    <tr><td><strong>تاریخ تولد:</strong></td><td><?php echo mlr_gregorian_to_jalali($request->birth_date, 'Y/m/d'); ?></td></tr>
                    <tr><td><strong>شغل:</strong></td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td><strong>آدرس محل سکونت:</strong></td><td><?php echo nl2br(esc_html($request->residential_address ?: '---')); ?></td></tr>
                    <tr><td><strong>کد پستی:</strong></td><td><?php echo esc_html($request->postal_code ?: '---'); ?></td></tr>
                    <tr><td><strong>آدرس محل فعالیت:</strong></td><td><?php echo nl2br(esc_html($request->work_address ?: '---')); ?></td></tr>
                </table>
            </div>
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle">اطلاعات تسهیلات</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام طرح:</strong></td><td><?php echo esc_html($request->plan_name ?: '---'); ?></td></tr>
                    <tr><td><strong>مبلغ تسهیلات:</strong></td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td><strong>مبلغ پیش پرداخت:</strong></td><td><?php echo number_format($request->prepayment); ?> ریال</td></tr>
                    <tr><td><strong>تعداد اقساط:</strong></td><td><?php echo esc_html($request->installment_count); ?> ماه</td></tr>
                    <tr><td><strong>فاصله اقساط:</strong></td><td><?php echo esc_html($request->installment_interval); ?> ماه</td></tr>
                    <tr><td><strong>مبلغ هر قسط:</strong></td><td><?php echo number_format($request->installment_amount); ?> ریال</td></tr>
                    <tr><td><strong>مبلغ کل بازپرداخت:</strong></td><td><?php echo number_format($request->total_payment); ?> ریال</td></tr>
                    <tr><td><strong>مبلغ شارژ کیف پول:</strong></td><td><?php echo number_format($request->wallet_charge); ?> ریال</td></tr>
                    <tr><td><strong>وضعیت فعلی:</strong></td><td><span class="mlr-status-badge" data-status="<?php echo esc_attr($request->status); ?>"><?php echo esc_html($request->status); ?></span></td></tr>
                </table>
            </div>
        </div>
        <?php // --- END: Main Details Grid --- ?>
        
        <?php // --- START: Order Items Section --- ?>
        <?php if (!empty($order_items) && is_array($order_items)): ?>
        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle">محصولات درخواستی</h4>
            <table class="mlr-details-table mlr-product-details-table">
                <thead>
                    <tr>
                        <th>نام محصول</th>
                        <th>شناسه</th>
                        <th>قیمت واحد (ریال)</th>
                        <th>تعداد</th>
                        <th>قیمت کل (ریال)</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $total_order_price = 0;
                foreach($order_items as $item): 
                    $item_price = $item['price'] ?? 0;
                    $item_qty = $item['qty'] ?? 1;
                    $item_total = (float)$item_price * (int)$item_qty;
                    $total_order_price += $item_total;
                ?>
                    <tr>
                        <td><?php echo esc_html($item['name'] ?? '---'); ?></td>
                        <td><?php echo esc_html($item['id'] ?? '---'); ?></td>
                        <td><?php echo number_format($item_price); ?></td>
                        <td><?php echo number_format($item_qty); ?></td>
                        <td><?php echo number_format($item_total); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4"><strong>جمع کل</strong></td>
                        <td><strong><?php echo number_format($total_order_price); ?></strong></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php endif; ?>
        <?php // --- END: Order Items Section --- ?>

        <?php // --- START: Uploaded Documents Section --- ?>
        <div class="mlr-modal-card">
            <h4 class="mlr-modal-subtitle">مدارک بارگذاری شده</h4>
            <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
                <ul class="mlr-file-list">
                    <?php 
                    $doc_labels = mlr_get_all_document_options(); // Get all defined labels
                    ?>
                    <?php foreach($uploaded_documents as $doc_key => $doc_value): ?>
                        <li>
                            <strong><?php echo esc_html($doc_labels[$doc_key] ?? ucfirst(str_replace('_', ' ', $doc_key))); ?>:</strong>
                            <?php if (is_array($doc_value)): // Handle multiple files for one key ?>
                                <ul>
                                    <?php foreach ($doc_value as $index => $url): ?>
                                        <li><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">مشاهده فایل <?php echo $index + 1; ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php elseif (is_string($doc_value) && !empty($doc_value)): // Handle single file ?>
                                <a href="<?php echo esc_url($doc_value); ?>" target="_blank" rel="noopener noreferrer">مشاهده فایل</a>
                            <?php else: ?>
                                <span><em>فایلی بارگذاری نشده است.</em></span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p style="text-align:center; padding: 10px 0;">هیچ مدرکی برای این درخواست بارگذاری نشده است.</p>
            <?php endif; ?>
        </div>
        <?php // --- END: Uploaded Documents Section --- ?>
        
    </div> <?php // End mlr-modal-content-inner ?>
    <?php
    $html_output = ob_get_clean(); // Get buffered HTML
    
    // 8. Send JSON Response
    wp_send_json_success(['html' => $html_output]);
}