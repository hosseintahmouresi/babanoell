<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_get_request_details', 'mlr_get_request_details_callback');

function mlr_get_request_details_callback() {
    check_ajax_referer('mlr_ajax_nonce_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'شما دسترسی لازم برای این عملیات را ندارید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $plans_table = $wpdb->prefix . 'installment_plans';
    
    $request = $wpdb->get_row($wpdb->prepare("
        SELECT r.*, p.name AS plan_name 
        FROM {$table_name} r 
        LEFT JOIN {$plans_table} p ON r.installment_plan_id = p.id 
        WHERE r.id = %d
    ", $request_id));

    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد.']);
        return;
    }
    
    $occupations = [ 'official_employee' => 'کارمند رسمی', 'contract_employee' => 'کارمند قراردادی', 'worker' => 'کارگر', 'freelancer' => 'آزاد', 'retired' => 'بازنشسته', 'pensioner' => 'مستمری بگیر', 'employer' => 'کارفرما', 'other' => 'سایر' ];
    $occupation_display = isset($occupations[$request->occupation]) ? $occupations[$request->occupation] : esc_html($request->occupation);
    $all_doc_labels = mlr_get_all_document_options();
    $uploaded_documents = maybe_unserialize($request->required_documents);
    $comments = !empty($request->comments) ? json_decode($request->comments, true) : [];

    ob_start();
    ?>
    <div class="mlr-modal-header">
        <h3 class="mlr-modal-title">جزئیات درخواست (شناسه: <?php echo esc_html($request->id); ?>)</h3>
    </div>
    <div class="mlr-modal-body">

        <div class="mlr-modal-card mlr-modal-comments-section">
            <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-format-chat"></span>یادداشت‌های کارشناسان</h4>
            <div class="mlr-comments-history" id="mlr-comments-history-container">
                <?php if (!empty($comments) && is_array($comments)): ?>
                    <?php foreach ($comments as $comment): ?>
                        <div class="mlr-comment-bubble">
                            <div class="mlr-comment-header">
                                <strong class="mlr-comment-author"><?php echo esc_html($comment['display_name'] ?? 'کاربر'); ?></strong>
                                <span class="mlr-comment-date"><?php echo mlr_gregorian_to_jalali($comment['timestamp'] ?? '', 'Y/m/d H:i'); ?></span>
                            </div>
                            <div class="mlr-comment-body"><?php echo nl2br(esc_html($comment['text'] ?? '')); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p id="mlr-no-comments-yet" style="text-align: center; color: #777; padding: 20px 0;">هنوز یادداشتی ثبت نشده است.</p>
                <?php endif; ?>
            </div>
            <div class="mlr-add-comment-form">
                <textarea id="mlr_new_comment_text" rows="4" class="widefat" placeholder="یادداشت جدید خود را اینجا بنویسید..."></textarea>
                <button type="button" class="button button-primary" id="mlr-add-comment-btn" data-id="<?php echo esc_attr($request->id); ?>">افزودن یادداشت</button>
                <span class="spinner"></span>
            </div>
        </div>
        
        <div class="mlr-modal-grid">
            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-admin-users"></span>اطلاعات متقاضی</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام متقاضی:</strong></td><td><?php echo esc_html($request->full_name); ?></td></tr>
                    <tr><td><strong>کدملی:</strong></td><td><?php echo esc_html($request->national_code); ?></td></tr>
                    <tr><td><strong>شماره موبایل:</strong></td><td><?php echo esc_html($request->mobile_number); ?></td></tr>
                    <tr><td><strong>تلفن ثابت:</strong></td><td><?php echo esc_html($request->phone_number ?: '---'); ?></td></tr>
                    <tr><td><strong>تاریخ تولد:</strong></td><td><?php echo mlr_gregorian_to_jalali($request->birth_date); ?></td></tr>
                    <tr><td><strong>شغل:</strong></td><td><?php echo esc_html($occupation_display); ?></td></tr>
                    <tr><td><strong>آدرس:</strong></td><td><?php echo nl2br(esc_html($request->residential_address ?: '---')); ?></td></tr>
                    <tr><td><strong>کد پستی:</strong></td><td><?php echo esc_html($request->postal_code ?: '---'); ?></td></tr>
                    <tr><td><strong>آدرس محل فعالیت:</strong></td><td><?php echo nl2br(esc_html($request->work_address ?: '---')); ?></td></tr>
                </table>
            </div>

            <div class="mlr-modal-card">
                <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-money-alt"></span>اطلاعات تسهیلات</h4>
                <table class="mlr-details-table">
                    <tr><td><strong>نام طرح:</strong></td><td><?php echo esc_html($request->plan_name ?: '---'); ?></td></tr>
                    <tr><td><strong>وضعیت فعلی:</strong></td><td><span class="status-badge status-<?php echo sanitize_html_class(str_replace(' ', '-', $request->status)); ?>"><?php echo esc_html($request->status); ?></span></td></tr>
                    <tr><td><strong>مبلغ تسهیلات:</strong></td><td><?php echo number_format($request->loan_amount); ?> ریال</td></tr>
                    <tr><td><strong>پیش پرداخت:</strong></td><td><?php echo number_format($request->prepayment); ?> ریال</td></tr>
                    <tr><td><strong>تعداد اقساط:</strong></td><td><?php echo esc_html($request->installment_count); ?> ماه</td></tr>
                    <tr><td><strong>مبلغ هر قسط:</strong></td><td><?php echo number_format($request->installment_amount); ?> ریال</td></tr>
                    <tr><td><strong>کل بازپرداخت:</strong></td><td><?php echo number_format($request->total_payment); ?> ریال</td></tr>
                    <tr><td><strong>شارژ کیف پول:</strong></td><td><?php echo number_format($request->wallet_charge); ?> ریال</td></tr>
                    <tr><td><strong>نام محصول:</strong></td><td><?php echo nl2br(esc_html($request->product_name ?: '---')); ?></td></tr>
                </table>
            </div>
        </div>

        <?php if (!empty($uploaded_documents) && is_array($uploaded_documents)): ?>
        <div class="mlr-modal-card">
             <h4 class="mlr-modal-subtitle"><span class="dashicons dashicons-media-default"></span>مدارک بارگذاری شده</h4>
            <div class="mlr-file-grid">
                <?php foreach($uploaded_documents as $doc_key => $doc_value): ?>
                    <div class="mlr-file-item">
                        <strong><?php echo esc_html($all_doc_labels[$doc_key] ?? ucfirst(str_replace('_', ' ', $doc_key))); ?>:</strong>
                        <div class="mlr-file-links">
                        <?php if (is_array($doc_value)): ?>
                            <?php foreach ($doc_value as $index => $url): ?>
                                <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-download"></span> فایل <?php echo $index + 1; ?></a>
                            <?php endforeach; ?>
                        <?php elseif (is_string($doc_value) && !empty($doc_value)): ?>
                            <a href="<?php echo esc_url($doc_value); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-download"></span> مشاهده فایل</a>
                        <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
    <?php
    $html_output = ob_get_clean();

    wp_send_json_success(['html' => $html_output]);
}