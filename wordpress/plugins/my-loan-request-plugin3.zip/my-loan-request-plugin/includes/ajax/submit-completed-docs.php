<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_mlr_submit_completed_docs', 'mlr_submit_completed_docs_callback');

function mlr_submit_completed_docs_callback() {
    check_ajax_referer('mlr_frontend_nonce', 'nonce');
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'برای بارگذاری مدارک، لطفاً ابتدا وارد شوید.']);
        return;
    }

    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    if (!$request_id) {
        wp_send_json_error(['message' => 'شناسه درخواست نامعتبر است.']);
        return;
    }

    if (empty($_FILES['completed_check_files'])) {
        wp_send_json_error(['message' => 'هیچ فایلی برای چک تکمیل شده انتخاب نشده است.']);
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'loan_requests';
    $user_id = get_current_user_id();

    $request = $wpdb->get_row($wpdb->prepare("SELECT required_documents FROM $table_name WHERE id = %d AND user_id = %d AND status = 'تکمیل مدارک'", $request_id, $user_id));
    if (!$request) {
        wp_send_json_error(['message' => 'درخواست مورد نظر یافت نشد یا در حال حاضر در وضعیت مناسب برای این عملیات نیست.']);
        return;
    }

    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }
    
    $existing_documents = maybe_unserialize($request->required_documents) ?: [];
    $errors = [];
    $allowed_mimes = ['jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf'];

    if (!empty($_FILES['completed_check_files']['name'][0])) {
        $check_files = $_FILES['completed_check_files'];
        $rearranged_check_files = [];
        foreach ($check_files['name'] as $key => $value) {
            if ($check_files['name'][$key]) {
                $rearranged_check_files[] = ['name' => $check_files['name'][$key], 'type' => $check_files['type'][$key], 'tmp_name' => $check_files['tmp_name'][$key], 'error' => $check_files['error'][$key], 'size' => $check_files['size'][$key]];
            }
        }
        $check_urls = [];
        foreach ($rearranged_check_files as $file) {
            $movefile = wp_handle_upload($file, array('test_form' => false));
            if ($movefile && !isset($movefile['error'])) {
                $check_urls[] = $movefile['url'];
            } else {
                $errors[] = 'چک: ' . ($movefile['error'] ?? 'خطای نامشخص');
            }
        }
        if (!empty($check_urls)) {
            $existing_documents['completed_check_files'] = $check_urls;
        }
    }
    
    if (!empty($_FILES['signed_contract_files']['name'][0])) {
        $contract_files = $_FILES['signed_contract_files'];
        $rearranged_contract_files = [];
        foreach ($contract_files['name'] as $key => $value) {
            if ($contract_files['name'][$key]) {
                $rearranged_contract_files[] = ['name' => $contract_files['name'][$key], 'type' => $contract_files['type'][$key], 'tmp_name' => $contract_files['tmp_name'][$key], 'error' => $contract_files['error'][$key], 'size' => $contract_files['size'][$key]];
            }
        }
        $contract_urls = [];
        foreach ($rearranged_contract_files as $file) {
            $movefile = wp_handle_upload($file, ['test_form' => false, 'mimes' => $allowed_mimes]);
            if ($movefile && !isset($movefile['error'])) {
                $contract_urls[] = $movefile['url'];
            } else {
                $errors[] = 'قرارداد امضا شده: ' . ($movefile['error'] ?? 'خطای نامشخص');
            }
        }
        if (!empty($contract_urls)) {
            $existing_documents['signed_contract_files'] = $contract_urls;
        }
    }

    if (!empty($_FILES['signed_invoice_files']['name'][0])) {
        $invoice_files = $_FILES['signed_invoice_files'];
        $rearranged_invoice_files = [];
        foreach ($invoice_files['name'] as $key => $value) {
            if ($invoice_files['name'][$key]) {
                $rearranged_invoice_files[] = ['name' => $invoice_files['name'][$key], 'type' => $invoice_files['type'][$key], 'tmp_name' => $invoice_files['tmp_name'][$key], 'error' => $invoice_files['error'][$key], 'size' => $invoice_files['size'][$key]];
            }
        }
        $invoice_urls = [];
        foreach ($rearranged_invoice_files as $file) {
            $movefile = wp_handle_upload($file, ['test_form' => false, 'mimes' => $allowed_mimes]);
            if ($movefile && !isset($movefile['error'])) {
                $invoice_urls[] = $movefile['url'];
            } else {
                $errors[] = 'فاکتور امضا شده: ' . ($movefile['error'] ?? 'خطای نامشخص');
            }
        }
        if (!empty($invoice_urls)) {
            $existing_documents['signed_invoice_files'] = $invoice_urls;
        }
    }
    
    if (!empty($_FILES['other_completed_files']['name'][0])) {
        $other_files = $_FILES['other_completed_files'];
        $rearranged_other_files = [];
        foreach ($other_files['name'] as $key => $value) {
            if ($other_files['name'][$key]) {
                $rearranged_other_files[] = ['name' => $other_files['name'][$key], 'type' => $other_files['type'][$key], 'tmp_name' => $other_files['tmp_name'][$key], 'error' => $other_files['error'][$key], 'size' => $other_files['size'][$key]];
            }
        }
        $other_urls = [];
        foreach ($rearranged_other_files as $file) {
            $movefile = wp_handle_upload($file, ['test_form' => false, 'mimes' => $allowed_mimes]);
            if ($movefile && !isset($movefile['error'])) {
                $other_urls[] = $movefile['url'];
            } else {
                $errors[] = 'سایر مدارک: ' . ($movefile['error'] ?? 'خطای نامشخص');
            }
        }
        if (!empty($other_urls)) {
            $existing_documents['other_completed_files'] = $other_urls;
        }
    }

    if (!empty($errors)) {
        wp_send_json_error(['message' => 'خطا در آپلود فایل‌ها: ' . implode(', ', $errors)]);
        return;
    }

    $updated = $wpdb->update(
        $table_name,
        [
            'required_documents' => serialize($existing_documents),
            'status'             => 'تأیید مدارک',
            'last_edited_at'     => current_time('mysql')
        ],
        ['id' => $request_id]
    );

    if ($updated === false) {
        wp_send_json_error(['message' => 'خطایی در به‌روزرسانی درخواست رخ داد.']);
        return;
    }

    mlr_send_sms_on_loan_status_change($request_id, 'تأیید مدارک');

    wp_send_json_success(['message' => 'مدارک شما با موفقیت ارسال شد و درخواست به مرحله تأیید نهایی رفت.']);
}