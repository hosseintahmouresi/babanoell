<?php
if (!defined('ABSPATH')) {
    exit;
}

function mlr_render_user_requests_table($title, $allowed_statuses = []) {
    if (!is_user_logged_in()) {
        return '<p>برای مشاهده این بخش، لطفاً ابتدا وارد شوید.</p>';
    }

    wp_enqueue_style('dashicons');
    
    $version = '8.2.0';
    wp_enqueue_script('mlr-user-requests-js', MLR_PLUGIN_URL . 'assets/js/mlr-user-requests.js', ['jquery', 'mlr-jalali-datepicker'], $version, true);
    wp_localize_script('mlr-user-requests-js', 'mlr_ajax_obj', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'filter_nonce'    => wp_create_nonce('mlr_user_requests_nonce'),
        'details_nonce'   => wp_create_nonce('mlr_frontend_nonce'),
        'cycle_nonce'     => wp_create_nonce('mlr_user_cycle_nonce'),
        'allowed_statuses' => $allowed_statuses
    ]);
    
    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], $version);

    $unique_id = uniqid('mlr-table-');
    
    $ordered_statuses = [
        'در حال بررسی', 'نقص مدارک', 'رد شده', 'تأیید کارشناس', 
        'تکمیل مدارک', 'تأیید مدارک', 'اعطا شده',
    ];

    ob_start();
    ?>
    <div class="mlr-user-requests <?php if ($title === 'سیکل‌های تسویه حساب') echo 'mlr-settlement-cycles'; ?>" id="<?php echo esc_attr($unique_id); ?>">
        
        <?php if(!empty($title)): ?>
            <h2><?php echo esc_html($title); ?></h2>
        <?php endif; ?>

        <div class="mlr-filter-form">
            <input type="text" id="mlr-search" placeholder="کدملی، متقاضی، شماره موبایل، شناسه">
            <select id="mlr-status">
                <option value="">وضعیت درخواست</option>
                <?php foreach ($ordered_statuses as $status): ?>
                    <option value="<?php echo esc_attr($status); ?>"><?php echo esc_html($status); ?></option>
                <?php endforeach; ?>
            </select>
            <select id="mlr-settlement-status">
                <option value="">وضعیت تسویه</option>
                <option value="منتظر تعیین تاریخ">منتظر تعیین تاریخ</option>
                <option value="در انتظار تسویه">در انتظار تسویه</option>
                <option value="تسویه شده">تسویه شده</option>
            </select>
            <input type="text" class="jalali-datepicker" id="mlr-date-from" placeholder="از تاریخ..." autocomplete="off" readonly>
            <input type="text" class="jalali-datepicker" id="mlr-date-to" placeholder="تا تاریخ..." autocomplete="off" readonly>
            <button type="button" id="mlr-filter-btn" class="button">فیلتر</button>
        </div>

        <div class="mlr-table-responsive-wrapper">
            <table class="mlr-requests-table">
                <thead>
                    <tr>
                        <th>شناسه</th> <th>متقاضی</th> <th>شماره موبایل</th> <th>کد ملی</th>
                        <th>مبلغ (ریال)</th> <th>طرح</th> <th>وضعیت</th> <th>تسویه</th>
                        <th>تاریخ ثبت</th> <th>عملیات</th>
                    </tr>
                </thead>
                <tbody id="mlr-requests-table-body">
                    <tr><td colspan="10" style="text-align: center; padding: 20px;">در حال بارگذاری درخواست‌ها...</td></tr>
                </tbody>
            </table>
        </div>
        
        <div class="mlr-modal-overlay" style="display:none;"></div>
        <div class="mlr-modal" style="display:none;">
            <button class="mlr-modal-close">&times;</button>
            <div class="mlr-modal-content"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function mlr_jalali_to_gregorian($jalali_date_str) {
    if (empty($jalali_date_str)) return null;
    if (preg_match('/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/', $jalali_date_str, $matches)) {
        list($j_y, $j_m, $j_d) = array_map('intval', [$matches[1], $matches[2], $matches[3]]);
    } else { return null; }
    
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $jy = $j_y - 979; $jm = $j_m - 1; $jd = $j_d - 1;
    $j_day_no = 365 * $jy + floor($jy / 33) * 8 + floor((($jy % 33) + 3) / 4);
    for ($i = 0; $i < $jm; ++$i) { $j_day_no += $j_days_in_month[$i]; }
    $j_day_no += $jd; $g_day_no = $j_day_no + 79;
    $gy = 1600 + 400 * floor($g_day_no / 146097);
    $g_day_no = $g_day_no % 146097; $leap = true;
    if ($g_day_no >= 36525) { $g_day_no--; $gy += 100 * floor($g_day_no / 36524); $g_day_no = $g_day_no % 36524; if ($g_day_no >= 365) { $g_day_no++; } else { $leap = false; } }
    $gy += 4 * floor($g_day_no / 1461); $g_day_no %= 1461;
    if ($g_day_no >= 366) { $leap = false; $g_day_no--; $gy += floor($g_day_no / 365); $g_day_no = $g_day_no % 365; }
    for ($i = 0; $g_day_no >= $g_days_in_month[$i] + ($i == 1 && $leap); $i++) { $g_day_no -= $g_days_in_month[$i] + ($i == 1 && $leap); }
    $gm = $i + 1; $gd = $g_day_no + 1;
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

function mlr_gregorian_to_jalali($gregorian_date_str, $format = 'Y/m/d') {
    if (empty($gregorian_date_str) || $gregorian_date_str === '0000-00-00 00:00:00' || is_null($gregorian_date_str)) return '---';
    try {
        $g_date = new DateTime($gregorian_date_str, new DateTimeZone('Asia/Tehran'));
        $g_y = (int)$g_date->format('Y'); $g_m = (int)$g_date->format('m'); $g_d = (int)$g_date->format('d');
    } catch (Exception $e) { return 'تاریخ نامعتبر'; }
    $g_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    $j_days_in_month = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    $gy = $g_y - 1600; $gm = $g_m - 1; $gd = $g_d - 1;
    $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);
    for ($i = 0; $i < $gm; ++$i) { $g_day_no += $g_days_in_month[$i]; }
    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0))) { $g_day_no++; }
    $g_day_no += $gd; $j_day_no = $g_day_no - 79; $j_np = floor($j_day_no / 12053);
    $j_day_no = $j_day_no % 12053; $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
    $j_day_no %= 1461; if ($j_day_no >= 366) { $jy += floor(($j_day_no - 1) / 365); $j_day_no = ($j_day_no - 1) % 365; }
    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i) { $j_day_no -= $j_days_in_month[$i]; }
    $jm = $i + 1; $jd = $j_day_no + 1;
    $final_format = str_replace(['Y', 'm', 'd', 'H', 'i'], [sprintf('%04d', $jy), sprintf('%02d', $jm), sprintf('%02d', $jd), $g_date->format('H'), $g_date->format('i')], $format);
    return $final_format;
}

function mlr_get_all_document_options() {
    return [
        'national_card_front' => 'کارت ملی (رو)', 'national_card_back' => 'کارت ملی (پشت)', 'birth_certificate' => 'شناسنامه (تمام صفحات)',
        'payslip' => 'فیش حقوقی', 'employment_certificate' => 'گواهی اشتغال به کار', 'business_license' => 'جواز کسب',
        'sana_certificate' => 'گواهی ثبت ثنا', 'blank_check_image' => 'تصویر چک صیادی', 'residence_document' => 'سند یا اجاره‌نامه محل سکونت',
        'workplace_document' => 'سند یا اجاره‌نامه محل کار', 'account_statement' => 'گردش حساب ۳ ماهه', 'activity_license' => 'مجوز فعالیت (سایر)',
        'additional_documents' => 'مدارک تکمیلی', 'completed_check_files' => 'چک‌های تکمیل شده', 'signed_contract_files' => 'قرارداد امضا شده',
        'signed_invoice_files' => 'فاکتور امضا شده', 'other_completed_files' => 'سایر مدارک نهایی'
    ];
}

function mlr_get_all_valid_statuses() {
    return ['در حال بررسی', 'نقص مدارک', 'رد شده', 'تأیید کارشناس', 'تکمیل مدارک', 'تأیید مدارک', 'اعطا شده'];
}

function mlr_get_calculation_labels() {
    return [
        'loanAmount' => ['label' => 'مبلغ تسهیلات', 'unit' => 'ریال'], 'installmentCount' => ['label' => 'تعداد اقساط', 'unit' => 'قسط'],
        'prepayment' => ['label' => 'پیش پرداخت', 'unit' => 'ریال'], 'totalPayment' => ['label' => 'مبلغ پرداخت نهایی', 'unit' => 'ریال'],
        'installmentAmount' => ['label' => 'مبلغ هر قسط', 'unit' => 'ریال'], 'profit' => ['label' => 'سود تسهیلات', 'unit' => 'ریال'],
        'operationCost' => ['label' => 'مبلغ هزینه عملیات', 'unit' => 'ریال'], 'walletCharge' => ['label' => 'مبلغ شارژ کیف پول', 'unit' => 'ریال'],
        'acceptorPayment' => ['label' => 'مبلغ واریزی برای پذیرنده', 'unit' => 'ریال'], 'guaranteeCheckPrincipal' => ['label' => 'مبلغ چک ضمانت (اصل)', 'unit' => 'ریال'],
        'guaranteeCheckTotal' => ['label' => 'مبلغ چک ضمانت (اصل و فرع)', 'unit' => 'ریال'], 'numberOfInstallments' => ['label' => 'تعداد قسط/چک', 'unit' => 'عدد'],
        'operationCostPercent' => ['label' => 'درصد هزینه عملیات', 'unit' => 'درصد'], 'operationCostWithVat' => ['label' => 'جمع هزینه عملیات + ارزش افزوده', 'unit' => 'ریال'],
        'netLeasingPayment' => ['label' => 'خالص واریزی لیزینگ', 'unit' => 'ریال'], 'acceptorCommission' => ['label' => 'کمیسیون پذیرنده', 'unit' => 'ریال'],
        'acceptorCommissionWithVat' => ['label' => 'کمیسیون پذیرنده + ارزش افزوده', 'unit' => 'ریال'],
    ];
}