<?php
function mlr_install() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Loan requests table with a unified 'comments' field
    $table_requests = $wpdb->prefix . 'loan_requests';
    $sql_requests = "CREATE TABLE $table_requests (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        full_name varchar(255) NOT NULL,
        national_code varchar(10) NOT NULL,
        mobile_number varchar(11) NOT NULL,
        phone_number varchar(20) DEFAULT '' NOT NULL,
        birth_date date DEFAULT NULL,
        occupation varchar(100) DEFAULT '' NOT NULL,
        residential_address text,
        postal_code varchar(10) DEFAULT '' NOT NULL,
        work_address text,
        product_name text,
        installment_plan_id mediumint(9) NOT NULL,
        loan_amount bigint NOT NULL,
        installment_interval int NOT NULL,
        installment_count int NOT NULL,
        bank_validation_file varchar(255) DEFAULT NULL,
        required_documents text DEFAULT NULL,
        order_items text DEFAULT NULL,
        order_total bigint DEFAULT NULL,
        description text DEFAULT NULL,
        signature_image varchar(255) DEFAULT NULL,
        contract_file varchar(255) DEFAULT NULL,
        check_images text DEFAULT NULL,
        status varchar(50) NOT NULL DEFAULT 'در حال بررسی',
        settlement_status varchar(20) DEFAULT NULL,
        comments text DEFAULT NULL,
        created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        last_edited_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    // Installment plans table (no changes needed here for this request)
    $table_installment_plans = $wpdb->prefix . 'installment_plans';
    $sql_installment_plans = "CREATE TABLE $table_installment_plans (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        description text,
        min_amount bigint NOT NULL,
        max_amount bigint NOT NULL,
        min_interval int NOT NULL,
        max_interval int NOT NULL,
        min_count int NOT NULL,
        max_count int NOT NULL,
        requires_bank_validation tinyint(1) DEFAULT 0,
        requires_national_card_front tinyint(1) DEFAULT 0,
        requires_national_card_back tinyint(1) DEFAULT 0,
        required_documents text,
        issue_check tinyint(1) DEFAULT 0,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_requests);
    dbDelta($sql_installment_plans);
}
?>