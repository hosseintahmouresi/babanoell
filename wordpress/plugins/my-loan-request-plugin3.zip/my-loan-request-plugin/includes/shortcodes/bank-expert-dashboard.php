<?php
if (!defined('ABSPATH')) {
    exit;
}

add_shortcode('mlr_bank_expert_dashboard', 'mlr_bank_expert_dashboard_shortcode');

function mlr_bank_expert_dashboard_shortcode() {
    // Check if user is logged in and has the 'bank' role
    if (!is_user_logged_in()) {
        return '<p>برای دسترسی به این بخش، لطفاً ابتدا وارد شوید.</p>';
    }

    $current_user = wp_get_current_user();
    if (!in_array('bank', (array) $current_user->roles)) {
        return '<p>شما دسترسی لازم برای مشاهده این صفحه را ندارید.</p>';
    }

    // Enqueue necessary scripts and styles
    wp_enqueue_style('dashicons');
    wp_enqueue_style('persian-datepicker-style', 'https://unpkg.com/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css');
    wp_enqueue_script('persian-date', 'https://unpkg.com/persian-date@1.1.0/dist/persian-date.min.js', [], '1.1.0', true);
    wp_enqueue_script('persian-datepicker-script', 'https://unpkg.com/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js', ['jquery', 'persian-date'], '1.2.0', true);
    
    // Enqueue the main frontend CSS
    wp_enqueue_style('mlr-frontend-css', MLR_PLUGIN_URL . 'assets/css/frontend.css', [], '6.6.0');
    // Enqueue the specific CSS for this dashboard
    wp_enqueue_style('mlr-bank-expert-dashboard-css', MLR_PLUGIN_URL . 'assets/css/bank-expert-dashboard.css', [], '1.0.0');

    // Enqueue the specific JS for this dashboard
    wp_enqueue_script('mlr-bank-expert-dashboard-js', MLR_PLUGIN_URL . 'assets/js/bank-expert-dashboard.js', ['jquery'], '1.0.0', true);
    wp_localize_script('mlr-bank-expert-dashboard-js', 'mlr_bank_ajax_obj', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('mlr_frontend_nonce'), // Re-use the same nonce for security
    ]);
    
    $unique_id = uniqid('mlr-bank-dashboard-');

    ob_start();
    ?>
    <div class="mlr-user-requests" id="<?php echo esc_attr($unique_id); ?>">
        
        <h2>درخواست‌های ارجاع شده به شما</h2>
        
        <div class="mlr-filter-form">
            <input type="text" id="mlr-search" placeholder="کدملی، متقاضی، شماره موبایل، شناسه">
            <input type="text" class="jalali-datepicker" id="mlr-date-from" placeholder="از تاریخ..." autocomplete="off">
            <input type="text" class="jalali-datepicker" id="mlr-date-to" placeholder="تا تاریخ..." autocomplete="off">
            <button type="button" id="mlr-filter-btn" class="button">فیلتر</button>
        </div>

        <div class="mlr-table-responsive-wrapper">
            <table class="mlr-requests-table">
                <thead>
                    <tr>
                        <th>شناسه</th>
                        <th>متقاضی</th>
                        <th>شماره موبایل</th>
                        <th>کد ملی</th>
                        <th>مبلغ (ریال)</th>
                        <th>طرح</th>
                        <th>وضعیت</th>
                        <th>تاریخ ارجاع</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody id="mlr-requests-table-body">
                    <tr><td colspan="9" style="text-align: center; padding: 20px;">در حال بارگذاری درخواست‌ها...</td></tr>
                </tbody>
            </table>
        </div>
        
        <div class="mlr-modal-overlay" style="display:none;"></div>
        <div class="mlr-modal" style="display:none;">
            <button class="mlr-modal-close">&times;</button>
            <div class="mlr-modal-content"></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}