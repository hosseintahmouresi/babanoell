<?php
if (!defined('ABSPATH')) {
    exit;
}

function mlr_granted_requests_page() {
    if (!current_user_can('manage_options')) {
        wp_die('شما دسترسی لازم برای مشاهده این صفحه را ندارید.');
    }

    global $wpdb;
    $table_requests = $wpdb->prefix . 'loan_requests';
    $users_table = $wpdb->prefix . 'users';
    $success_message = '';
    $error_message = '';

    // --- Process form to assign settlement date ---
    if (isset($_POST['mlr_assign_date']) && check_admin_referer('mlr_assign_date_action')) {
        $request_ids = isset($_POST['request_ids']) ? array_map('intval', $_POST['request_ids']) : [];
        $settlement_date_jalali = isset($_POST['settlement_date']) ? sanitize_text_field($_POST['settlement_date']) : '';

        if (empty($settlement_date_jalali)) {
            $error_message = 'خطا: انتخاب تاریخ تسویه الزامی است.';
        } elseif (!empty($request_ids)) {
            $settlement_date_gregorian = mlr_jalali_to_gregorian($settlement_date_jalali);
            // Add current time if conversion is successful, otherwise handle error
            if($settlement_date_gregorian) {
                $settlement_date_gregorian .= ' ' . date('H:i:s'); // Use current time
                $ids_placeholder = implode(',', array_fill(0, count($request_ids), '%d'));

                $updated_count = $wpdb->query($wpdb->prepare(
                    "UPDATE $table_requests
                     SET settlement_status = 'در انتظار تسویه', settlement_date = %s
                     WHERE id IN ($ids_placeholder) AND status = 'اعطا شده' AND (settlement_status = 'منتظر تعیین تاریخ' OR settlement_status IS NULL OR settlement_status = '')", // More robust check
                    array_merge([$settlement_date_gregorian], $request_ids)
                ));

                if ($updated_count !== false) {
                     $success_message = $updated_count . ' درخواست با موفقیت برای تسویه در تاریخ ' . esc_html($settlement_date_jalali) . ' تعیین تکلیف شدند و به مرحله ایجاد سیکل منتقل شدند.';
                } else {
                     $error_message = 'خطا در به‌روزرسانی دیتابیس: ' . $wpdb->last_error;
                     mlr_log("Error updating settlement date: " . $wpdb->last_error); // Log error
                }
            } else {
                $error_message = 'خطا: فرمت تاریخ تسویه نامعتبر است.';
            }
        } else {
             $error_message = 'هیچ درخواستی برای تعیین تاریخ انتخاب نشده است.';
        }
    }

    // Query for requests WAITING for a date
    $waiting_requests = $wpdb->get_results("
        SELECT r.id, r.full_name, r.mobile_number, r.wallet_charge, r.final_settlement_amount, r.product_name, r.last_edited_at, r.settlement_status, u.display_name
        FROM $table_requests r
        LEFT JOIN $users_table u ON r.user_id = u.ID
        WHERE r.status = 'اعطا شده' AND (r.settlement_status = 'منتظر تعیین تاریخ' OR r.settlement_status IS NULL OR r.settlement_status = '')
        ORDER BY u.display_name, r.last_edited_at DESC
    ");

    wp_enqueue_script('jquery'); // Ensure jQuery is loaded

    ?>
    <div class="wrap mlr-admin-wrap mlr-settlement-page">
        <div class="mlr-page-header">
             <h1><span class="dashicons dashicons-calendar-alt"></span> مرحله ۱: تعیین تاریخ تسویه (درخواست‌های اعطا شده)</h1>
        </div>
        <p class="mlr-page-description">در این مرحله، برای درخواست‌های اعطا شده که آماده تسویه هستند، تاریخ تسویه را مشخص کنید تا به مرحله بعد (ایجاد سیکل) منتقل شوند.</p>

        <?php if ($success_message) : ?><div id="message" class="notice notice-success is-dismissible mlr-notice"><p><?php echo wp_kses_post($success_message); ?></p></div><?php endif; ?>
        <?php if ($error_message) : ?><div id="message" class="notice notice-error is-dismissible mlr-notice"><p><?php echo wp_kses_post($error_message); ?></p></div><?php endif; ?>

        <?php if (empty($waiting_requests)): ?>
            <div class="mlr-card">
                <div class="mlr-card-content" style="text-align: center; padding: 30px;">
                    <span class="dashicons dashicons-info-outline" style="font-size: 30px; color: #777; margin-bottom: 10px; display: block;"></span>
                    <p>در حال حاضر هیچ درخواست جدیدی منتظر تعیین تاریخ تسویه نیست.</p>
                    <a href="<?php echo admin_url('admin.php?page=mlr-unsettled-requests'); ?>" class="button button-primary">مشاهده درخواست‌های آماده ایجاد سیکل</a>
                </div>
            </div>
        <?php else: ?>
            <form method="post" id="mlr-assign-date-form">
                <?php wp_nonce_field('mlr_assign_date_action'); ?>
                <div class="mlr-card mlr-bulk-action-card">
                    <div class="mlr-card-content">
                        <label for="settlement_date" class="mlr-label">تاریخ تسویه برای موارد انتخابی:</label>
                        <div class="mlr-bulk-action-controls">
                            <input type="text" name="settlement_date" id="settlement_date" class="jalali-datepicker mlr-input" placeholder="تاریخ را انتخاب کنید *" required autocomplete="off" readonly >
                            <button type="submit" name="mlr_assign_date" class="button button-primary"><span class="dashicons dashicons-arrow-left-alt"></span> ثبت تاریخ و انتقال به مرحله بعد</button>
                        </div>
                    </div>
                </div>

                <div class="mlr-card mlr-table-card">
                     <h2 class="mlr-card-title"><span class="dashicons dashicons-list-view"></span> درخواست‌های منتظر تعیین تاریخ</h2>
                     <div class="mlr-card-content no-padding">
                        <table class="wp-list-table widefat fixed striped mlr-compact-table">
                            <thead>
                                <tr>
                                    <td id="cb1" class="manage-column column-cb check-column"><input type="checkbox" id="mlr-select-all-waiting"></td>
                                    <th class="column-id">شناسه</th>
                                    <th>پذیرنده</th>
                                    <th>متقاضی</th>
                                    <th>موبایل</th>
                                    <th class="column-amount">مبلغ تسویه (ریال)</th>
                                    <th class="column-date">تاریخ اعطا</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($waiting_requests as $request): ?>
                                <tr class="mlr-request-row" data-id="<?php echo esc_attr($request->id); ?>">
                                    <th scope="row" class="check-column"><input type="checkbox" name="request_ids[]" value="<?php echo esc_attr($request->id); ?>" class="mlr-request-checkbox-waiting"></th>
                                    <td class="column-id"><?php echo esc_html($request->id); ?></td>
                                    <td><?php echo esc_html($request->display_name ?: 'کاربر حذف شده'); ?></td>
                                    <td><strong><?php echo esc_html($request->full_name); ?></strong></td>
                                    <td><?php echo esc_html($request->mobile_number); ?></td>
                                    <td class="column-amount"><?php echo number_format($request->final_settlement_amount); ?></td>
                                    <td class="column-date"><?php echo mlr_gregorian_to_jalali($request->last_edited_at, 'Y/m/d'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <?php // --- Styles (Keep as is) --- ?>
    <style>
        /* --- Settlement Pages Common Styles --- */
        .mlr-settlement-page .mlr-page-description { color: #50575e; margin-top: 5px; font-size: 14px; margin-bottom: 20px; padding: 0 5px; }
        .mlr-settlement-page .mlr-card { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; margin-bottom: 25px; box-shadow: 0 1px 1px rgba(0,0,0,.04); overflow: hidden; }
        .mlr-settlement-page .mlr-card-title { font-size: 16px; font-weight: 600; padding: 14px 20px; margin: 0; border-bottom: 1px solid #dcdcde; color: #1d2327; display: flex; align-items: center; gap: 8px; background-color: #f6f7f7; }
        .mlr-settlement-page .mlr-card-title .dashicons { color: #50575e; }
        .mlr-settlement-page .mlr-card-content { padding: 20px; }
        .mlr-settlement-page .mlr-card-content.no-padding { padding: 0; }
        .mlr-settlement-page .mlr-compact-table { margin-bottom: 0; }
        .mlr-settlement-page .mlr-compact-table th, .mlr-settlement-page .mlr-compact-table thead td { font-size: 12px; padding: 10px 12px; background: #f9f9f9; text-align: right; }
        .mlr-settlement-page .mlr-compact-table tbody td, .mlr-settlement-page .mlr-compact-table tbody th { padding: 10px 12px; font-size: 13px; vertical-align: middle; text-align: right; }
        .mlr-settlement-page .column-id { width: 8%; font-weight: 500; color: #646970; }
        .mlr-settlement-page .column-amount { width: 20%; font-weight: 500; }
        .mlr-settlement-page .column-date { width: 15%; font-size: 12px; color: #646970; }
        .mlr-settlement-page .mlr-notice { margin: 15px 5px !important; }

        /* --- Granted Requests Page (Step 1) Specific Styles --- */
        .mlr-settlement-page .mlr-bulk-action-card .mlr-card-content { display: flex; align-items: center; gap: 15px; flex-wrap: wrap; background-color: #f0f6fc; border-bottom: 1px solid #cce2ff; }
        .mlr-settlement-page .mlr-label { font-weight: 600; color: #1d2327; flex-shrink: 0; margin-left: 5px;}
        .mlr-settlement-page .mlr-bulk-action-controls { display: flex; align-items: center; gap: 10px; flex-grow: 1;}
        .mlr-settlement-page .mlr-input { padding: 8px 10px; border-radius: 4px; border: 1px solid #8c8f94; box-sizing: border-box; }
        /* Style for Jalali Datepicker Input */
        .mlr-settlement-page input.jalali-datepicker { /* Increased specificity */
            width: 180px;
            cursor: pointer;
            background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='%2350575E' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='4' width='18' height='18' rx='2' ry='2'%3E%3C/rect%3E%3Cline x1='16' y1='2' x2='16' y2='6'%3E%3C/line%3E%3Cline x1='8' y1='2' x2='8' y2='6'%3E%3C/line%3E%3Cline x1='3' y1='10' x2='21' y2='10'%3E%3C/line%3E%3C/svg%3E") no-repeat left 10px center;
            background-size: 16px;
        }
        .mlr-settlement-page .mlr-bulk-action-controls .button .dashicons { vertical-align: middle; margin-top: -2px; margin-left: 2px; font-size: 18px; }
        .mlr-settlement-page .mlr-compact-table tbody tr:hover { background-color: #f0f6fc !important; }
        .mlr-settlement-page .check-column { width: 3em !important; }
    </style>

    <?php // --- Remove inline JS for Datepicker --- ?>
    <script>
    jQuery(document).ready(function($) {
        // --- Checkbox Logic (Keep this) ---
        $('#mlr-select-all-waiting').on('click', function() {
            $('.mlr-request-checkbox-waiting').prop('checked', $(this).is(':checked'));
        });
         $('#mlr-assign-date-form').on('submit', function(e) {
             if (!$('#settlement_date').val()) {
                 alert('لطفاً تاریخ تسویه را انتخاب کنید.');
                 e.preventDefault();
             } else if ($('.mlr-request-checkbox-waiting:checked').length === 0) {
                  alert('لطفاً حداقل یک درخواست را برای تعیین تاریخ انتخاب کنید.');
                 e.preventDefault();
             }
         });
    });
    </script>
    <?php
}
?>